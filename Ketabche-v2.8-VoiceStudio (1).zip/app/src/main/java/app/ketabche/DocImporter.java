package app.ketabche;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import org.json.JSONArray;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

final class DocImporter {
    private static volatile boolean pdfBoxReady = false;
    private static final long MAX_DOC_BYTES = 45L * 1024L * 1024L;

    private DocImporter() {}

    static JSONObject importUri(Context ctx, Uri uri) throws Exception {
        ContentResolver cr = ctx.getContentResolver();
        String displayName = resolveName(cr, uri);
        byte[] data = readBytes(cr, uri);
        if (data.length == 0) {
            throw new Exception("empty_file");
        }

        String lower = displayName.toLowerCase(Locale.ROOT);
        boolean isPdf = lower.endsWith(".pdf") || startsWith(data, new byte[]{0x25, 0x50, 0x44, 0x46, 0x2D});
        boolean isZip = !isPdf && startsWith(data, new byte[]{0x50, 0x4B, 0x03, 0x04});
        boolean isEpub = lower.endsWith(".epub") || (isZip && hasZipEntry(data, "META-INF/container.xml"));
        boolean isDocx = !isEpub && (lower.endsWith(".docx") || isZip);

        String title = stripExtension(displayName);
        if (title.isEmpty()) {
            title = isPdf ? "کتاب PDF" : (isEpub ? "کتاب EPUB" : (isDocx ? "کتاب Word" : "کتاب واردشده"));
        }

        JSONObject res = new JSONObject();
        res.put("title", title);

        if (isPdf) {
            res.put("ext", "pdf");
            ArrayList<String> pages = extractPdfPages(ctx, data);
            if (pages.isEmpty()) {
                res.put("error", "no_text");
                return res;
            }
            JSONArray arr = new JSONArray();
            for (String p : pages) {
                arr.put(p);
            }
            res.put("pages", arr);
            return res;
        }

        if (isEpub) {
            res.put("ext", "epub");
            return extractEpub(data, title);
        }

        if (isDocx) {
            res.put("ext", "docx");
            String text = extractDocxText(data);
            if (text.trim().isEmpty()) {
                res.put("error", "no_text");
                return res;
            }
            JSONArray arr = new JSONArray();
            arr.put(text);
            res.put("pages", arr);
            return res;
        }

        res.put("ext", lower.endsWith(".md") ? "md" : "txt");
        String txt = new String(data, StandardCharsets.UTF_8);
        if (txt.startsWith("\uFEFF")) {
            txt = txt.substring(1);
        }
        if (txt.trim().isEmpty()) {
            res.put("error", "no_text");
            return res;
        }
        JSONArray arr = new JSONArray();
        arr.put(txt);
        res.put("pages", arr);
        return res;
    }

    private static boolean hasZipEntry(byte[] data, String targetName) {
        ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(data));
        try {
            ZipEntry ze;
            int guard = 0;
            while ((ze = zis.getNextEntry()) != null && guard++ < 500) {
                if (targetName.equalsIgnoreCase(ze.getName())) {
                    return true;
                }
                zis.closeEntry();
            }
        } catch (Exception ignored) {
        } finally {
            try {
                zis.close();
            } catch (Exception ignored) {
            }
        }
        return false;
    }

    private static JSONObject extractEpub(byte[] data, String fallbackTitle) throws Exception {
        HashMap<String, byte[]> files = new HashMap<>();
        ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(data));
        try {
            ZipEntry ze;
            while ((ze = zis.getNextEntry()) != null) {
                if (!ze.isDirectory()) {
                    String name = ze.getName();
                    if (name.endsWith(".xml") || name.endsWith(".opf") || name.endsWith(".xhtml")
                            || name.endsWith(".html") || name.endsWith(".htm")) {
                        files.put(name, readStream(zis));
                    }
                }
                zis.closeEntry();
            }
        } finally {
            try {
                zis.close();
            } catch (Exception ignored) {
            }
        }

        String opfPath = null;
        byte[] container = files.get("META-INF/container.xml");
        if (container != null) {
            opfPath = parseOpfPath(container);
        }
        if (opfPath == null) {
            for (String k : files.keySet()) {
                if (k.endsWith(".opf")) {
                    opfPath = k;
                    break;
                }
            }
        }

        String bookTitle = fallbackTitle;
        ArrayList<String> spineHrefs = new ArrayList<>();
        String opfDir = "";
        if (opfPath != null && files.containsKey(opfPath)) {
            int slash = opfPath.lastIndexOf('/');
            if (slash >= 0) {
                opfDir = opfPath.substring(0, slash + 1);
            }
            HashMap<String, String> manifest = new HashMap<>();
            ArrayList<String> spineIds = new ArrayList<>();
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            factory.setNamespaceAware(true);
            XmlPullParser p = factory.newPullParser();
            p.setInput(new ByteArrayInputStream(files.get(opfPath)), "UTF-8");
            boolean inTitle = false;
            int ev = p.getEventType();
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG) {
                    String n = p.getName();
                    if ("title".equals(n)) {
                        inTitle = true;
                    } else if ("item".equals(n)) {
                        String id = p.getAttributeValue(null, "id");
                        String href = p.getAttributeValue(null, "href");
                        if (id != null && href != null) {
                            manifest.put(id, href);
                        }
                    } else if ("itemref".equals(n)) {
                        String idref = p.getAttributeValue(null, "idref");
                        if (idref != null) {
                            spineIds.add(idref);
                        }
                    }
                } else if (ev == XmlPullParser.TEXT && inTitle) {
                    String t = p.getText();
                    if (t != null && !t.trim().isEmpty()) {
                        bookTitle = t.trim();
                    }
                } else if (ev == XmlPullParser.END_TAG && "title".equals(p.getName())) {
                    inTitle = false;
                }
                ev = p.next();
            }
            for (String idref : spineIds) {
                String href = manifest.get(idref);
                if (href != null) {
                    int hash = href.indexOf('#');
                    if (hash >= 0) {
                        href = href.substring(0, hash);
                    }
                    spineHrefs.add(opfDir + href);
                }
            }
        }

        if (spineHrefs.isEmpty()) {
            for (String k : files.keySet()) {
                if (k.endsWith(".xhtml") || k.endsWith(".html") || k.endsWith(".htm")) {
                    spineHrefs.add(k);
                }
            }
        }

        JSONArray pagesArr = new JSONArray();
        JSONArray chaptersArr = new JSONArray();
        for (String href : spineHrefs) {
            byte[] xb = files.get(href);
            if (xb == null) {
                continue;
            }
            String[] parsed = extractXhtmlChapter(xb);
            String chTitle = parsed[0];
            String chBody = normalizeText(parsed[1]);
            if (chBody.isEmpty()) {
                continue;
            }
            int pgIdx = pagesArr.length();
            pagesArr.put(chBody);
            if (!chTitle.isEmpty()) {
                JSONObject chObj = new JSONObject();
                chObj.put("t", chTitle.length() > 100 ? chTitle.substring(0, 100) : chTitle);
                chObj.put("p", pgIdx);
                chaptersArr.put(chObj);
            }
        }

        JSONObject res = new JSONObject();
        res.put("title", bookTitle);
        res.put("ext", "epub");
        if (pagesArr.length() == 0) {
            res.put("error", "no_text");
            return res;
        }
        res.put("pages", pagesArr);
        if (chaptersArr.length() > 0) {
            res.put("chapters", chaptersArr);
        }
        return res;
    }

    private static String parseOpfPath(byte[] containerXml) {
        try {
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            factory.setNamespaceAware(true);
            XmlPullParser p = factory.newPullParser();
            p.setInput(new ByteArrayInputStream(containerXml), "UTF-8");
            int ev = p.getEventType();
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG && "rootfile".equals(p.getName())) {
                    String fp = p.getAttributeValue(null, "full-path");
                    if (fp != null && !fp.trim().isEmpty()) {
                        return fp.trim();
                    }
                }
                ev = p.next();
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private static String[] extractXhtmlChapter(byte[] xhtmlBytes) {
        String raw = new String(xhtmlBytes, StandardCharsets.UTF_8);
        String heading = "";
        java.util.regex.Matcher hm = java.util.regex.Pattern
                .compile("(?is)<h[1-3][^>]*>(.*?)</h[1-3]>")
                .matcher(raw);
        if (hm.find()) {
            heading = stripHtmlTags(hm.group(1)).replaceAll("\\s+", " ").trim();
        }
        String body = raw.replaceAll("(?is)<script[^>]*>.*?</script>", " ")
                .replaceAll("(?is)<style[^>]*>.*?</style>", " ")
                .replaceAll("(?is)<head[^>]*>.*?</head>", " ")
                .replaceAll("(?is)<br\\s*/?>", "\n")
                .replaceAll("(?is)</(p|div|h[1-6]|li|tr|blockquote|section|article)>", "\n\n")
                .replaceAll("(?is)</(td|th)>", " | ");
        body = stripHtmlTags(body);
        return new String[]{heading, body};
    }

    private static String stripHtmlTags(String s) {
        if (s == null) return "";
        String t = s.replaceAll("<[^>]+>", "");
        t = t.replace("&nbsp;", " ")
             .replace("&amp;", "&")
             .replace("&lt;", "<")
             .replace("&gt;", ">")
             .replace("&quot;", "\"")
             .replace("&#39;", "'")
             .replace("&apos;", "'")
             .replace("&zwnj;", "\u200C");
        return t;
    }

    private static ArrayList<String> extractPdfPages(Context ctx, byte[] data) throws Exception {
        if (!pdfBoxReady) {
            synchronized (DocImporter.class) {
                if (!pdfBoxReady) {
                    PDFBoxResourceLoader.init(ctx.getApplicationContext());
                    pdfBoxReady = true;
                }
            }
        }
        ArrayList<String> pages = new ArrayList<>();
        PDDocument doc = null;
        try {
            doc = PDDocument.load(new ByteArrayInputStream(data));
            int total = doc.getNumberOfPages();
            PDFTextStripper stripper = new PDFTextStripper();
            stripper.setSortByPosition(true);
            for (int i = 1; i <= total; i++) {
                stripper.setStartPage(i);
                stripper.setEndPage(i);
                String raw = stripper.getText(doc);
                String clean = normalizeText(raw);
                if (!clean.isEmpty()) {
                    pages.add(clean);
                }
            }
        } finally {
            if (doc != null) {
                try {
                    doc.close();
                } catch (Exception ignored) {
                }
            }
        }
        return pages;
    }

    private static String extractDocxText(byte[] data) throws Exception {
        HashMap<String, byte[]> entries = new HashMap<>();
        ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(data));
        try {
            ZipEntry ze;
            while ((ze = zis.getNextEntry()) != null) {
                String name = ze.getName();
                if ("word/document.xml".equals(name)
                        || "word/footnotes.xml".equals(name)
                        || "word/endnotes.xml".equals(name)) {
                    entries.put(name, readStream(zis));
                }
                zis.closeEntry();
            }
        } finally {
            try {
                zis.close();
            } catch (Exception ignored) {
            }
        }

        byte[] docXml = entries.get("word/document.xml");
        if (docXml == null) {
            throw new Exception("invalid_docx");
        }
        StringBuilder full = new StringBuilder();
        full.append(parseWordXml(docXml));

        byte[] fnXml = entries.get("word/footnotes.xml");
        if (fnXml != null) {
            String fnText = parseWordXml(fnXml).trim();
            if (!fnText.isEmpty()) {
                full.append("\n\n──────── پاورقی‌ها ────────\n").append(fnText);
            }
        }
        byte[] enXml = entries.get("word/endnotes.xml");
        if (enXml != null) {
            String enText = parseWordXml(enXml).trim();
            if (!enText.isEmpty()) {
                full.append("\n\n──────── پی‌نوشت‌ها ────────\n").append(enText);
            }
        }
        return normalizeText(full.toString());
    }

    private static String parseWordXml(byte[] xmlBytes) throws Exception {
        XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
        factory.setNamespaceAware(true);
        XmlPullParser p = factory.newPullParser();
        p.setInput(new ByteArrayInputStream(xmlBytes), "UTF-8");

        StringBuilder out = new StringBuilder();
        StringBuilder para = new StringBuilder();
        ArrayList<String> rowCells = null;
        StringBuilder cellBuf = null;
        boolean inTable = false;
        boolean inText = false;

        int ev = p.getEventType();
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                String name = p.getName();
                if ("tbl".equals(name)) {
                    inTable = true;
                } else if ("tr".equals(name) && inTable) {
                    rowCells = new ArrayList<>();
                } else if ("tc".equals(name) && rowCells != null) {
                    cellBuf = new StringBuilder();
                } else if ("p".equals(name)) {
                    para.setLength(0);
                } else if ("t".equals(name)) {
                    inText = true;
                } else if ("tab".equals(name)) {
                    para.append('\t');
                } else if ("br".equals(name) || "cr".equals(name)) {
                    para.append('\n');
                }
            } else if (ev == XmlPullParser.TEXT) {
                if (inText) {
                    String t = p.getText();
                    if (t != null) {
                        para.append(t);
                    }
                }
            } else if (ev == XmlPullParser.END_TAG) {
                String name = p.getName();
                if ("t".equals(name)) {
                    inText = false;
                } else if ("p".equals(name)) {
                    String line = para.toString();
                    if (cellBuf != null) {
                        if (cellBuf.length() > 0 && !line.trim().isEmpty()) {
                            cellBuf.append(' ');
                        }
                        cellBuf.append(line.trim());
                    } else {
                        if (out.length() > 0) {
                            out.append('\n');
                        }
                        out.append(line);
                    }
                    para.setLength(0);
                } else if ("tc".equals(name) && rowCells != null && cellBuf != null) {
                    rowCells.add(cellBuf.toString().trim());
                    cellBuf = null;
                } else if ("tr".equals(name) && rowCells != null) {
                    StringBuilder rowLine = new StringBuilder();
                    boolean any = false;
                    for (int i = 0; i < rowCells.size(); i++) {
                        String c = rowCells.get(i);
                        if (!c.isEmpty()) {
                            any = true;
                        }
                        if (i > 0) {
                            rowLine.append(" | ");
                        }
                        rowLine.append(c);
                    }
                    if (any) {
                        if (out.length() > 0) {
                            out.append('\n');
                        }
                        out.append(rowLine);
                    }
                    rowCells = null;
                } else if ("tbl".equals(name)) {
                    inTable = false;
                    if (out.length() > 0) {
                        out.append('\n');
                    }
                }
            }
            ev = p.next();
        }
        return out.toString();
    }

    private static String normalizeText(String s) {
        if (s == null) {
            return "";
        }
        s = s.replace("\r\n", "\n").replace('\r', '\n');
        s = s.replaceAll("\n{3,}", "\n\n");
        return s.trim();
    }

    private static String resolveName(ContentResolver cr, Uri uri) {
        Cursor c = null;
        try {
            c = cr.query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) {
                    String n = c.getString(idx);
                    if (n != null && !n.trim().isEmpty()) {
                        return n.trim();
                    }
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) {
                try {
                    c.close();
                } catch (Exception ignored) {
                }
            }
        }
        String seg = uri.getLastPathSegment();
        if (seg != null) {
            int slash = seg.lastIndexOf('/');
            if (slash >= 0) {
                seg = seg.substring(slash + 1);
            }
            int colon = seg.lastIndexOf(':');
            if (colon >= 0) {
                seg = seg.substring(colon + 1);
            }
            return seg.trim();
        }
        return "";
    }

    private static String stripExtension(String name) {
        if (name == null) {
            return "";
        }
        int dot = name.lastIndexOf('.');
        if (dot > 0) {
            return name.substring(0, dot).trim();
        }
        return name.trim();
    }

    private static boolean startsWith(byte[] data, byte[] prefix) {
        if (data.length < prefix.length) {
            return false;
        }
        for (int i = 0; i < prefix.length; i++) {
            if (data[i] != prefix[i]) {
                return false;
            }
        }
        return true;
    }

    private static byte[] readBytes(ContentResolver cr, Uri uri) throws Exception {
        InputStream in = cr.openInputStream(uri);
        if (in == null) {
            throw new Exception("no_stream");
        }
        try {
            return readStream(in);
        } finally {
            try {
                in.close();
            } catch (Exception ignored) {
            }
        }
    }

    private static byte[] readStream(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        long total = 0;
        int n;
        while ((n = in.read(buf)) > 0) {
            total += n;
            if (total > MAX_DOC_BYTES) {
                throw new Exception("too_big");
            }
            out.write(buf, 0, n);
        }
        return out.toByteArray();
    }
}
