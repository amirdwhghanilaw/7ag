package app.ketabche;

import java.net.URI;
import java.util.Locale;

final class NetPolicy {
    private NetPolicy() {}

    static boolean allowed(String url) {
        if (url == null || url.length() > 4096) {
            return false;
        }
        try {
            URI uri = new URI(url);
            String scheme = uri.getScheme();
            String host = uri.getHost();
            String rawPath = uri.getRawPath();
            if (scheme == null || !"https".equals(scheme.toLowerCase(Locale.ROOT))) {
                return false;
            }
            if (host == null || rawPath == null) {
                return false;
            }
            if (uri.getRawUserInfo() != null || uri.getRawFragment() != null) {
                return false;
            }
            if (uri.getPort() != -1 && uri.getPort() != 443) {
                return false;
            }
            String lowerPath = rawPath.toLowerCase(Locale.ROOT);
            if (lowerPath.contains("..") || lowerPath.contains("%2e") || lowerPath.contains("%2f")
                    || lowerPath.contains("%5c") || lowerPath.contains("\\") || lowerPath.contains("%00")) {
                return false;
            }
            String lowerHost = host.toLowerCase(Locale.ROOT);
            if ("api.dictionaryapi.dev".equals(lowerHost)) {
                return rawPath.startsWith("/api/v2/entries/en/") && rawPath.length() > "/api/v2/entries/en/".length();
            }
            if ("api.mymemory.translated.net".equals(lowerHost)) {
                return "/get".equals(rawPath);
            }
            if ("translate.googleapis.com".equals(lowerHost)) {
                return "/translate_a/single".equals(rawPath);
            }
            if ("clients5.google.com".equals(lowerHost)) {
                return "/translate_a/t".equals(rawPath);
            }
            if ("fa.wiktionary.org".equals(lowerHost) || "en.wiktionary.org".equals(lowerHost)) {
                return "/w/api.php".equals(rawPath);
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    static boolean allowedVoiceStudio(String url) {
        if (url == null || url.length() > 2048) {
            return false;
        }
        try {
            URI uri = new URI(url);
            String scheme = uri.getScheme();
            String host = uri.getHost();
            if (scheme == null || host == null) {
                return false;
            }
            String s = scheme.toLowerCase(Locale.ROOT);
            if (!"http".equals(s) && !"https".equals(s)) {
                return false;
            }
            if (uri.getRawUserInfo() != null || uri.getRawFragment() != null) {
                return false;
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
