package app.ketabche;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaPlayer;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

final class VoiceStudioClient {
    private final Context ctx;
    private MediaPlayer player;
    private volatile boolean stopped = false;

    VoiceStudioClient(Context ctx) {
        this.ctx = ctx.getApplicationContext();
    }

    static String normalizeBase(String url) {
        if (url == null) {
            return "";
        }
        String u = url.trim();
        while (u.endsWith("/")) {
            u = u.substring(0, u.length() - 1);
        }
        return u;
    }

    String getJson(String baseUrl, String path, String apiKey) throws Exception {
        String endpoint = normalizeBase(baseUrl) + path;
        if (!NetPolicy.allowedVoiceStudio(endpoint)) {
            throw new IOException("Invalid VoiceStudio URL");
        }
        HttpURLConnection conn = (HttpURLConnection) new URL(endpoint).openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(8000);
        conn.setReadTimeout(15000);
        conn.setUseCaches(false);
        conn.setRequestProperty("Accept", "application/json");
        conn.setRequestProperty("User-Agent", "Ketabche/2.8 (Android; VoiceStudio Client)");
        if (apiKey != null && !apiKey.trim().isEmpty()) {
            conn.setRequestProperty("Authorization", "Bearer " + apiKey.trim());
        }
        int code = conn.getResponseCode();
        InputStream in = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
        try {
            if (in == null) {
                if (code >= 400) {
                    throw new IOException("HTTP " + code);
                }
                return "{}";
            }
            BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            br.close();
            if (code >= 400) {
                throw new IOException("HTTP " + code + ": " + sb.toString());
            }
            return sb.toString();
        } finally {
            conn.disconnect();
        }
    }

    File synthesizeToFile(String baseUrl, String apiKey, String text, String model,
                          String voice, String lang, float speed, String instruct) throws Exception {
        String endpoint = normalizeBase(baseUrl) + "/v1/audio/speech";
        if (!NetPolicy.allowedVoiceStudio(endpoint)) {
            throw new IOException("Invalid VoiceStudio URL");
        }
        JSONObject payload = new JSONObject();
        payload.put("model", (model == null || model.trim().isEmpty()) ? "omnivoice" : model.trim());
        payload.put("input", text.length() > 4096 ? text.substring(0, 4096) : text);
        payload.put("voice", (voice == null || voice.trim().isEmpty()) ? "default" : voice.trim());
        payload.put("response_format", "mp3");
        payload.put("speed", Math.max(0.25f, Math.min(4.0f, speed)));
        if (lang != null && !lang.trim().isEmpty()) {
            payload.put("language", lang.trim());
        }
        if (instruct != null && !instruct.trim().isEmpty()) {
            payload.put("instruct", instruct.trim());
        }

        HttpURLConnection conn = (HttpURLConnection) new URL(endpoint).openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(60000);
        conn.setUseCaches(false);
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        conn.setRequestProperty("Accept", "audio/mpeg, audio/*");
        conn.setRequestProperty("User-Agent", "Ketabche/2.8 (Android; VoiceStudio Client)");
        if (apiKey != null && !apiKey.trim().isEmpty()) {
            conn.setRequestProperty("Authorization", "Bearer " + apiKey.trim());
        }

        byte[] body = payload.toString().getBytes(StandardCharsets.UTF_8);
        OutputStream os = conn.getOutputStream();
        try {
            os.write(body);
            os.flush();
        } finally {
            os.close();
        }

        int code = conn.getResponseCode();
        if (code < 200 || code >= 300) {
            conn.disconnect();
            throw new IOException("VoiceStudio HTTP " + code);
        }

        File cacheFile = new File(ctx.getCacheDir(), "vs_seg_" + System.nanoTime() + ".mp3");
        InputStream in = conn.getInputStream();
        FileOutputStream fos = new FileOutputStream(cacheFile);
        try {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) {
                if (stopped) {
                    break;
                }
                fos.write(buf, 0, n);
            }
            fos.flush();
        } finally {
            try { fos.close(); } catch (Exception ignored) {}
            try { in.close(); } catch (Exception ignored) {}
            conn.disconnect();
        }
        if (stopped) {
            cacheFile.delete();
            return null;
        }
        return cacheFile;
    }

    synchronized void playFile(final File audioFile, final Runnable onComplete, final Runnable onError) {
        stopPlaybackInternal();
        stopped = false;
        try {
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build());
            player.setDataSource(audioFile.getAbsolutePath());
            player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    try { audioFile.delete(); } catch (Exception ignored) {}
                    if (onComplete != null) {
                        onComplete.run();
                    }
                }
            });
            player.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(MediaPlayer mp, int what, int extra) {
                    try { audioFile.delete(); } catch (Exception ignored) {}
                    if (onError != null) {
                        onError.run();
                    }
                    return true;
                }
            });
            player.prepare();
            player.start();
        } catch (Exception e) {
            try { audioFile.delete(); } catch (Exception ignored) {}
            if (onError != null) {
                onError.run();
            }
        }
    }

    synchronized void stopPlayback() {
        stopped = true;
        stopPlaybackInternal();
    }

    private void stopPlaybackInternal() {
        if (player != null) {
            try { player.stop(); } catch (Exception ignored) {}
            try { player.release(); } catch (Exception ignored) {}
            player = null;
        }
    }

    void resetStopFlag() {
        stopped = false;
    }
}
