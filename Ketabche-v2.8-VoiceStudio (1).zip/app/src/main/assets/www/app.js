/* کتابچه — برنامه‌ی ذخیره‌ی متن صفحه‌به‌صفحه با ورق‌زدن و هایلایت
   همه‌ی داده‌ها فقط روی همین دستگاه ذخیره می‌شود. */
(function () {
'use strict';

/* =====================================================================
   ابزارهای کمکی
   ===================================================================== */
function $(s, r) { return (r || document).querySelector(s); }
function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
function h(tag, props, kids) {
  var n = document.createElement(tag);
  if (props) {
    for (var k in props) {
      var v = props[k];
      if (v == null || v === false) continue;
      if (k === 'class') n.className = v;
      else if (k === 'html') n.innerHTML = v;
      else if (k === 'text') n.textContent = v;
      else if (k === 'style') n.style.cssText = v;
      else if (k.slice(0, 2) === 'on') n.addEventListener(k.slice(2), v);
      else n.setAttribute(k, v === true ? '' : v);
    }
  }
  if (kids != null) {
    (Array.isArray(kids) ? kids : [kids]).forEach(function (c) {
      if (c == null || c === false) return;
      n.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    });
  }
  return n;
}
var FA_NUM;
try { FA_NUM = new Intl.NumberFormat('fa-IR'); } catch (e) { FA_NUM = null; }
function fa(n) { return FA_NUM ? FA_NUM.format(n) : String(n); }
function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }
function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
function fmtDate(ts) {
  try {
    return new Intl.DateTimeFormat('fa-IR-u-ca-persian', { year: 'numeric', month: 'long', day: 'numeric' }).format(new Date(ts));
  } catch (e) { return new Date(ts).toLocaleDateString(); }
}
function esc(s) {
  return String(s).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}
function norm(t) { return String(t == null ? '' : t).replace(/\r\n?/g, '\n').replace(/\u2028|\u2029/g, '\n'); }
function snippet(t, n) {
  t = String(t).replace(/\s+/g, ' ').trim();
  return t.length > n ? t.slice(0, n).trim() + '…' : t;
}

var ICONS = {
  back: '<path d="M5 12h14M12 5l7 7-7 7"/>',
  forward: '<path d="M19 12H5M12 19l-7-7 7-7"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  dots: '<circle cx="12" cy="5" r="1.4"/><circle cx="12" cy="12" r="1.4"/><circle cx="12" cy="19" r="1.4"/>',
  edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
  list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
  mark: '<path d="m9 11-6 6v3h9l3-3"/><path d="m22 12-4.6 4.6a2 2 0 0 1-2.8 0l-5.2-5.2a2 2 0 0 1 0-2.8L14 4"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
  sliders: '<path d="M21 4h-7M10 4H3M21 12h-9M8 12H3M21 20h-5M12 20H3M14 2v4M8 10v4M16 18v4"/>',
  trash: '<path d="M3 6h18M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6M10 11v6M14 11v6M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>',
  share: '<path d="M4 12v7a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7M16 6l-4-4-4 4M12 2v13"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  x: '<path d="M18 6 6 18M6 6l12 12"/>',
  up: '<path d="m18 15-6-6-6 6"/>',
  down: '<path d="m6 9 6 6 6-6"/>',
  book: '<path d="M2 4h6a4 4 0 0 1 4 4v13a3 3 0 0 0-3-3H2z"/><path d="M22 4h-6a4 4 0 0 0-4 4v13a3 3 0 0 1 3-3h7z"/>',
  download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>',
  upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/>',
  copy: '<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
  eraser: '<path d="m7 21-4.3-4.3a2 2 0 0 1 0-2.8l9.6-9.6a2 2 0 0 1 2.8 0l5.6 5.6a2 2 0 0 1 0 2.8L13 21"/><path d="M22 21H7M5 11l9 9"/>',
  info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>',
  pen: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
  hash: '<path d="M4 9h16M4 15h16M10 3 8 21M16 3l-2 18"/>',
  speaker: '<path d="M11 5 6 9H2v6h4l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7M19 5a10 10 0 0 1 0 14"/>',
  play: '<path fill="currentColor" stroke="none" d="M7 4.6v14.8a.8.8 0 0 0 1.2.7l12-7.4a.8.8 0 0 0 0-1.4L8.2 3.9A.8.8 0 0 0 7 4.6z"/>',
  pause: '<rect fill="currentColor" stroke="none" x="6" y="4.5" width="4.2" height="15" rx="1.2"/><rect fill="currentColor" stroke="none" x="13.8" y="4.5" width="4.2" height="15" rx="1.2"/>',
  skipPrev: '<path d="M19 20 9 12l10-8z"/><path d="M5 19V5"/>',
  skipNext: '<path d="m5 4 10 8-10 8z"/><path d="M19 5v14"/>',
  eye: '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>',
  eyeOff: '<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><path d="M1 1l22 22"/>',
  image: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/>',
  type: '<path d="M4 7V4h16v3M9 20h6M12 4v16"/>',
  palette: '<circle cx="13.5" cy="6.5" r=".6"/><circle cx="17.5" cy="10.5" r=".6"/><circle cx="8.5" cy="7.5" r=".6"/><circle cx="6.5" cy="12.5" r=".6"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.93 0 1.65-.75 1.65-1.69 0-.44-.18-.84-.44-1.13-.29-.29-.44-.65-.44-1.13a1.64 1.64 0 0 1 1.67-1.67h2c3.05 0 5.55-2.5 5.55-5.55C21.97 6.01 17.46 2 12 2z"/>',
  rotate: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>',
  layout: '<rect x="3" y="3" width="18" height="18" rx="3"/><rect x="7" y="7" width="10" height="10" rx="1"/>',
  words: '<path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20"/><path d="m8 13 4-7 4 7M9.1 11h5.8"/>',
  globe: '<circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>',
  layers: '<path d="m12 2 9 5-9 5-9-5z"/><path d="m3 12 9 5 9-5M3 17l9 5 9-5"/>',
  note: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M16 13H8M16 17H8M10 9H8"/>',
  archive: '<rect x="2" y="3" width="20" height="5" rx="1"/><path d="M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8"/><path d="M10 12h4"/>',
  unarchive: '<rect x="2" y="3" width="20" height="5" rx="1"/><path d="M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8"/><path d="m9 14 3-3 3 3M12 11v6"/>',
  folder: '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>',
  pin: '<path d="M12 17v5"/><path d="M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z"/>',
  notebook: '<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M8 7h8M8 11h8M8 15h8M7 2v20"/>',
  lock: '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  unlock: '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 9.9-1"/>',
  key: '<circle cx="7.5" cy="15.5" r="5.5"/><path d="m21 2-9.6 9.6M15.5 7.5l3 3L22 7l-3-3"/>',
  pdf: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M8 13h8M8 17h5"/>',
  word: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="m8 13 1.5 5 2.5-4 2.5 4 1.5-5"/>',
  md: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M7 17v-5l2 2.5 2-2.5v5M14.5 14.5 16 17l1.5-2.5M16 12v5"/>',
  js: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M10 12v4a1.5 1.5 0 0 1-3 0M16.5 12.5c-.5-.5-2-.5-2 .7 0 1.3 2.5.8 2.5 2.3 0 1.2-1.8 1.2-2.5.5"/>',
  top: '<path d="M18 11 12 5 6 11M12 5v15M5 3h14"/>',
  bottom: '<path d="m6 13 6 6 6-6M12 19V4M5 21h14"/>',
  autoDown: '<path d="m7 13 5 5 5-5M7 6l5 5 5-5"/>',
  autoUp: '<path d="m17 11-5-5-5 5M17 18l-5-5-5 5"/>',
  bookmark: '<path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>',
  bookmarkFill: '<path fill="currentColor" d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/>',
  moon: '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>',
  grid: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  listView: '<path d="M8 6h13M8 12h13M8 18h13"/><rect x="3" y="4.5" width="3" height="3" rx=".6"/><rect x="3" y="10.5" width="3" height="3" rx=".6"/><rect x="3" y="16.5" width="3" height="3" rx=".6"/>',
  sort: '<path d="M3 6h14M3 12h10M3 18h6"/><path d="m17 14 3 3 3-3M20 7v10"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  maximize: '<path d="M8 3H5a2 2 0 0 0-2 2v3M21 8V5a2 2 0 0 0-2-2h-3M3 16v3a2 2 0 0 0 2 2h3M16 21h3a2 2 0 0 0 2-2v-3"/>',
  translate: '<path d="m5 8 6 6M4 14l6-6 2-3M2 5h12M7 2h1M22 22l-5-10-5 10M14 18h6"/>'
};
function debounce(fn, ms) {
  var t = null;
  return function () {
    var args = arguments, ctx = this;
    clearTimeout(t);
    t = setTimeout(function () { fn.apply(ctx, args); }, ms || 100);
  };
}
function ic(name, size) {
  size = size || 24;
  return '<svg class="ic" width="' + size + '" height="' + size + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
    'stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + ICONS[name] + '</svg>';
}

/* =====================================================================
   پل ارتباطی با اندروید (و جایگزین‌های مرورگر برای تست)
   ===================================================================== */
var A = window.Android || null;
function bridge(name) { return !!(A && typeof A[name] === 'function'); }
function toastNative(msg) { try { if (bridge('toast')) { A.toast(msg); return true; } } catch (e) {} return false; }
function hapticTap() { try { if (bridge('haptic')) A.haptic(); else if (navigator.vibrate) navigator.vibrate(8); } catch (e) {} }

/* =====================================================================
   داده‌ها
   ===================================================================== */
var STORE_KEY = 'ketabche.data.v1';
var COLORS = ['y', 'o', 'r', 'p', 'm', 'v', 'b', 'c', 't', 'g', 'l', 'n'];
var COLOR_NAMES = { y: 'زرد', o: 'نارنجی', r: 'قرمز', p: 'صورتی', m: 'ارغوانی', v: 'بنفش', b: 'آبی', c: 'فیروزه‌ای روشن',
  t: 'سبزآبی', g: 'سبز', l: 'لیمویی', n: 'قهوه‌ای' };
var COVER_TOKEN_RE = /^[A-Za-z0-9_-]{1,64}$/;
var COVERS = ['#8c3b2a', '#2f5d62', '#4a4e8a', '#6b4f2a', '#3c6e47', '#7a3e65', '#2d4059', '#8a5a1f',
  '#5e2b2f', '#40502f', '#24455a', '#5a4a78'];

var DEFAULT_NOTE_CATS = ['عمومی', 'مطالعه', 'نقل‌قول', 'ایده', 'کارها'];
function defaultData() {
  return {
    v: 5, seeded: false, nextCover: 0, lastBook: null, seenVer: 0,
    settings: { theme: 'auto', glass: true, fontSize: 21, lineHeight: 1.95, fontFa: 'vazir', fontEn: 'auto', weight: 400, frame: true, justify: true,
      flip: 'rtl', anim: true, keepOn: false, color: 'y', ttsRate: 1, ttsPitch: 1, net: false,
      ttsAr: true, ttsEn: true, ttsFr: true, ttsDe: true, ttsTr: true, ttsFa: true,
      vsEnabled: false, vsUrl: 'http://192.168.1.10:8000', vsApiKey: '', vsModel: 'omnivoice', vsVoice: 'default', vsInstruct: '', vsFallback: true,
      uiStyle: 'ios18', uiAutoTheme: true,
      glassTrans: 34, glassBlur: 24,
      autoScrollSpeed: 1,
      pageBg: 'classic', pageBgImg: '', pageBgCover: '',
      libView: 'grid', libSort: 'recent' },
    books: [], words: [], notes: [], noteCats: DEFAULT_NOTE_CATS.slice()
  };
}
function sanitize(d) {
  var base = defaultData();
  if (!d || typeof d !== 'object') return base;
  var out = base;
  out.seeded = !!d.seeded;
  out.nextCover = (d.nextCover | 0) || 0;
  out.lastBook = d.lastBook || null;
  out.seenVer = clamp(d.seenVer | 0, 0, 99);
  var st = d.settings || {};
  out.bookCats = Array.isArray(d.bookCats) ? d.bookCats.filter(function(x){ return x && typeof x.id === 'string' && typeof x.name === 'string'; }).slice(0, 30) : [];
  for (var k in base.settings) if (st[k] !== undefined && typeof st[k] === typeof base.settings[k]) out.settings[k] = st[k];
  var oldTheme = { light: 'snow', dark: 'night' };
  if (oldTheme[out.settings.theme]) out.settings.theme = oldTheme[out.settings.theme];
  if (out.settings.theme !== 'auto' && !THEMES[out.settings.theme]) out.settings.theme = 'auto';
  if (out.settings.flip !== 'ltr') out.settings.flip = 'rtl';
  if (st.fontFa === undefined && st.font === 'system') out.settings.fontFa = 'system';
  if (!FA_FONTS.some(function (f) { return f.id === out.settings.fontFa; })) out.settings.fontFa = 'vazir';
  if (!EN_FONTS.some(function (f) { return f.id === out.settings.fontEn; })) out.settings.fontEn = 'auto';
  if (WEIGHTS.indexOf(out.settings.weight) < 0) out.settings.weight = 400;
  if (COLORS.indexOf(out.settings.color) < 0) out.settings.color = 'y';
  out.settings.fontSize = clamp(+out.settings.fontSize || 21, 8, 35);
  out.settings.lineHeight = clamp(+out.settings.lineHeight || 1.95, 1.4, 2.6);
  out.settings.ttsRate = clamp(+out.settings.ttsRate || 1, 0.5, 2);
  out.settings.ttsPitch = clamp(+out.settings.ttsPitch || 1, 0.6, 1.4);
  out.settings.glassTrans = clamp(st.glassTrans !== undefined ? +st.glassTrans : 32, 5, 88);
  out.settings.glassBlur = clamp(st.glassBlur !== undefined ? +st.glassBlur : 20, 0, 36);
  if (typeof st.pageBgImg === 'string' && st.pageBgImg.length < 6000000 && /^data:image\/(jpeg|png|webp|svg\+xml)/.test(st.pageBgImg.slice(0, 48))) out.settings.pageBgImg = st.pageBgImg;
  else out.settings.pageBgImg = '';
  if (typeof st.pageBgCover === 'string' && COVER_TOKEN_RE.test(st.pageBgCover)) out.settings.pageBgCover = st.pageBgCover;
  else out.settings.pageBgCover = '';
  if (out.settings.pageBg !== 'custom_img' && !PAGE_BGS.some(function (b) { return b.id === out.settings.pageBg; })) out.settings.pageBg = 'classic';
  if (!UI_STYLES.some(function (u) { return u.id === out.settings.uiStyle; })) out.settings.uiStyle = 'ios18';
  if (out.settings.libView !== 'list') out.settings.libView = 'grid';
  if (['recent', 'title', 'progress'].indexOf(out.settings.libSort) < 0) out.settings.libSort = 'recent';
  if (out.seenVer < 10) {
    out.settings.uiStyle = 'ios18';
    out.settings.theme = 'auto';
    out.settings.glass = true;
  }
  (Array.isArray(d.words) ? d.words : []).slice(0, 20000).forEach(function (x) {
    if (!x || typeof x !== 'object') return;
    var w = String(x.w == null ? '' : x.w).replace(/\s+/g, ' ').trim().slice(0, 160);
    if (!w) return;
    var now = Date.now();
    out.words.push({ id: String(x.id || uid()).slice(0, 64), w: w, m: String(x.m == null ? '' : x.m).slice(0, 3000), ex: '',
      bid: String(x.bid || '').slice(0, 64), bk: String(x.bk || '').slice(0, 120), pg: clamp(x.pg | 0, 0, 100000),
      created: +x.created || now, updated: +x.updated || now, box: clamp(x.box | 0, 0, 5), due: Math.max(0, +x.due || 0), seen: clamp(x.seen | 0, 0, 100000),
      lg: typeof x.lg === 'string' && /^(ar|en|fr|de|tr|fa)$/.test(x.lg) ? x.lg : '' });
  });
  if (Array.isArray(d.noteCats) && d.noteCats.length) {
    var cats = [];
    d.noteCats.slice(0, 50).forEach(function (c) {
      var s = String(c == null ? '' : c).replace(/\s+/g, ' ').trim().slice(0, 40);
      if (s && cats.indexOf(s) < 0) cats.push(s);
    });
    if (cats.length) out.noteCats = cats;
  }
  (Array.isArray(d.notes) ? d.notes : []).slice(0, 20000).forEach(function (x) {
    if (!x || typeof x !== 'object') return;
    var title = String(x.title == null ? '' : x.title).replace(/\s+/g, ' ').trim().slice(0, 160);
    var text = norm(x.text).slice(0, 20000);
    var cipher = typeof x.cipher === 'string' ? x.cipher.slice(0, 80000) : '';
    var pwdHash = typeof x.pwdHash === 'string' ? x.pwdHash.slice(0, 128) : '';
    var pwdSalt = typeof x.pwdSalt === 'string' ? x.pwdSalt.slice(0, 64) : '';
    var locked = !!(x.locked && pwdHash);
    if (!title && !text && !cipher) return;
    var now = Date.now();
    var cat = String(x.cat == null ? 'عمومی' : x.cat).replace(/\s+/g, ' ').trim().slice(0, 40) || 'عمومی';
    if (out.noteCats.indexOf(cat) < 0) out.noteCats.push(cat);
    out.notes.push({
      id: String(x.id || uid()).slice(0, 64),
      title: title || 'بدون عنوان',
      text: text,
      locked: locked,
      pwdHash: pwdHash,
      pwdSalt: pwdSalt,
      cipher: cipher,
      cat: cat,
      color: COLORS.indexOf(x.color) >= 0 ? x.color : 'y',
      archived: !!x.archived,
      pinned: !!x.pinned,
      bid: String(x.bid || '').slice(0, 64),
      bk: String(x.bk || '').slice(0, 120),
      pg: clamp(x.pg | 0, 0, 100000),
      lg: typeof x.lg === 'string' && /^(fa|en|fr|de|ar|tr)$/.test(x.lg) ? x.lg : '',
      created: +x.created || now,
      updated: +x.updated || now
    });
  });
  (Array.isArray(d.books) ? d.books : []).forEach(function (b) {
    if (!b || typeof b !== 'object') return;
    var nb = {
      id: String(b.id || uid()), title: String(b.title || 'بدون عنوان'),
      color: (b.color | 0) % COVERS.length, created: +b.created || Date.now(), updated: +b.updated || Date.now(),
      last: Math.max(0, b.last | 0),
      lg: typeof b.lg === 'string' && /^(fa|en|fr|de|ar|tr)$/.test(b.lg) ? b.lg : '',
      trMode: (b.trMode === 'full' || b.trMode === 'bilingual') ? b.trMode : 'off',
      trSrc: typeof b.trSrc === 'string' && /^(auto|en|ar|fr|de|tr|es|ru|fa)$/.test(b.trSrc) ? b.trSrc : 'auto',
      trStyle: (b.trStyle === 'formal' || b.trStyle === 'colloquial') ? b.trStyle : 'standard',
      chapters: Array.isArray(b.chapters) ? b.chapters.slice(0, 500).map(function (ch) {
        return { t: String(ch && ch.t || '').slice(0, 120), p: Math.max(0, (ch && ch.p) | 0) };
      }).filter(function (ch) { return !!ch.t; }) : [],
      pages: []
    };
    if (typeof b.cover === 'string' && COVER_TOKEN_RE.test(b.cover)) nb.cover = b.cover;
    if (typeof b.coverData === 'string' && b.coverData.length < 6000000 && /^data:image\/(jpeg|png|webp);base64,/.test(b.coverData.slice(0, 40))) nb.coverData = b.coverData;
    (Array.isArray(b.pages) ? b.pages : []).forEach(function (p) {
      if (!p || typeof p !== 'object') return;
      var text = norm(p.text);
      var np = { id: String(p.id || uid()), text: text, created: +p.created || Date.now(), updated: +p.updated || Date.now(), hl: [], bm: !!p.bm };
      (Array.isArray(p.hl) ? p.hl : []).forEach(function (x) {
        if (!x) return;
        var s = x.s | 0, e = x.e | 0;
        if (e > text.length) e = text.length;
        if (s < 0) s = 0;
        if (e > s) np.hl.push({ id: String(x.id || uid()), s: s, e: e, c: COLORS.indexOf(x.c) >= 0 ? x.c : 'y' });
      });
      np.hl.sort(function (a, b) { return a.s - b.s; });
      if (p.tr && typeof p.tr === 'object' && typeof p.tr.h === 'string' && Array.isArray(p.tr.segs)) {
        np.tr = {
          h: String(p.tr.h).slice(0, 48),
          sl: String(p.tr.sl || 'auto').slice(0, 12),
          tl: String(p.tr.tl || 'fa').slice(0, 12),
          segs: p.tr.segs.slice(0, 4000).map(function (sg) {
            var o = { o: String(sg && sg.o != null ? sg.o : ''), t: String(sg && sg.t != null ? sg.t : ''), pe: !!(sg && sg.pe) };
            if (sg && sg.ed) o.ed = true;
            if (sg && typeof sg.rawT === 'string') o.rawT = sg.rawT;
            return o;
          })
        };
      }
      nb.pages.push(np);
    });
    out.books.push(nb);
  });
  var stIn = d && d.stats && typeof d.stats === 'object' ? d.stats : {};
  var dailyOut = {};
  if (stIn.daily && typeof stIn.daily === 'object') {
    Object.keys(stIn.daily).slice(-90).forEach(function (dk) {
      if (!/^\d{4}-\d{2}-\d{2}$/.test(dk)) return;
      var v = stIn.daily[dk] || {};
      dailyOut[dk] = { mins: Math.max(0, +v.mins || 0), pages: Math.max(0, v.pages | 0) };
    });
  }
  out.stats = { daily: dailyOut, goalMins: clamp((stIn.goalMins | 0) || 30, 5, 300) };
  return out;
}

var Store = {
  readRaw: function () {
    var raw = null;
    try { if (bridge('load')) raw = A.load(); } catch (e) {}
    if (!raw) { try { raw = localStorage.getItem(STORE_KEY); } catch (e) {} }
    return raw;
  },
  load: function () {
    var raw = Store.readRaw(), d = null;
    if (raw) { try { d = JSON.parse(raw); } catch (e) { d = null; } }
    if (!d && raw) {            // فایل خراب بود: نسخه‌ی پشتیبان خودکار
      try { if (bridge('loadBackup')) d = JSON.parse(A.loadBackup()); } catch (e) { d = null; }
    }
    return sanitize(d);
  },
  mirrorAt: 0,
  /* نسخه‌ی آینه در localStorage فقط پشتیبان است؛ نوشتن چند مگابایت در هر ذخیره نخ اصلی را می‌گیرد،
     پس در اندروید حداکثر هر ۳۰ ثانیه (و هنگام رفتن به پس‌زمینه) نوشته می‌شود. */
  save: function (json, force) {
    var ok = false;
    try { if (bridge('save')) ok = A.save(json) !== false; } catch (e) {}
    var now = Date.now();
    if (!ok || force || now - Store.mirrorAt > 30000) {
      try { localStorage.setItem(STORE_KEY, json); Store.mirrorAt = now; } catch (e) {}
    }
  }
};

var S = {
  data: null,
  view: 'library',
  libTab: 'books',  // 'books' | 'words'
  bookId: null,
  index: 0,
  flip: null,       // وضعیت ورق‌زدن
  lastSel: null,    // آخرین انتخاب متن
  barMode: null,    // 'sel' | 'hl'
  barHid: null,
  flashTimer: null,
  saveTimer: null,
  dirty: false,
  undo: null,
  covers: {},       // حافظه‌ی نهان عکس جلدها (توکن → data URI)
  coverWait: null,
  tts: null,        // وضعیت خوانش صوتی
  unlockedNotes: {}, noteKeys: {},
  touching: false, lastAct: 0, dirtySince: 0, posDirty: false
};

/* ذخیره‌ی داده‌ها
   v2.3: ذخیره‌ی کامل (JSON.stringify + نوشتن فایل با fsync در اندروید) سنگین است و روی نخ اصلی اجرا می‌شود.
   قبلاً ۳۵۰ میلی‌ثانیه بعد از هر ورق‌زدن اجرا می‌شد و درست وقتی کاربر ورق بعدی را می‌زد صفحه را قفل می‌کرد.
   اکنون: ۱) جای صفحه‌ی خواندن‌شده با یک کلید کوچک جدا ذخیره می‌شود؛ ۲) ذخیره‌ی کامل تا وقتی کاربر
   در حال لمس/اسکرول/ورق‌زدن است عقب می‌افتد (حداکثر ۱۵ ثانیه) و در زمان بیکاری اجرا می‌شود؛
   ۳) هنگام رفتن به پس‌زمینه همیشه فوراً ذخیره می‌شود. */
var POS_KEY = 'ketabche.pos.v1';
var SAVE_MAX_DEFER = 15000;
function noteActivity() { S.lastAct = performance.now(); }
function scheduleSave() {
  if (!S.dirty) S.dirtySince = performance.now();
  S.dirty = true;
  clearTimeout(S.saveTimer);
  S.saveTimer = setTimeout(saveWhenIdle, 600);
}
function saveWhenIdle() {
  var now = performance.now();
  var busy = S.flip || S.touching || (now - (S.lastAct || 0) < 700);
  if (busy && now - (S.dirtySince || now) < SAVE_MAX_DEFER) {
    S.saveTimer = setTimeout(saveWhenIdle, 450);
    return;
  }
  if (typeof requestIdleCallback === 'function') requestIdleCallback(function () { flushSave(); }, { timeout: 1200 });
  else flushSave();
}
function flushSave(force) {
  clearTimeout(S.saveTimer);
  if (!S.dirty || !S.data) return;
  S.dirty = false; S.posDirty = false;
  Store.save(JSON.stringify(S.data), force === true);
  try { localStorage.removeItem(POS_KEY); } catch (e) {}   // ذخیره‌ی کامل آخرین جای خواندن را هم دارد
}
/* جای صفحه‌ی خواندن‌شده: فقط یک کلید کوچک (نه کل داده‌ها) */
var posTimer = null;
function writePos() {
  var b = curBook(); if (!b) return;
  try {
    var m = JSON.parse(localStorage.getItem(POS_KEY) || '{}') || {};
    m[b.id] = b.last | 0;
    localStorage.setItem(POS_KEY, JSON.stringify(m));
  } catch (e) {}
}
function savePosSoon() {
  S.posDirty = true;
  clearTimeout(posTimer);
  posTimer = setTimeout(writePos, 450);
}
function applySavedPositions(data) {
  try {
    var m = JSON.parse(localStorage.getItem(POS_KEY) || 'null');
    if (!m || typeof m !== 'object') return;
    var any = false;
    data.books.forEach(function (bk) {
      if (typeof m[bk.id] === 'number' && m[bk.id] >= 0 && m[bk.id] !== bk.last) { bk.last = Math.min(m[bk.id], bk.pages.length); any = true; }
    });
    if (any) { S.dirty = true; S.dirtySince = performance.now(); }   // در اولین فرصت داخل ذخیره‌ی کامل ثبت شود
  } catch (e) {}
}
/* فراخوانی از اندروید (onPause) و هنگام پنهان‌شدن صفحه: همیشه فوری و کامل */
window.flushSave = function () {
  if (S.posDirty) { writePos(); S.dirty = true; }   // جای خواندن در حافظه به‌روز است؛ داخل ذخیره‌ی کامل هم برود
  flushSave(true);
};
document.addEventListener('visibilitychange', function () { if (document.hidden) window.flushSave(); });
window.addEventListener('pagehide', function () { window.flushSave(); });
['touchstart', 'touchmove', 'scroll', 'wheel'].forEach(function (t) {
  document.addEventListener(t, noteActivity, { capture: true, passive: true });
});

function curBook() {
  if (!S.bookId) return null;
  for (var i = 0; i < S.data.books.length; i++) if (S.data.books[i].id === S.bookId) return S.data.books[i];
  return null;
}
function bookById(id) {
  for (var i = 0; i < S.data.books.length; i++) if (S.data.books[i].id === id) return S.data.books[i];
  return null;
}
function touch(book, page) {
  var now = Date.now();
  if (book) book.updated = now;
  if (page) page.updated = now;
  scheduleSave();
}

/* =====================================================================
   هایلایت‌ها: عملیات روی بازه‌ها
   ===================================================================== */
function mergeAdj(list) {
  list.sort(function (a, b) { return a.s - b.s || a.e - b.e; });
  var out = [];
  list.forEach(function (x) {
    var p = out[out.length - 1];
    if (p && p.e >= x.s && p.c === x.c) { p.e = Math.max(p.e, x.e); }
    else out.push({ id: x.id, s: x.s, e: x.e, c: x.c });
  });
  return out;
}
function cutRange(list, s, e) {
  var out = [];
  list.forEach(function (x) {
    if (x.e <= s || x.s >= e) { out.push(x); return; }
    if (x.s < s) out.push({ id: x.id, s: x.s, e: s, c: x.c });
    if (x.e > e) out.push({ id: x.s < s ? uid() : x.id, s: e, e: x.e, c: x.c });
  });
  return out;
}
function addHighlight(pg, s, e, c) {
  var list = cutRange(pg.hl, s, e);
  list.push({ id: uid(), s: s, e: e, c: c });
  pg.hl = mergeAdj(list);
}
function removeHighlightRange(pg, s, e) { pg.hl = mergeAdj(cutRange(pg.hl, s, e)); }

/* پس از ویرایش متن، بازه‌ی هایلایت‌ها را با متن جدید هماهنگ می‌کند */
function remapHighlights(oldT, newT, hl) {
  var p = 0, mx = Math.min(oldT.length, newT.length);
  while (p < mx && oldT.charCodeAt(p) === newT.charCodeAt(p)) p++;
  var sf = 0;
  while (sf < oldT.length - p && sf < newT.length - p &&
         oldT.charCodeAt(oldT.length - 1 - sf) === newT.charCodeAt(newT.length - 1 - sf)) sf++;
  var oldEnd = oldT.length - sf, delta = newT.length - oldT.length, out = [];
  hl.forEach(function (x) {
    if (oldEnd === p && x.s < p && x.e > p) {            // درج متن وسط هایلایت: هایلایت کش می‌آید
      out.push({ id: x.id, s: x.s, e: x.e + delta, c: x.c }); return;
    }
    var used = false;
    if (x.s < p) { out.push({ id: x.id, s: x.s, e: Math.min(x.e, p), c: x.c }); used = true; }
    if (x.e > oldEnd) {
      out.push({ id: used ? uid() : x.id, s: Math.max(x.s, oldEnd) + delta, e: x.e + delta, c: x.c });
    }
  });
  return mergeAdj(out.filter(function (x) { return x.e > x.s && x.s >= 0 && x.e <= newT.length; }));
}

/* =====================================================================
   نمایش متن یک صفحه (خط‌به‌خط) با هایلایت و علامت جستجو
   ===================================================================== */
function renderLines(root, text, hls, flash) {
  root.textContent = '';
  var lines = text.split('\n'), pos = 0, frag = document.createDocumentFragment();
  for (var i = 0; i < lines.length; i++) {
    var line = lines[i], end = pos + line.length;
    var ln = h('div', { class: 'ln' + (line.length ? '' : ' empty'), dir: 'auto' });
    ln.setAttribute('data-s', pos);
    if (line.length) {
      var pts = [pos, end], k;
      for (k = 0; k < hls.length; k++) {
        if (hls[k].e > pos && hls[k].s < end) { pts.push(clamp(hls[k].s, pos, end), clamp(hls[k].e, pos, end)); }
      }
      if (flash && flash.e > pos && flash.s < end) pts.push(clamp(flash.s, pos, end), clamp(flash.e, pos, end));
      pts.sort(function (a, b) { return a - b; });
      for (k = 0; k < pts.length - 1; k++) {
        var a = pts[k], b = pts[k + 1];
        if (b <= a) continue;
        var seg = line.slice(a - pos, b - pos), hit = null;
        for (var j = 0; j < hls.length; j++) if (hls[j].s <= a && hls[j].e >= b) { hit = hls[j]; break; }
        var fl = flash && flash.s <= a && flash.e >= b;
        if (hit) {
          var m = h('mark', { 'data-id': hit.id, 'data-c': hit.c }); m.textContent = seg;
          if (fl) m.className = flash.cls || 'flash';
          ln.appendChild(m);
        } else if (fl) {
          ln.appendChild(h('span', { class: flash.cls || 'flash', text: seg }));
        } else ln.appendChild(document.createTextNode(seg));
      }
    }
    frag.appendChild(ln);
    pos = end + 1;
  }
  root.appendChild(frag);
}

/* تبدیل نقطه‌ی انتخاب‌شده در DOM به شاخص نویسه در متن صفحه */
function nodeToOffset(root, node, off) {
  if (node === root) {
    var kids = root.children;
    if (off >= kids.length) return root.__len | 0;
    return +kids[off].getAttribute('data-s');
  }
  var el = node.nodeType === 1 ? node : node.parentNode, ln = el;
  while (ln && ln !== root && !(ln.classList && ln.classList.contains('ln'))) ln = ln.parentNode;
  if (!ln || ln === root) return 0;
  var r = document.createRange();
  r.selectNodeContents(ln);
  try { r.setEnd(node, off); } catch (e) { return +ln.getAttribute('data-s'); }
  return +ln.getAttribute('data-s') + r.toString().length;
}
function getSelOffsets(root, text) {
  var sel = window.getSelection();
  if (!sel || sel.rangeCount === 0 || sel.isCollapsed) return null;
  var r = sel.getRangeAt(0).cloneRange();
  var rr = document.createRange(); rr.selectNodeContents(root);
  if (r.compareBoundaryPoints(Range.END_TO_START, rr) >= 0 || r.compareBoundaryPoints(Range.START_TO_END, rr) <= 0) return null;
  if (r.compareBoundaryPoints(Range.START_TO_START, rr) < 0) r.setStart(rr.startContainer, rr.startOffset);
  if (r.compareBoundaryPoints(Range.END_TO_END, rr) > 0) r.setEnd(rr.endContainer, rr.endOffset);
  root.__len = text.length;
  var s = nodeToOffset(root, r.startContainer, r.startOffset);
  var e = nodeToOffset(root, r.endContainer, r.endOffset);
  while (s < e && /\s/.test(text.charAt(s))) s++;
  while (e > s && /\s/.test(text.charAt(e - 1))) e--;
  if (e <= s) return null;
  return { s: s, e: e };
}

/* =====================================================================
   تم و تنظیمات ظاهری
   ===================================================================== */
/* پوسته‌ها و قلم‌ها (v1.4) */
var UI_STYLES = [
  { id: 'ios18',           cat: 'digital', name: 'آی‌اواس ۱۸ اپل (خودکار)', sub: 'طراحی کوپرتینو اپل با تطبیق خودکار روز و شب', theme: 'auto', glass: true, trans: 34, r: '14px' },
  { id: 'oneui',           cat: 'future',  name: 'وان‌یوآی ۷ سامسونگ',   sub: 'کپسول‌های نرم و مدرن One UI',      theme: 'sky',      glass: true,  trans: 30, r: '12px' },
  { id: 'vision',          cat: 'future',  name: 'ویژن پرو اپل',         sub: 'شیشه‌ی فضایی و نوارهای معلق',       theme: 'pearl',    glass: true,  trans: 48, r: '16px' },
  { id: 'fluent',          cat: 'future',  name: 'فلوئنت ویندوز ۱۱',     sub: 'اکریلیک مهندسی با گوشه‌های تیز',   theme: 'snow',     glass: true,  trans: 28, r: '4px' },
  { id: 'cyber',           cat: 'future',  name: 'نئون سایبرپانک',       sub: 'لبه‌های برش‌خورده و درخشش نئونی',   theme: 'cosmos',   glass: true,  trans: 42, r: '2px 10px 2px 10px' },
  { id: 'aurora_glass',    cat: 'future',  name: 'منشور شفق قطبی',       sub: 'طیف نوری رنگارنگ و کریستالی',       theme: 'aurora',   glass: true,  trans: 50, r: '13px' },
  { id: 'liquid',          cat: 'future',  name: 'جیوه‌ی سیال',          sub: 'فرم‌های قطره‌ای و براق متالیک',     theme: 'lavender', glass: true,  trans: 40, r: '18px' },

  { id: 'bottom_nav',      cat: 'layout',  name: 'ناوبری پایین مدرن',    sub: 'انتقال تب‌ها به داک شناور پایین',    theme: 'navy',     glass: true,  trans: 34, r: '14px' },
  { id: 'compact_pro',     cat: 'layout',  name: 'فشرده‌ی حرفه‌ای (۳ ستون)', sub: 'چیدمان پرتراکم ۳ ستونی کتابخانه', theme: 'night',    glass: true,  trans: 25, r: '7px' },
  { id: 'magazine',        cat: 'layout',  name: 'گالری مجله‌ای عریض',   sub: 'کارت‌های افقی و پوسترگونه کتاب‌ها', theme: 'rose',     glass: true,  trans: 30, r: '11px' },
  { id: 'floating_island', cat: 'layout',  name: 'جزیره‌ی شناور',        sub: 'هدر و تب‌های جزیره‌ای جدا از لبه',  theme: 'emerald',  glass: true,  trans: 44, r: '16px' },
  { id: 'bento',           cat: 'layout',  name: 'بنتو گرید اپل',        sub: 'چیدمان شبکه‌ای ۲ ستونی کارت‌ها',   theme: 'snow',     glass: true,  trans: 26, r: '12px' },
  { id: 'origami',         cat: 'layout',  name: 'اوریگامی هندسی',       sub: 'کارت‌های نامتقارن با خط تای کاغذ',  theme: 'amber',    glass: true,  trans: 28, r: '12px 2px 12px 2px' },

  { id: 'minimal',         cat: 'modern',  name: 'مینیمال سوئیسی',       sub: 'خطوط معماری ظریف بدون سایه',        theme: 'snow',     glass: false, trans: 10, r: '2px' },
  { id: 'neomorph',        cat: 'modern',  name: 'نئومورفیک نرم',        sub: 'برجستگی‌های هم‌رنگ بدنه با سایه نرم', theme: 'pearl',  glass: false, trans: 15, r: '12px' },
  { id: 'brutal',          cat: 'modern',  name: 'نئوبروتالیسم پاپ',     sub: 'کادرهای مشکی ضخیم و سایه‌ی تیز',    theme: 'amber',    glass: false, trans: 10, r: '6px' },
  { id: 'clay',            cat: 'modern',  name: 'کلی‌مورفیسم سه‌بعدی',   sub: 'کارت‌های پفکی و حجم‌دار سه‌بعدی',   theme: 'rose',     glass: false, trans: 18, r: '16px' },
  { id: 'nordic',          cat: 'modern',  name: 'اسکاندیناوی آرام',     sub: 'فرم‌های سنگ‌ریزه‌ای و طبیعت‌گرا',   theme: 'sage',     glass: true,  trans: 28, r: '13px 4px 13px 4px' },
  { id: 'oled_pitch',      cat: 'modern',  name: 'اولد مطلق (OLED)',     sub: 'پس‌زمینه‌ی مشکی مطلق با خطوط نوری', theme: 'black',    glass: false, trans: 10, r: '10px' },

  { id: 'material3',       cat: 'digital', name: 'متریال یو گوگل (M3)',  sub: 'طراحی پیکسل گوگل با سطوح تونال',    theme: 'lavender', glass: false, trans: 20, r: '14px' },
  { id: 'terminal',        cat: 'digital', name: 'ترمینال هکری ماتریکس', sub: 'کادرهای درخشان سبز و خطوط اسکن',    theme: 'emerald',  glass: false, trans: 20, r: '1px' },
  { id: 'retro_os',        cat: 'digital', name: 'سیستم‌عامل رترو ۹۰',   sub: 'لبه‌های پخ‌خورده‌ی کلاسیک پیکسلی',  theme: 'paper',    glass: false, trans: 10, r: '0px' },
  { id: 'synthwave',       cat: 'digital', name: 'سینث‌ویو نئون ۸۰',     sub: 'گرادیان غروب نئونی بنفش و سرخابی', theme: 'amethyst', glass: true,  trans: 42, r: '10px' },
  { id: 'pastel_dream',    cat: 'digital', name: 'رویای پاستلی ابری',    sub: 'کارت‌های ابری لطیف با حاشیه‌ی روشن', theme: 'rose',    glass: true,  trans: 36, r: '16px' },

  { id: 'manuscript',      cat: 'classic', name: 'نسخه‌ی خطی زرکوب',     sub: 'جدول‌بندی دوخطی طلایی و اصیل',      theme: 'paper',    glass: false, trans: 15, r: '6px' },
  { id: 'leather',         cat: 'classic', name: 'مجلد چرمی دوخته‌شده',  sub: 'حاشیه‌های کوک‌خورده‌ی طلایی و چرم', theme: 'mocha',    glass: false, trans: 15, r: '8px' },
  { id: 'ink_zen',         cat: 'classic', name: 'مرکب و کاغذ ژاپنی',    sub: 'نوار عمودی قلم‌مو و کاغذ واشی',     theme: 'paper',    glass: false, trans: 15, r: '2px 9px 9px 2px' },
  { id: 'velvet',          cat: 'classic', name: 'تالار مخمل سلطنتی',    sub: 'مخمل تیره با قاب‌های زرین',         theme: 'amethyst', glass: true,  trans: 25, r: '12px' },
  { id: 'gazette',         cat: 'classic', name: 'روزنامه‌ی کلاسیک',     sub: 'خط‌کشی‌های تحریری و مطبوعاتی',      theme: 'sepia',    glass: false, trans: 10, r: '0px' },
  { id: 'academia',        cat: 'classic', name: 'دارک آکادمیا آکسفورد', sub: 'کتابخانه‌ی کلاسیک با سایه‌ی شمع',   theme: 'coal',     glass: false, trans: 18, r: '5px' }
];
var THEMES = {
  paper:    { name: 'کاغذی', bar: '#f5eed9', dark: false },
  snow:     { name: 'برفی', bar: '#ffffff', dark: false },
  sepia:    { name: 'سپیا', bar: '#ead9b7', dark: false },
  sage:     { name: 'نعناعی', bar: '#e6eddb', dark: false },
  rose:     { name: 'گلگون', bar: '#f7e6eb', dark: false },
  sky:      { name: 'آسمانی', bar: '#e3eff8', dark: false },
  lavender: { name: 'اسطوخودوس', bar: '#eae4f7', dark: false },
  amber:    { name: 'کهربایی', bar: '#f5e6cf', dark: false },
  pearl:    { name: 'مرواریدی', bar: '#e8f1f2', dark: false },
  night:    { name: 'شب', bar: '#161a1f', dark: true },
  navy:     { name: 'سرمه‌ای', bar: '#0e1829', dark: true },
  coal:     { name: 'ذغالی', bar: '#1c1612', dark: true },
  emerald:  { name: 'زمردی', bar: '#0a1f18', dark: true },
  amethyst: { name: 'یاقوت بنفش', bar: '#180d26', dark: true },
  aurora:   { name: 'شفق قطبی', bar: '#091d26', dark: true },
  mocha:    { name: 'موکا', bar: '#1f1511', dark: true },
  cosmos:   { name: 'کهکشانی', bar: '#0d1026', dark: true },
  black:    { name: 'مشکی', bar: '#050506', dark: true }
};
var THEME_ORDER = [
  'auto',
  'paper', 'snow', 'sepia', 'sage', 'rose', 'sky', 'lavender', 'amber', 'pearl',
  'night', 'navy', 'coal', 'emerald', 'amethyst', 'aurora', 'mocha', 'cosmos', 'black'
];
var SYS_EN = 'system-ui,-apple-system,Roboto';
var FA_FONTS = [
  { id: 'vazir', name: 'وزیرمتن', note: 'مدرن، هندسی و روان', stack: '"Vazirmatn"' },
  { id: 'notonaskh', name: 'نسخ نوتو (معیار)', note: 'خوانا، اصیل و مناسب مطالعه‌ی طولانی', stack: '"kf-notonaskh"' },
  { id: 'kufi', name: 'کوفی مدرن', note: 'ساختار هندسی و منظم، مناسب عنوان و متن', stack: '"kf-kufi"' },
  { id: 'notosans', name: 'بی‌سریف نوتو', note: 'تمیز، یکدست و امروزی', stack: '"kf-notosans"' },
  { id: 'nastaliq', name: 'نستعلیق تحریری', note: 'خوشنویسی کلاسیک ایرانی و شاعرانه', stack: '"kf-nastaliq"' },
  { id: 'naskh', name: 'نسخ کتابی', note: 'سریف و آرام، شبیه چاپ کتاب', stack: '"kf-naskh"' },
  { id: 'dejavu', name: 'ساده و درشت', note: 'حروف باز و خوانا برای متن‌های کوتاه', stack: '"kf-dejavu"' },
  { id: 'system', name: 'قلم گوشی', note: 'همان قلم پیش‌فرض دستگاه شما', stack: SYS_EN + ',"Noto Naskh Arabic","Noto Sans Arabic UI","Droid Arabic Naskh"' }
];
var EN_FONTS = [
  { id: 'auto', name: 'خودکار', note: 'شکلش با قلم فارسی فرق دارد', stack: '' },
  { id: 'inter', name: 'Inter', stack: '"ke-inter"' },
  { id: 'instrument', name: 'Instrument Sans', stack: '"ke-instrument"' },
  { id: 'poppins', name: 'Poppins', stack: '"ke-poppins"' },
  { id: 'adventor', name: 'Adventor Sans', stack: '"ke-adventor"' },
  { id: 'notosans', name: 'Noto Sans', stack: '"ke-notosans"' },
  { id: 'carlito', name: 'Carlito', stack: '"ke-carlito"' },
  { id: 'lora', name: 'Lora', stack: '"ke-lora"' },
  { id: 'crimson', name: 'Crimson Pro', stack: '"ke-crimson"' },
  { id: 'notoserif', name: 'Noto Serif', stack: '"ke-notoserif"' },
  { id: 'schola', name: 'Century Schola', stack: '"ke-schola"' },
  { id: 'bonum', name: 'Bookman Bonum', stack: '"ke-bonum"' },
  { id: 'termes', name: 'Times Termes', stack: '"ke-termes"' },
  { id: 'plex', name: 'IBM Plex Serif', stack: '"ke-plex"' },
  { id: 'baskerville', name: 'Libre Baskerville', stack: '"ke-baskerville"' },
  { id: 'caladea', name: 'Caladea', stack: '"ke-caladea"' },
  { id: 'pagella', name: 'TeX Gyre Pagella', stack: '"ke-pagella"' },
  { id: 'jetbrains', name: 'JetBrains Mono', stack: '"ke-jetbrains"' },
  { id: 'hand', name: 'Nothing You Could Do', stack: '"ke-hand"' },
  { id: 'system', name: 'System', stack: SYS_EN }
];
var WEIGHTS = [300, 400, 600];
// «خودکار»: قلم لاتینی که شکلش با قلم فارسی فرق دارد (فارسی بی‌سریف ← انگلیسی سریف‌دار و برعکس)
var EN_AUTO = { vazir: 'lora', kufi: 'crimson', notosans: 'notoserif', notonaskh: 'inter', nastaliq: 'crimson', naskh: 'inter', dejavu: 'crimson', system: 'lora' };
function effEn(st) { return findFont(EN_FONTS, st.fontEn === 'auto' ? (EN_AUTO[st.fontFa] || 'lora') : st.fontEn); }
function findFont(list, id) {
  for (var i = 0; i < list.length; i++) if (list[i].id === id) return list[i];
  return list[0];
}
function fontStack(st) {
  var fa = findFont(FA_FONTS, st.fontFa), en = effEn(st);
  return (en.stack ? en.stack + ',' : '') + fa.stack + ',"Vazirmatn",sans-serif';
}
var fontsAsked = {};
function preloadFonts(st) {
  try {
    if (!(document.fonts && document.fonts.load)) return;
    [findFont(FA_FONTS, st.fontFa).stack, effEn(st).stack].forEach(function (stk) {
      var m = /^"([^"]+)"/.exec(stk);
      if (!m || m[1] === 'Vazirmatn') return;
      [400, 700].forEach(function (w) {
        var key = m[1] + w;
        if (fontsAsked[key]) return;
        fontsAsked[key] = 1;
        document.fonts.load(w + ' 20px "' + m[1] + '"', 'Aa کتابچه').catch(function () {});
      });
    });
  } catch (e) {}
}
function systemNight() {
  try { if (bridge('isNight')) return !!A.isNight(); } catch (e) {}
  return !!(window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
}
function resolveTheme() {
  var st = S.data.settings;
  var t = st.theme;
  var isApple = !st.uiStyle || st.uiStyle === 'ios18' || st.uiStyle === 'vision' || st.uiStyle === 'bento';
  if (t === 'auto') return systemNight() ? 'night' : (isApple ? 'snow' : 'paper');
  return THEMES[t] ? t : (isApple ? 'snow' : 'paper');
}
var THEME_SURFACES = {
  paper:    { page: '#fcf6e6', bar: '#f5eed9', sheet: '#fbf6e8' },
  snow:     { page: '#ffffff', bar: '#ffffff', sheet: '#ffffff' },
  sepia:    { page: '#f3e5c8', bar: '#ead9b7', sheet: '#f1e3c5' },
  sage:     { page: '#eff4e5', bar: '#e6eddb', sheet: '#edf2e2' },
  rose:     { page: '#fdf4f6', bar: '#f7e6eb', sheet: '#fcf1f4' },
  sky:      { page: '#f2f8fd', bar: '#e3eff8', sheet: '#f0f7fc' },
  lavender: { page: '#f6f3fc', bar: '#eae4f7', sheet: '#f4f0fb' },
  amber:    { page: '#fdf6ec', bar: '#f5e6cf', sheet: '#fbf2e4' },
  pearl:    { page: '#f6fafa', bar: '#e8f1f2', sheet: '#f3f8f8' },
  night:    { page: '#1a1d23', bar: '#161a1f', sheet: '#1c2026' },
  navy:     { page: '#101a2d', bar: '#0e1829', sheet: '#13203a' },
  coal:     { page: '#211a15', bar: '#1c1612', sheet: '#251d17' },
  emerald:  { page: '#0d261e', bar: '#0a1f18', sheet: '#102d24' },
  amethyst: { page: '#1e112e', bar: '#180d26', sheet: '#221436' },
  aurora:   { page: '#0c2430', bar: '#091d26', sheet: '#0f2b38' },
  mocha:    { page: '#261a15', bar: '#1f1511', sheet: '#2b1d17' },
  cosmos:   { page: '#121633', bar: '#0d1026', sheet: '#151a3b' },
  black:    { page: '#0a0a0b', bar: '#050506', sheet: '#121214' }
};
function hexToRgba(hex, alpha) {
  hex = String(hex || '#ffffff').replace('#', '');
  if (hex.length === 3) hex = hex[0]+hex[0]+hex[1]+hex[1]+hex[2]+hex[2];
  var r = parseInt(hex.slice(0, 2), 16) || 0;
  var g = parseInt(hex.slice(2, 4), 16) || 0;
  var b = parseInt(hex.slice(4, 6), 16) || 0;
  return 'rgba(' + r + ',' + g + ',' + b + ',' + clamp(alpha, 0.08, 0.98).toFixed(2) + ')';
}
/* تصاویر زمینه‌ی ساده با خط‌های افقی شبیه به دفترچه (برای مطالعه‌ی کتاب‌ها و یادداشت‌ها) */
var PAGE_BGS = [
  { id: 'classic',     name: 'دفترچه کلاسیک آبی',    sub: 'کاغذ کرم با خط‌های افقی آبی و خط حاشیه',   bg: '#fdfaf2', ink: '#221c14', muted: '#7d705c', line: '#3b82f6', op: 0.28, margin: '#e11d48', style: 'solid', kind: 'lined' },
  { id: 'simple',      name: 'دفترچه تحریر ساده',    sub: 'کاغذ روشن با خط‌های افقی ساده و یکدست',    bg: '#fbf9f5', ink: '#1f1b16', muted: '#756c60', line: '#6b5e4c', op: 0.22, margin: '',        style: 'solid', kind: 'lined' },
  { id: 'warm',        name: 'دفترچه کاغذ کاهی',     sub: 'کاغذ کاهی گرم با خط‌های افقی قهوه‌ای',     bg: '#f5ead4', ink: '#332411', muted: '#856d4c', line: '#8a5a28', op: 0.25, margin: '#b45309', style: 'solid', kind: 'lined' },
  { id: 'theme_lined', name: 'دفترچه هماهنگ با پوسته', sub: 'خط‌های افقی ممتد روی رنگ پوسته‌ی فعلی',   bg: '',        ink: '',        muted: '',        line: 'auto',    op: 0.22, margin: '',        style: 'solid', kind: 'lined' },
  { id: 'mint',        name: 'دفترچه سبز مطالعه',    sub: 'کاغذ سبز ملایم آرام‌بخش چشم با خط افقی', bg: '#f1f7f0', ink: '#18261a', muted: '#5e7561', line: '#2e6a44', op: 0.23, margin: '#0d9488', style: 'solid', kind: 'lined' },
  { id: 'rose',        name: 'دفترچه گلگون ملایم',   sub: 'کاغذ صورتی روشن با خط‌های افقی ظریف',      bg: '#fdf5f7', ink: '#2d161e', muted: '#875f6d', line: '#b8336a', op: 0.21, margin: '',        style: 'solid', kind: 'lined' },
  { id: 'double',      name: 'دفترچه دوخط تحریری',   sub: 'خط‌های افقی دوبل ممتد مناسب مطالعه',      bg: '#fcf7ec', ink: '#281f14', muted: '#7f6e57', line: '#7c5832', op: 0.25, margin: '#c2410c', style: 'double', kind: 'lined' },
  { id: 'dark',        name: 'دفترچه شب (تیره)',     sub: 'کاغذ تیره با خط‌های افقی نقره‌ای ملایم',   bg: '#171b22', ink: '#e5e2dc', muted: '#8b93a2', line: '#94a3b8', op: 0.19, margin: '#f59e0b', style: 'solid', dark: true, kind: 'lined' },
  { id: 'img_parchment', name: 'تصویر کاغذ کهن',     sub: 'تصویر زمینه‌ی بافت کاغذ قدیمی و گرم',      bg: '#f4e7ce', ink: '#2c1d0d', muted: '#7a5f40', line: '#8a5a28', op: 0.18, margin: '',        style: 'img_parchment', kind: 'image' },
  { id: 'img_botanical', name: 'تصویر طبیعت و برگ',  sub: 'تصویر زمینه‌ی آرام‌بخش با نقش برگ‌های ملایم', bg: '#eff6f1', ink: '#16261b', muted: '#587260', line: '#2e6a44', op: 0.18, margin: '',        style: 'img_botanical', kind: 'image' },
  { id: 'img_sky',       name: 'تصویر آسمان آرام',   sub: 'تصویر زمینه‌ی آبی ملایم و ابری برای مطالعه', bg: '#f0f6fc', ink: '#142234', muted: '#5a708c', line: '#2563eb', op: 0.18, margin: '',        style: 'img_sky',       kind: 'image' },
  { id: 'img_night',     name: 'تصویر شب پرستاره',   sub: 'تصویر زمینه‌ی تیره با ستاره‌های ظریف',      bg: '#131824', ink: '#e6e4de', muted: '#8c96ab', line: '#64748b', op: 0.17, margin: '',        style: 'img_night',     dark: true, kind: 'image' },
  { id: 'none',        name: 'ساده (بدون خط)',       sub: 'صفحه‌ی کاغذی ساده بدون خطوط افقی',       bg: '',        ink: '',        muted: '',        line: '',        op: 0,    margin: '',        style: 'none', kind: 'lined' }
];
function findPageBg(id) {
  if (id === 'custom_img') {
    return { id: 'custom_img', name: 'تصویر انتخابی گالری', sub: 'تصویر دلخواه شما از گالری دستگاه', bg: '#fbf9f4', ink: '#1f1b16', muted: '#6b6257', line: '', op: 0, margin: '', style: 'custom_img', kind: 'image' };
  }
  for (var i = 0; i < PAGE_BGS.length; i++) if (PAGE_BGS[i].id === id) return PAGE_BGS[i];
  return PAGE_BGS[0];
}
function makePageDecorUri(pb) {
  if (!pb) return 'none';
  if (pb.id === 'custom_img') {
    var st = S.data && S.data.settings;
    var customSrc = st ? coverSrc({ cover: st.pageBgCover, coverData: st.pageBgImg }) : '';
    return customSrc ? 'url("' + customSrc + '")' : 'none';
  }
  if (pb.style === 'img_parchment') {
    var svgP = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 600" width="100%" height="100%" preserveAspectRatio="none">' +
      '<defs><radialGradient id="g1" cx="50%" cy="45%" r="65%"><stop offset="0%" stop-color="#fbf3e2"/><stop offset="70%" stop-color="#f3e3c3"/><stop offset="100%" stop-color="#e3cca0"/></radialGradient></defs>' +
      '<rect width="400" height="600" fill="url(#g1)"/>' +
      '<circle cx="60" cy="90" r="95" fill="#d9be8b" fill-opacity="0.16"/>' +
      '<circle cx="340" cy="510" r="120" fill="#cfaee6" fill-opacity="0.06"/>' +
      '<path d="M18 18 H382 V582 H18 Z" fill="none" stroke="#b6925b" stroke-opacity="0.32" stroke-width="1.5"/>' +
      '<path d="M24 24 H376 V576 H24 Z" fill="none" stroke="#b6925b" stroke-opacity="0.18" stroke-width="0.8"/>' +
      '</svg>';
    return 'url("data:image/svg+xml;utf8,' + encodeURIComponent(svgP) + '")';
  }
  if (pb.style === 'img_botanical') {
    var svgB = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 600" width="100%" height="100%" preserveAspectRatio="none">' +
      '<defs><linearGradient id="gb" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#f5faf6"/><stop offset="55%" stop-color="#eaf4ec"/><stop offset="100%" stop-color="#dff0e3"/></linearGradient></defs>' +
      '<rect width="400" height="600" fill="url(#gb)"/>' +
      '<path d="M0 130 Q90 90 150 20 Q85 40 0 85 Z" fill="#2e6a44" fill-opacity="0.07"/>' +
      '<path d="M400 480 Q300 510 240 590 Q320 570 400 530 Z" fill="#2e6a44" fill-opacity="0.08"/>' +
      '<circle cx="330" cy="80" r="70" fill="#52946b" fill-opacity="0.06"/>' +
      '<circle cx="70" cy="510" r="85" fill="#52946b" fill-opacity="0.06"/>' +
      '</svg>';
    return 'url("data:image/svg+xml;utf8,' + encodeURIComponent(svgB) + '")';
  }
  if (pb.style === 'img_sky') {
    var svgS = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 600" width="100%" height="100%" preserveAspectRatio="none">' +
      '<defs><linearGradient id="gs" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#e8f2fc"/><stop offset="50%" stop-color="#f3f8fd"/><stop offset="100%" stop-color="#ffffff"/></linearGradient></defs>' +
      '<rect width="400" height="600" fill="url(#gs)"/>' +
      '<circle cx="80" cy="85" r="75" fill="#93c5fd" fill-opacity="0.16"/>' +
      '<circle cx="155" cy="95" r="55" fill="#bfdbfe" fill-opacity="0.18"/>' +
      '<circle cx="320" cy="490" r="95" fill="#93c5fd" fill-opacity="0.12"/>' +
      '</svg>';
    return 'url("data:image/svg+xml;utf8,' + encodeURIComponent(svgS) + '")';
  }
  if (pb.style === 'img_night') {
    var svgN = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 600" width="100%" height="100%" preserveAspectRatio="none">' +
      '<defs><linearGradient id="gn" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#0f1522"/><stop offset="55%" stop-color="#151d2e"/><stop offset="100%" stop-color="#1b253b"/></linearGradient></defs>' +
      '<rect width="400" height="600" fill="url(#gn)"/>' +
      '<circle cx="70" cy="80" r="1.6" fill="#fde68a" fill-opacity="0.55"/>' +
      '<circle cx="310" cy="65" r="2" fill="#f8fafc" fill-opacity="0.45"/>' +
      '<circle cx="240" cy="140" r="1.3" fill="#f8fafc" fill-opacity="0.4"/>' +
      '<circle cx="95" cy="480" r="1.8" fill="#fde68a" fill-opacity="0.45"/>' +
      '<circle cx="335" cy="510" r="1.4" fill="#f8fafc" fill-opacity="0.4"/>' +
      '<circle cx="330" cy="105" r="45" fill="#38bdf8" fill-opacity="0.05"/>' +
      '</svg>';
    return 'url("data:image/svg+xml;utf8,' + encodeURIComponent(svgN) + '")';
  }
  return 'none';
}
function makeNotebookSvgUri(pb, stepPx, isDarkTheme) {
  if (!pb || pb.style === 'none' || pb.style === 'custom_img' || !pb.line) return 'none';
  var h = Math.max(18, Math.round(stepPx || 40));
  var y = h - 1;
  var col = pb.line === 'auto' ? (isDarkTheme ? '#cbd5e1' : '#574c3d') : pb.line;
  var op = pb.op || 0.24;
  var svg = '<svg xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" width="64" height="' + h + '" viewBox="0 0 64 ' + h + '">';
  if (pb.style === 'double') {
    var y2 = Math.max(4, Math.round(h * 0.66));
    svg += '<line x1="0" y1="' + y2 + '" x2="64" y2="' + y2 + '" stroke="' + col + '" stroke-opacity="' + (op * 0.48).toFixed(2) + '" stroke-width="0.85"/>';
    svg += '<line x1="0" y1="' + y + '" x2="64" y2="' + y + '" stroke="' + col + '" stroke-opacity="' + op + '" stroke-width="1.2"/>';
  } else {
    svg += '<line x1="0" y1="' + y + '" x2="64" y2="' + y + '" stroke="' + col + '" stroke-opacity="' + op + '" stroke-width="1.15"/>';
  }
  svg += '</svg>';
  return 'url("data:image/svg+xml;utf8,' + encodeURIComponent(svg) + '")';
}
function applyTheme() {
  var st = S.data.settings, d = document.documentElement, t = resolveTheme();
  var th = THEMES[t] || THEMES.paper;
  var pb = findPageBg(st.pageBg || 'classic');
  var lineStep = Math.max(15, Math.round((+st.fontSize || 21) * (+st.lineHeight || 1.95)));
  d.setAttribute('data-ui', st.uiStyle || 'ios18');
  d.setAttribute('data-theme', t);
  d.setAttribute('data-page-bg', pb.id);
  d.setAttribute('data-glass', st.glass !== false ? '1' : '0');
  d.setAttribute('data-just', st.justify ? '1' : '0');
  d.setAttribute('data-flip', st.flip);
  d.setAttribute('data-frame', st.frame ? '1' : '0');
  d.style.setProperty('--fs', st.fontSize + 'px');
  d.style.setProperty('--lh', st.lineHeight);
  d.style.setProperty('--line-step', lineStep + 'px');
  d.style.setProperty('--fw', st.weight);
  d.style.setProperty('--font', fontStack(st));
  var nbImg = makeNotebookSvgUri(pb, lineStep, !!th.dark);
  var nbCardImg = makeNotebookSvgUri(pb, 28, !!th.dark);
  var nbPreviewImg = makeNotebookSvgUri(pb, 26, !!th.dark);
  var nbDecorImg = makePageDecorUri(pb);
  d.style.setProperty('--nb-img', nbImg);
  d.style.setProperty('--nb-card-img', nbCardImg);
  d.style.setProperty('--nb-prev-img', nbPreviewImg);
  d.style.setProperty('--nb-decor-img', nbDecorImg);
  if (pb.bg) {
    d.style.setProperty('--nb-page', pb.bg);
    d.style.setProperty('--nb-ink', pb.ink);
    d.style.setProperty('--nb-muted', pb.muted);
  } else {
    d.style.removeProperty('--nb-page');
    d.style.removeProperty('--nb-ink');
    d.style.removeProperty('--nb-muted');
  }
  if (pb.margin) {
    d.style.setProperty('--nb-margin', hexToRgba(pb.margin, 0.30));
  } else {
    d.style.setProperty('--nb-margin', 'transparent');
  }
  var sf = THEME_SURFACES[t] || THEME_SURFACES.paper;
  var trans = clamp(st.glassTrans !== undefined ? +st.glassTrans : 32, 5, 88);
  var alpha = clamp(1 - (trans / 100), 0.12, 0.95);
  var blurPx = clamp(st.glassBlur !== undefined ? +st.glassBlur : 20, 0, 36);
  d.style.setProperty('--glass-bg', hexToRgba(sf.page, alpha));
  d.style.setProperty('--glass-bar', hexToRgba(sf.bar, clamp(alpha - 0.03, 0.10, 0.94)));
  d.style.setProperty('--glass-sheet', hexToRgba(sf.sheet, clamp(alpha + 0.05, 0.15, 0.96)));
  d.style.setProperty('--glass-blur', blurPx + 'px');
  preloadFonts(st);
  var barHex = (st.uiStyle === 'ios18' || !st.uiStyle) ? (th.dark ? '#161618' : '#f2f2f7') : th.bar;
  try { if (bridge('setBars')) A.setBars(barHex, !th.dark); } catch (e) {}
  try { if (bridge('keepScreenOn')) A.keepScreenOn(!!st.keepOn); } catch (e) {}
  var thBtn = $('#libTheme');
  if (thBtn) {
    thBtn.innerHTML = ic(th.dark ? 'sun' : 'moon', 21);
    thBtn.title = th.dark ? 'تغییر سریع به حالت روشن' : 'تغییر سریع به حالت شب';
  }
}
window.onSystemTheme = function () { if (S.data) { applyTheme(); } };
try {
  if (window.matchMedia) {
    var mqDark = window.matchMedia('(prefers-color-scheme: dark)');
    if (mqDark.addEventListener) mqDark.addEventListener('change', function () { if (S.data) applyTheme(); });
    else if (mqDark.addListener) mqDark.addListener(function () { if (S.data) applyTheme(); });
  }
} catch (e) {}

/* =====================================================================
   لایه‌ها (شیت، منو، دیالوگ) و دکمه‌ی بازگشت
   ===================================================================== */
var layers = [];
var layersEl = null;
function openLayer(node, o) {
  o = o || {};
  var L = { node: node, closed: false, onBack: o.onBack, onClose: o.onClose };
  layers.push(L);
  layersEl.appendChild(node);
  L.close = function (instant) {
    if (L.closed) return;
    L.closed = true;
    var i = layers.indexOf(L); if (i >= 0) layers.splice(i, 1);
    var sh = node.querySelector('.sheet');
    var done = function () { if (node.parentNode) node.parentNode.removeChild(node); };
    if (sh && !instant) { sh.classList.add('out'); setTimeout(done, 150); } else done();
    if (L.onClose) L.onClose();
  };
  return L;
}
window.handleBack = function () {
  if (layers.length) {
    var L = layers[layers.length - 1];
    if (L.onBack) L.onBack(); else L.close();
    return true;
  }
  if (S.view === 'reader' && S.immersive) { setImmersive(false); return true; }
  if (S.view === 'reader') { closeBook(); return true; }
  if (S.view === 'library' && S.libTab !== 'books') { setLibTab('books'); return true; }
  return false;
};

function sheet(title, build, o) {
  o = o || {};
  var dim = h('div', { class: 'dim' });
  var body = h('div', { class: 'sheet-b' });
  var closeBtn = h('button', { class: 'ibtn', 'aria-label': 'بستن', html: ic('x') });
  var sh = h('div', { class: 'sheet' + (o.tall ? ' tall' : '') }, [
    h('div', { class: 'sheet-h' }, [h('h3', { text: title }), closeBtn]), o.top || null, body
  ]);
  var node = h('div', { class: 'layer' }, [dim, sh]);
  var L = openLayer(node, { onClose: o.onClose });
  dim.addEventListener('click', function () { L.close(); });
  closeBtn.addEventListener('click', function () { L.close(); });
  build(body, L);
  return L;
}
function dialog(o) {
  return new Promise(function (resolve) {
    var done = false;
    var input = null;
    var dim = h('div', { class: 'dim' });
    var box = h('div', { class: 'dialog' });
    box.appendChild(h('h3', { text: o.title || '' }));
    if (o.message) box.appendChild(h('p', { text: o.message }));
    if (o.input) {
      input = h('input', { class: 'field', type: 'text', value: o.value || '', placeholder: o.placeholder || '',
        dir: 'auto', maxlength: o.max || 120, inputmode: o.number ? 'numeric' : 'text' });
      box.appendChild(input);
    }
    var L;
    var fin = function (v) { if (done) return; done = true; L.close(true); resolve(v); };
    var ok = h('button', { class: 'btn ' + (o.danger ? 'danger' : 'pri'), text: o.ok || 'تأیید' });
    var cancel = h('button', { class: 'btn', text: o.cancel || 'انصراف' });
    box.appendChild(h('div', { class: 'acts' }, o.noCancel ? [ok] : [cancel, ok]));
    L = openLayer(h('div', { class: 'layer' }, [dim, box]), { onBack: function () { fin(null); } });
    ok.addEventListener('click', function () { fin(input ? input.value : true); });
    cancel.addEventListener('click', function () { fin(null); });
    dim.addEventListener('click', function () { fin(null); });
    if (input) {
      input.addEventListener('keydown', function (e) { if (e.key === 'Enter') fin(input.value); });
      setTimeout(function () { input.focus(); input.select(); }, 60);
    }
  });
}
function menu(anchor, items) {
  var dim = h('div', { class: 'dim', style: 'background:transparent;animation:none' });
  var m = h('div', { class: 'menu' });
  var L = openLayer(h('div', { class: 'layer' }, [dim, m]));
  items.forEach(function (it) {
    if (it === '-') { m.appendChild(h('hr')); return; }
    var b = h('button', { class: it.danger ? 'danger' : '', html: ic(it.icon, 20) + '<span></span>' });
    b.lastChild.textContent = it.label;
    b.addEventListener('click', function () { L.close(true); setTimeout(it.fn, 0); });
    m.appendChild(b);
  });
  dim.addEventListener('click', function () { L.close(true); });
  var r = anchor.getBoundingClientRect(), W = window.innerWidth, H = window.innerHeight;
  var maxH = Math.max(200, H - 24);
  m.style.maxHeight = maxH + 'px';
  var mw = m.offsetWidth, mh = Math.min(m.offsetHeight, maxH);
  var left = clamp(r.left, 8, W - mw - 8);
  var top = r.bottom + 4;
  if (top + mh > H - 12) top = Math.max(12, Math.min(r.top - mh - 4, H - mh - 12));
  m.style.left = left + 'px'; m.style.top = top + 'px';
  return L;
}
var toastTimer = null;
function toast(msg, action) {
  var t = $('#toast');
  t.textContent = '';
  t.appendChild(h('span', { text: msg }));
  if (action) {
    var b = h('button', { text: action.label });
    b.addEventListener('click', function () { t.classList.remove('show'); action.fn(); });
    t.appendChild(b);
  }
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(function () { t.classList.remove('show'); }, action ? 6500 : 2200);
}

/* =====================================================================
   ساختار صفحه‌ی کاغذی
   ===================================================================== */
function buildPage(el) {
  el.innerHTML = '';
  var scroll = h('div', { class: 'page-scroll' });
  scroll.appendChild(h('div', { class: 'page-text' }));
  var blank = h('div', { class: 'blank-leaf' });
  blank.appendChild(h('button', { class: 'plus', 'aria-label': 'صفحه جدید', html: ic('plus', 34) }));
  blank.appendChild(h('b', { text: 'صفحه‌ی جدید' }));
  blank.appendChild(h('span', { class: 'sm', text: 'برای نوشتن یا چسباندن متن در این صفحه بزنید.' }));
  scroll.appendChild(blank);
  el.appendChild(h('div', { class: 'frame' }));
  el.appendChild(h('div', { class: 'spine' }));
  el.appendChild(scroll);
  el.appendChild(h('div', { class: 'bm-ribbon', 'aria-hidden': 'true', html: ic('bookmarkFill', 16) }));
  el.appendChild(h('div', { class: 'pno' }));
  el.appendChild(h('div', { class: 'shade' }));
  $('.plus', el).addEventListener('click', function (e) { e.stopPropagation(); addPageFlow(); });
}

var pBase, pTop, stage;
function pageParts(el) {
  return { scroll: $('.page-scroll', el), text: $('.page-text', el), pno: $('.pno', el), shade: $('.shade', el), blank: $('.blank-leaf', el) };
}
function renderPage(el, idx, scrollTop, flash) {
  var b = curBook(), p = pageParts(el);
  var isBlank = idx >= b.pages.length || idx < 0;
  el.classList.toggle('blank', isBlank);
  if (isBlank) {
    el.classList.remove('bookmarked');
    p.text.textContent = '';
    p.pno.textContent = '';
    var emptyBook = b.pages.length === 0;
    $('b', p.blank).textContent = emptyBook ? 'این کتاب هنوز صفحه‌ای ندارد' : 'صفحه‌ی جدید';
    $('.sm', p.blank).textContent = emptyBook ? 'اولین صفحه را بنویسید یا متنی را بچسبانید.' : 'برای افزودن صفحه‌ی بعدی بزنید.';
    p.scroll.scrollTop = 0;
    return;
  }
  var pg = b.pages[idx];
  el.classList.toggle('bookmarked', !!pg.bm);
  var trMode = b.trMode || 'off';
  if (trMode === 'full' || trMode === 'bilingual') {
    renderTranslatedPage(p.text, b, pg, idx, trMode, el === pBase);
  } else {
    renderLines(p.text, pg.text, pg.hl, flash || sayRange(pg));
  }
  p.pno.textContent = fa(idx + 1);
  p.scroll.scrollTop = scrollTop || 0;
}

/* =====================================================================
   خواندن: نوار بالا/پایین و ناوبری
   ===================================================================== */
function setIcons() {
  $('#brandMark').innerHTML = '<img class="brand-logo" src="logo.png" alt="" draggable="false">';
  $('#tabBooksIc').innerHTML = ic('book', 18);
  $('#tabWordsIc').innerHTML = ic('words', 18);
  if ($('#tabQuickIc')) $('#tabQuickIc').innerHTML = ic('layers', 18);
  if ($('#tabNotesIc')) $('#tabNotesIc').innerHTML = ic('note', 18);
  if ($('#libStats')) $('#libStats').innerHTML = ic('clock', 21);
  if ($('#libSearch')) $('#libSearch').innerHTML = ic('search', 21);
  if ($('#libTheme')) $('#libTheme').innerHTML = ic('moon', 21);
  $('#libMore').innerHTML = ic('dots');
  $('#fabNewBook').innerHTML = ic('plus', 22) + '<span>کتاب جدید</span>';
  $('#rdBack').innerHTML = ic('back');
  if ($('#rdTr')) $('#rdTr').innerHTML = ic('translate', 21);
  if ($('#rdBm')) $('#rdBm').innerHTML = ic('bookmark', 21);
  if ($('#rdBg')) $('#rdBg').innerHTML = ic('notebook', 21);
  if ($('#rdSearch')) $('#rdSearch').innerHTML = ic('search', 22);
  $('#rdToc').innerHTML = ic('list', 22);
  if ($('#rdHl')) $('#rdHl').innerHTML = ic('mark', 22);
  if ($('#rdShare')) $('#rdShare').innerHTML = ic('share', 21);
  $('#rdMore').innerHTML = ic('dots');
  $('#bSay').innerHTML = ic('speaker', 22);
  $('#bEdit').innerHTML = ic('edit', 22);
  $('#bAdd').innerHTML = ic('plus', 24);
  setDirIcons();
}
function setDirIcons() {
  var rtl = S.data.settings.flip === 'rtl';
  $('#bPrev').innerHTML = ic(rtl ? 'back' : 'forward', 24);
  $('#bNext').innerHTML = ic(rtl ? 'forward' : 'back', 24);
}
function updateBars() {
  var b = curBook(); if (!b) return;
  var n = b.pages.length, i = S.index;
  var pct = n ? Math.round(clamp(Math.min(i + 1, n) / n, 0, 1) * 100) : 0;
  var pg = i < n ? b.pages[i] : null;
  $('#rdTitle').textContent = b.title;
  var remTxt = n ? (' · ' + fa(pct) + '٪') : '';
  $('#rdSub').textContent = n ? ('صفحه ' + fa(Math.min(i + 1, n)) + ' از ' + fa(n) + remTxt) : 'کتاب خالی';
  $('#bPosText').textContent = i >= n ? (n ? 'صفحه‌ی جدید' : 'خالی') : 'صفحه ' + fa(i + 1) + ' از ' + fa(n);
  $('#bPosFill').style.width = pct + '%';
  var fFill = $('#rdFocusFill');
  if (fFill) fFill.style.width = pct + '%';
  var bmBtn = $('#rdBm');
  if (bmBtn) {
    var isBm = !!(pg && pg.bm);
    bmBtn.disabled = !pg;
    bmBtn.classList.toggle('bm-on', isBm);
    bmBtn.innerHTML = ic(isBm ? 'bookmarkFill' : 'bookmark', 21);
    bmBtn.title = isBm ? 'حذف نشانک این صفحه' : 'نشانک‌گذاری این صفحه';
  }
  $('#bPrev').disabled = i <= 0;
  $('#bNext').disabled = i >= n;
  $('#bEdit').disabled = i >= n;
  updateTrBtn();
  updateSayBtn();
}
function hideBar() {
  var bar = $('#actbar');
  bar.classList.remove('show');
  S.barMode = null; S.barHid = null;
}
function currentRoot() { return pageParts(pBase).text; }
function currentPage() { var b = curBook(); return b ? b.pages[S.index] : null; }

function showPageNow(idx, opts) {
  opts = opts || {};
  var b = curBook(); if (!b) return;
  var prevIdx = S.index;
  S.index = clamp(idx, 0, b.pages.length);
  if (S.index !== prevIdx && S.index < b.pages.length) recordStudyPage();
  b.last = S.index;
  savePosSoon();
  hideBar();
  renderPage(pBase, S.index, opts.scroll || 0, opts.flash || null);
  pTop.style.display = 'none';
  pBase.style.transform = '';
  updateBars();
  if (opts.flash) {
    var sc = pageParts(pBase).scroll, f = $('.flash', pageParts(pBase).text);
    if (f) {
      var r = f.getBoundingClientRect(), sr = sc.getBoundingClientRect();
      sc.scrollTop += (r.top - sr.top) - sc.clientHeight * 0.3;
    }
    clearTimeout(S.flashTimer);
    S.flashTimer = setTimeout(function () {
      $$('.flash', pageParts(pBase).text).forEach(function (n) { n.classList.remove('flash'); });
    }, 2400);
  } else ttsReveal();
}

/* ---------- ورق‌زدن سه‌بعدی طبیعی به چپ و راست + اسکرول لمسی نرم ----------
   v2.3 — بازنویسی کامل موتور لمس:
   • به‌جای رویدادهای touch از Pointer Events + pointer-capture استفاده می‌شود. در نسخه‌ی قبل، هنگام
     شروع ورق‌زدن متنِ زیر انگشت (عنصر .ln) از DOM حذف و دوباره ساخته می‌شد و مرورگر دیگر
     touchmove/touchend را به برنامه نمی‌رساند؛ ورق وسط راه گیر می‌کرد و هرگز تمام نمی‌شد.
   • به‌روزرسانی حرکت فقط یک‌بار در هر فریم (requestAnimationFrame) انجام می‌شود.
   • سایه‌ی برگ یک لایه‌ی جداست و فقط opacity/transform آن عوض می‌شود (نه box-shadow در هر فریم).
   • در پایان ورق، صفحه‌ی مقصد دوباره ساخته نمی‌شود (پرش و لرزش پایان ورق حذف شد). */
var THETA = 86;
var flipSh = null;
var SHADE_TURN_RIGHT = 'linear-gradient(to right, rgba(0,0,0,0.25) 0%, rgba(255,255,255,0.15) 28%, rgba(0,0,0,0.03) 72%, rgba(0,0,0,0.30) 100%)';
var SHADE_TURN_LEFT = 'linear-gradient(to left, rgba(0,0,0,0.25) 0%, rgba(255,255,255,0.15) 28%, rgba(0,0,0,0.03) 72%, rgba(0,0,0,0.30) 100%)';
function dirSign() { return S.data.settings.flip === 'ltr' ? -1 : 1; }
function easeInOut(t) { return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; }
function easeOutCubic(t) { return 1 - Math.pow(1 - t, 3); }
function setFlipProgress(f, p) {
  p = clamp(p, 0, 1);
  f.p = p;
  var sign = f.turnRight ? 1 : -1;
  var arch = Math.sin(p * Math.PI);
  var tf = 'rotateY(' + (sign * p * THETA).toFixed(2) + 'deg) scaleX(' + (1 - arch * 0.032).toFixed(4) + ')';
  pTop.style.transform = tf;
  pTop.style.opacity = p > 0.88 ? clamp((1 - p) / 0.12, 0, 1).toFixed(3) : '1';
  if (flipSh) {
    flipSh.style.transform = tf;
    flipSh.style.opacity = arch.toFixed(3);
  }
  f.topShade.style.opacity = (clamp(p * 1.15, 0, 1) * 0.72).toFixed(3);
  f.baseShade.style.opacity = ((1 - p) * 0.25).toFixed(3);
}
function beginFlip(forward) {
  var b = curBook(); if (!b) return null;
  var n = b.pages.length;
  if (forward && S.index >= n) return null;
  if (!forward && S.index <= 0) return null;
  var sc = pageParts(pBase).scroll.scrollTop;
  var turnRight = forward ? (dirSign() > 0) : (dirSign() < 0);
  var f = { forward: forward, turnRight: turnRight, p: 0, from: S.index, to: S.index + (forward ? 1 : -1), sc: sc, raf: 0, done: false, target: 0, drag: false,
    topShade: pageParts(pTop).shade, baseShade: pageParts(pBase).shade };
  hideBar();
  try { window.getSelection && window.getSelection().removeAllRanges(); } catch (e) {}
  renderPage(pTop, f.from, sc);
  renderPage(pBase, f.to, 0);
  var origin = turnRight ? '100% 50%' : '0% 50%';
  pTop.style.transformOrigin = origin;
  f.topShade.style.background = turnRight ? SHADE_TURN_RIGHT : SHADE_TURN_LEFT;
  if (flipSh) {
    flipSh.style.transformOrigin = origin;
    flipSh.className = turnRight ? 'r' : 'l';
    flipSh.style.display = 'block';
  }
  pTop.style.display = 'block';
  S.flip = f;
  setFlipProgress(f, 0);
  return f;
}
function finishFlip(f, commit) {
  if (f.done) return;
  f.done = true;
  cancelAnimationFrame(f.raf);
  if (S.flip === f) S.flip = null;
  f.topShade.style.opacity = '0';
  f.topShade.style.background = '';
  f.baseShade.style.opacity = '0';
  pTop.style.opacity = '';
  pTop.style.transformOrigin = '';
  if (flipSh) { flipSh.style.display = 'none'; flipSh.style.opacity = '0'; flipSh.style.transform = ''; }
  if (!curBook()) { pTop.style.display = 'none'; pTop.style.transform = ''; return; }
  if (commit) {
    // صفحه‌ی مقصد همان لحظه‌ی beginFlip در pBase ساخته شده؛ دوباره‌سازی لازم نیست.
    var b = curBook();
    S.index = f.to; b.last = S.index; savePosSoon();
  } else {
    renderPage(pBase, f.from, f.sc);
  }
  pTop.style.display = 'none';
  pTop.style.transform = '';
  updateBars();
  ttsReveal();
}
function animateFlip(f, target, dur, cb) {
  cancelAnimationFrame(f.raf);
  f.target = target;
  var from = f.p, t0 = performance.now();
  if (!S.data.settings.anim) { setFlipProgress(f, target); finishFlip(f, target === 1); if (cb) cb(); return; }
  var easeFn = f.drag ? easeOutCubic : easeInOut;
  var D = Math.max(110, dur * Math.abs(target - from));
  (function step(now) {
    var k = clamp((now - t0) / D, 0, 1);
    setFlipProgress(f, from + (target - from) * easeFn(k));
    if (k < 1) f.raf = requestAnimationFrame(step);
    else { finishFlip(f, target === 1); if (cb) cb(); }
  })(t0);
}
function flipTo(forward) {
  if (S.flip) {
    var cur = S.flip; finishFlip(cur, cur.target === 1);
  }
  var f = beginFlip(forward);
  if (!f) { nudge(forward); return; }
  animateFlip(f, 1, 460);
}
function nudge(forward) {
  var s = dirSign() * (forward ? 1 : -1);
  pBase.style.transition = 'transform .14s ease-out';
  pBase.style.transform = 'translateX(' + (s * 14) + 'px)';
  setTimeout(function () {
    pBase.style.transform = '';
    setTimeout(function () { pBase.style.transition = ''; }, 150);
  }, 115);
}

function setupGestures() {
  var d = null, raf = 0;

  function stopRaf() { if (raf) { cancelAnimationFrame(raf); raf = 0; } }
  function release(dd) {
    if (dd && dd.cap) { try { stage.releasePointerCapture(dd.id); } catch (e) {} dd.cap = false; }
  }
  function capture(dd) {
    if (dd.cap) return;
    try { stage.setPointerCapture(dd.id); dd.cap = true; } catch (e) {}
  }
  function startGesture(e) {
    if (S.flip) { var cur0 = S.flip; finishFlip(cur0, cur0.target === 1); }
    var scEl = pageParts(pBase).scroll;
    var now = performance.now();
    S.touching = true;
    d = {
      id: e.pointerId,
      isMouse: e.pointerType === 'mouse',
      x0: e.clientX, y0: e.clientY, cx: e.clientX, cy: e.clientY,
      t0: now,
      scroll0: scEl ? scEl.scrollTop : 0,
      axis: null, started: false, f: null, forward: false, cap: false,
      last: [{ x: e.clientX, y: e.clientY, t: now }]
    };
  }
  /* موقعیت فعلی انگشت را به پیشرفت ورق تبدیل می‌کند (بیشینه یک‌بار در هر فریم) */
  function applyDrag(dd) {
    if (!dd || dd.axis !== 'x') return;
    var dx = dd.cx - dd.x0;
    var curForward = dx * dirSign() > 0;
    if (dd.f && curForward !== dd.forward && Math.abs(dx) > 12) {
      finishFlip(dd.f, false);
      dd.forward = curForward;
      dd.f = beginFlip(curForward);
      if (dd.f) dd.f.drag = true;
    }
    if (dd.f) {
      var W = Math.max(180, stage.clientWidth);
      var p = ((dx * dirSign() > 0) === dd.forward) ? clamp(Math.abs(dx) / (W * 0.70), 0, 1) : 0;
      setFlipProgress(dd.f, p);
    } else {
      pBase.style.transform = 'translateX(' + clamp(dx * 0.22, -26, 26).toFixed(1) + 'px)';
    }
  }
  function frame() {
    raf = 0;
    applyDrag(d);
  }
  function moveGesture(e) {
    var dx = e.clientX - d.x0, dy = e.clientY - d.y0;
    var now = performance.now();
    d.cx = e.clientX; d.cy = e.clientY;
    if (!d.axis) {
      if (Math.abs(dx) < 7 && Math.abs(dy) < 7) return;
      var sel = window.getSelection && window.getSelection();
      if (sel && !sel.isCollapsed) { release(d); d = null; S.touching = false; return; }
      if (Math.abs(dx) > Math.abs(dy) * 1.08 && Math.abs(dx) > 8) {
        d.axis = 'x';
        d.forward = dx * dirSign() > 0;
        d.started = true;
        capture(d);
        d.f = beginFlip(d.forward);
        if (d.f) d.f.drag = true;
      } else if (Math.abs(dy) > 7) {
        d.axis = 'y';
        if (!d.isMouse) return;      // لمس: اسکرول عمودی را خود مرورگر انجام می‌دهد (pan-y)
        capture(d);
      } else {
        return;
      }
    }
    if (d.axis === 'y') {
      if (d.isMouse) {
        var scEl = pageParts(pBase).scroll;
        if (scEl) scEl.scrollTop = d.scroll0 - dy;
      }
      return;
    }
    // محور افقی
    d.last.push({ x: e.clientX, y: e.clientY, t: now });
    while (d.last.length > 1 && now - d.last[0].t > 90) d.last.shift();
    if (!raf) raf = requestAnimationFrame(frame);
  }
  function endGesture(e, cancelled) {
    if (!d) return;
    stopRaf();
    var dd = d; d = null;
    S.touching = false;
    release(dd);
    var x = e ? e.clientX : dd.cx, y = e ? e.clientY : dd.cy;
    if (e) { dd.cx = x; dd.cy = y; }
    if (dd.axis === 'x' && dd.started) {
      applyDrag(dd);   // آخرین موقعیت انگشت (ممکن است فریم قبلی هنوز اعمال نشده باشد)
      if (!dd.f) {
        pBase.style.transition = 'transform .16s ease-out';
        pBase.style.transform = '';
        setTimeout(function () { pBase.style.transition = ''; }, 180);
        return;
      }
      var f = dd.f;
      if (cancelled) {
        animateFlip(f, f.p > 0.5 ? 1 : 0, 260);
        return;
      }
      var last = dd.last[0], now = performance.now();
      var dt = last ? Math.max(1, now - last.t) : 16;
      var v = last && now > last.t ? (x - last.x) / dt : 0;
      var towards = (v * dirSign() > 0) === dd.forward ? Math.abs(v) : -Math.abs(v);
      var commit = f.p > 0.22 || (towards > 0.18 && f.p > 0.03);
      if (towards < -0.22) commit = false;
      animateFlip(f, commit ? 1 : 0, 390);
      return;
    }
    if (!dd.axis && !cancelled && (performance.now() - dd.t0 < 320)) {
      var stRect = stage.getBoundingClientRect();
      var relX = x - stRect.left;
      if (relX >= 0 && relX <= 30) {
        var rtlA = S.data.settings.flip === 'rtl';
        flipTo(rtlA);
      } else if (relX >= stRect.width - 30 && relX <= stRect.width) {
        var rtlB = S.data.settings.flip === 'rtl';
        flipTo(!rtlB);
      }
    }
  }

  stage.addEventListener('pointerdown', function (e) {
    if (!e.isPrimary) return;
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    startGesture(e);
  });
  stage.addEventListener('pointermove', function (e) {
    if (!d || e.pointerId !== d.id) return;
    moveGesture(e);
  });
  stage.addEventListener('pointerup', function (e) {
    if (!d || e.pointerId !== d.id) return;
    endGesture(e, false);
  });
  stage.addEventListener('pointercancel', function (e) {
    if (!d || e.pointerId !== d.id) return;
    endGesture(e, true);
  });
  // اگر برنامه به پس‌زمینه رفت یا لمس نیمه‌کاره ماند، ورق نیمه‌کاره رها نشود
  window.addEventListener('blur', function () { if (d) endGesture(null, true); });
  document.addEventListener('visibilitychange', function () { if (document.hidden && d) endGesture(null, true); });

  setupListTouchScrolling();
}

function setupListTouchScrolling() {
  ['#libList', '#wordList', '#noteList'].forEach(function (sel) {
    var container = $(sel);
    if (!container || container.__touchScrollWired) return;
    container.__touchScrollWired = true;
    var dragState = null;
    function getStageScroller() {
      return $('.no-scroll-stage', container);
    }
    container.addEventListener('mousedown', function (e) {
      if (e.button !== 0) return;
      if (e.target.closest && e.target.closest('input,textarea,select')) return;
      var sc = getStageScroller();
      if (!sc) return;
      dragState = { y0: e.clientY, x0: e.clientX, top0: sc.scrollTop, moved: false, sc: sc };
    });
    window.addEventListener('mousemove', function (e) {
      if (!dragState) return;
      var dy = e.clientY - dragState.y0, dx = e.clientX - dragState.x0;
      if (!dragState.moved && Math.abs(dy) > 6 && Math.abs(dy) > Math.abs(dx)) {
        dragState.moved = true;
      }
      if (dragState.moved) {
        dragState.sc.scrollTop = dragState.top0 - dy;
        e.preventDefault();
      }
    });
    window.addEventListener('mouseup', function () {
      if (!dragState) return;
      if (dragState.moved) {
        container.__suppressClickUntil = Date.now() + 120;
      }
      dragState = null;
    });
    container.addEventListener('click', function (e) {
      if (container.__suppressClickUntil && Date.now() < container.__suppressClickUntil) {
        e.stopPropagation();
        e.preventDefault();
      }
    }, true);
  });
}

/* =====================================================================
   انتخاب متن و هایلایت
   ===================================================================== */
function buildActBar(mode, hid) {
  var bar = $('#actbar');
  bar.innerHTML = '';
  var pg = currentPage(), curColor = null;
  if (mode === 'hl' && pg) {
    for (var i = 0; i < pg.hl.length; i++) if (pg.hl[i].id === hid) curColor = pg.hl[i].c;
  }
  function guard(b) {
    b.addEventListener('pointerdown', function (e) { e.preventDefault(); S.barTouch = true; setTimeout(function () { S.barTouch = false; }, 1500); });
    return b;
  }
  var grid = h('div', { class: 'sw-grid' });
  COLORS.forEach(function (c) {
    var b = guard(h('button', { class: 'swatch' + (curColor === c ? ' cur' : ''), 'data-c': c, 'aria-label': 'هایلایت ' + COLOR_NAMES[c], title: COLOR_NAMES[c] }));
    b.addEventListener('click', function () { S.barTouch = false; applyColor(mode, hid, c); });
    grid.appendChild(b);
  });
  bar.appendChild(grid);
  bar.appendChild(h('span', { class: 'vsep' }));
  var acts = h('div', { class: 'acts' });
  var del = guard(h('button', { class: 'ibtn', 'aria-label': mode === 'hl' ? 'حذف هایلایت' : 'پاک کردن هایلایت', html: ic('eraser', 22) }));
  del.addEventListener('click', function () { S.barTouch = false; removeColor(mode, hid); });
  acts.appendChild(del);
  var cp = guard(h('button', { class: 'ibtn', 'aria-label': 'کپی', html: ic('copy', 22) }));
  cp.addEventListener('click', function () { S.barTouch = false; copyFromBar(mode, hid); });
  acts.appendChild(cp);
  var say = guard(h('button', { class: 'ibtn', 'aria-label': 'خواندن از اینجا', html: ic('speaker', 22) }));
  say.addEventListener('click', function () { S.barTouch = false; sayFromBar(mode, hid); });
  acts.appendChild(say);
  var wd = guard(h('button', { class: 'ibtn', id: 'barWord', 'aria-label': 'ذخیره‌ی واژه', title: 'ذخیره‌ی واژه', html: ic('words', 22) }));
  wd.addEventListener('click', function () { S.barTouch = false; wordFromBar(mode, hid); });
  acts.appendChild(wd);
  var nt = guard(h('button', { class: 'ibtn', id: 'barNote', 'aria-label': 'ثبت در یادداشت‌ها', title: 'ثبت در یادداشت‌ها', html: ic('note', 22) }));
  nt.addEventListener('click', function () { S.barTouch = false; noteFromBar(mode, hid); });
  acts.appendChild(nt);
  bar.appendChild(acts);
}
function placeBar(rect) {
  var bar = $('#actbar');
  var st = stage.getBoundingClientRect();
  var low = rect && rect.height > 0 && ((rect.top + rect.bottom) / 2 - st.top) > st.height * 0.52;
  bar.classList.toggle('top', !!low);
}
function showBar(mode, hid, rect) {
  var bar = $('#actbar');
  placeBar(rect);
  if (S.barMode === mode && S.barHid === hid && bar.classList.contains('show')) return;
  S.barMode = mode; S.barHid = hid;
  buildActBar(mode, hid);
  bar.classList.remove('show'); void bar.offsetWidth;
  bar.classList.add('show');
}
var selTimer = null;
function onSelectionChange() {
  if (S.view !== 'reader' || S.flip || layers.length) return;
  var trB = curBook(); if (trB && trB.trMode && trB.trMode !== 'off') return;
  clearTimeout(selTimer);
  selTimer = setTimeout(function () {
    var pg = currentPage(); if (!pg) return;
    var o = getSelOffsets(currentRoot(), pg.text);
    if (o) {
      S.lastSel = { id: pg.id, s: o.s, e: o.e, t: Date.now() };
      var rg = null; try { rg = window.getSelection().getRangeAt(0).getBoundingClientRect(); } catch (er) {}
      showBar('sel', undefined, rg);
    } else if (S.barMode === 'sel' && !S.barTouch) {
      setTimeout(function () {
        var pg2 = currentPage();
        if (S.barMode === 'sel' && !S.barTouch && !(pg2 && getSelOffsets(currentRoot(), pg2.text))) hideBar();
      }, 350);
    }
  }, 60);
}
function selectionTarget() {
  var pg = currentPage(); if (!pg) return null;
  var o = getSelOffsets(currentRoot(), pg.text);
  if (!o && S.lastSel && S.lastSel.id === pg.id && Date.now() - S.lastSel.t < 20000) o = { s: S.lastSel.s, e: S.lastSel.e };
  return o ? { pg: pg, s: Math.min(o.s, pg.text.length), e: Math.min(o.e, pg.text.length) } : null;
}
function rerenderCurrent() {
  var sc = pageParts(pBase).scroll.scrollTop;
  renderPage(pBase, S.index, sc);
}
function clearSel() { try { window.getSelection().removeAllRanges(); } catch (e) {} S.lastSel = null; }
function applyColor(mode, hid, c) {
  var b = curBook(), pg = currentPage(); if (!pg) return;
  if (mode === 'hl') {
    pg.hl.forEach(function (x) { if (x.id === hid) x.c = c; });
    pg.hl = mergeAdj(pg.hl);
    touch(b, pg); rerenderCurrent(); hideBar();
    return;
  }
  var t = selectionTarget();
  if (!t) { hideBar(); return; }
  addHighlight(t.pg, t.s, t.e, c);
  S.data.settings.color = c;
  touch(b, t.pg);
  clearSel(); rerenderCurrent(); hideBar();
}
function removeColor(mode, hid) {
  var b = curBook(), pg = currentPage(); if (!pg) return;
  if (mode === 'hl') {
    pg.hl = pg.hl.filter(function (x) { return x.id !== hid; });
    touch(b, pg); rerenderCurrent(); hideBar();
    return;
  }
  var t = selectionTarget();
  if (!t) { hideBar(); return; }
  var before = JSON.stringify(t.pg.hl);
  removeHighlightRange(t.pg, t.s, t.e);
  if (JSON.stringify(t.pg.hl) !== before) { touch(b, t.pg); toast('هایلایت پاک شد'); }
  else toast('در این بخش هایلایتی نبود');
  clearSel(); rerenderCurrent(); hideBar();
}
function copyText(txt) {
  var ok = false;
  try { if (bridge('copy')) { A.copy(txt); ok = true; } } catch (e) {}
  if (!ok) {
    try {
      var ta = h('textarea', { style: 'position:fixed;top:0;left:0;opacity:0' }); ta.value = txt;
      document.body.appendChild(ta); ta.select(); ok = document.execCommand('copy'); document.body.removeChild(ta);
    } catch (e) {}
  }
  toast(ok ? 'کپی شد' : 'کپی انجام نشد');
}
function copyFromBar(mode, hid) {
  var pg = currentPage(); if (!pg) return;
  if (mode === 'hl') {
    var x = pg.hl.filter(function (q) { return q.id === hid; })[0];
    if (x) copyText(pg.text.slice(x.s, x.e));
    hideBar(); return;
  }
  var t = selectionTarget();
  if (t) copyText(t.pg.text.slice(t.s, t.e));
  hideBar();
}
function onStageClick(e) {
  if (S.flip) return;
  var sel = window.getSelection();
  if (sel && !sel.isCollapsed) return;
  var m = e.target.closest ? e.target.closest('mark') : null;
  if (m && pBase.contains(m)) {
    showBar('hl', m.getAttribute('data-id'), m.getBoundingClientRect());
    return;
  }
  if (S.barMode === 'hl') { hideBar(); return; }
  if (e.target.closest && (e.target.closest('.zone') || e.target.closest('.blank-leaf') || e.target.closest('button'))) return;
  if (pBase && !pBase.classList.contains('blank')) {
    var rect = stage.getBoundingClientRect();
    var rx = (e.clientX - rect.left) / Math.max(1, rect.width);
    if (rx > 0.16 && rx < 0.84) toggleImmersive();
  }
}

/* =====================================================================
   خوانش صوتی (Text-to-Speech اندروید)
   جمله‌ها اینجا ساخته می‌شوند؛ صف پخش در خود برنامه‌ی اندروید است
   تا با خاموش شدن صفحه هم خوانش ادامه پیدا کند.
   ===================================================================== */
var RATES = [0.75, 1, 1.25, 1.5, 2];
var SEG_MAX = 260;
var RE_AR = /[؀-ۿݐ-ݿࢠ-ࣿﭐ-﷿ﹰ-﻿]/;
var RE_LAT = /[A-Za-zÀ-ɏ]/;
var RE_SPEAK = /[0-9A-Za-zÀ-ɏ؀-ۿݐ-ݿࢠ-ࣿﭐ-﷿ﹰ-﻿]/;
var END_CH = '.!?؟؛…۔';
var CLOSERS = '"\'»”’)]}›';

var webSpeech = typeof window !== 'undefined' && 'speechSynthesis' in window && typeof SpeechSynthesisUtterance !== 'undefined' ? window.speechSynthesis : null;
var LOCALE_MAP = { ar: 'ar-SA', en: 'en-US', fr: 'fr-FR', de: 'de-DE', tr: 'tr-TR', fa: 'fa-IR' };
function ttsAvailable() { return bridge('ttsStart') || !!webSpeech; }
function webTtsStart(segs, start, rate, pitch) {
  if (!webSpeech) return false;
  try {
    webSpeech.cancel();
    var idx = start | 0;
    var voices = [];
    try { voices = webSpeech.getVoices() || []; } catch (e) {}
    function playNext() {
      if (!S.tts || idx >= segs.length) {
        if (window.onTts) window.onTts('end', idx, '');
        return;
      }
      if (S.tts.state === 'paused') return;
      S.tts.webIdx = idx;
      var g = segs[idx];
      var u = new SpeechSynthesisUtterance(g.t);
      var targetLang = LOCALE_MAP[g.l] || g.l || 'en-US';
      if (g.l === 'fa' && voices.length) {
        var hasFa = voices.some(function (v) { return /^fa/i.test(v.lang); });
        if (!hasFa) targetLang = 'ar-SA';
      }
      u.lang = targetLang;
      u.rate = clamp(+rate || 1, 0.5, 2);
      u.pitch = clamp(+pitch || 1, 0.6, 1.4);
      u.onstart = function () {
        if (window.onTts) { window.onTts('state', idx, 'playing'); window.onTts('seg', idx, ''); }
      };
      u.onend = function () { if (!S.tts || S.tts.state === 'paused') return; idx++; playNext(); };
      u.onerror = function () { if (!S.tts || S.tts.state === 'paused') return; idx++; playNext(); };
      webSpeech.speak(u);
    }
    S.tts._webPlayNext = function (newIdx) {
      if (newIdx != null) idx = newIdx;
      webSpeech.cancel();
      setTimeout(playNext, 20);
    };
    setTimeout(playNext, 20);
    return true;
  } catch (e) { return false; }
}
function pageIndexById(b, id) {
  if (!b || !id) return -1;
  for (var i = 0; i < b.pages.length; i++) if (b.pages[i].id === id) return i;
  return -1;
}

/* متن را به جمله تقسیم می‌کند؛ خروجی: آرایه‌ی [شروع، پایان) */
function sentenceRanges(text) {
  var out = [], n = text.length, i = 0, start = 0;
  function push(a, b) {
    while (a < b && /\s/.test(text.charAt(a))) a++;
    while (b > a && /\s/.test(text.charAt(b - 1))) b--;
    if (b > a) out.push([a, b]);
  }
  while (i < n) {
    var ch = text.charAt(i);
    if (ch === '\n') { push(start, i); start = i + 1; i++; continue; }
    if (END_CH.indexOf(ch) >= 0) {
      var j = i + 1;
      while (j < n && END_CH.indexOf(text.charAt(j)) >= 0) j++;
      while (j < n && CLOSERS.indexOf(text.charAt(j)) >= 0) j++;
      if (j >= n || /\s/.test(text.charAt(j))) { push(start, j); start = j; }
      i = j; continue;
    }
    i++;
  }
  push(start, n);
  return out;
}

/* =====================================================================
   تشخیص زبان برای خوانش صوتی: عربی، انگلیسی و فرانسوی خوانده می‌شوند؛ فارسی خوانده نمی‌شود.
   خط عربی: فارسی یا عربی؟  خط لاتین: انگلیسی یا فرانسوی؟  (نمره‌دهی واژه به واژه + تصمیم در سطح جمله)
   ===================================================================== */
var LANG_NAME = { ar: 'عربی', en: 'انگلیسی', fr: 'فرانسوی', de: 'آلمانی', tr: 'ترکی استانبولی', fa: 'فارسی' };
var SPOKEN = ['ar', 'en', 'fr', 'de', 'tr'];
function ttsOn(l) {
  var st = S.data.settings;
  return l === 'ar' ? st.ttsAr !== false
    : l === 'fr' ? st.ttsFr !== false
    : l === 'de' ? st.ttsDe !== false
    : l === 'tr' ? st.ttsTr !== false
    : l === 'en' ? st.ttsEn !== false : false;
}
function setOf(s) { var o = {}; s.split(/\s+/).forEach(function (w) { if (w) o[w] = 1; }); return o; }
var RE_FA_ONLY = /[پچژگٹڈڑںےہھ]/;          // پ چ ژ گ و حروف اردو: در عربی نیستند
var RE_FA_SOFT = /[کی]/;                                                                // ک ی فارسی (عربیِ اصیل ي و ك دارد؛ پس این دو نشانه‌ی فارسی‌اند)
var RE_AR_STRONG = /[ةىٱً-ْٰ]/;                                      // ة ى ٱ و اعراب
var RE_AR_WEAK = /[يكأإؤ]/;                                               // ي ك أ إ ؤ (در واژه‌های عربیِ فارسی هم هست)
var AR_W = setOf('في الى إلى إلي على عن مع أن إن أنه أنها إنه إنها هذا هذه ذلك تلك هؤلاء التي الذي الذين اللذان اللتان لا لم لن ليس كان كانت يكون تكون ثم أو بل لكن حتى إذا إذ كما عند هناك أيضا أيضاً لقد إلا غير وقد ولا وما وفي وعلى وإلى منذ حيث أمام خلال دون عليه عليها له لها لهم فيه فيها منه منها بين أنا نحن أنت هو هي');
var FA_W = setOf('در از به را با تا این آن است بود نیست می نمی خود هر همه اما اگر ولی نیز چون چه که برای شد شده شود باشد دارد داشت کرد کرده کند کنند یک دو سه بر بی هیچ پس نه');
function normFa(t) { return t.replace(/ي/g, 'ی').replace(/ك/g, 'ک').replace(/[ً-ْٰـ‌-‏]/g, ''); }
/* نمره‌ی یک واژه‌ی با خط عربی: {a: عربی, f: فارسی} */
function scoreArabicScript(tok) {
  var t = tok.replace(/^[^؀-ۿݐ-ݿ]+|[^؀-ۿݐ-ݿ]+$/g, ''), a = 0, f = 0;
  if (!t) return { a: 0, f: 0 };
  var n = normFa(t);
  if (RE_FA_ONLY.test(t)) f += 3;
  if (RE_AR_STRONG.test(t)) a += 3; else if (RE_AR_WEAK.test(t)) a += 1;
  if (RE_FA_SOFT.test(t)) f += 2;
  if (AR_W[t] || AR_W[t.replace(/ى/g, 'ي')]) a += 2;
  if (FA_W[n]) f += 2;
  if (n.length >= 4 && /^[وفبكل]?ال/.test(t)) a += 1;          // «ال» ی تعریف
  return { a: a, f: f };
}

var FR_W = setOf("le la les un une des du de et est en que qui dans pour pas ne sur avec au aux ce cette ces mais ou où donc il elle ils elles nous vous je tu se sont était étaient été être avoir avait avaient ont aussi comme très bien tout tous toute toutes cela ça sans sous entre vers chez par moins encore déjà alors puis ainsi lorsque quand parce pourquoi comment quel quelle quels quelles leur leurs mon ma mes ton ta tes notre nos votre vos sa ses lui eux celui celle ceux celles dont ni soit peut peuvent doit faut fait faire dit suis es sommes êtes sera seront serait aurait avez avons ai as très peu beaucoup toujours jamais rien personne chaque autre autres même mêmes depuis pendant avant après contre selon malgré voici voilà bonjour merci oui non monsieur madame");
var EN_W = setOf("the of and to in is that it was for on are as with his they at be this from or had by not but what all were when we there can an your which their said if do will each about how up out them then she many some so these would other into has her two like him see time could no make than first been its who now people my made over did down only way find use may water long little very after words called just where most know get through back much before go good new write our me man too any day same right look think also around another came come work three word must because does part even place well such here take why help put different away again off went old number great tell men say small every found still between name should home big give air line set own under read last never us left end along while might next sound below saw something thought both few those always looked show large often together asked house world going want school important until form food keep children feet land side without boy once animals life enough took sometimes four head above kind began almost live page got earth need far hand high year mother light country father let night picture being study second soon story since white ever paper hard near sentence better best across during today however sure knew try told young sun thing whole hear example heard several change answer room sea against top turned learn point city play toward five using himself usually i you he have a don't doesn't isn't it's i'm i've i'll you're we're they're that's there's can't won't didn't wasn't");
var DE_W = setOf("der die das und in den von zu mit sich auf für nicht ist im dem भी ein eine einer einem einen المرء als auch es an werden aus er hat dass sie nach wird bei einer um am sind noch wie einem über einen so zum war haben nur oder aber vor zur bis mehr durch man sein wurde sei چطور kann gegen vom können schon wenn habe뇌 ich du wir ihr er sie mein dein sein unser euer ihr kein keine keinen keinem keiner nichts alles immer wieder heute morgen gestern sehr gut viel viele شبیه weil obwohl während تام پسا بدون unter zwischen hinter neben vor über durch für ohne gegen um trotz wegen dank hallo guten tag morgen abend danke bitte entschuldigung herr frau deutschland deutsch");
var TR_W = setOf("bir ve bu برای درda de için ile چطور کهmi mı mu mü ne اما فقط یاچونکه çok daha en gibi kadar sonra önce göre karşı doğru rağmen beri dolayı başka her هیچ بعضى bütün tüm hep hiç var yok değil چطور من سن او ما شما آنها ben sen o biz siz onlar benim senin onun bizim sizin onların bu şu o bunlar şunlar onlar burada şurada orada böyle şöyle öyle şimdi sonra dün bugün yarın çok az iyi kötü büyük küçük yeni eski güzel گوزل لطفاً مرسی سلام merhaba günaydın iyi akşamlar teşekkürler teşekkür ederim lütfen evet hayır değil nasıl neden niçin nerede ne zaman kim hangi kaç");
(function () {
  var all = [FR_W, EN_W, DE_W, TR_W];
  for (var i = 0; i < all.length; i++) {
    for (var j = i + 1; j < all.length; j++) {
      for (var k in all[i]) if (all[j][k]) { delete all[i][k]; delete all[j][k]; }
    }
  }
})();
var RE_FR_ACC = /[àâæèéêëîïôœùûÿ]/;
var RE_FR_ELIDE = /^(?:l|d|j|qu|jusqu|lorsqu|puisqu|c|n|s|m|t)['’][a-zà-ɏ]/;
var RE_DE_STRONG = /ß/;
var RE_DE_UML = /[äöü]/;
var RE_TR_STRONG = /[ğışİ]/;
var RE_TR_WEAK = /[çöü]/;
/* نمره‌ی یک واژه‌ی لاتین: {f: فرانسوی, e: انگلیسی, d: آلمانی, t: ترکی} */
function scoreLatin(tok) {
  var raw = tok.replace(/^[^A-Za-zÀ-ɏ]+|[^A-Za-zÀ-ɏ'’]+$/g, '');
  var t = raw.toLowerCase().replace(/’/g, "'"), f = 0, e = 0, d = 0, tr = 0;
  if (!t) return { f: 0, e: 0, d: 0, t: 0 };
  if (RE_DE_STRONG.test(t)) d += 4;
  if (RE_TR_STRONG.test(raw) || RE_TR_STRONG.test(t)) tr += 4;
  if (RE_FR_ACC.test(t)) f += 3;
  if (RE_FR_ELIDE.test(tok.toLowerCase())) f += 3;
  if (RE_DE_UML.test(t)) { d += 2; tr += 1; }
  if (RE_TR_WEAK.test(t)) { tr += 2; f += (t.indexOf('ç') >= 0 ? 1 : 0); }
  if (/sch|tsch|ung$|keit$|heit$|lich$/.test(t)) d += 2;
  if (/lar$|ler$|lık$|lik$|luk$|lük$|스|iyor|acak|ecek/.test(t)) tr += 2;
  if (FR_W[t]) f += 2;
  if (EN_W[t]) e += 2;
  if (DE_W[t]) d += 2;
  if (TR_W[t]) tr += 2;
  return { f: f, e: e, d: d, t: tr };
}

function scriptOf(t) {
  var ar = 0, lat = 0;
  for (var i = 0; i < t.length; i++) {
    var c = t.charAt(i);
    if (RE_AR.test(c)) ar++; else if (RE_LAT.test(c)) lat++;
  }
  if (!ar && !lat) return null;
  return ar >= lat ? 'A' : 'L';
}
/* نمره‌ی کل یک متن کوتاه (برای حدس زبانِ واژه از روی جمله‌اش) */
function scoreText(text) {
  var o = { ar: 0, fa: 0, fr: 0, en: 0, de: 0, tr: 0, A: 0, L: 0 };
  String(text || '').split(/\s+/).forEach(function (tk) {
    var sc = scriptOf(tk);
    if (sc === 'A') { var x = scoreArabicScript(tk); o.ar += x.a; o.fa += x.f; o.A++; }
    else if (sc === 'L') { var y = scoreLatin(tk); o.fr += y.f; o.en += y.e; o.de += y.d; o.tr += y.t; o.L++; }
  });
  return o;
}
function pickArabicScript(o, tie) { return o.ar - o.fa >= 2 ? 'ar' : (o.fa > o.ar ? 'fa' : (tie === 'ar' ? 'ar' : 'fa')); }
function pickLatin(o, tie) {
  var d = o.de || 0, tr = o.tr || 0, f = o.fr || 0, e = o.en || 0;
  var pairs = [['en', e], ['fr', f], ['de', d], ['tr', tr]];
  pairs.sort(function (a, b) { return b[1] - a[1]; });
  if (pairs[0][1] > pairs[1][1]) return pairs[0][0];
  if (tie && (tie === 'fr' || tie === 'de' || tie === 'tr' || tie === 'en')) return tie;
  return 'en';
}

/* زبانِ یک واژه یا عبارت. lg: انتخاب دستی کاربر ('' = خودکار)؛ ex: جمله‌ی نمونه برای کمک به تشخیص */
function wordLang(w, ex, lg) {
  if (lg === 'ar' || lg === 'en' || lg === 'fr' || lg === 'de' || lg === 'tr' || lg === 'fa') return lg;
  var a = scoreText(w);
  if (a.A >= a.L && a.A > 0) {                                  // خط عربی: فارسی یا عربی
    if (a.fa > a.ar) return 'fa';
    if (a.ar > a.fa) return 'ar';
    return pickArabicScript(scoreText(ex));
  }
  if (a.L > 0) {                                                // خط لاتین: انگلیسی، فرانسوی، آلمانی یا ترکی
    var topL = pickLatin(a, null);
    var maxV = Math.max(a.en, a.fr, a.de, a.tr);
    var cntMax = (a.en === maxV ? 1 : 0) + (a.fr === maxV ? 1 : 0) + (a.de === maxV ? 1 : 0) + (a.tr === maxV ? 1 : 0);
    if (maxV > 0 && cntMax === 1) return topL;
    return pickLatin(scoreText(ex));
  }
  return 'en';
}
function langOfToken(t) {       // فقط برای حالت‌های ساده: 'fa' = خط عربی، 'en' = لاتین (زبان دقیق را wordLang می‌گوید)
  var sc = scriptOf(t);
  return sc === 'A' ? 'fa' : sc === 'L' ? 'en' : null;
}

/* یک جمله را به تکه‌های هم‌زبان تقسیم می‌کند. تکه‌ی کوتاه‌تر از سه واژه در همسایه‌اش ادغام می‌شود. */
function langRuns(text, a, b, prevLang) {
  var sub = text.slice(a, b), re = /\S+/g, toks = [], m, i;
  var sA = { a: 0, f: 0 }, sL = { fr: 0, en: 0, de: 0, tr: 0 };
  while ((m = re.exec(sub))) {
    var tk = { s: a + m.index, e: a + m.index + m[0].length, l: null, sc: scriptOf(m[0]) };
    if (tk.sc === 'A') {
      var x = scoreArabicScript(m[0]); sA.a += x.a; sA.f += x.f;
      if (x.a - x.f >= 2) tk.l = 'ar'; else if (x.f - x.a >= 2) tk.l = 'fa';
    } else if (tk.sc === 'L') {
      var y = scoreLatin(m[0]); sL.fr += y.f; sL.en += y.e; sL.de += y.d; sL.tr += y.t;
      var arr = [['en', y.e], ['fr', y.f], ['de', y.d], ['tr', y.t]];
      arr.sort(function (p, q) { return q[1] - p[1]; });
      if (arr[0][1] - arr[1][1] >= 2) tk.l = arr[0][0];
    }
    toks.push(tk);
  }
  if (!toks.length) return [];
  var any = false;
  for (i = 0; i < toks.length; i++) if (toks[i].sc) { any = true; break; }
  if (!any) {
    if (!/[0-9]/.test(sub)) return [];
    return [{ l: prevLang || 'fa', s: toks[0].s, e: toks[toks.length - 1].e }];
  }
  /* واژه‌های بدون نشانه از نزدیک‌ترین واژه‌ی هم‌خطِ دارای زبان در همان جمله می‌گیرند؛ اگر هیچ نبود از نمره‌ی کل جمله و زبانِ جمله‌ی قبل */
  ['A', 'L'].forEach(function (sc) {
    var idx = [], j, last = null;
    for (j = 0; j < toks.length; j++) if (toks[j].sc === sc) idx.push(j);
    if (!idx.length) return;
    var has = idx.some(function (k) { return toks[k].l; });
    if (!has) {
      var l0 = sc === 'A' ? pickArabicScript(sA, prevLang === 'ar' ? 'ar' : 'fa') : pickLatin(sL, prevLang);
      idx.forEach(function (k) { toks[k].l = l0; });
      return;
    }
    idx.forEach(function (k) { if (toks[k].l) last = toks[k].l; else if (last) toks[k].l = last; });
    last = null;
    for (j = idx.length - 1; j >= 0; j--) { var q = toks[idx[j]]; if (q.l) last = q.l; else q.l = last; }
  });
  var last2 = null;
  for (i = 0; i < toks.length; i++) { if (toks[i].l) last2 = toks[i].l; else if (last2) toks[i].l = last2; }
  last2 = null;
  for (i = toks.length - 1; i >= 0; i--) { if (toks[i].l) last2 = toks[i].l; else toks[i].l = last2; }
  var runs = [];
  toks.forEach(function (t) {
    var r = runs[runs.length - 1];
    if (r && r.l === t.l) { r.e = t.e; r.n++; } else runs.push({ l: t.l, s: t.s, e: t.e, n: 1 });
  });
  var guard = 0;
  while (runs.length > 1 && guard++ < 60) {
    var k = -1, best = 3;
    for (i = 0; i < runs.length; i++) if (runs[i].n < best) { best = runs[i].n; k = i; }
    if (k < 0) break;
    var L = runs[k - 1], R = runs[k + 1];
    if (L && R && L.l === R.l) { L.e = R.e; L.n += runs[k].n + R.n; runs.splice(k, 2); }
    else if (L && (!R || L.n >= R.n)) { L.e = runs[k].e; L.n += runs[k].n; runs.splice(k, 1); }
    else { R.s = runs[k].s; R.n += runs[k].n; runs.splice(k, 1); }
  }
  return runs;
}

/* تکه‌های خیلی بلند را در نزدیک‌ترین ویرگول یا فاصله می‌شکند (موتور صدا طول متن را محدود می‌کند) */
function chunkRange(text, a, b, out) {
  while (b - a > SEG_MAX) {
    var cut = -1, lim = a + SEG_MAX, i, ch;
    for (i = lim; i > a + 120; i--) {
      ch = text.charAt(i - 1);
      if (ch === '،' || ch === ',' || ch === ':' || ch === ';' || ch === '؛') { cut = i; break; }
    }
    if (cut < 0) for (i = lim; i > a + 120; i--) { if (/\s/.test(text.charAt(i - 1))) { cut = i; break; } }
    if (cut < 0) cut = lim;
    out.push([a, cut]);
    a = cut;
    while (a < b && /\s/.test(text.charAt(a))) a++;
  }
  if (b > a) out.push([a, b]);
}

/* همه‌ی جمله‌های کتاب از صفحه‌ی fromPage به بعد؛ فقط زبان‌های روشنِ عربی/انگلیسی/فرانسوی. فارسی همیشه رد می‌شود. */
function buildSegments(b, fromPage) {
  var segs = [], prevLang = null;
  function addPage(pg, pi) {
    var text = pg.text;
    sentenceRanges(text).forEach(function (r) {
      langRuns(text, r[0], r[1], prevLang).forEach(function (run) {
        var parts = [];
        chunkRange(text, run.s, run.e, parts);
        parts.forEach(function (pr) {
          var s = pr[0], e = pr[1];
          while (s < e && /\s/.test(text.charAt(s))) s++;
          while (e > s && /\s/.test(text.charAt(e - 1))) e--;
          if (e <= s) return;
          var t = text.slice(s, e);
          if (!RE_SPEAK.test(t)) return;
          prevLang = run.l;
          if (SPOKEN.indexOf(run.l) < 0 || !ttsOn(run.l)) return;
          segs.push({ pid: pg.id, p: pi, s: s, e: e, l: run.l, t: t });
        });
      });
    });
  }
  for (var pi = Math.max(0, fromPage); pi < b.pages.length; pi++) addPage(b.pages[pi], pi);
  return segs;
}

function sayRange(pg) {
  var T = S.tts;
  if (T && T.cur && pg && T.cur.pid === pg.id) return { s: T.cur.s, e: T.cur.e, cls: 'say' };
  return null;
}

/* جمله‌ی در حال خواندن را در دید نگه می‌دارد */
function ttsReveal() {
  if (!S.tts || !S.tts.cur || S.view !== 'reader' || S.flip) return;
  var p = pageParts(pBase), el = $('.say', p.text);
  if (!el) return;
  var r = el.getBoundingClientRect(), sr = p.scroll.getBoundingClientRect();
  if (r.top < sr.top + sr.height * 0.08 || r.bottom > sr.bottom - sr.height * 0.12) {
    var top = p.scroll.scrollTop + (r.top - sr.top) - sr.height * 0.25;
    try { p.scroll.scrollTo({ top: top, behavior: 'smooth' }); } catch (e) { p.scroll.scrollTop = top; }
  }
}
function ttsPaint() {
  if (S.view !== 'reader' || S.flip) return;
  var pg = currentPage(); if (!pg) return;
  var sel = window.getSelection();
  if (sel && !sel.isCollapsed) return;
  renderPage(pBase, S.index, pageParts(pBase).scroll.scrollTop);
  ttsReveal();
}

function ttsClear() {
  var had = S.tts;
  S.tts = null;
  updateTtsBar();
  updateSpeakingNoteCards();
  updateSpeakingVocabRows();
  if (had && had.cur) { try { ttsPaint(); } catch (e) {} }
}
function ttsStop() {
  if (!S.tts) return;
  try { if (bridge('ttsStop')) A.ttsStop(); else if (webSpeech) webSpeech.cancel(); } catch (e) {}
  ttsClear();
}

function ttsBegin(fromPage, fromOffset) {
  var b = curBook(); if (!b) return;
  if (!ttsAvailable()) { toast('خوانش صوتی در این دستگاه پشتیبانی نمی‌شود'); return; }
  if (!b.pages.length) { toast('کتاب هنوز صفحه‌ای ندارد'); return; }
  if (fromPage >= b.pages.length) fromPage = 0;
  var segs = buildSegments(b, fromPage), start = 0, i;
  if (!segs.length) {
    var onL = SPOKEN.filter(ttsOn).map(function (k) { return LANG_NAME[k]; });
    toast(onL.length ? 'متن ' + onL.join('، ') + ' برای خواندن پیدا نشد؛ متن فارسی خوانده نمی‌شود' : 'هیچ زبانی برای خوانش روشن نیست؛ در «تنظیمات خوانش صوتی» روشن کنید');
    return;
  }
  if (fromOffset != null) {
    var pid = b.pages[fromPage].id, found = -1;
    for (i = 0; i < segs.length; i++) if (segs[i].pid === pid && segs[i].e > fromOffset) { found = i; break; }
    if (found < 0) for (i = 0; i < segs.length; i++) if (segs[i].p > fromPage) { found = i; break; }   // در این صفحه دیگر متنِ قابل‌خواندن نمانده: از صفحه‌ی بعدی که دارد
    if (found < 0) { toast('بعد از این نقطه متنِ قابل‌خواندن نیست'); return; }
    start = found;
  }
  var st = S.data.settings;
  S.tts = { book: b.id, segs: segs, idx: start, cur: null, state: 'loading', lastPid: null, sample: false };
  hideBar(); clearSel();
  try {
    if (bridge('ttsStart')) {
      A.ttsStart(JSON.stringify(segs.map(function (g) { return { p: g.p, s: g.s, e: g.e, l: g.l, t: g.t }; })), start, st.ttsRate, st.ttsPitch);
    } else if (!webTtsStart(segs, start, st.ttsRate, st.ttsPitch)) {
      throw new Error('no tts');
    }
  } catch (e) { S.tts = null; toast('شروع خوانش انجام نشد'); }
  updateTtsBar();
}

var SAMPLES = {
  en: 'Hello. This is a sample of English speech.',
  fr: 'Bonjour. Ceci est un exemple de lecture en français.',
  de: 'Hallo. Dies ist ein Beispiel für deutsche Sprache.',
  tr: 'Merhaba. Bu Türkçe sesli okuma örneğidir.',
  ar: 'مرحبا. هذا مثال على القراءة باللغة العربية.',
  fa: 'سلام. این یک نمونه از خوانش صوتی در برنامه‌ی کتابچه است.'
};
function ttsSample(l) {
  if (!ttsAvailable()) { toast('خوانش صوتی در این دستگاه پشتیبانی نمی‌شود'); return; }
  l = SAMPLES[l] ? l : 'en';
  var segs = [
    { pid: null, p: 0, s: 0, e: 0, l: l, t: SAMPLES[l] }
  ];
  var st = S.data.settings;
  S.tts = { book: null, segs: segs, idx: 0, cur: null, state: 'loading', lastPid: null, sample: true };
  try {
    if (bridge('ttsStart')) A.ttsStart(JSON.stringify(segs), 0, st.ttsRate, st.ttsPitch);
    else if (!webTtsStart(segs, 0, st.ttsRate, st.ttsPitch)) throw new Error('no tts');
  } catch (e) { S.tts = null; toast('شروع خوانش انجام نشد'); }
}

function ttsToggle() {
  var T = S.tts;
  if (T && (T.book || T.note)) {
    try {
      if (T.state === 'playing') {
        if (bridge('ttsPause')) A.ttsPause();
        else if (webSpeech) { T.state = 'paused'; webSpeech.cancel(); updateTtsBar(); }
      } else if (T.state === 'paused') {
        if (bridge('ttsResume')) A.ttsResume();
        else if (T._webPlayNext) { T.state = 'playing'; T._webPlayNext(T.idx); updateTtsBar(); }
      }
    } catch (e) {}
    return;
  }
  var b = curBook(); if (!b) return;
  ttsBegin(S.index, null);
}
function ttsStep(delta) {
  var T = S.tts; if (!T || (!T.book && !T.note)) return;
  var i = clamp(T.idx + delta, 0, T.segs.length - 1);
  T.idx = i;
  try {
    if (bridge('ttsSeek')) A.ttsSeek(i);
    else if (T._webPlayNext) T._webPlayNext(i);
  } catch (e) {}
}
function ttsCycleRate() {
  var st = S.data.settings, nx = RATES[0], i;
  for (i = 0; i < RATES.length; i++) if (RATES[i] > st.ttsRate + 0.001) { nx = RATES[i]; break; }
  st.ttsRate = nx;
  scheduleSave();
  try { if (bridge('ttsSet')) A.ttsSet(st.ttsRate, st.ttsPitch); } catch (e) {}
  updateTtsBar();
}

function ttsOnSeg(idx) {
  var T = S.tts; if (!T) return;
  T.idx = idx;
  var sg = T.segs[idx];
  if (!sg) { updateTtsBar(); return; }
  T.cur = sg;
  if (T.vocabSeq && sg.wid) {
    T.wordId = sg.wid;
    T.stepIdx = idx;
    updateTtsBar();
    updateSpeakingVocabRows(true);
    return;
  }
  if (T.note && sg.nid) {
    T.noteId = sg.nid;
    updateTtsBar();
    updateSpeakingNoteCards();
    return;
  }
  if (!sg.pid) { updateTtsBar(); return; }
  updateTtsBar();
  if (S.view !== 'reader' || S.bookId !== T.book) return;
  var b = curBook(), pi = pageIndexById(b, sg.pid);
  if (pi < 0) return;
  var changed = T.lastPid !== sg.pid;
  T.lastPid = sg.pid;
  if (S.flip) return;
  if (changed && pi !== S.index) {
    hideBar();
    if (pi === S.index + 1 && !layers.length) flipTo(true); else showPageNow(pi);
  } else if (pi === S.index) {
    ttsPaint();
  }
}


var _vsVoiceCbs = {};
var _vsTestCbs = {};
var _vsCbSeq = 0;

function syncVoiceStudio() {
  var st = S.data && S.data.settings;
  if (!st || !bridge('vsConfigure')) return;
  try {
    A.vsConfigure(JSON.stringify({
      enabled: !!st.vsEnabled,
      url: String(st.vsUrl || '').trim(),
      apiKey: String(st.vsApiKey || '').trim(),
      model: String(st.vsModel || 'omnivoice').trim(),
      voice: String(st.vsVoice || 'default').trim(),
      instruct: String(st.vsInstruct || '').trim(),
      fallback: st.vsFallback !== false
    }));
  } catch (e) {}
}

function vsDecodeB64(b64) {
  if (!b64) return '';
  try {
    var bin = atob(b64);
    var bytes = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    if (typeof TextDecoder !== 'undefined') return new TextDecoder('utf-8').decode(bytes);
    return decodeURIComponent(escape(bin));
  } catch (e) {
    return '';
  }
}

window.onVsVoices = function (id, code, b64) {
  var cb = _vsVoiceCbs[id];
  delete _vsVoiceCbs[id];
  if (!cb) return;
  if (code !== 200) { cb(null); return; }
  try { cb(JSON.parse(vsDecodeB64(b64))); } catch (e) { cb(null); }
};

window.onVsTest = function (id, code, b64) {
  var cb = _vsTestCbs[id];
  delete _vsTestCbs[id];
  if (!cb) return;
  if (code !== 200) { cb(false, null); return; }
  try { cb(true, JSON.parse(vsDecodeB64(b64))); } catch (e) { cb(true, null); }
};

function vsRequestVoices(cb) {
  if (!bridge('vsListVoices')) { cb(null); return; }
  syncVoiceStudio();
  var id = 'vsv_' + (++_vsCbSeq);
  _vsVoiceCbs[id] = cb;
  try { A.vsListVoices(id); } catch (e) { delete _vsVoiceCbs[id]; cb(null); }
}

function vsRequestTest(cb) {
  if (!bridge('vsTest')) { cb(false, null); return; }
  syncVoiceStudio();
  var id = 'vst_' + (++_vsCbSeq);
  _vsTestCbs[id] = cb;
  try { A.vsTest(id); } catch (e) { delete _vsTestCbs[id]; cb(false, null); }
}

window.onTts = function (type, idx, extra) {
  var T = S.tts;
  if (type === 'state') {
    if (!T) return;
    if (extra === 'idle') { ttsClear(); return; }
    T.state = extra;
    updateTtsBar();
    updateSpeakingNoteCards();
    updateSpeakingVocabRows();
  } else if (type === 'seg') {
    ttsOnSeg(idx | 0);
  } else if (type === 'end') {
    var was = T && (T.book || T.note);
    ttsClear();
    if (was) toast('خوانش صوتی به پایان رسید');
  } else if (type === 'sync') {
    if (!T) { if (extra && extra !== 'idle') { try { if (bridge('ttsStop')) A.ttsStop(); } catch (e) {} } return; }
    if (extra === 'idle') { ttsClear(); return; }
    T.state = extra;
    if (idx >= 0) ttsOnSeg(idx | 0); else updateTtsBar();
  } else if (type === 'warn') {
    if (extra === 'vs_fallback') {
      toast('اتصال به VoiceStudio برقرار نشد؛ خوانش با موتور آفلاین گوشی ادامه یافت');
      return;
    }
    var nm = String(extra || '').split(',').filter(function (k) { return LANG_NAME[k]; }).map(function (k) { return LANG_NAME[k]; }).join(' و ') || 'این زبان';
    toast('صدای ' + nm + ' روی گوشی نیست؛ بخش‌های ' + nm + ' خوانده نمی‌شوند', { label: 'تنظیمات', fn: function () { try { if (bridge('openTtsSettings')) A.openTtsSettings(); } catch (e) {} } });
  } else if (type === 'error') {
    var errStr = String(extra || '');
    if (T && !T._faFallback && /^lang:fa:/.test(errStr)) {
      T._faFallback = true;
      T.segs.forEach(function (g) { if (g.l === 'fa') g.l = 'ar'; });
      var st = S.data.settings;
      try {
        if (bridge('ttsStart')) {
          toast('موتور صدای فارسی نصب نیست؛ با صدای هم‌خط خوانده می‌شود');
          A.ttsStart(JSON.stringify(T.segs.map(function (g) { return { p: g.p || 0, s: g.s || 0, e: g.e || 0, l: g.l, t: g.t }; })), T.idx || 0, st.ttsRate, st.ttsPitch);
          return;
        }
      } catch (e) {}
    }
    ttsError(errStr);
  }
};

function ttsError(code) {
  var m = /^lang:(ar|en|fr|de|tr|fa):(data|unsupported)$/.exec(code);
  function go(name) { return function (r) { if (r) { try { if (bridge(name)) A[name](); } catch (e) {} } }; }
  if (m) {
    var nm = LANG_NAME[m[1]];
    if (m[2] === 'data') {
      dialog({ title: 'صدای ' + nm + ' نصب نیست',
        message: 'بسته‌ی صدای زبان ' + nm + ' روی گوشی نصب نشده است. با دکمه‌ی زیر می‌توانید آن را از تنظیمات موتور صدای گوشی دانلود کنید (دانلود به اینترنتِ گوشی نیاز دارد).',
        ok: 'نصب صدا', cancel: 'بستن' }).then(go('installTtsData'));
    } else {
      dialog({ title: 'خواندن ' + nm + ' پشتیبانی نمی‌شود',
        message: 'موتور تبدیل متن به گفتارِ فعلیِ گوشی، زبان ' + nm + ' را ندارد. در تنظیمات گوشی موتور دیگری که این زبان را دارد (مثلاً Google Speech Services) نصب و انتخاب کنید.',
        ok: 'تنظیمات صدا', cancel: 'بستن' }).then(go('openTtsSettings'));
    }
    return;
  }
  if (code === 'vs_net') {
    dialog({ title: 'خطای اتصال به VoiceStudio',
      message: 'ارتباط با سرور VoiceStudio برقرار نشد. آدرس سرور، روشن بودن VoiceStudio و اتصال شبکه را بررسی کنید یا گزینه‌ی «بازگشت خودکار به صدای آفلاین گوشی» را فعال نمایید.',
      ok: 'تنظیمات خوانش', cancel: 'بستن' }).then(function (r) { if (r) openTtsSettings(); });
    return;
  }
  if (code === 'init') {
    dialog({ title: 'موتور صدا در دسترس نیست',
      message: 'موتور تبدیل متن به گفتار در این گوشی پیدا یا روشن نشد. در تنظیمات گوشی یک موتور (مثلاً Google Speech Services) نصب و انتخاب کنید.',
      ok: 'تنظیمات صدا', cancel: 'بستن' }).then(go('openTtsSettings'));
    return;
  }
  toast('خوانش با خطا متوقف شد');
}

function buildTtsBar() {
  var bar = $('#ttsbar');
  var prev = h('button', { class: 'ibtn', 'aria-label': 'جمله‌ی قبل', html: ic('skipPrev', 22) });
  var play = h('button', { class: 'ibtn play', id: 'ttsPlay', 'aria-label': 'پخش یا توقف', html: ic('play', 24) });
  var next = h('button', { class: 'ibtn', 'aria-label': 'جمله‌ی بعد', html: ic('skipNext', 22) });
  var info = h('div', { class: 'info' }, [h('b', { id: 'ttsT1' }), h('span', { id: 'ttsT2' })]);
  var spd = h('button', { class: 'spd', id: 'ttsSpd', 'aria-label': 'سرعت خواندن' });
  var cls = h('button', { class: 'ibtn', 'aria-label': 'پایان خوانش', html: ic('x', 22) });
  bar.appendChild(h('div', { class: 'ctl' }, [prev, play, next]));
  bar.appendChild(info); bar.appendChild(spd); bar.appendChild(cls);
  prev.addEventListener('click', function () { ttsStep(-1); });
  next.addEventListener('click', function () { ttsStep(1); });
  play.addEventListener('click', ttsToggle);
  spd.addEventListener('click', ttsCycleRate);
  info.addEventListener('click', openTtsSettings);
  cls.addEventListener('click', ttsStop);
}
function updateTtsBar() {
  var T = S.tts, bar = $('#ttsbar'), rd = $('#rd'), lib = $('#lib');
  if (!bar) return;
  var onBook = !!(T && T.book && S.view === 'reader' && S.bookId === T.book);
  var onNote = !!(T && T.note && S.view === 'library');
  var on = onBook || onNote;
  if (onNote && bar.parentNode !== lib) {
    lib.insertBefore(bar, $('#fabNewBook'));
  } else if (!onNote && bar.parentNode !== rd) {
    rd.insertBefore(bar, $('.botbar', rd));
  }
  bar.classList.toggle('hidden', !on);
  rd.classList.toggle('tts-on', onBook);
  if (lib) lib.classList.toggle('tts-on', onNote);
  $('#bSay').classList.toggle('on', !!(T && T.book));
  updateSayBtn();
  if (!on) return;
  var play = $('#ttsPlay');
  play.innerHTML = ic(T.state === 'playing' ? 'pause' : 'play', 24);
  play.classList.toggle('busy', T.state === 'loading');
  var sg = T.segs[T.idx];
  if (onNote) {
    var ntTitle = sg && sg.ntitle ? snippet(sg.ntitle, 28) : (T.vocabSeq ? 'لغات' : 'یادداشت');
    var unitLbl = T.vocabSeq ? 'لغت ' : 'بخش ';
    $('#ttsT1').textContent = T.state === 'loading' ? 'در حال آماده‌سازی صدا…' : (T.state === 'paused' ? 'متوقف شد: ' + ntTitle : 'خوانش: ' + ntTitle);
    $('#ttsT2').textContent = unitLbl + fa(T.idx + 1) + ' از ' + fa(T.segs.length) + (sg && sg.l ? ' · ' + (LANG_NAME[sg.l] || '') : '');
  } else {
    var pi = sg && sg.pid ? pageIndexById(curBook(), sg.pid) : -1;
    $('#ttsT1').textContent = T.state === 'loading' ? 'در حال آماده‌سازی صدا…' : (T.state === 'paused' ? 'متوقف شد' : 'در حال خواندن');
    $('#ttsT2').textContent = (pi >= 0 ? 'صفحه ' + fa(pi + 1) : '') + (sg ? (pi >= 0 ? ' · ' : '') + (LANG_NAME[sg.l] || '') : '');
  }
  $('#ttsSpd').textContent = fa(S.data.settings.ttsRate) + '×';
}
function updateSayBtn() {
  var b = curBook(), btn = $('#bSay');
  if (!btn) return;
  var active = !!(S.tts && S.tts.book);
  btn.disabled = !active && (!b || S.index >= b.pages.length);
}

function openTtsSettings() {
  sheet('خوانش صوتی', function (body) {
    var st = S.data.settings;
    function apply() {
      scheduleSave();
      try { if (bridge('ttsSet')) A.ttsSet(st.ttsRate, st.ttsPitch); } catch (e) {}
      updateTtsBar();
    }
    function slider(label, key, min, max, step) {
      body.appendChild(h('div', { class: 'sec-t', text: label }));
      var val = h('b', { text: fa(st[key]) });
      var rng = h('input', { type: 'range', min: min, max: max, step: step, value: st[key] });
      function fill() { rng.style.setProperty('--p', ((+rng.value - min) / (max - min) * 100) + '%'); }
      fill();
      rng.addEventListener('input', function () { st[key] = +rng.value; val.textContent = fa(st[key]); fill(); });
      rng.addEventListener('change', function () { st[key] = +rng.value; apply(); });
      body.appendChild(h('div', { class: 'stepper' }, [rng, val]));
    }
    slider('سرعت خواندن', 'ttsRate', 0.5, 2, 0.05);
    slider('زیر و بمی صدا', 'ttsPitch', 0.6, 1.4, 0.05);
    body.appendChild(h('div', { class: 'sec-t', text: 'زبان‌هایی که خوانده شوند' }));
    [['ttsAr', 'عربی'], ['ttsEn', 'انگلیسی'], ['ttsFr', 'فرانسوی'], ['ttsDe', 'آلمانی'], ['ttsTr', 'ترکی استانبولی']].forEach(function (o) {
      var key = o[0], sw = h('div', { class: 'sw-toggle' + (st[key] !== false ? ' on' : '') });
      var row = h('div', { class: 'set-row', 'data-k': key, role: 'switch', 'aria-checked': st[key] !== false ? 'true' : 'false' }, [
        h('div', { class: 'grow' }, [h('div', { class: 't', text: o[1] })]), sw]);
      row.addEventListener('click', function () {
        st[key] = st[key] === false; sw.classList.toggle('on', st[key]); row.setAttribute('aria-checked', st[key] ? 'true' : 'false'); scheduleSave();
      });
      body.appendChild(row);
    });
    body.appendChild(h('div', { class: 'sec-t', text: 'آزمایش صدا' }));
    var tests = h('div', { class: 'tts-tests' });
    [['fa', 'فارسی'], ['ar', 'عربی'], ['en', 'انگلیسی'], ['fr', 'فرانسوی'], ['de', 'آلمانی'], ['tr', 'ترکی']].forEach(function (o) {
      var tb = h('button', { class: 'btn', 'data-l': o[0], html: ic('speaker', 18) + '<span>' + o[1] + '</span>' });
      tb.addEventListener('click', function () { ttsSample(o[0]); });
      tests.appendChild(tb);
    });
    body.appendChild(tests);
    body.appendChild(h('div', { class: 'sec-t', text: 'موتور هوش مصنوعی VoiceStudio (کیفیت بالا)' }));
    var vsSw = h('div', { class: 'sw-toggle' + (st.vsEnabled ? ' on' : '') });
    var vsRow = h('div', { class: 'set-row', role: 'switch', 'aria-checked': st.vsEnabled ? 'true' : 'false' }, [
      h('div', { class: 'grow' }, [
        h('div', { class: 't', text: 'فعال‌سازی VoiceStudio' }),
        h('div', { class: 's', text: 'پخش باکیفیت متن کتاب و یادداشت با مدل‌های OmniVoice، VoxCPM2 و CosyVoice' })
      ]),
      vsSw
    ]);
    vsRow.addEventListener('click', function () {
      st.vsEnabled = !st.vsEnabled;
      vsSw.classList.toggle('on', st.vsEnabled);
      vsRow.setAttribute('aria-checked', st.vsEnabled ? 'true' : 'false');
      syncVoiceStudio();
      scheduleSave();
    });
    body.appendChild(vsRow);

    var vsFbSw = h('div', { class: 'sw-toggle' + (st.vsFallback !== false ? ' on' : '') });
    var vsFbRow = h('div', { class: 'set-row', role: 'switch', 'aria-checked': st.vsFallback !== false ? 'true' : 'false' }, [
      h('div', { class: 'grow' }, [
        h('div', { class: 't', text: 'بازگشت خودکار به صدای آفلاین گوشی' }),
        h('div', { class: 's', text: 'در صورت قطع شبکه یا خاموش بودن سرور VoiceStudio' })
      ]),
      vsFbSw
    ]);
    vsFbRow.addEventListener('click', function () {
      st.vsFallback = st.vsFallback === false;
      vsFbSw.classList.toggle('on', st.vsFallback);
      vsFbRow.setAttribute('aria-checked', st.vsFallback ? 'true' : 'false');
      syncVoiceStudio();
      scheduleSave();
    });
    body.appendChild(vsFbRow);

    var inputStyle = 'width:100%;box-sizing:border-box;padding:10px 12px;border-radius:12px;border:1px solid var(--bd,rgba(128,128,128,.25));background:var(--bg2,rgba(128,128,128,.08));color:inherit;font:inherit;margin:6px 0 10px';
    var vsBox = h('div', { style: 'padding:4px 0 8px' });

    function vsField(label, key, placeholder, dir) {
      vsBox.appendChild(h('div', { style: 'font-size:.82rem;opacity:.75;margin-top:4px', text: label }));
      var inp = h('input', { type: 'text', value: st[key] || '', placeholder: placeholder, dir: dir || 'ltr', style: inputStyle });
      inp.addEventListener('input', function () {
        st[key] = inp.value;
        syncVoiceStudio();
        scheduleSave();
      });
      vsBox.appendChild(inp);
      return inp;
    }

    vsField('آدرس سرور VoiceStudio (وای‌فای محلی یا سرور آنلاین)', 'vsUrl', 'http://192.168.1.10:8000', 'ltr');

    vsBox.appendChild(h('div', { style: 'font-size:.82rem;opacity:.75;margin-top:4px', text: 'موتور / مدل VoiceStudio' }));
    var modelSel = h('select', { dir: 'ltr', style: inputStyle });
    [
      ['omnivoice', 'OmniVoice (پیشنهادی - ۶۴۶ زبان شامل فارسی)'],
      ['voxcpm2', 'VoxCPM2 (طراحی صدا و طبیعی‌ترین لحن)'],
      ['cosyvoice', 'CosyVoice (شبیه‌سازی صدا و چندزبانه)'],
      ['moss-tts-nano', 'MOSS-TTS Nano (سبک و سریع)'],
      ['kittentts', 'KittenTTS (سریع برای انگلیسی)'],
      ['tts-1-hd', 'موتور فعال پیش‌فرض سرور (tts-1-hd)']
    ].forEach(function (m) {
      var opt = h('option', { value: m[0], text: m[1] });
      if ((st.vsModel || 'omnivoice') === m[0]) opt.selected = true;
      modelSel.appendChild(opt);
    });
    modelSel.addEventListener('change', function () {
      st.vsModel = modelSel.value;
      syncVoiceStudio();
      scheduleSave();
    });
    vsBox.appendChild(modelSel);

    var voiceInp = vsField('نام یا شناسه پروفایل صدا (Voice ID / Name)', 'vsVoice', 'default', 'ltr');
    var voiceSelWrap = h('div', { style: 'display:none;margin-bottom:8px' });
    vsBox.appendChild(voiceSelWrap);

    vsField('دستور سبک خوانش (اختیاری - Instruct)', 'vsInstruct', 'warm narrator, calm audiobook tone', 'auto');
    vsField('کلید API (اختیاری - فقط در صورت فعال بودن رمز سرور)', 'vsApiKey', 'Bearer token (optional)', 'ltr');

    var vsBtns = h('div', { style: 'display:flex;gap:8px;margin-top:6px' });
    var testBtn = h('button', { class: 'btn grow', type: 'button', html: ic('speaker', 18) + '<span>تست اتصال سرور</span>' });
    var listBtn = h('button', { class: 'btn grow', type: 'button', html: ic('list', 18) + '<span>دریافت لیست صداها</span>' });
    testBtn.addEventListener('click', function () {
      toast('در حال بررسی اتصال به VoiceStudio…');
      vsRequestTest(function (ok) {
        if (ok) toast('اتصال به سرور VoiceStudio با موفقیت برقرار شد');
        else toast('سرور VoiceStudio در دسترس نیست؛ آدرس و شبکه را بررسی کنید');
      });
    });
    listBtn.addEventListener('click', function () {
      toast('در حال دریافت فهرست صداهای VoiceStudio…');
      vsRequestVoices(function (data) {
        var list = (data && Array.isArray(data.voices)) ? data.voices : (Array.isArray(data) ? data : null);
        if (!list || !list.length) {
          toast('لیست صدا دریافت نشد یا خالی است');
          return;
        }
        voiceSelWrap.innerHTML = '';
        voiceSelWrap.style.display = 'block';
        var sel = h('select', { dir: 'ltr', style: inputStyle });
        list.forEach(function (v) {
          var vid = v.voice_id || v.id || v.name || 'default';
          var vnm = (v.name || vid) + (v.type ? ' (' + v.type + ')' : '');
          var op = h('option', { value: vid, text: vnm });
          if (st.vsVoice === vid) op.selected = true;
          sel.appendChild(op);
        });
        sel.addEventListener('change', function () {
          st.vsVoice = sel.value;
          voiceInp.value = sel.value;
          syncVoiceStudio();
          scheduleSave();
        });
        voiceSelWrap.appendChild(sel);
        toast(fa(list.length) + ' صدا از VoiceStudio دریافت شد');
      });
    });
    vsBtns.appendChild(testBtn);
    vsBtns.appendChild(listBtn);
    vsBox.appendChild(vsBtns);
    body.appendChild(vsBox);

    body.appendChild(h('div', { class: 'sec-t', text: 'موتور صدای گوشی' }));
    var eng = h('button', { class: 'btn block', html: ic('sliders', 20) + '<span>تنظیمات تبدیل متن به گفتار</span>' });
    eng.addEventListener('click', function () { try { if (bridge('openTtsSettings')) A.openTtsSettings(); } catch (e) {} });
    var dat = h('button', { class: 'btn block', style: 'margin-top:8px', html: ic('download', 20) + '<span>نصب یا به‌روزرسانی صدای زبان‌ها</span>' });
    dat.addEventListener('click', function () { try { if (bridge('installTtsData')) A.installTtsData(); } catch (e) {} });
    body.appendChild(eng); body.appendChild(dat);
    body.appendChild(h('div', { class: 'empty-note', style: 'padding:16px 4px 0;text-align:start', text: 'خوانش، متن‌های عربی، انگلیسی، فرانسوی، آلمانی و ترکی استانبولی را به صورت خودکار تشخیص داده و می‌خواند و بخش‌های فارسی را رد می‌کند. موتور صدای گوشی باید صدای آن زبان را داشته باشد؛ اگر نداشت برنامه پیام می‌دهد و می‌توانید «نصب یا به‌روزرسانی صدا» را بزنید.' }));
  });
}

function sayFromBar(mode, hid) {
  var pg = currentPage(); if (!pg) return;
  var off = null;
  if (mode === 'hl') {
    var x = pg.hl.filter(function (q) { return q.id === hid; })[0];
    if (x) off = x.s;
  } else {
    var t = selectionTarget();
    if (t) off = t.s;
  }
  hideBar(); clearSel();
  ttsBegin(S.index, off == null ? 0 : off);
}

/* =====================================================================
   ویرایشگر صفحه
   ===================================================================== */
function editorOpen(o) {
  // o: {title, text, ok, onSave(text, opts), allowSplit}
  var ta = h('textarea', { class: 'lined-paper-input', dir: 'auto', spellcheck: 'false', placeholder: 'متن این صفحه را بنویسید یا بچسبانید…', 'aria-label': 'متن صفحه' });
  ta.value = o.text || '';
  var count = h('span', { class: 'grow' });
  var closeBtn = h('button', { class: 'ibtn', 'aria-label': 'بستن', html: ic('x') });
  var bgBtn = h('button', { class: 'ibtn', type: 'button', 'aria-label': 'تصویر زمینه دفترچه', title: 'تصویر زمینه دفترچه', html: ic('notebook', 20) });
  bgBtn.addEventListener('click', function () { openPageBgPicker(); });
  var saveBtn = h('button', { class: 'btn pri', text: o.ok || 'ذخیره', style: 'height:40px;padding:0 20px' });
  var node = h('div', { class: 'layer' }, [
    h('div', { class: 'editor' }, [
      h('div', { class: 'topbar' }, [closeBtn, h('h3', { text: o.title }), bgBtn, saveBtn]),
      h('div', { class: 'ta-wrap' }, [ta]),
      h('div', { class: 'foot' }, [count])
    ])
  ]);
  var initial = ta.value, L;
  function upd() {
    var n = ta.value.length;
    count.textContent = n ? (fa(n) + ' نویسه') : '';
  }
  function tryClose() {
    if (ta.value === initial) { L.close(true); return; }
    dialog({ title: 'تغییرات ذخیره نشده', message: 'می‌خواهید بدون ذخیره خارج شوید؟', ok: 'خروج', danger: true, cancel: 'ادامه‌ی نوشتن' })
      .then(function (r) { if (r) L.close(true); });
  }
  L = openLayer(node, { onBack: tryClose });
  closeBtn.addEventListener('click', tryClose);
  saveBtn.addEventListener('click', function () {
    var txt = norm(ta.value);
    if (!txt.replace(/\s+/g, '').length) { toast('متن صفحه خالی است'); return; }
    var r = o.onSave(txt);
    if (r !== false) L.close(true);
  });
  ta.addEventListener('input', upd);
  upd();
  setTimeout(function () {
    ta.focus();
    try { ta.setSelectionRange(ta.value.length, ta.value.length); } catch (e) {}
  }, 80);
  return L;
}

/* تقسیم متن به صفحه‌های هم‌اندازه (متناسب با اندازه‌ی صفحه‌ی فعلی) */
function splitByMarkers(text) {
  var parts = text.split(/\n[ \t]*(?:-{3,}|\*{3,}|_{3,})[ \t]*(?:\n|$)/);
  return parts.map(function (s) { return s.replace(/^\n+|\s+$/g, ''); }).filter(function (s) { return s.length; });
}
function splitToFit(text) {
  var ref = pageParts(pBase).scroll;
  var cs = getComputedStyle(ref);
  var w = ref.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
  var hgt = ref.clientHeight - parseFloat(cs.paddingTop) - parseFloat(cs.paddingBottom) + 8;
  var holder = h('div', { class: 'measure' });
  var box = h('div', { class: 'page-text', style: 'width:' + w + 'px' });
  holder.appendChild(box);
  document.body.appendChild(holder);
  var tokens = text.match(/\S+|\s+/g) || [];
  var pages = [], i = 0;
  function fits(a, b) {
    renderLines(box, tokens.slice(a, b).join('').replace(/^\s+|\s+$/g, ''), [], null);
    return box.offsetHeight <= hgt;
  }
  while (i < tokens.length) {
    while (i < tokens.length && /^\s+$/.test(tokens[i])) i++;
    if (i >= tokens.length) break;
    var lo = i + 1, hi = tokens.length, best = i + 1;
    if (fits(i, hi)) best = hi;
    else {
      while (lo <= hi) {
        var mid = (lo + hi) >> 1;
        if (fits(i, mid)) { best = mid; lo = mid + 1; } else hi = mid - 1;
      }
    }
    if (best <= i) best = i + 1;
    var chunk = tokens.slice(i, best).join('').replace(/^\s+|\s+$/g, '');
    if (chunk) pages.push(chunk);
    i = best;
  }
  document.body.removeChild(holder);
  return pages;
}
function overflowsOnePage(text) {
  var ref = pageParts(pBase).scroll;
  var cs = getComputedStyle(ref);
  var w = ref.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
  var hgt = ref.clientHeight - parseFloat(cs.paddingTop) - parseFloat(cs.paddingBottom) + 8;
  var holder = h('div', { class: 'measure' });
  var box = h('div', { class: 'page-text', style: 'width:' + w + 'px' });
  holder.appendChild(box); document.body.appendChild(holder);
  renderLines(box, text, [], null);
  var over = box.offsetHeight > hgt;
  document.body.removeChild(holder);
  return over;
}

function newPageObj(text) {
  var now = Date.now();
  return { id: uid(), text: text, created: now, updated: now, hl: [] };
}
function insertPages(texts, at) {
  var b = curBook();
  var objs = texts.map(newPageObj);
  b.pages.splice.apply(b.pages, [at, 0].concat(objs));
  touch(b, null);
  return objs.length;
}

function addPageFlow(afterIndex) {
  var b = curBook(); if (!b) return;
  var at = afterIndex == null ? b.pages.length : clamp(afterIndex + 1, 0, b.pages.length);
  editorOpen({
    title: 'صفحه‌ی جدید', ok: 'افزودن', text: '',
    onSave: function (text) {
      var markers = splitByMarkers(text);
      var go = function (pages) {
        var n = insertPages(pages, at);
        showPageNow(at);
        if (n > 1) toast(fa(n) + ' صفحه اضافه شد');
      };
      if (markers.length > 1) {
        dialog({ title: 'تقسیم متن به چند صفحه', message: 'در متن شما خط جداکننده (---) وجود دارد. متن به ' + fa(markers.length) + ' صفحه تقسیم شود؟',
          ok: 'تقسیم کن', cancel: 'یک صفحه' }).then(function (r) {
          if (r === null) go([text]); else go(markers);
        });
        return true;
      }
      if (overflowsOnePage(text)) {
        var parts = splitToFit(text);
        if (parts.length > 1) {
          dialog({ title: 'متن بلندتر از یک صفحه است', message: 'متن را خودکار به ' + fa(parts.length) +
            ' صفحه‌ی هم‌اندازه تقسیم کنم؟ (در غیر این صورت در یک صفحه می‌ماند و با کشیدن به بالا و پایین خوانده می‌شود.)',
            ok: 'تقسیم کن', cancel: 'یک صفحه' }).then(function (r) {
            if (r === null) go([text]); else go(parts);
          });
          return true;
        }
      }
      go([text]);
      return true;
    }
  });
}
function editPageFlow() {
  var b = curBook(), pg = currentPage(); if (!b || !pg) return;
  editorOpen({
    title: 'ویرایش صفحه‌ی ' + fa(S.index + 1), ok: 'ذخیره', text: pg.text,
    onSave: function (text) {
      if (text !== pg.text) {
        ttsStop();
        pg.hl = remapHighlights(pg.text, text, pg.hl);
        pg.text = text;
        touch(b, pg);
      }
      rerenderCurrent();
      return true;
    }
  });
}
function deletePageFlow(idx) {
  var b = curBook(); if (!b || idx >= b.pages.length) return;
  dialog({ title: 'حذف صفحه', message: 'صفحه‌ی ' + fa(idx + 1) + ' حذف شود؟', ok: 'حذف', danger: true }).then(function (r) {
    if (!r) return;
    ttsStop();
    var removed = b.pages.splice(idx, 1)[0];
    touch(b, null);
    showPageNow(Math.min(idx, b.pages.length));
    toast('صفحه حذف شد', { label: 'بازگردانی', fn: function () {
      b.pages.splice(Math.min(idx, b.pages.length), 0, removed);
      touch(b, null);
      showPageNow(Math.min(idx, b.pages.length - 1));
    } });
  });
}
function movePage(idx, delta) {
  var b = curBook(), j = idx + delta;
  if (!b || j < 0 || j >= b.pages.length) return false;
  ttsStop();
  var t = b.pages[idx]; b.pages[idx] = b.pages[j]; b.pages[j] = t;
  touch(b, null);
  return true;
}

/* =====================================================================
   شیت‌ها: فهرست صفحه‌ها، هایلایت‌ها، جستجو، تنظیمات
   ===================================================================== */
function openToc() {
  var b = curBook(); if (!b) return;
  sheet('فهرست صفحه‌ها', function (body, L) {
    var topShareHubBtn = h('button', { class: 'btn-exp share-hub', type: 'button', html: ic('share', 15) + '<span>بخش اشتراک‌گذاری کتاب و صفحات</span>' });
    var topPdfBtn = h('button', { class: 'btn-exp pdf', type: 'button', html: ic('pdf', 15) + '<span>PDF</span>' });
    var topWordBtn = h('button', { class: 'btn-exp word', type: 'button', html: ic('word', 15) + '<span>Word</span>' });
    var topMdBtn = h('button', { class: 'btn-exp md', type: 'button', html: ic('md', 15) + '<span>Markdown</span>' });
    var topJsBtn = h('button', { class: 'btn-exp js', type: 'button', html: ic('js', 15) + '<span>JS</span>' });
    topShareHubBtn.addEventListener('click', function () { L.close(true); openBookPageShareSheet(b, S.index); });
    topPdfBtn.addEventListener('click', function () { exportBook(b, 'pdf'); });
    topWordBtn.addEventListener('click', function () { exportBook(b, 'word'); });
    topMdBtn.addEventListener('click', function () { exportBook(b, 'md'); });
    topJsBtn.addEventListener('click', function () { exportBook(b, 'js'); });
    if (b.pages.length) {
      body.appendChild(h('div', { class: 'exp-acts', style: 'margin-bottom:10px;justify-content:center' }, [topShareHubBtn, topPdfBtn, topWordBtn, topMdBtn, topJsBtn]));
    }
    var tocMode = 'all';
    var bmCount = b.pages.filter(function (p) { return !!p.bm; }).length;
    var chList = getBookChapters(b);
    var tocTabs = h('div', { class: 'toc-mode-bar' });
    var btnAll = h('button', { class: 'toc-mode-btn on', type: 'button', text: 'همه (' + fa(b.pages.length) + ')' });
    var btnCh = h('button', { class: 'toc-mode-btn', type: 'button', html: ic('book', 14) + '<span>فصل‌ها (' + fa(chList.length) + ')</span>' });
    var btnBm = h('button', { class: 'toc-mode-btn', type: 'button', html: ic('bookmarkFill', 14) + '<span>نشانک (' + fa(bmCount) + ')</span>' });
    function setTocTab(m) {
      tocMode = m;
      btnAll.classList.toggle('on', m === 'all');
      btnCh.classList.toggle('on', m === 'ch');
      btnBm.classList.toggle('on', m === 'bm');
      draw();
    }
    btnAll.addEventListener('click', function () { setTocTab('all'); });
    btnCh.addEventListener('click', function () { setTocTab('ch'); });
    btnBm.addEventListener('click', function () { setTocTab('bm'); });
    tocTabs.appendChild(btnAll); tocTabs.appendChild(btnCh); tocTabs.appendChild(btnBm);
    if (b.pages.length) body.appendChild(tocTabs);
    var list = h('div');
    var filter = h('input', { class: 'field', type: 'search', placeholder: 'جستجو در فهرست…', dir: 'auto', style: 'margin-bottom:6px' });
    if (b.pages.length > 6) body.appendChild(filter);
    body.appendChild(list);
    function draw() {
      list.textContent = '';
      var q = filter.value.trim(), shown = 0;
      if (tocMode === 'ch') {
        var chs = getBookChapters(b);
        if (!chs.length) {
          list.appendChild(h('div', { class: 'empty-note', text: 'فصل یا سرفصل مشخصی در این کتاب پیدا نشد. کتاب‌های EPUB و فایل‌های دارای تیتر «فصل / Chapter» به صورت خودکار اینجا فهرست می‌شوند.' }));
          return;
        }
        chs.forEach(function (ch) {
          if (q && ch.t.indexOf(q) < 0) return;
          var cRow = h('div', { class: 'toc-ch-item' }, [
            h('span', { class: 'toc-ch-num', text: 'ص ' + fa(ch.p + 1) }),
            h('span', { class: 'toc-ch-title', dir: 'auto', text: ch.t })
          ]);
          cRow.addEventListener('click', function () { L.close(); showPageNow(clamp(ch.p, 0, Math.max(0, b.pages.length - 1))); });
          list.appendChild(cRow);
        });
        return;
      }
      b.pages.forEach(function (pg, i) {
        if (tocMode === 'bm' && !pg.bm) return;
        if (q && pg.text.indexOf(q) < 0) return;
        shown++;
        var sh = h('button', { class: 'ibtn', 'aria-label': 'اشتراک‌گذاری این صفحه', title: 'اشتراک‌گذاری صفحه ' + fa(i + 1) + ' (PDF / Word / MD / JS)', html: ic('share', 19) });
        var up = h('button', { class: 'ibtn', 'aria-label': 'بالاتر', html: ic('up', 20) });
        var dn = h('button', { class: 'ibtn', 'aria-label': 'پایین‌تر', html: ic('down', 20) });
        var rm = h('button', { class: 'ibtn', 'aria-label': 'حذف صفحه', html: ic('trash', 20) });
        up.disabled = i === 0 || !!q; dn.disabled = i === b.pages.length - 1 || !!q;
        var row = h('div', { class: 'page-item' + (i === S.index ? ' cur' : '') }, [
          h('div', { class: 'num' + (pg.bm ? ' bm' : ''), html: fa(i + 1) + (pg.bm ? '<span class="toc-bm-dot">' + ic('bookmarkFill', 11) + '</span>' : '') }),
          h('div', { class: 'body' }, [
            h('div', { class: 'sn', dir: 'auto', text: snippet(pg.text, 110) }),
            h('div', { class: 'pg', text: (pg.bm ? 'نشانک‌دار · ' : '') + (pg.hl.length ? fa(pg.hl.length) + ' هایلایت · ' : '') + fmtDate(pg.updated) })
          ]),
          h('div', { class: 'mini' }, [sh, up, dn, rm])
        ]);
        row.addEventListener('click', function (e) {
          if (e.target.closest('.mini')) return;
          L.close(); showPageNow(i);
        });
        sh.addEventListener('click', function (e) {
          e.stopPropagation();
          menu(sh, [
            { icon: 'share', label: 'بخش اشتراک‌گذاری و پیش‌نمایش صفحه‌ی ' + fa(i + 1) + '…', fn: function () { L.close(true); openBookPageShareSheet(b, i); } },
            '-',
            { icon: 'pdf', label: 'ارسال صفحه‌ی ' + fa(i + 1) + ' به صورت PDF (.pdf)', fn: function () { exportBook(b, 'pdf', i); } },
            { icon: 'word', label: 'ارسال صفحه‌ی ' + fa(i + 1) + ' به صورت Word (.docx)', fn: function () { exportBook(b, 'word', i); } },
            { icon: 'md', label: 'ارسال صفحه‌ی ' + fa(i + 1) + ' به صورت Markdown (.md)', fn: function () { exportBook(b, 'md', i); } },
            { icon: 'js', label: 'ارسال صفحه‌ی ' + fa(i + 1) + ' به صورت JavaScript (.js)', fn: function () { exportBook(b, 'js', i); } },
            '-',
            { icon: 'copy', label: 'کپی کد Markdown صفحه‌ی ' + fa(i + 1), fn: function () { exportBook(b, 'md', i, { copyOnly: true }); } },
            { icon: 'copy', label: 'کپی کد JS صفحه‌ی ' + fa(i + 1), fn: function () { exportBook(b, 'js', i, { copyOnly: true }); } },
            { icon: 'share', label: 'اشتراک‌گذاری متنی صفحه‌ی ' + fa(i + 1), fn: function () { shareText(pg.text, b.title + ' - صفحه ' + fa(i + 1)); } }
          ]);
        });
        up.addEventListener('click', function () { if (movePage(i, -1)) { fixIndexAfterMove(); draw(); } });
        dn.addEventListener('click', function () { if (movePage(i, 1)) { fixIndexAfterMove(); draw(); } });
        rm.addEventListener('click', function () { L.close(); deletePageFlow(i); });
        list.appendChild(row);
      });
      if (!shown) list.appendChild(h('div', { class: 'empty-note', text: tocMode === 'bm' ? 'هنوز صفحه‌ای نشانک‌گذاری نشده است. با دکمه‌ی نشانک در نوار بالا هر صفحه را علامت بزنید.' : (b.pages.length ? 'صفحه‌ای با این متن پیدا نشد.' : 'کتاب هنوز صفحه‌ای ندارد.') }));
    }
    function fixIndexAfterMove() {
      // نشانگر صفحه‌ی جاری باید همراه جابه‌جایی صفحه حرکت کند
      var cur = S.__curId;
      for (var k = 0; k < b.pages.length; k++) if (b.pages[k].id === cur) { S.index = k; break; }
      b.last = S.index;
    }
    S.__curId = b.pages[S.index] ? b.pages[S.index].id : null;
    filter.addEventListener('input', draw);
    draw();
  }, { onClose: function () { showPageNow(S.index); } });
}

function openHighlights() {
  var b = curBook(); if (!b) return;
  sheet('هایلایت‌های کتاب', function (body, L) {
    var all = [];
    b.pages.forEach(function (pg, i) { pg.hl.forEach(function (x) { all.push({ pg: pg, i: i, x: x }); }); });
    if (!all.length) {
      body.appendChild(h('div', { class: 'empty-note', html: 'هنوز هایلایتی ندارید.<br>در صفحه چند لحظه روی یک کلمه انگشت بگذارید، متن را انتخاب کنید و یکی از ۱۲ رنگ را بزنید.' }));
      return;
    }
    var filter = null;
    var hlPdfBtn = h('button', { class: 'btn-exp pdf', type: 'button', html: ic('pdf', 16) + '<span>ارسال PDF</span>' });
    var hlWordBtn = h('button', { class: 'btn-exp word', type: 'button', html: ic('word', 16) + '<span>ارسال Word</span>' });
    var hlMdBtn = h('button', { class: 'btn-exp md', type: 'button', html: ic('md', 16) + '<span>Markdown</span>' });
    var hlJsBtn = h('button', { class: 'btn-exp js', type: 'button', html: ic('js', 16) + '<span>JS</span>' });
    var shareBtn = h('button', { class: 'btn-exp', type: 'button', html: ic('share', 16) + '<span>متن ساده</span>' });
    function exportHl(fmt) {
      var pages = [];
      b.pages.forEach(function (pg, i) {
        pg.hl.forEach(function (x) {
          if (filter && x.c !== filter) return;
          pages.push({
            heading: 'صفحه ' + fa(i + 1) + ' (' + (COLOR_NAMES[x.c] || 'هایلایت') + ')',
            meta: b.title,
            text: pg.text.slice(x.s, x.e),
            hl: [{ s: 0, e: pg.text.slice(x.s, x.e).length, c: x.c }],
            badgeColor: '#' + (HL_HEX[x.c] || '007AFF'),
            badgeHex: HL_HEX[x.c] || 'FDE047'
          });
        });
      });
      if (!pages.length) { toast('هایلایتی با این رنگ نیست'); return; }
      runExportDocSpec({
        kind: 'pages',
        title: 'هایلایت‌های «' + b.title + '»',
        subtitle: fa(pages.length) + ' مورد برگزیده',
        fileBase: b.title + '-highlights',
        accent: '#007aff',
        pageBreak: false,
        pages: pages
      }, fmt);
    }
    hlPdfBtn.addEventListener('click', function () { exportHl('pdf'); });
    hlWordBtn.addEventListener('click', function () { exportHl('word'); });
    hlMdBtn.addEventListener('click', function () { exportHl('md'); });
    hlJsBtn.addEventListener('click', function () { exportHl('js'); });
    shareBtn.addEventListener('click', function () { shareText(highlightsText(b, filter), 'هایلایت‌های ' + b.title); });
    body.appendChild(h('div', { class: 'exp-acts', style: 'margin-bottom:10px;justify-content:center' }, [hlPdfBtn, hlWordBtn, hlMdBtn, hlJsBtn, shareBtn]));
    var dots = h('div', { class: 'cfilter' });
    body.appendChild(dots);
    var list = h('div'); body.appendChild(list);
    function used() { return COLORS.filter(function (c) { return all.some(function (it) { return it.x.c === c; }); }); }
    function drawDots() {
      dots.textContent = '';
      var u = used();
      if (filter && u.indexOf(filter) < 0) filter = null;
      dots.style.display = u.length > 1 ? '' : 'none';
      var allb = h('button', { class: 'chip sm' + (filter ? '' : ' on'), text: 'همه' });
      allb.addEventListener('click', function () { filter = null; drawDots(); drawList(); });
      dots.appendChild(allb);
      u.forEach(function (c) {
        var d = h('button', { class: 'fdot' + (filter === c ? ' on' : ''), 'data-c': c, 'aria-label': COLOR_NAMES[c], title: COLOR_NAMES[c] });
        d.addEventListener('click', function () { filter = filter === c ? null : c; drawDots(); drawList(); });
        dots.appendChild(d);
      });
    }
    function drawList() {
      list.textContent = '';
      var shown = 0;
      all.forEach(function (it) {
        if (filter && it.x.c !== filter) return;
        shown++;
        var rm = h('button', { class: 'ibtn', 'aria-label': 'حذف', html: ic('trash', 20) });
        var row = h('div', { class: 'hl-item' }, [
          h('div', { class: 'col', 'data-c': it.x.c }),
          h('div', { class: 'body' }, [
            h('div', { class: 'tx', dir: 'auto', text: snippet(it.pg.text.slice(it.x.s, it.x.e), 220) }),
            h('div', { class: 'pg', text: 'صفحه ' + fa(it.i + 1) })
          ]), rm
        ]);
        row.addEventListener('click', function (e) {
          if (e.target.closest('.ibtn')) return;
          L.close(true);
          showPageNow(it.i, { flash: { s: it.x.s, e: it.x.e } });
        });
        rm.addEventListener('click', function () {
          it.pg.hl = it.pg.hl.filter(function (q) { return q.id !== it.x.id; });
          touch(b, it.pg);
          all.splice(all.indexOf(it), 1);
          rerenderCurrent();
          if (!all.length) { L.close(true); return; }
          drawDots(); drawList();
        });
        list.appendChild(row);
      });
      if (!shown) list.appendChild(h('div', { class: 'empty-note', text: 'هایلایتی با این رنگ نیست.' }));
    }
    drawDots(); drawList();
  });
}

function highlightsText(b, color) {
  var out = ['«' + b.title + '» — هایلایت‌ها', ''];
  b.pages.forEach(function (pg, i) {
    pg.hl.forEach(function (x) {
      if (color && x.c !== color) return;
      out.push('• ' + pg.text.slice(x.s, x.e).replace(/\s*\n\s*/g, ' ') + ' (صفحه ' + fa(i + 1) + ')');
    });
  });
  return out.join('\n');
}
function bookText(b) {
  var out = ['«' + b.title + '»', ''];
  b.pages.forEach(function (pg, i) { out.push('— صفحه ' + fa(i + 1) + ' —', '', pg.text, ''); });
  return out.join('\n');
}

function openSearch() {
  var b = curBook(); if (!b) return;
  sheet('جستجو در کتاب', function (body, L) {
    var input = h('input', { class: 'field', type: 'search', placeholder: 'کلمه یا عبارت…', dir: 'auto', enterkeyhint: 'search' });
    var list = h('div', { style: 'margin-top:8px' });
    body.appendChild(input); body.appendChild(list);
    function run() {
      list.textContent = '';
      var q = input.value.trim();
      if (!q) { list.appendChild(h('div', { class: 'empty-note', text: 'متن مورد نظر را بنویسید.' })); return; }
      var ql = q.toLowerCase(), count = 0;
      b.pages.forEach(function (pg, i) {
        var tl = pg.text.toLowerCase(), from = 0, idx;
        var hits = 0;
        while ((idx = tl.indexOf(ql, from)) >= 0 && hits < 5 && count < 120) {
          hits++; count++; from = idx + ql.length;
          (function (pgI, at) {
            var a = Math.max(0, at - 36), z = Math.min(pg.text.length, at + q.length + 60);
            var pre = pg.text.slice(a, at).replace(/\s+/g, ' '), mid = pg.text.slice(at, at + q.length), post = pg.text.slice(at + q.length, z).replace(/\s+/g, ' ');
            var sn = h('div', { class: 'sn', dir: 'auto' });
            sn.appendChild(document.createTextNode((a > 0 ? '… ' : '') + pre));
            sn.appendChild(h('mark', { text: mid }));
            sn.appendChild(document.createTextNode(post + (z < pg.text.length ? ' …' : '')));
            var row = h('div', { class: 'res-item' }, [h('div', { class: 'body' }, [sn, h('div', { class: 'pg', text: 'صفحه ' + fa(pgI + 1) })])]);
            row.addEventListener('click', function () { L.close(true); showPageNow(pgI, { flash: { s: at, e: at + q.length } }); });
            list.appendChild(row);
          })(i, idx);
        }
      });
      if (!count) list.appendChild(h('div', { class: 'empty-note', text: 'نتیجه‌ای پیدا نشد.' }));
    }
    input.addEventListener('input', run);
    run();
    setTimeout(function () { input.focus(); }, 120);
  });
}

function gotoDialog() {
  var b = curBook(); if (!b || !b.pages.length) return;
  var total = b.pages.length;
  var cur = clamp(S.index, 0, total - 1);
  sheet('پرش سریع به صفحه', function (body, L) {
    var pctEl = h('span', { class: 'scrub-pct' });
    var numEl = h('b', { class: 'scrub-num' });
    var head = h('div', { class: 'scrub-head' }, [numEl, pctEl]);
    var rng = h('input', { class: 'rng scrub-rng', type: 'range', min: 1, max: total, value: cur + 1 });
    var preview = h('div', { class: 'scrub-preview', dir: 'auto' });
    var numInput = h('input', { class: 'field scrub-in', type: 'number', min: 1, max: total, value: String(cur + 1), placeholder: 'شماره صفحه…' });
    var goBtn = h('button', { class: 'btn pri', type: 'button', text: 'برو به صفحه' });
    function sync(idx) {
      idx = clamp(idx, 0, total - 1);
      var pct = Math.round(((idx + 1) / total) * 100);
      numEl.textContent = 'صفحه ' + fa(idx + 1) + ' از ' + fa(total);
      pctEl.textContent = fa(pct) + '٪';
      rng.value = idx + 1;
      rng.style.setProperty('--p', (total > 1 ? (idx / (total - 1)) * 100 : 100) + '%');
      numInput.value = String(idx + 1);
      var pg = b.pages[idx];
      preview.textContent = pg ? (snippet(pg.text, 150) || 'صفحه‌ی بدون متن') : '';
    }
    rng.addEventListener('input', function () { sync((+rng.value || 1) - 1); });
    numInput.addEventListener('input', function () {
      var n = parseInt(String(numInput.value).replace(/[۰-۹]/g, function (c) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(c); }).replace(/[٠-٩]/g, function (c) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(c); }), 10);
      if (n >= 1 && n <= total) sync(n - 1);
    });
    function commit() {
      var n = parseInt(String(numInput.value).replace(/[۰-۹]/g, function (c) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(c); }).replace(/[٠-٩]/g, function (c) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(c); }), 10);
      var target = clamp((n || (+rng.value || 1)) - 1, 0, total - 1);
      L.close();
      showPageNow(target);
      hapticTap();
    }
    goBtn.addEventListener('click', commit);
    numInput.addEventListener('keydown', function (e) { if (e.key === 'Enter') commit(); });
    body.appendChild(head);
    if (total > 1) body.appendChild(rng);
    body.appendChild(preview);
    var bms = [];
    b.pages.forEach(function (pg, i) { if (pg.bm) bms.push(i); });
    if (bms.length) {
      var bmWrap = h('div', { class: 'scrub-bms' }, [h('small', { text: 'نشانک‌ها:' })]);
      bms.slice(0, 12).forEach(function (bi) {
        var pill = h('button', { class: 'scrub-bm-pill', type: 'button', html: ic('bookmarkFill', 12) + '<span>' + fa(bi + 1) + '</span>' });
        pill.addEventListener('click', function () { L.close(); showPageNow(bi); hapticTap(); });
        bmWrap.appendChild(pill);
      });
      body.appendChild(bmWrap);
    }
    body.appendChild(h('div', { class: 'scrub-foot' }, [numInput, goBtn]));
    sync(cur);
  });
}

function hasCustomBgImage() {
  var st = S.data && S.data.settings;
  if (!st) return false;
  return !!(st.pageBgCover || st.pageBgImg);
}

function pickStudyBgImage(cb) {
  pickCoverImage('bg_' + uid(), function (res) {
    if (!res) return;
    cb(res);
  });
}

function buildPageBgGrid(onSelectCb) {
  var st = S.data.settings;
  var wrap = h('div', { class: 'nb-picker-wrap' });
  var customRow = h('div', { class: 'nb-custom-bar' });
  var grid = h('div', { class: 'nb-grid' });
  wrap.appendChild(customRow);
  wrap.appendChild(grid);

  function renderCustomBar() {
    customRow.textContent = '';
    var hasCustom = hasCustomBgImage();
    var pickImgBtn = h('button', {
      class: 'btn pri',
      type: 'button',
      html: ic('image', 18) + '<span>' + (hasCustom ? 'تغییر عکس زمینه از گالری' : 'انتخاب عکس زمینه از گالری') + '</span>'
    });
    pickImgBtn.addEventListener('click', function () {
      pickStudyBgImage(function (res) {
        if (st.pageBgCover && res.cover && st.pageBgCover !== res.cover) {
          dropCoverFile(st.pageBgCover);
        }
        st.pageBgCover = res.cover || '';
        st.pageBgImg = res.coverData || '';
        st.pageBg = 'custom_img';
        scheduleSave();
        applyTheme();
        if (S.view === 'reader') rerenderCurrent();
        if (S.view === 'library' && S.libTab === 'notes') renderNotes();
        if (onSelectCb) onSelectCb(findPageBg('custom_img'));
        renderCustomBar();
        refreshGrid();
        toast('عکس زمینه از گالری انتخاب و اعمال شد');
      });
    });
    customRow.appendChild(pickImgBtn);

    if (hasCustom) {
      var useCustomBtn = h('button', {
        class: 'btn' + (st.pageBg === 'custom_img' ? ' on' : ''),
        type: 'button',
        html: ic('check', 16) + '<span>عکس انتخابی</span>'
      });
      var rmCustomBtn = h('button', {
        class: 'ibtn',
        type: 'button',
        'aria-label': 'حذف عکس انتخابی',
        title: 'حذف عکس انتخابی',
        html: ic('trash', 18)
      });
      useCustomBtn.addEventListener('click', function () {
        st.pageBg = 'custom_img';
        scheduleSave(); applyTheme();
        if (S.view === 'reader') rerenderCurrent();
        if (onSelectCb) onSelectCb(findPageBg('custom_img'));
        renderCustomBar();
        refreshGrid();
        toast('عکس زمینه‌ی انتخابی فعال شد');
      });
      rmCustomBtn.addEventListener('click', function () {
        if (st.pageBgCover) dropCoverFile(st.pageBgCover);
        st.pageBgCover = '';
        st.pageBgImg = '';
        if (st.pageBg === 'custom_img') st.pageBg = 'classic';
        scheduleSave(); applyTheme();
        if (S.view === 'reader') rerenderCurrent();
        renderCustomBar();
        refreshGrid();
        toast('عکس انتخابی حذف شد');
      });
      customRow.appendChild(useCustomBtn);
      customRow.appendChild(rmCustomBtn);
    }
  }

  function refreshGrid() {
    grid.textContent = '';
    var th = THEMES[resolveTheme()] || THEMES.paper;
    var items = PAGE_BGS.slice();
    if (hasCustomBgImage()) {
      items.unshift(findPageBg('custom_img'));
    }
    items.forEach(function (pb) {
      var active = (st.pageBg || 'classic') === pb.id;
      var bgCol = pb.bg || 'var(--page)';
      var inkCol = pb.ink || 'var(--ink)';
      var svgUri = makeNotebookSvgUri(pb, 18, !!th.dark);
      var decorUri = makePageDecorUri(pb);
      var bgImgVal = svgUri !== 'none' && decorUri !== 'none' ? (svgUri + ', ' + decorUri) : (svgUri !== 'none' ? svgUri : decorUri);
      var bgSizeVal = svgUri !== 'none' && decorUri !== 'none' ? '100% 18px, cover' : (svgUri !== 'none' ? '100% 18px' : 'cover');
      var bgPosVal = svgUri !== 'none' && decorUri !== 'none' ? '0 6px, center' : (svgUri !== 'none' ? '0 6px' : 'center');
      var sampleStyle = 'background-color:' + bgCol + ';color:' + inkCol + ';background-image:' + bgImgVal + ';background-size:' + bgSizeVal + ';background-position:' + bgPosVal + ';';
      var sample = h('div', { class: 'nb-prev' + (pb.margin ? ' has-margin' : '') + (pb.id === 'custom_img' ? ' is-custom-img' : ''), style: sampleStyle }, [
        pb.margin ? h('i', { class: 'nb-m-line', style: 'background:' + hexToRgba(pb.margin, 0.45) }) : null,
        h('span', { class: 'nb-smp-txt', text: 'متن نمونه در دفترچه' }),
        h('span', { class: 'nb-smp-txt sm', text: pb.kind === 'image' ? 'تصویر زمینه مطالعه' : 'خط‌های افقی ممتد' })
      ]);
      var card = h('button', {
        class: 'nb-card' + (active ? ' on' : ''),
        type: 'button',
        'data-nb': pb.id,
        'aria-label': pb.name
      }, [
        sample,
        h('div', { class: 'nb-info' }, [
          h('div', { style: 'min-width:0;flex:1' }, [
            h('b', { text: pb.name }),
            h('small', { text: pb.sub })
          ]),
          h('span', { class: 'ui-chk', html: ic('check', 11) })
        ])
      ]);
      card.addEventListener('click', function () {
        st.pageBg = pb.id;
        $$('.nb-card', grid).forEach(function (x) { x.classList.toggle('on', x === card); });
        scheduleSave();
        applyTheme();
        if (S.view === 'reader') rerenderCurrent();
        if (S.view === 'library' && S.libTab === 'notes') renderNotes();
        if (onSelectCb) onSelectCb(pb);
        renderCustomBar();
        toast('تصویر زمینه‌ی مطالعه: «' + pb.name + '»');
      });
      grid.appendChild(card);
    });
  }

  renderCustomBar();
  refreshGrid();
  return wrap;
}

function openPageBgPicker(afterCb) {
  sheet('تصویر زمینه مطالعه', function (body) {
    body.appendChild(h('div', { class: 'empty-note', style: 'padding:2px 2px 12px;text-align:start;line-height:1.85',
      text: 'تصویر زمینه‌ی مطالعه را از میان طرح‌های دفترچه‌ای با خط‌های افقی ممتد، تصاویر آماده یا تصویر دلخواه از گالری انتخاب کنید.' }));
    body.appendChild(buildPageBgGrid(afterCb));
  });
}

function getAppGuideSections() {
  return [
    {
      icon: 'book',
      badge: '۱',
      title: 'بخش کتاب‌ها و ذخیره‌ی دستی در بخش‌های زبانی',
      summary: 'ساخت، ویرایش و ذخیره‌ی دستی هر کتاب در بخش کتاب‌های انگلیسی، فارسی، فرانسوی، آلمانی، عربی، ترکی و...',
      points: [
        'ساخت کتاب جدید: با زدن دکمه‌ی «+ کتاب جدید»، نام کتاب، تصویر جلد (از گالری) و بخش زبانی کتاب را انتخاب کنید.',
        'ذخیره‌ی دستی هر کتاب در بخش‌ها: در قسمت کتاب‌ها می‌توانید هر کتاب را به صورت کاملاً دستی در یکی از بخش‌های «کتاب‌های انگلیسی (EN)»، «کتاب‌های فارسی (FA)»، «فرانسوی (FR)»، «آلمانی (DE)»، «عربی (AR)»، «ترکی استانبولی (TR)» یا بخش‌های دلخواه ذخیره و جابه‌جا کنید.',
        'سه روش سریع تغییر بخش کتاب: ۱) ضربه روی دکمه‌ی نشان زبان روی جلد هر کتاب در کتابخانه، ۲) دکمه‌ی «ذخیره دستی در بخش‌ها» در نوار بالای کتاب‌ها، ۳) منوی سه‌نقطه‌ی هر کتاب.',
        'مطالعه و ورق‌زدن طبیعی: در بخش کتاب‌ها تا ۲۰ کتاب در هر صفحه با لمس صفحه بالا و پایین می‌شوند و در داخل هر صفحه‌ی کتاب نیز می‌توانید با لمس صفحه مطالب را به نرمی بالا و پایین ببرید و برگه‌ها را به چپ و راست ورق بزنید.'
      ]
    },
    {
      icon: 'hl',
      badge: '۲',
      title: 'هایلایت ۱۲ رنگ، جستجو، فهرست و اشتراک‌گذاری ۴ فرمت (PDF, Word, Markdown, JS)',
      summary: 'علامت‌گذاری متن‌ها با ۱۲ رنگ و اشتراک‌گذاری هر صفحه یا کل کتاب به صورت PDF، Word، Markdown (.md) و JavaScript (.js)',
      points: [
        'هایلایت ۱۲ رنگ: در صفحه‌ی خواندن کتاب، انگشت خود را روی کلمه یا جمله نگه دارید تا انتخاب شود؛ سپس از نوار پایین یکی از ۱۲ رنگ ماژیک را لمس کنید.',
        'ویرایش یا حذف هایلایت: با ضربه روی هر بخش هایلایت‌شده می‌توانید رنگ آن را تغییر دهید، آن را پاک کنید، به عنوان یادداشت ذخیره نمایید یا با صدا بشنوید.',
        'بخش اشتراک‌گذاری کتاب و صفحات (PDF / Word / Markdown / JS): از دکمه‌ی اشتراک‌گذاری در نوار بالای مطالعه، فهرست صفحه‌ها، منوی سه‌نقطه یا نوار بالای کتابخانه می‌توانید هر صفحه، مجموعه‌ای از صفحات یا کل کتاب را به صورت فایل PDF، Word (.docx)، Markdown (.md) و JavaScript (.js) ذخیره، کپی یا به اشتراک بگذارید.'
      ]
    },
    {
      icon: 'words',
      badge: '۳',
      title: 'بخش لغات و سیستم مرور هوشمند لایتنر (۵ سطحی)',
      summary: 'ذخیره‌ی واژه‌های جدید به تفکیک ۶ زبان، پیشنهاد معنی آنلاین و مرور فلش‌کارت',
      points: [
        'ثبت واژه از متن یا مستقل: هنگام مطالعه‌ی کتاب یا یادداشت، واژه‌ی ناآشنا را انتخاب کرده و آیکن «ذخیره‌ی واژه» را بزنید، یا در تب «لغات» دکمه‌ی «+ لغت جدید» را لمس کنید.',
        'تفکیک مجزای هر زبان: واژه‌های هر زبان (انگلیسی، فرانسوی، ترکی استانبولی، آلمانی، عربی و فارسی) در بخش اختصاصی همان زبان ذخیره می‌شوند تا با هم قاطی نشوند.',
        'فلش‌کارت ۵ سطحی (لایتنر): با زدن دکمه‌ی «مرور فلش‌کارت»، کارت‌های واژه نمایش داده می‌شوند و بر اساس میزان تسلط شما در فواصل ۱، ۳، ۷، ۱۴ و ۳۰ روزه زمان‌بندی می‌گردند.'
      ]
    },
    {
      icon: 'layers',
      badge: '۴',
      title: 'بخش مرور سریع و اسکرول اختصاصی (دستی و خودکار)',
      summary: 'تنها بخش دارای اسکرول آزاد، نوار کنترل اسکرول، اسکرول خودکار و حرکت گام‌به‌گام با خوانش صوتی',
      points: [
        'اسکرول لمسی نرم در همه‌ی بخش‌ها: در بخش لغات تا ۱۰۰ لغت و در بخش کتاب‌ها تا ۲۰ کتاب با لمس صفحه به نرمی بالا و پایین می‌شوند.',
        'فونت خودکار ۱۰ و اسکرول روان: در بخش مرور سریع، اندازه‌ی فونت به صورت خودکار روی ۱۰ تنظیم می‌شود تا تعداد زیادی لغت و معنی در یک نگاه دیده شوند و می‌توانید با لمس صفحه یا دکمه‌ی «اسکرول خودکار» (با سرعت ۰٫۵× تا ۴×) فهرست را مرور کنید.',
        'خوانش و حرکت خودکار لغت‌به‌لغت: با زدن دکمه‌ی «خوانش و حرکت» یا «لغت بعدی ▼»، برنامه هر لغت را تلفظ کرده و همزمان جدول را به سمت پایین اسکرول می‌کند.'
      ]
    },
    {
      icon: 'note',
      badge: '۵',
      title: 'بخش یادداشت‌ها و رمزگذاری امنیتی مجزا',
      summary: 'ثبت یادداشت روی کاغذ دفترچه‌ای خط‌دار، دسته‌بندی موضوعی، سنجاق و قفل رمزدار اختصاصی',
      points: [
        'ثبت و دسته‌بندی یادداشت: یادداشت‌های خود را با عنوان، زبان، دسته‌بندی دلخواه (مطالعه، روزانه، نقل‌قول و...) و رنگ نشانگر ذخیره کنید.',
        'رمزگذاری اختصاصی هر یادداشت: با فعال کردن «رمزگذاری یادداشت» یا زدن آیکن قفل روی کارت یادداشت، یک رمز عبور مجزا برای آن تعیین کنید تا متن آن کاملاً رمزنگاری و قفل شود.',
        'ورق‌زدن صفحه‌ای و خروجی: فهرست یادداشت‌ها و صفحه‌ی مطالعه‌ی یادداشت بدون اسکرول و به صورت صفحه‌به‌صفحه است و قابلیت خروجی PDF و Word دارد.'
      ]
    },
    {
      icon: 'speaker',
      badge: '۶',
      title: 'خوانش صوتی چندزبانه (TTS) و تنظیمات صدا',
      summary: 'تلفظ و روخوانی متون انگلیسی، فرانسوی، آلمانی، عربی و ترکی استانبولی با تنظیم سرعت و زیر و بمی',
      points: [
        'روخوانی هوشمند: با زدن آیکن بلندگو در صفحه‌ی کتاب، کارت واژه، جدول مرور سریع یا صفحه‌ی یادداشت، متن با موتور صوتی دستگاه خوانده می‌شود.',
        'تنظیمات خوانش صوتی: از منوی سه‌نقطه‌ی بالای صفحه یا داخل تنظیمات، سرعت خواندن (۰٫۵× تا ۲×)، زیر و بمی صدا و زبان‌های مجاز را تنظیم نمایید.'
      ]
    },
    {
      icon: 'sliders',
      badge: '۷',
      title: 'تنظیمات اندازه فونت کلمات (۸ تا ۳۵)، ظاهر و پشتیبان‌گیری',
      summary: 'تنظیم دقیق سایز کلمات از ۸ تا ۳۵، ۳۰ شکل محیط کاربری، کاغذ دفترچه‌ای و فایل پشتیبان',
      points: [
        'اندازه‌ی فونت کلمات (۸ تا ۳۵): در تب اول تنظیمات می‌توانید اندازه‌ی فونت کلمات را دقیقاً بین ۸ تا ۳۵ پیکسل تنظیم کنید؛ این تغییر بلافاصله روی کلمات، معانی، مرور سریع، کتاب‌ها و یادداشت‌ها اعمال می‌شود.',
        'پشتیبان‌گیری و بازیابی: از منوی بالای صفحه گزینه‌ی «پشتیبان‌گیری» را بزنید تا فایل کامل کتاب‌ها، لغات و یادداشت‌ها در گوشی ذخیره شود و هر زمان خواستید با «بازیابی» آن را بازگردانید.'
      ]
    }
  ];
}

function buildAppGuideContent(isFullSheet) {
  var wrap = h('div', { class: 'guide-wrap' + (isFullSheet ? ' full' : '') });
  var intro = h('div', { class: 'guide-hero' }, [
    h('div', { class: 'guide-hero-ic', html: ic('book', 22) }),
    h('div', { class: 'guide-hero-txt' }, [
      h('b', { text: 'راهنمای جامع اپلیکیشن کتابچه' }),
      h('span', { text: 'معرفی کامل تمامی بخش‌های برنامه و شیوه‌ی استفاده‌ی گام‌به‌گام (روی هر بخش بزنید)' })
    ])
  ]);
  wrap.appendChild(intro);

  var toolbar = h('div', { class: 'guide-toolbar' });
  var expandAllBtn = h('button', { class: 'chip sm', type: 'button', html: ic('list', 13) + '<span>باز کردن همه</span>' });
  var collapseAllBtn = h('button', { class: 'chip sm', type: 'button', html: ic('up', 13) + '<span>بستن همه</span>' });
  toolbar.appendChild(expandAllBtn);
  toolbar.appendChild(collapseAllBtn);
  wrap.appendChild(toolbar);

  var sections = getAppGuideSections();
  var listBox = h('div', { class: 'guide-list' });

  sections.forEach(function (sec, idx) {
    var isOpen = isFullSheet ? true : (idx < 2);
    var itemEl = h('div', { class: 'guide-card' + (isOpen ? ' open' : '') });
    var hdrBtn = h('button', { class: 'guide-card-hdr', type: 'button', 'aria-expanded': isOpen ? 'true' : 'false' }, [
      h('span', { class: 'guide-badge', text: sec.badge }),
      h('span', { class: 'guide-ic', html: ic(sec.icon, 17) }),
      h('div', { class: 'guide-hdr-txt' }, [
        h('b', { text: sec.title }),
        h('small', { text: sec.summary })
      ]),
      h('span', { class: 'guide-chev', text: '▾' })
    ]);
    var ul = h('ul', { class: 'guide-points' });
    sec.points.forEach(function (pt) {
      ul.appendChild(h('li', { text: pt }));
    });
    var bodyEl = h('div', { class: 'guide-card-body' }, [ul]);
    hdrBtn.addEventListener('click', function () {
      var nowOpen = !itemEl.classList.contains('open');
      itemEl.classList.toggle('open', nowOpen);
      hdrBtn.setAttribute('aria-expanded', nowOpen ? 'true' : 'false');
    });
    itemEl.appendChild(hdrBtn);
    itemEl.appendChild(bodyEl);
    listBox.appendChild(itemEl);
  });

  expandAllBtn.addEventListener('click', function () {
    $$('.guide-card', listBox).forEach(function (c) { c.classList.add('open'); });
  });
  collapseAllBtn.addEventListener('click', function () {
    $$('.guide-card', listBox).forEach(function (c) { c.classList.remove('open'); });
  });

  wrap.appendChild(listBox);
  return wrap;
}

function openAppGuideSheet() {
  openSettings('guide');
}

function openSettings(initialTab) {
  var st = S.data.settings;
  var activeStTab = (initialTab === 'guide' || initialTab === 'paper' || initialTab === 'theme') ? initialTab : 'font';

  var pvWord = h('div', { class: 'pv-word-sample' }, [
    h('span', { dir: 'ltr', class: 'pv-w-en', text: 'Eloquent' }),
    h('span', { dir: 'rtl', class: 'pv-w-fa', text: 'شیوا، بلیغ (اندازه فونت: ' + fa(st.fontSize) + ')' })
  ]);
  var pv = h('div', { class: 'pv' }, [h('div', { class: 'pv-t' }, [
    h('p', { dir: 'rtl', html: '<mark data-c="y">قلم</mark> و اندازه‌ی فونت کلمات (۸ تا ۳۵) به صورت زنده اعمال می‌شود.' }),
    pvWord
  ])]);

  var stNav = h('div', { class: 'st-tabs-nav', role: 'tablist' });
  var top = h('div', { class: 'st-top' }, [pv, stNav]);

  sheet('تنظیمات و راهنمای برنامه', function (body) {
    function save() {
      if (S.libTab === 'quick') {
        document.documentElement.style.setProperty('--qfs', st.fontSize + 'px');
      } else {
        S._savedNormalFs = st.fontSize;
      }
      scheduleSave();
      applyTheme();
      setDirIcons();
      var faSpan = $('.pv-w-fa', pvWord);
      if (faSpan) faSpan.textContent = 'شیوا، بلیغ (اندازه فونت: ' + fa(st.fontSize) + ')';
      if (S.view === 'reader') rerenderCurrent();
      else if (S.view === 'library') {
        if (S.libTab === 'words') renderWords();
        else if (S.libTab === 'quick') renderQuickReview();
        else if (S.libTab === 'notes') renderNotes();
        else renderLibrary();
      }
    }
    function headTo(container, icon, title, small) {
      var el = h('div', { class: 'set-h', html: ic(icon, 18) + '<span></span>' });
      el.lastChild.textContent = title;
      if (small) el.appendChild(h('small', { text: small }));
      container.appendChild(el);
      return el;
    }
    function setP(r) { r.style.setProperty('--p', ((+r.value - +r.min) / (+r.max - +r.min) * 100) + '%'); }
    function segTo(container, opts, key, after) {
      var wrap = h('div', { class: 'seg' });
      opts.forEach(function (o) {
        var b = h('button', { class: st[key] === o[0] ? 'on' : '', text: o[1], 'data-v': String(o[0]) });
        b.addEventListener('click', function () {
          st[key] = o[0]; $$('button', wrap).forEach(function (x) { x.classList.remove('on'); }); b.classList.add('on'); save();
          if (after) after();
        });
        wrap.appendChild(b);
      });
      container.appendChild(wrap);
    }
    function toggleTo(container, label, desc, key) {
      var sw = h('div', { class: 'sw-toggle' + (st[key] ? ' on' : '') });
      var row = h('div', { class: 'set-row', role: 'switch', 'aria-checked': st[key] ? 'true' : 'false' }, [
        h('div', { class: 'grow' }, [h('div', { class: 't', text: label }), desc ? h('div', { class: 'd', text: desc }) : null]), sw]);
      row.addEventListener('click', function () {
        st[key] = !st[key]; sw.classList.toggle('on', st[key]); row.setAttribute('aria-checked', st[key] ? 'true' : 'false'); save();
      });
      container.appendChild(row);
    }
    function tg() { return h('div', { class: 'tg' }, [h('i'), h('i'), h('i'), h('i')]); }

    var paneFont = h('div', { class: 'st-pane', 'data-st-pane': 'font' });
    var paneGuide = h('div', { class: 'st-pane hidden', 'data-st-pane': 'guide' });
    var panePaper = h('div', { class: 'st-pane hidden', 'data-st-pane': 'paper' });
    var paneTheme = h('div', { class: 'st-pane hidden', 'data-st-pane': 'theme' });

    /* ========== پنل ۱: اندازه فونت کلمات (۸ تا ۳۵) و قلم ========== */
    headTo(paneFont, 'type', 'اندازه‌ی فونت کلمات (۸ تا ۳۵)', 'اعمال فوری روی کلمات، معانی، مرور سریع، کتاب‌ها و یادداشت‌ها');
    var val = h('b', { text: fa(st.fontSize) });
    var minus = h('button', { class: 'ibtn', style: 'background:var(--chip);font-weight:800;font-size:13px;direction:ltr', text: 'A-', 'aria-label': 'کوچک‌تر' });
    var plus = h('button', { class: 'ibtn', style: 'background:var(--chip);font-weight:800;font-size:20px;direction:ltr', text: 'A+', 'aria-label': 'بزرگ‌تر' });
    var rng = h('input', { type: 'range', min: 8, max: 35, step: 1, value: clamp(st.fontSize, 8, 35), 'aria-label': 'اندازه‌ی فونت کلمات از ۸ تا ۳۵' });
    var fsPresetWrap = h('div', { class: 'chips', style: 'margin-top:6px;margin-bottom:6px' });
    function syncFsPresets() {
      $$('.chip', fsPresetWrap).forEach(function (c) {
        c.classList.toggle('on', +c.getAttribute('data-fs') === +st.fontSize);
      });
    }
    function setFs(v) {
      st.fontSize = clamp(v, 8, 35);
      rng.value = st.fontSize;
      setP(rng);
      val.textContent = fa(st.fontSize);
      syncFsPresets();
      save();
    }
    [
      [8, '۸ (حداقل)'],
      [10, '۱۰ (مرور سریع)'],
      [12, '۱۲'],
      [16, '۱۶'],
      [21, '۲۱ (پیش‌فرض)'],
      [26, '۲۶'],
      [30, '۳۰'],
      [35, '۳۵ (حداکثر)']
    ].forEach(function (p) {
      var ch = h('button', { class: 'chip sm' + (+st.fontSize === p[0] ? ' on' : ''), type: 'button', 'data-fs': String(p[0]), text: p[1] });
      ch.addEventListener('click', function () { setFs(p[0]); });
      fsPresetWrap.appendChild(ch);
    });
    rng.addEventListener('input', function () { setFs(+rng.value); });
    minus.addEventListener('click', function () { setFs(st.fontSize - 1); });
    plus.addEventListener('click', function () { setFs(st.fontSize + 1); });
    setP(rng);
    paneFont.appendChild(h('div', { class: 'sl' }, [minus, rng, plus, val]));
    paneFont.appendChild(fsPresetWrap);

    headTo(paneFont, 'list', 'فاصله‌ی خطوط');
    var lh = h('input', { type: 'range', min: 1.4, max: 2.6, step: 0.05, value: st.lineHeight, 'aria-label': 'فاصله‌ی خطوط' });
    lh.addEventListener('input', function () { st.lineHeight = +lh.value; setP(lh); save(); });
    setP(lh);
    paneFont.appendChild(h('div', { class: 'sl' }, [h('span', { class: 'lab', text: 'فشرده' }), lh, h('span', { class: 'lab', text: 'باز' })]));

    headTo(paneFont, 'type', 'ضخامت نوشته');
    segTo(paneFont, [[300, 'سبک'], [400, 'معمولی'], [600, 'پررنگ']], 'weight');

    headTo(paneFont, 'type', 'قلم فارسی');
    var faWrap = h('div');
    FA_FONTS.forEach(function (f) {
      var row = h('button', { class: 'frow' + (st.fontFa === f.id ? ' on' : ''), 'data-f': f.id }, [
        h('div', { class: 'bd' }, [
          h('div', { class: 'smp', style: 'font-family:' + f.stack + ',"Vazirmatn",sans-serif;font-weight:var(--fw)', dir: 'rtl', text: 'کتابچه؛ متن‌های شما' }),
          h('div', { class: 'nm', text: f.name + ' — ' + f.note })]),
        h('span', { class: 'rdo', html: ic('check', 14) })]);
      row.addEventListener('click', function () {
        st.fontFa = f.id; $$('.frow', faWrap).forEach(function (x) { x.classList.toggle('on', x === row); }); save();
        if (typeof updAuto === 'function') updAuto();
      });
      faWrap.appendChild(row);
    });
    paneFont.appendChild(faWrap);

    headTo(paneFont, 'type', 'قلم انگلیسی', 'برای حروف و اعداد لاتین');
    var enWrap = h('div');
    var auto = EN_FONTS[0];
    var autoRow = h('button', { class: 'frow' + (st.fontEn === 'auto' ? ' on' : ''), 'data-f': 'auto' }, [
      h('div', { class: 'bd' }, [h('div', { class: 'nm' }, [h('b', { text: auto.name }), ' — ' + auto.note, h('span', { class: 'auto-now' })])]),
      h('span', { class: 'rdo', html: ic('check', 14) })]);
    function updAuto() { $('.auto-now', autoRow).textContent = ' (الان: ' + effEn(st).name + ')'; }
    updAuto();
    var grid = h('div', { class: 'fgrid' });
    function selEn(id) {
      st.fontEn = id;
      autoRow.classList.toggle('on', id === 'auto');
      $$('.ftile', grid).forEach(function (x) { x.classList.toggle('on', x.getAttribute('data-f') === id); });
      save();
    }
    autoRow.addEventListener('click', function () { selEn('auto'); });
    enWrap.appendChild(autoRow);
    EN_FONTS.slice(1).forEach(function (f) {
      var t = h('button', { class: 'ftile' + (st.fontEn === f.id ? ' on' : ''), 'data-f': f.id }, [
        h('span', { class: 'aa', style: 'font-family:' + f.stack + ';font-weight:var(--fw)', text: 'Aa Bb 12' }),
        h('span', { class: 'nm', text: f.name }),
        h('span', { class: 'rdo', html: ic('check', 12) })]);
      t.addEventListener('click', function () { selEn(f.id); });
      grid.appendChild(t);
    });
    enWrap.appendChild(grid);
    paneFont.appendChild(enWrap);

    /* ========== پنل ۲: راهنمای برنامه (معرفی کامل بخش‌ها و شیوه استفاده) ========== */
    headTo(paneGuide, 'info', 'راهنمای برنامه و شیوه‌ی استفاده', 'آموزش کامل ۷ بخش اصلی');
    paneGuide.appendChild(buildAppGuideContent(true));

    /* ========== پنل ۳: کاغذ دفترچه و صفحه‌آرایی ========== */
    headTo(panePaper, 'notebook', 'تصویر زمینه مطالعه (کتاب‌ها و یادداشت‌ها)', fa(PAGE_BGS.length) + ' طرح دفترچه‌ای');
    panePaper.appendChild(buildPageBgGrid());
    headTo(panePaper, 'book', 'صفحه‌آرایی و ورق‌زدن');
    toggleTo(panePaper, 'قاب جدولی', 'دورِ هر صفحه یک قاب نازک، مثل نسخه‌های خطی.', 'frame');
    toggleTo(panePaper, 'تراز دو طرف', 'متن‌ها مثل کتاب از دو طرف هم‌تراز شوند.', 'justify');
    toggleTo(panePaper, 'حرکت ورق‌زدن', 'انیمیشن سه‌بعدی هنگام عوض شدن صفحه.', 'anim');
    toggleTo(panePaper, 'روشن ماندن صفحه', 'هنگام خواندن صفحه‌نمایش خاموش نشود.', 'keepOn');
    headTo(panePaper, 'book', 'جهت ورق‌زدن کتاب');
    segTo(panePaper, [['rtl', 'راست به چپ (فارسی)'], ['ltr', 'چپ به راست']], 'flip');

    /* ========== پنل ۴: پوسته‌ی رنگی و ۳۰ شکل محیط ========== */
    headTo(paneTheme, 'palette', 'پوسته‌ی رنگی', fa(THEME_ORDER.length - 1) + ' پوسته + خودکار');
    var tiles = h('div', { class: 'themes' });
    THEME_ORDER.forEach(function (id) {
      var name = id === 'auto' ? 'خودکار' : THEMES[id].name, tp;
      if (id === 'auto') {
        tp = h('div', { class: 'tp' }, [
          h('div', { class: 'hf l', 'data-theme': 'paper' }, [h('div', { class: 'tb' }), tg()]),
          h('div', { class: 'hf r', 'data-theme': 'night' }, [h('div', { class: 'tb' }), tg()])]);
      } else {
        tp = h('div', { class: 'tp', 'data-theme': id }, [h('div', { class: 'tb' }), tg()]);
      }
      var tile = h('button', { class: 'tile' + (st.theme === id ? ' on' : ''), 'data-t': id, 'aria-label': 'پوسته‌ی ' + name }, [
        h('span', { class: 'ring' }, [tp, h('span', { class: 'tchk', html: ic('check', 12) })]), h('span', { text: name })]);
      tile.addEventListener('click', function () {
        st.theme = id; $$('.tile', tiles).forEach(function (x) { x.classList.toggle('on', x === tile); }); save();
      });
      tiles.appendChild(tile);
    });
    paneTheme.appendChild(tiles);

    headTo(paneTheme, 'layout', 'شکل و معماری محیط اپ', fa(UI_STYLES.length) + ' طرح جامع');
    toggleTo(paneTheme, 'هماهنگی خودکار رنگ و شیشه با طرح', 'با انتخاب هر شکل محیط، رنگ و شفافیت پیشنهادی همان طرح نیز اعمال شود.', 'uiAutoTheme');

    var uiCatSel = 'all';
    var uiCatBar = h('div', { class: 'ui-cats' });
    var uiGrid = h('div', { class: 'ui-grid' });

    function drawUiGallery() {
      uiCatBar.textContent = '';
      [
        ['all', 'همه (' + fa(UI_STYLES.length) + ')'],
        ['future', 'آینده‌نگر و شیشه‌ای'],
        ['layout', 'چیدمان‌های خاص'],
        ['modern', 'مینیمال و مدرن'],
        ['digital', 'دیجیتال و پویا'],
        ['classic', 'کلاسیک و اصیل']
      ].forEach(function (c) {
        var b = h('button', { class: 'chip sm' + (uiCatSel === c[0] ? ' on' : ''), text: c[1] });
        b.addEventListener('click', function () { uiCatSel = c[0]; drawUiGallery(); });
        uiCatBar.appendChild(b);
      });

      uiGrid.textContent = '';
      var frag = document.createDocumentFragment();
      UI_STYLES.forEach(function (u) {
        if (uiCatSel !== 'all' && u.cat !== uiCatSel) return;
        var active = st.uiStyle === u.id;
        var prev = h('div', { class: 'ui-prev', 'data-theme': u.theme }, [
          h('div', { class: 'ui-prev-bar', style: 'background:var(--bar);border-radius:' + u.r }, [
            h('i', { style: 'background:var(--accent)' }),
            h('i', { style: 'background:var(--gold)' })
          ]),
          h('div', { class: 'ui-prev-body' }, [
            h('div', { class: 'ui-prev-c', style: 'background:var(--page);border-radius:' + u.r + ';border:1px solid var(--accent)' }),
            h('div', { class: 'ui-prev-c', style: 'background:var(--page);border-radius:' + u.r + ';border:1px solid var(--line)' })
          ])
        ]);
        var card = h('button', { class: 'ui-card' + (active ? ' on' : ''), 'data-ui-id': u.id, 'aria-label': u.name }, [
          prev,
          h('div', { class: 'ui-info' }, [
            h('div', { style: 'min-width:0;flex:1' }, [
              h('b', { text: u.name }),
              h('small', { text: u.sub })
            ]),
            h('span', { class: 'ui-chk', html: ic('check', 11) })
          ])
        ]);
        card.addEventListener('click', function () {
          st.uiStyle = u.id;
          if (st.uiAutoTheme !== false) {
            st.theme = u.theme;
            st.glass = u.glass;
            st.glassTrans = u.trans;
            if (typeof gtRng !== 'undefined' && gtRng) {
              gtRng.value = st.glassTrans;
              setP(gtRng);
              gtVal.textContent = fa(st.glassTrans) + '٪';
            }
            $$('.tile', tiles).forEach(function (x) { x.classList.toggle('on', x.getAttribute('data-t') === st.theme); });
          }
          $$('.ui-card', uiGrid).forEach(function (x) { x.classList.toggle('on', x === card); });
          save();
          toast('محیط برنامه به «' + u.name + '» تغییر یافت');
        });
        frag.appendChild(card);
      });
      uiGrid.appendChild(frag);
    }
    drawUiGallery();
    paneTheme.appendChild(uiCatBar);
    paneTheme.appendChild(uiGrid);

    headTo(paneTheme, 'layout', 'جلوه‌ی شیشه‌ای (Glass)');
    toggleTo(paneTheme, 'حالت شیشه‌ای پیشرفته', 'نوارها، پنل‌ها و کارت‌ها با جلوه‌ی شیشه‌ای شفاف نمایش داده شوند.', 'glass');
    headTo(paneTheme, 'palette', 'میزان شفافیت شیشه');
    var gtVal = h('b', { text: fa(st.glassTrans) + '٪' });
    var gtRng = h('input', { type: 'range', min: 5, max: 88, step: 1, value: st.glassTrans, 'aria-label': 'میزان شفافیت شیشه' });
    gtRng.addEventListener('input', function () {
      st.glassTrans = clamp(+gtRng.value, 5, 88);
      if (!st.glass) st.glass = true;
      setP(gtRng);
      gtVal.textContent = fa(st.glassTrans) + '٪';
      save();
    });
    setP(gtRng);
    paneTheme.appendChild(h('div', { class: 'sl' }, [h('span', { class: 'lab', text: 'مات' }), gtRng, h('span', { class: 'lab', text: 'شفاف' }), gtVal]));

    headTo(paneTheme, 'palette', 'میزان ماتی و بلور شیشه');
    var gbVal = h('b', { text: fa(st.glassBlur) });
    var gbRng = h('input', { type: 'range', min: 0, max: 36, step: 2, value: st.glassBlur, 'aria-label': 'میزان بلور شیشه' });
    gbRng.addEventListener('input', function () {
      st.glassBlur = clamp(+gbRng.value, 0, 36);
      setP(gbRng);
      gbVal.textContent = fa(st.glassBlur);
      save();
    });
    setP(gbRng);
    paneTheme.appendChild(h('div', { class: 'sl' }, [h('span', { class: 'lab', text: 'شفاف' }), gbRng, h('span', { class: 'lab', text: 'بخاردار' }), gbVal]));

    body.appendChild(paneFont);
    body.appendChild(paneGuide);
    body.appendChild(panePaper);
    body.appendChild(paneTheme);

    var reset = h('button', { class: 'btn block', id: 'stReset', html: ic('rotate', 18) + '<span>بازنشانی تنظیمات ظاهر به حالت پیش‌فرض</span>' });
    reset.addEventListener('click', function () {
      var d = defaultData().settings;
      ['pageBg', 'uiStyle', 'uiAutoTheme', 'theme', 'glass', 'glassTrans', 'glassBlur', 'fontFa', 'fontEn', 'weight', 'fontSize', 'lineHeight', 'justify', 'frame'].forEach(function (k) { st[k] = d[k]; });
      save(); toast('ظاهر به حالت پیش‌فرض برگشت');
      var L = layers[layers.length - 1]; if (L) L.close(true);
      setTimeout(function () { openSettings(activeStTab); }, 30);
    });
    body.appendChild(h('div', { class: 'st-foot' }, [reset]));

    var navDefs = [
      ['font', 'type', 'قلم و فونت (۸–۳۵)'],
      ['guide', 'info', 'راهنمای برنامه'],
      ['paper', 'notebook', 'کاغذ و صفحه'],
      ['theme', 'palette', 'پوسته و محیط']
    ];
    function switchStTab(tid) {
      activeStTab = tid;
      $$('.st-tab-btn', stNav).forEach(function (b) {
        b.classList.toggle('on', b.getAttribute('data-tid') === tid);
      });
      paneFont.classList.toggle('hidden', tid !== 'font');
      paneGuide.classList.toggle('hidden', tid !== 'guide');
      panePaper.classList.toggle('hidden', tid !== 'paper');
      paneTheme.classList.toggle('hidden', tid !== 'theme');
      body.scrollTop = 0;
    }
    navDefs.forEach(function (nd) {
      var btn = h('button', {
        class: 'st-tab-btn' + (activeStTab === nd[0] ? ' on' : ''),
        type: 'button',
        'data-tid': nd[0],
        html: ic(nd[1], 15) + '<span>' + nd[2] + '</span>'
      });
      btn.addEventListener('click', function () { switchStTab(nd[0]); });
      stNav.appendChild(btn);
    });
    switchStTab(activeStTab);
  }, { top: top, tall: true });
}

/* =====================================================================
   اشتراک‌گذاری و فایل پشتیبان
   ===================================================================== */
function shareText(text, title) {
  try { if (bridge('share')) { A.share(title || '', text); return; } } catch (e) {}
  try { if (navigator.share) { navigator.share({ title: title || '', text: text }); return; } } catch (e) {}
  downloadBlob((title || 'text') + '.txt', text, 'text/plain');
}
function downloadBlob(name, content, mime) {
  try {
    var blob = new Blob([content], { type: mime + ';charset=utf-8' });
    var a = h('a', { href: URL.createObjectURL(blob), download: name });
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
  } catch (e) { toast('ذخیره انجام نشد'); }
}
function pad2(n) { return (n < 10 ? '0' : '') + n; }
function backupName() {
  var d = new Date();
  return 'ketabche-backup-' + d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) + '.json';
}
/* =====================================================================
   موتور رمزگذاری مجزای یادداشت‌ها + تولید و ارسال PDF و Word با کیفیت اصلی
   ===================================================================== */
function utf8ToBytes(str) {
  str = String(str == null ? '' : str);
  if (typeof TextEncoder !== 'undefined') return new TextEncoder().encode(str);
  var u = unescape(encodeURIComponent(str)), arr = new Uint8Array(u.length);
  for (var i = 0; i < u.length; i++) arr[i] = u.charCodeAt(i);
  return arr;
}
function bytesToUtf8(bytes) {
  if (typeof TextDecoder !== 'undefined') return new TextDecoder('utf-8').decode(bytes);
  var s = '';
  for (var i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
  try { return decodeURIComponent(escape(s)); } catch (e) { return s; }
}
function bytesToBase64(bytes) {
  var bin = '', len = bytes.length, chunk = 8192;
  for (var i = 0; i < len; i += chunk) {
    var sub = bytes.subarray(i, Math.min(i + chunk, len));
    bin += String.fromCharCode.apply(null, sub);
  }
  return btoa(bin);
}
function base64ToBytes(b64) {
  var bin = atob(String(b64 || '')), out = new Uint8Array(bin.length);
  for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
function utf8ToBase64(str) {
  return bytesToBase64(utf8ToBytes(str));
}

/* --- رمزگذاری و قفل مجزا برای هر یادداشت --- */
function hashNotePwd(pwd, salt) {
  var s = String(pwd || '') + '::ketabche.v2::' + String(salt || 'salt');
  var h1 = 0x811c9dc5, h2 = 0x811c9dc5 ^ 0x5bd1e995;
  for (var r = 0; r < 64; r++) {
    for (var i = 0; i < s.length; i++) {
      var c = s.charCodeAt(i);
      h1 ^= c + r;
      h1 = Math.imul(h1, 0x01000193) >>> 0;
      h2 ^= (c << 3) ^ r;
      h2 = Math.imul(h2, 0x5bd1e995) >>> 0;
    }
  }
  return ('00000000' + h1.toString(16)).slice(-8) + ('00000000' + h2.toString(16)).slice(-8);
}
function noteKeyStream(pwd, salt, len) {
  var seedStr = String(pwd || '') + '::stream::' + String(salt || '');
  var s0 = 0x9e3779b9, s1 = 0x243f6a88;
  for (var i = 0; i < seedStr.length; i++) {
    var code = seedStr.charCodeAt(i);
    s0 = Math.imul(s0 ^ code, 0x85ebca6b) >>> 0;
    s1 = Math.imul(s1 ^ (code + i), 0xc2b2ae35) >>> 0;
  }
  var out = new Uint8Array(len);
  for (var j = 0; j < len; j++) {
    s0 ^= (s0 << 13) >>> 0;
    s0 ^= (s0 >>> 17) >>> 0;
    s0 ^= (s0 << 5) >>> 0;
    s1 = (Math.imul(s1, 1664525) + 1013904223) >>> 0;
    out[j] = ((s0 ^ s1) >>> ((j & 3) * 8)) & 0xff;
  }
  return out;
}
function encryptNoteText(plain, pwd, salt) {
  var raw = utf8ToBytes(plain || '');
  var ks = noteKeyStream(pwd, salt, raw.length);
  var enc = new Uint8Array(raw.length);
  for (var i = 0; i < raw.length; i++) enc[i] = raw[i] ^ ks[i];
  return bytesToBase64(enc);
}
function decryptNoteText(cipherB64, pwd, salt) {
  if (!cipherB64) return '';
  try {
    var enc = base64ToBytes(cipherB64);
    var ks = noteKeyStream(pwd, salt, enc.length);
    var dec = new Uint8Array(enc.length);
    for (var i = 0; i < enc.length; i++) dec[i] = enc[i] ^ ks[i];
    return bytesToUtf8(dec);
  } catch (e) {
    return '';
  }
}
function hasNotePassword(x) {
  return !!(x && x.locked && x.pwdHash);
}
function isNoteLocked(x) {
  return !!(x && x.locked && x.pwdHash && S.unlockedNotes[x.id] === undefined);
}
function getNoteText(x) {
  if (!x) return '';
  if (x.locked && x.pwdHash) {
    if (S.unlockedNotes[x.id] !== undefined) return S.unlockedNotes[x.id];
    if (x.text && !x.cipher) return x.text;
    return '';
  }
  return x.text || '';
}
function setNotePasswordRaw(x, pwd, plainText) {
  if (!x) return;
  var salt = uid();
  x.pwdSalt = salt;
  x.pwdHash = hashNotePwd(pwd, salt);
  x.cipher = encryptNoteText(plainText != null ? plainText : getNoteText(x), pwd, salt);
  x.text = '';
  x.locked = true;
  delete S.unlockedNotes[x.id];
  delete S.noteKeys[x.id];
}
function removeNotePasswordRaw(x, plainText) {
  if (!x) return;
  x.text = plainText != null ? plainText : getNoteText(x);
  x.locked = false;
  x.pwdHash = '';
  x.pwdSalt = '';
  x.cipher = '';
  delete S.unlockedNotes[x.id];
  delete S.noteKeys[x.id];
}
function lockNoteNow(x) {
  if (!x || !hasNotePassword(x)) return;
  if (x.text) {
    delete S.unlockedNotes[x.id];
    x.text = '';
  } else {
    delete S.unlockedNotes[x.id];
  }
  if (S.view === 'library' && S.libTab === 'notes') renderNotes();
  toast('یادداشت قفل شد 🔒');
}
function ensureNoteUnlocked(x, cb) {
  if (!x) return;
  if (!isNoteLocked(x)) {
    cb(getNoteText(x));
    return;
  }
  openNoteUnlockDialog(x, cb);
}
function openNoteUnlockDialog(x, onSuccess) {
  var dim = h('div', { class: 'dim' });
  var inp = h('input', {
    class: 'field',
    type: 'password',
    dir: 'auto',
    maxlength: 64,
    placeholder: 'رمز عبور این یادداشت…',
    'aria-label': 'رمز عبور یادداشت'
  });
  var eyeBtn = h('button', { class: 'ibtn pwd-eye', type: 'button', 'aria-label': 'نمایش رمز', html: ic('eye', 18) });
  var showPwd = false;
  eyeBtn.addEventListener('click', function () {
    showPwd = !showPwd;
    inp.type = showPwd ? 'text' : 'password';
    eyeBtn.innerHTML = ic(showPwd ? 'eyeOff' : 'eye', 18);
  });
  var errEl = h('div', { class: 'pwd-err' });
  var okBtn = h('button', { class: 'btn pri', type: 'button', text: 'باز کردن قفل' });
  var cancelBtn = h('button', { class: 'btn', type: 'button', text: 'انصراف' });
  var box = h('div', { class: 'dialog' }, [
    h('h3', { html: ic('lock', 20) + ' <span style="vertical-align:middle">یادداشت رمزگذاری‌شده</span>' }),
    h('p', { text: 'برای مشاهده یا ویرایش «' + (x.title || 'یادداشت') + '»، رمز عبور آن را وارد کنید:' }),
    h('div', { class: 'pwd-wrap' }, [inp, eyeBtn]),
    errEl,
    h('div', { class: 'acts' }, [cancelBtn, okBtn])
  ]);
  var L = openLayer(h('div', { class: 'layer' }, [dim, box]));
  function verify() {
    var v = inp.value;
    if (!v) {
      errEl.textContent = 'لطفاً رمز عبور را وارد کنید.';
      inp.focus();
      return;
    }
    if (hashNotePwd(v, x.pwdSalt) !== x.pwdHash) {
      errEl.textContent = 'رمز عبور واردشده نادرست است.';
      box.classList.remove('shake-err');
      void box.offsetWidth;
      box.classList.add('shake-err');
      inp.select();
      return;
    }
    var plain = x.cipher ? decryptNoteText(x.cipher, v, x.pwdSalt) : (x.text || '');
    S.unlockedNotes[x.id] = plain;
    S.noteKeys[x.id] = v;
    L.close(true);
    if (S.view === 'library' && S.libTab === 'notes') renderNotes();
    if (onSuccess) onSuccess(plain, v);
  }
  okBtn.addEventListener('click', verify);
  cancelBtn.addEventListener('click', function () { L.close(true); });
  dim.addEventListener('click', function () { L.close(true); });
  inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') verify(); });
  setTimeout(function () { inp.focus(); }, 60);
}

function openNotePasswordManageDialog(x, onDone) {
  if (!x) return;
  ensureNoteUnlocked(x, function (plainText) {
    var hasLock = hasNotePassword(x);
    var dim = h('div', { class: 'dim' });
    var inp1 = h('input', {
      class: 'field',
      type: 'password',
      dir: 'auto',
      maxlength: 64,
      placeholder: hasLock ? 'رمز عبور جدید…' : 'رمز عبور دلخواه برای این یادداشت…'
    });
    var inp2 = h('input', {
      class: 'field',
      type: 'password',
      dir: 'auto',
      maxlength: 64,
      style: 'margin-top:8px',
      placeholder: 'تکرار رمز عبور…'
    });
    var errEl = h('div', { class: 'pwd-err' });
    var saveBtn = h('button', { class: 'btn pri', type: 'button', text: hasLock ? 'تغییر رمز و قفل' : 'ثبت رمز و قفل' });
    var rmBtn = hasLock ? h('button', { class: 'btn danger', type: 'button', text: 'حذف رمز' }) : null;
    var cancelBtn = h('button', { class: 'btn', type: 'button', text: 'انصراف' });
    var acts = hasLock ? [cancelBtn, rmBtn, saveBtn] : [cancelBtn, saveBtn];
    var box = h('div', { class: 'dialog' }, [
      h('h3', { text: hasLock ? 'مدیریت رمز یادداشت' : 'رمزگذاری روی یادداشت' }),
      h('p', { text: 'این رمز فقط روی یادداشت «' + (x.title || 'بدون عنوان') + '» به صورت مجزا اعمال می‌شود:' }),
      inp1,
      inp2,
      errEl,
      h('div', { class: 'acts', style: 'flex-wrap:wrap' }, acts)
    ]);
    var L = openLayer(h('div', { class: 'layer' }, [dim, box]));
    function applyNewPwd() {
      var p1 = inp1.value;
      var p2 = inp2.value;
      if (!p1) { errEl.textContent = 'لطفاً رمز عبور را بنویسید.'; inp1.focus(); return; }
      if (p1 !== p2) { errEl.textContent = 'رمز عبور و تکرار آن یکسان نیستند.'; inp2.focus(); return; }
      setNotePasswordRaw(x, p1, plainText);
      x.updated = Date.now();
      scheduleSave(); flushSave();
      L.close(true);
      if (S.view === 'library' && S.libTab === 'notes') renderNotes();
      if (onDone) onDone();
      toast('یادداشت با رمز اختصاصی قفل شد 🔒');
    }
    saveBtn.addEventListener('click', applyNewPwd);
    if (rmBtn) {
      rmBtn.addEventListener('click', function () {
        removeNotePasswordRaw(x, plainText);
        x.updated = Date.now();
        scheduleSave(); flushSave();
        L.close(true);
        if (S.view === 'library' && S.libTab === 'notes') renderNotes();
        if (onDone) onDone();
        toast('رمز و قفل این یادداشت برداشته شد');
      });
    }
    cancelBtn.addEventListener('click', function () { L.close(true); });
    dim.addEventListener('click', function () { L.close(true); });
    inp2.addEventListener('keydown', function (e) { if (e.key === 'Enter') applyNewPwd(); });
    setTimeout(function () { inp1.focus(); }, 60);
  });
}

/* --- موتور ساخت فایل Word استاندارد (.docx OpenXML) با حفظ خطوط دفترچه و رنگ‌ها --- */
var CRC_TABLE = (function () {
  var t = new Uint32Array(256);
  for (var i = 0; i < 256; i++) {
    var c = i;
    for (var k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    t[i] = c >>> 0;
  }
  return t;
})();
function crc32Bytes(bytes) {
  var crc = 0xffffffff;
  for (var i = 0; i < bytes.length; i++) crc = CRC_TABLE[(crc ^ bytes[i]) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}
function buildZipStore(files) {
  var localParts = [], centralParts = [], offset = 0;
  function u16(v) { return [v & 0xff, (v >>> 8) & 0xff]; }
  function u32(v) { return [v & 0xff, (v >>> 8) & 0xff, (v >>> 16) & 0xff, (v >>> 24) & 0xff]; }
  files.forEach(function (f) {
    var nameBytes = utf8ToBytes(f.name);
    var dataBytes = f.data instanceof Uint8Array ? f.data : utf8ToBytes(f.data);
    var crc = crc32Bytes(dataBytes), sz = dataBytes.length;
    var lh = new Uint8Array([0x50, 0x4b, 0x03, 0x04, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      .concat(u32(crc), u32(sz), u32(sz), u16(nameBytes.length), [0, 0]));
    localParts.push(lh, nameBytes, dataBytes);
    var ch = new Uint8Array([0x50, 0x4b, 0x01, 0x02, 20, 0, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      .concat(u32(crc), u32(sz), u32(sz), u16(nameBytes.length), [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], u32(offset)));
    centralParts.push(ch, nameBytes);
    offset += lh.length + nameBytes.length + sz;
  });
  var cdSize = 0;
  centralParts.forEach(function (p) { cdSize += p.length; });
  var eocd = new Uint8Array([0x50, 0x4b, 0x05, 0x06, 0, 0, 0, 0]
    .concat(u16(files.length), u16(files.length), u32(cdSize), u32(offset), [0, 0]));
  var total = offset + cdSize + eocd.length;
  var out = new Uint8Array(total), pos = 0;
  localParts.concat(centralParts, [eocd]).forEach(function (part) {
    out.set(part, pos);
    pos += part.length;
  });
  return out;
}
function xmlEsc(s) {
  return String(s == null ? '' : s)
    .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g, '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
var HL_HEX = {
  y: 'FDE047', o: 'FDBA74', r: 'FCA5A5', p: 'F9A8D4', m: 'F0ABFC', v: 'C4B5FD',
  b: '93C5FD', c: '67E8F9', t: '5EEAD4', g: '86EFAC', l: 'BEF264', n: 'D6D3D1'
};
function cleanHex6(hex, fallback) {
  var h = String(hex || '').replace('#', '').trim().toUpperCase();
  if (h.length === 3) h = h[0]+h[0]+h[1]+h[1]+h[2]+h[2];
  return /^[0-9A-F]{6}$/.test(h) ? h : (fallback || 'FFFFFF');
}

function createDocxBytes(docSpec) {
  var st = S.data.settings;
  var pb = findPageBg(st.pageBg || 'classic');
  var pageBgHex = cleanHex6(pb.bg || '#fdfaf2', 'FDFAF2');
  var inkHex = cleanHex6(pb.ink || '#1f1b16', '1F1B16');
  var mutedHex = cleanHex6(pb.muted || '#756c60', '756C60');
  var lineHex = pb.line && pb.line !== 'auto' ? cleanHex6(pb.line, '93C5FD') : (pb.dark ? '475569' : '93C5FD');
  var hasNotebookLines = pb.style !== 'none' && pb.kind !== 'image';
  var lineStyle = pb.style === 'double' ? 'double' : 'single';
  var fontSzHalfPt = Math.round(clamp(+st.fontSize || 20, 8, 35) * 1.15);
  var bodyXml = '';

  function pRun(txt, opts) {
    opts = opts || {};
    var rPr = '<w:rPr><w:rFonts w:ascii="Vazirmatn" w:hAnsi="Vazirmatn" w:cs="Vazirmatn"/><w:rtl/>';
    if (opts.bold) rPr += '<w:b/><w:bCs/>';
    rPr += '<w:color w:val="' + (opts.color || inkHex) + '"/>';
    rPr += '<w:sz w:val="' + (opts.sz || fontSzHalfPt) + '"/><w:szCs w:val="' + (opts.sz || fontSzHalfPt) + '"/>';
    if (opts.shd) rPr += '<w:shd w:val="clear" w:color="auto" w:fill="' + opts.shd + '"/>';
    rPr += '</w:rPr>';
    return '<w:r>' + rPr + '<w:t xml:space="preserve">' + xmlEsc(txt) + '</w:t></w:r>';
  }

  function addHeaderBlock(title, subtitle, accentHex) {
    var acc = cleanHex6(accentHex || '#007aff', '007AFF');
    bodyXml += '<w:p><w:pPr><w:bidi/><w:spacing w:before="120" w:after="80"/>' +
      '<w:pBdr><w:bottom w:val="single" w:sz="12" w:space="6" w:color="' + acc + '"/></w:pBdr></w:pPr>' +
      pRun(title, { bold: true, sz: fontSzHalfPt + 8, color: inkHex }) + '</w:p>';
    if (subtitle) {
      bodyXml += '<w:p><w:pPr><w:bidi/><w:spacing w:before="40" w:after="180"/></w:pPr>' +
        pRun(subtitle, { bold: false, sz: Math.max(18, fontSzHalfPt - 4), color: mutedHex }) + '</w:p>';
    }
  }

  function addLinedParagraphWithHighlights(lineText, hls, lineOffsetStart) {
    var pBdr = hasNotebookLines
      ? '<w:pBdr><w:bottom w:val="' + lineStyle + '" w:sz="6" w:space="4" w:color="' + lineHex + '"/></w:pBdr>'
      : '';
    var pPr = '<w:pPr><w:bidi/><w:spacing w:before="60" w:after="60" w:line="380" w:lineRule="auto"/>' + pBdr + '</w:pPr>';
    if (!lineText) {
      bodyXml += '<w:p>' + pPr + pRun(' ', {}) + '</w:p>';
      return;
    }
    if (!hls || !hls.length) {
      bodyXml += '<w:p>' + pPr + pRun(lineText, {}) + '</w:p>';
      return;
    }
    var L = lineText.length, a0 = lineOffsetStart, b0 = a0 + L;
    var cuts = [0, L];
    hls.forEach(function (h) {
      var s = clamp(h.s - a0, 0, L), e = clamp(h.e - a0, 0, L);
      if (e > s) { cuts.push(s, e); }
    });
    cuts.sort(function (x, y) { return x - y; });
    var runs = '';
    for (var i = 0; i < cuts.length - 1; i++) {
      var u = cuts[i], v = cuts[i + 1];
      if (v <= u) continue;
      var seg = lineText.slice(u, v), col = null;
      var absMid = a0 + ((u + v) >> 1);
      for (var k = 0; k < hls.length; k++) {
        if (hls[k].s <= absMid && absMid < hls[k].e) { col = HL_HEX[hls[k].c] || 'FDE047'; break; }
      }
      runs += pRun(seg, col ? { shd: col } : {});
    }
    bodyXml += '<w:p>' + pPr + runs + '</w:p>';
  }

  addHeaderBlock(docSpec.title || 'کتابچه', docSpec.subtitle || ('خروجی کتابچه · ' + fmtDate(Date.now())), docSpec.accent);

  if (docSpec.kind === 'pages') {
    (docSpec.pages || []).forEach(function (pg, idx) {
      if (pg.heading) {
        bodyXml += '<w:p><w:pPr><w:bidi/><w:spacing w:before="220" w:after="80"/>' +
          '<w:shd w:val="clear" w:color="auto" w:fill="' + (pg.badgeHex || 'E0F2FE') + '"/></w:pPr>' +
          pRun('  ' + pg.heading + '  ', { bold: true, sz: fontSzHalfPt + 2, color: '0F172A' }) + '</w:p>';
      }
      if (pg.meta) {
        bodyXml += '<w:p><w:pPr><w:bidi/><w:spacing w:before="20" w:after="100"/></w:pPr>' +
          pRun(pg.meta, { sz: Math.max(18, fontSzHalfPt - 4), color: mutedHex }) + '</w:p>';
      }
      var raw = norm(pg.text || '');
      var lines = raw.split('\n'), pos = 0;
      lines.forEach(function (ln) {
        addLinedParagraphWithHighlights(ln, pg.hl || [], pos);
        pos += ln.length + 1;
      });
      if (idx < docSpec.pages.length - 1 && docSpec.pageBreak) {
        bodyXml += '<w:p><w:r><w:br w:type="page"/></w:r></w:p>';
      } else {
        bodyXml += '<w:p><w:pPr><w:spacing w:before="120" w:after="120"/></w:pPr></w:p>';
      }
    });
  } else if (docSpec.kind === 'table') {
    var rows = docSpec.rows || [];
    bodyXml += '<w:tbl><w:tblPr><w:bidiVisual/><w:tblW w:w="5000" w:type="pct"/>' +
      '<w:tblBorders>' +
      '<w:top w:val="single" w:sz="6" w:space="0" w:color="CBD5E1"/>' +
      '<w:bottom w:val="single" w:sz="6" w:space="0" w:color="CBD5E1"/>' +
      '<w:left w:val="single" w:sz="6" w:space="0" w:color="CBD5E1"/>' +
      '<w:right w:val="single" w:sz="6" w:space="0" w:color="CBD5E1"/>' +
      '<w:insideH w:val="single" w:sz="4" w:space="0" w:color="E2E8F0"/>' +
      '<w:insideV w:val="single" w:sz="4" w:space="0" w:color="E2E8F0"/>' +
      '</w:tblBorders></w:tblPr>';
    // Header row
    bodyXml += '<w:tr>' +
      '<w:tc><w:tcPr><w:tcW w:w="800" w:type="pct"/><w:shd w:val="clear" w:color="auto" w:fill="E2E8F0"/></w:tcPr>' +
      '<w:p><w:pPr><w:bidi/><w:jc w:val="center"/></w:pPr>' + pRun('ردیف', { bold: true, color: '1E293B' }) + '</w:p></w:tc>' +
      '<w:tc><w:tcPr><w:tcW w:w="1800" w:type="pct"/><w:shd w:val="clear" w:color="auto" w:fill="E2E8F0"/></w:tcPr>' +
      '<w:p><w:pPr><w:bidi/></w:pPr>' + pRun(docSpec.col1 || 'واژه / اصطلاح', { bold: true, color: '1E293B' }) + '</w:p></w:tc>' +
      '<w:tc><w:tcPr><w:tcW w:w="2400" w:type="pct"/><w:shd w:val="clear" w:color="auto" w:fill="E2E8F0"/></w:tcPr>' +
      '<w:p><w:pPr><w:bidi/></w:pPr>' + pRun(docSpec.col2 || 'معنی و توضیحات', { bold: true, color: '1E293B' }) + '</w:p></w:tc>' +
      '</w:tr>';
    rows.forEach(function (r, idx) {
      var rowFill = idx % 2 === 1 ? 'F8FAFC' : pageBgHex;
      bodyXml += '<w:tr>' +
        '<w:tc><w:tcPr><w:shd w:val="clear" w:color="auto" w:fill="' + rowFill + '"/></w:tcPr>' +
        '<w:p><w:pPr><w:bidi/><w:jc w:val="center"/></w:pPr>' + pRun(fa(idx + 1), { color: mutedHex }) + '</w:p></w:tc>' +
        '<w:tc><w:tcPr><w:shd w:val="clear" w:color="auto" w:fill="' + rowFill + '"/></w:tcPr>' +
        '<w:p><w:pPr><w:bidi/></w:pPr>' + pRun(r.w || '', { bold: true, color: inkHex }) +
        (r.sub ? pRun('  (' + r.sub + ')', { sz: Math.max(16, fontSzHalfPt - 6), color: mutedHex }) : '') + '</w:p></w:tc>' +
        '<w:tc><w:tcPr><w:shd w:val="clear" w:color="auto" w:fill="' + rowFill + '"/></w:tcPr>' +
        '<w:p><w:pPr><w:bidi/></w:pPr>' + pRun(r.m || '—', { color: inkHex }) + '</w:p></w:tc>' +
        '</w:tr>';
    });
    bodyXml += '</w:tbl>';
  }

  var borderXml = st.frame
    ? '<w:pgBorders w:offsetFrom="page">' +
      '<w:top w:val="double" w:sz="12" w:space="18" w:color="' + lineHex + '"/>' +
      '<w:bottom w:val="double" w:sz="12" w:space="18" w:color="' + lineHex + '"/>' +
      '<w:left w:val="double" w:sz="12" w:space="18" w:color="' + lineHex + '"/>' +
      '<w:right w:val="double" w:sz="12" w:space="18" w:color="' + lineHex + '"/>' +
      '</w:pgBorders>'
    : '';

  var docXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">' +
    '<w:background w:color="' + pageBgHex + '"/>' +
    '<w:body>' + bodyXml +
    '<w:sectPr><w:bidi/><w:pgSz w:w="11906" w:h="16838"/>' +
    '<w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134"/>' +
    borderXml + '</w:sectPr></w:body></w:document>';

  var contentTypes = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' +
    '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' +
    '<Default Extension="xml" ContentType="application/xml"/>' +
    '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>' +
    '<Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/>' +
    '</Types>';

  var rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
    '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>' +
    '</Relationships>';

  var docRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
    '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings" Target="settings.xml"/>' +
    '</Relationships>';

  var settingsXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    '<w:settings xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">' +
    '<w:displayBackgroundShape/>' +
    '</w:settings>';

  return buildZipStore([
    { name: '[Content_Types].xml', data: contentTypes },
    { name: '_rels/.rels', data: rels },
    { name: 'word/_rels/document.xml.rels', data: docRels },
    { name: 'word/settings.xml', data: settingsXml },
    { name: 'word/document.xml', data: docXml }
  ]);
}

/* --- موتور ساخت فایل PDF استاندارد چندصفحه‌ای با حفظ دقیق خطوط دفترچه، رنگ‌ها و هایلایت‌ها --- */
function wrapLineForCanvas(ctx, text, maxW, hls, lineStartOffset) {
  if (!text) return [{ text: '', hls: [], startOff: lineStartOffset }];
  var words = text.split(/(\s+)/);
  var lines = [], cur = '', curStart = lineStartOffset, curLen = 0;
  for (var i = 0; i < words.length; i++) {
    var w = words[i];
    if (!w) continue;
    var test = cur + w;
    if (cur && ctx.measureText(test).width > maxW) {
      lines.push({ text: cur, startOff: curStart, endOff: curStart + curLen });
      cur = w.replace(/^\s+/, '');
      var trimmedLen = w.length - cur.length;
      curStart = curStart + curLen + trimmedLen;
      curLen = cur.length;
    } else {
      cur = test;
      curLen += w.length;
    }
  }
  if (cur || !lines.length) {
    lines.push({ text: cur, startOff: curStart, endOff: curStart + curLen });
  }
  return lines;
}

function renderDocSpecToCanvases(docSpec) {
  var st = S.data.settings;
  var pb = findPageBg(st.pageBg || 'classic');
  var bgCol = pb.bg || '#fdfaf2';
  var inkCol = pb.ink || '#1f1b16';
  var mutedCol = pb.muted || '#756c60';
  var lineCol = pb.line && pb.line !== 'auto' ? pb.line : (pb.dark ? '#64748b' : '#3b82f6');
  var marginCol = pb.margin || '';
  var hasLines = pb.style !== 'none';
  var W = 1240, H = 1754; // A4 @ 150 DPI
  var padX = 96, padTop = 105, padBot = 105;
  var contentW = W - padX * 2;
  var baseFs = clamp(Math.round((+st.fontSize || 21) * 1.42), 14, 52);
  var lineStep = Math.round(baseFs * clamp(+st.lineHeight || 1.95, 1.55, 2.4));
  var fontFam = fontStack(st);
  var canvases = [];

  function newPageCanvas(pageNum) {
    var cv = document.createElement('canvas');
    cv.width = W; cv.height = H;
    var ctx = cv.getContext('2d');
    ctx.fillStyle = bgCol;
    ctx.fillRect(0, 0, W, H);

    // کادر و قاب جدولی کتابچه
    if (st.frame) {
      ctx.strokeStyle = hexToRgba(lineCol, 0.42);
      ctx.lineWidth = 3;
      ctx.strokeRect(42, 42, W - 84, H - 84);
      ctx.lineWidth = 1.2;
      ctx.strokeRect(50, 50, W - 100, H - 100);
    }

    // خط حاشیه عمودی دفترچه
    if (marginCol) {
      ctx.strokeStyle = hexToRgba(marginCol, 0.35);
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      ctx.moveTo(W - 76, 52);
      ctx.lineTo(W - 76, H - 52);
      ctx.stroke();
    }

    // شماره صفحه در پایین
    ctx.save();
    ctx.direction = 'rtl';
    ctx.textAlign = 'center';
    ctx.font = '600 22px ' + fontFam;
    ctx.fillStyle = mutedCol;
    ctx.fillText('صفحه ' + fa(pageNum) + '  ·  کتابچه', W / 2, H - 58);
    ctx.restore();

    canvases.push(cv);
    return { cv: cv, ctx: ctx, y: padTop };
  }

  function drawNotebookRule(ctx, yBaseline) {
    if (!hasLines) return;
    var yLine = yBaseline + 12;
    ctx.save();
    ctx.strokeStyle = hexToRgba(lineCol, pb.op || 0.26);
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(padX - 10, yLine);
    ctx.lineTo(W - padX + 10, yLine);
    ctx.stroke();
    if (pb.style === 'double') {
      ctx.strokeStyle = hexToRgba(lineCol, (pb.op || 0.25) * 0.55);
      ctx.lineWidth = 1.1;
      ctx.beginPath();
      ctx.moveTo(padX - 10, yLine - 8);
      ctx.lineTo(W - padX + 10, yLine - 8);
      ctx.stroke();
    }
    ctx.restore();
  }

  var pageIdx = 1;
  var cur = newPageCanvas(pageIdx);

  // سرصفحه اصلی سند
  cur.ctx.save();
  cur.ctx.direction = 'rtl';
  cur.ctx.textAlign = 'right';
  cur.ctx.font = '800 ' + (baseFs + 10) + 'px ' + fontFam;
  cur.ctx.fillStyle = inkCol;
  cur.ctx.fillText(docSpec.title || 'کتابچه', W - padX, cur.y + baseFs);
  cur.y += baseFs + 22;
  if (docSpec.subtitle) {
    cur.ctx.font = '500 ' + Math.max(20, baseFs - 6) + 'px ' + fontFam;
    cur.ctx.fillStyle = mutedCol;
    cur.ctx.fillText(docSpec.subtitle, W - padX, cur.y + baseFs - 6);
    cur.y += baseFs + 12;
  }
  cur.ctx.strokeStyle = hexToRgba(docSpec.accent || lineCol, 0.55);
  cur.ctx.lineWidth = 3;
  cur.ctx.beginPath();
  cur.ctx.moveTo(padX, cur.y);
  cur.ctx.lineTo(W - padX, cur.y);
  cur.ctx.stroke();
  cur.ctx.restore();
  cur.y += 28;

  if (docSpec.kind === 'pages') {
    (docSpec.pages || []).forEach(function (pg, pIdx) {
      if (pIdx > 0 && docSpec.pageBreak) {
        pageIdx++;
        cur = newPageCanvas(pageIdx);
      } else if (cur.y > H - padBot - lineStep * 2) {
        pageIdx++;
        cur = newPageCanvas(pageIdx);
      }

      if (pg.heading) {
        if (cur.y > H - padBot - lineStep * 3) { pageIdx++; cur = newPageCanvas(pageIdx); }
        cur.ctx.save();
        cur.ctx.direction = 'rtl';
        cur.ctx.textAlign = 'right';
        var bCol = pg.badgeColor || '#007aff';
        cur.ctx.fillStyle = hexToRgba(bCol, 0.14);
        cur.ctx.fillRect(padX, cur.y, contentW, baseFs + 24);
        cur.ctx.fillStyle = bCol;
        cur.ctx.fillRect(W - padX - 6, cur.y, 6, baseFs + 24);
        cur.ctx.font = '800 ' + (baseFs + 2) + 'px ' + fontFam;
        cur.ctx.fillStyle = inkCol;
        cur.ctx.fillText(pg.heading, W - padX - 18, cur.y + baseFs + 3);
        cur.ctx.restore();
        cur.y += baseFs + 34;
      }

      if (pg.meta) {
        cur.ctx.save();
        cur.ctx.direction = 'rtl';
        cur.ctx.textAlign = 'right';
        cur.ctx.font = '600 ' + Math.max(19, baseFs - 7) + 'px ' + fontFam;
        cur.ctx.fillStyle = mutedCol;
        cur.ctx.fillText(pg.meta, W - padX, cur.y + baseFs - 8);
        cur.ctx.restore();
        cur.y += baseFs + 8;
      }

      cur.ctx.save();
      cur.ctx.font = st.weight + ' ' + baseFs + 'px ' + fontFam;
      var raw = norm(pg.text || '');
      var rawLines = raw.split('\n');
      var charOffset = 0;

      rawLines.forEach(function (rln) {
        var wrapped = wrapLineForCanvas(cur.ctx, rln, contentW - 16, pg.hl || [], charOffset);
        wrapped.forEach(function (wln) {
          if (cur.y + lineStep > H - padBot) {
            cur.ctx.restore();
            pageIdx++;
            cur = newPageCanvas(pageIdx);
            cur.ctx.save();
            cur.ctx.font = st.weight + ' ' + baseFs + 'px ' + fontFam;
          }
          var baselineY = cur.y + baseFs;
          drawNotebookRule(cur.ctx, baselineY);

          // بررسی هایلایت در این سطر
          var hasLineHl = false, hlCol = 'FDE047';
          if (pg.hl && pg.hl.length && wln.text) {
            for (var hi = 0; hi < pg.hl.length; hi++) {
              var hItem = pg.hl[hi];
              if (hItem.e > wln.startOff && hItem.s < wln.endOff) {
                hasLineHl = true;
                hlCol = '#' + (HL_HEX[hItem.c] || 'FDE047');
                break;
              }
            }
          }
          var isLtr = /^[A-Za-z0-9]/.test(wln.text.trim());
          cur.ctx.direction = isLtr ? 'ltr' : 'rtl';
          cur.ctx.textAlign = isLtr ? 'left' : 'right';
          var txX = isLtr ? (padX + 8) : (W - padX - 8);
          if (hasLineHl && wln.text.trim()) {
            var tw = Math.min(contentW, cur.ctx.measureText(wln.text).width + 12);
            cur.ctx.fillStyle = hexToRgba(hlCol, 0.42);
            var hlX = isLtr ? txX - 6 : (txX - tw + 6);
            cur.ctx.fillRect(hlX, baselineY - baseFs + 4, tw, baseFs + 8);
          }
          cur.ctx.fillStyle = inkCol;
          cur.ctx.fillText(wln.text, txX, baselineY);
          cur.y += lineStep;
        });
        charOffset += rln.length + 1;
      });
      cur.ctx.restore();
      cur.y += Math.round(lineStep * 0.45);
    });
  } else if (docSpec.kind === 'table') {
    var rows = docSpec.rows || [];
    var colIdxW = 90, colWordW = Math.round((contentW - colIdxW) * 0.42), colMeanW = contentW - colIdxW - colWordW;
    var rowFont = Math.max(22, baseFs - 3);
    var rowLineH = Math.round(rowFont * 1.55);

    function drawTableHeader() {
      var hH = rowLineH + 22;
      cur.ctx.save();
      cur.ctx.fillStyle = pb.dark ? '#1e293b' : '#e2e8f0';
      cur.ctx.fillRect(padX, cur.y, contentW, hH);
      cur.ctx.strokeStyle = hexToRgba(lineCol, 0.45);
      cur.ctx.lineWidth = 1.8;
      cur.ctx.strokeRect(padX, cur.y, contentW, hH);
      cur.ctx.font = '800 ' + rowFont + 'px ' + fontFam;
      cur.ctx.fillStyle = inkCol;
      cur.ctx.direction = 'ltr';
      cur.ctx.textAlign = 'left';
      cur.ctx.fillText(docSpec.col1 || 'لغات (Words)', padX + colIdxW + 16, cur.y + rowFont + 8);
      cur.ctx.direction = 'rtl';
      cur.ctx.textAlign = 'right';
      cur.ctx.fillText(docSpec.col2 || 'معنی لغات', W - padX - 16, cur.y + rowFont + 8);
      cur.ctx.textAlign = 'center';
      cur.ctx.fillText('#', padX + colIdxW / 2, cur.y + rowFont + 8);
      cur.ctx.restore();
      cur.y += hH;
    }

    drawTableHeader();

    rows.forEach(function (r, idx) {
      cur.ctx.save();
      cur.ctx.font = '600 ' + rowFont + 'px ' + fontFam;
      var wLines = wrapLineForCanvas(cur.ctx, String(r.w || '') + (r.sub ? ' (' + r.sub + ')' : ''), colWordW - 28, [], 0);
      var mLines = wrapLineForCanvas(cur.ctx, String(r.m || '—'), colMeanW - 28, [], 0);
      var maxLines = Math.max(wLines.length, mLines.length, 1);
      var rH = maxLines * rowLineH + 20;

      if (cur.y + rH > H - padBot) {
        cur.ctx.restore();
        pageIdx++;
        cur = newPageCanvas(pageIdx);
        drawTableHeader();
        cur.ctx.save();
        cur.ctx.font = '600 ' + rowFont + 'px ' + fontFam;
      }

      cur.ctx.fillStyle = (idx % 2 === 1) ? hexToRgba(lineCol, 0.06) : 'transparent';
      cur.ctx.fillRect(padX, cur.y, contentW, rH);
      cur.ctx.strokeStyle = hexToRgba(lineCol, 0.28);
      cur.ctx.lineWidth = 1.2;
      cur.ctx.strokeRect(padX, cur.y, contentW, rH);

      // خطوط عمودی جداکننده ستون‌ها
      cur.ctx.beginPath();
      cur.ctx.moveTo(padX + colIdxW, cur.y);
      cur.ctx.lineTo(padX + colIdxW, cur.y + rH);
      cur.ctx.moveTo(padX + colIdxW + colWordW, cur.y);
      cur.ctx.lineTo(padX + colIdxW + colWordW, cur.y + rH);
      cur.ctx.stroke();

      // شماره ردیف
      cur.ctx.fillStyle = mutedCol;
      cur.ctx.font = '700 ' + (rowFont - 2) + 'px ' + fontFam;
      cur.ctx.textAlign = 'center';
      cur.ctx.fillText(fa(idx + 1), padX + colIdxW / 2, cur.y + rowFont + 8);

      // ستون لغت
      cur.ctx.fillStyle = inkCol;
      cur.ctx.font = '800 ' + rowFont + 'px ' + fontFam;
      cur.ctx.direction = 'ltr';
      cur.ctx.textAlign = 'left';
      wLines.forEach(function (wl, li) {
        cur.ctx.fillText(wl.text, padX + colIdxW + 14, cur.y + (li + 1) * rowLineH + 2);
      });

      // ستون معنی
      cur.ctx.font = '500 ' + rowFont + 'px ' + fontFam;
      cur.ctx.direction = 'rtl';
      cur.ctx.textAlign = 'right';
      mLines.forEach(function (ml, li) {
        cur.ctx.fillText(ml.text, W - padX - 14, cur.y + (li + 1) * rowLineH + 2);
      });

      cur.ctx.restore();
      cur.y += rH;
    });
  }

  return canvases;
}

function createPdfBytesFromCanvases(canvases) {
  var chunks = [], size = 0, offsets = [0];
  function pushStr(s) {
    var b = new Uint8Array(s.length);
    for (var i = 0; i < s.length; i++) b[i] = s.charCodeAt(i) & 0xff;
    chunks.push(b);
    size += b.length;
  }
  function pushBytes(b) {
    chunks.push(b);
    size += b.length;
  }
  pushStr('%PDF-1.4\n%\xFF\xFF\xFF\xFF\n');
  var N = canvases.length;
  // Obj 1: Catalog, Obj 2: Pages
  // For each page i (0..N-1):
  //   imgObj = 3 + i*3
  //   contentObj = 4 + i*3
  //   pageObj = 5 + i*3
  offsets[1] = size;
  pushStr('1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n');

  var kids = [];
  for (var i = 0; i < N; i++) kids.push((5 + i * 3) + ' 0 R');
  offsets[2] = size;
  pushStr('2 0 obj\n<< /Type /Pages /Kids [' + kids.join(' ') + '] /Count ' + N + ' >>\nendobj\n');

  for (var p = 0; p < N; p++) {
    var cv = canvases[p];
    var dataUrl = cv.toDataURL('image/jpeg', 0.90);
    var jpgBytes = base64ToBytes(dataUrl.split(',')[1]);
    var imgId = 3 + p * 3, cntId = 4 + p * 3, pgId = 5 + p * 3;

    offsets[imgId] = size;
    pushStr(imgId + ' 0 obj\n<< /Type /XObject /Subtype /Image /Width ' + cv.width + ' /Height ' + cv.height +
      ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ' + jpgBytes.length + ' >>\nstream\n');
    pushBytes(jpgBytes);
    pushStr('\nendstream\nendobj\n');

    var cmd = 'q 595.28 0 0 841.89 0 0 cm /Im' + p + ' Do Q';
    offsets[cntId] = size;
    pushStr(cntId + ' 0 obj\n<< /Length ' + cmd.length + ' >>\nstream\n' + cmd + '\nendstream\nendobj\n');

    offsets[pgId] = size;
    pushStr(pgId + ' 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595.28 841.89] /Resources << /XObject << /Im' + p + ' ' + imgId + ' 0 R >> >> /Contents ' + cntId + ' 0 R >>\nendobj\n');
  }

  var totalObjs = 3 + N * 3;
  var xrefOffset = size;
  pushStr('xref\n0 ' + totalObjs + '\n0000000000 65535 f \n');
  for (var k = 1; k < totalObjs; k++) {
    var offStr = ('0000000000' + offsets[k]).slice(-10);
    pushStr(offStr + ' 00000 n \n');
  }
  pushStr('trailer\n<< /Size ' + totalObjs + ' /Root 1 0 R >>\nstartxref\n' + xrefOffset + '\n%%EOF\n');

  var out = new Uint8Array(size), pos = 0;
  chunks.forEach(function (c) { out.set(c, pos); pos += c.length; });
  return out;
}

function safeFileName(title, ext) {
  var clean = String(title || 'ketabche').replace(/[\\/:*?"<>|\r\n]+/g, '-').replace(/\s+/g, '-').slice(0, 60) || 'ketabche';
  return clean + '.' + ext;
}

function getExportFmtMeta(fmt) {
  var f = String(fmt || 'pdf').toLowerCase();
  if (f === 'word' || f === 'docx') {
    return { id: 'word', ext: 'docx', mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', short: 'Word', label: 'فایل ورد (Word)', icon: 'word', cls: 'word' };
  }
  if (f === 'md' || f === 'markdown') {
    return { id: 'md', ext: 'md', mime: 'text/markdown', short: 'Markdown', label: 'فایل مارک‌داون (Markdown)', icon: 'md', cls: 'md' };
  }
  if (f === 'js' || f === 'javascript') {
    return { id: 'js', ext: 'js', mime: 'text/javascript', short: 'JS', label: 'فایل جاوااسکریپت (JS)', icon: 'js', cls: 'js' };
  }
  return { id: 'pdf', ext: 'pdf', mime: 'application/pdf', short: 'PDF', label: 'فایل پی‌دی‌اف (PDF)', icon: 'pdf', cls: 'pdf' };
}

function formatLineWithMarkdownHighlights(lineText, hls, lineOffsetStart) {
  if (!lineText) return '';
  if (!hls || !hls.length) return lineText;
  var L = lineText.length, a0 = lineOffsetStart;
  var cuts = [0, L];
  hls.forEach(function (hItem) {
    var s = clamp(hItem.s - a0, 0, L), e = clamp(hItem.e - a0, 0, L);
    if (e > s) cuts.push(s, e);
  });
  cuts.sort(function (x, y) { return x - y; });
  var out = '';
  for (var i = 0; i < cuts.length - 1; i++) {
    var u = cuts[i], v = cuts[i + 1];
    if (v <= u) continue;
    var seg = lineText.slice(u, v), hasHl = false;
    var absMid = a0 + ((u + v) >> 1);
    for (var k = 0; k < hls.length; k++) {
      if (hls[k].s <= absMid && absMid < hls[k].e) { hasHl = true; break; }
    }
    if (hasHl && seg.trim()) {
      var lead = seg.match(/^\s*/)[0] || '';
      var trail = seg.match(/\s*$/)[0] || '';
      var core = seg.slice(lead.length, seg.length - trail.length);
      out += lead + '==' + core + '==' + trail;
    } else {
      out += seg;
    }
  }
  return out;
}

/* --- موتور ساخت فایل و متن استاندارد Markdown (.md) برای کتاب‌ها، صفحات، یادداشت‌ها و لغات --- */
function createMarkdownContent(docSpec) {
  var lines = [];
  var title = docSpec.title || 'کتابچه';
  var subtitle = docSpec.subtitle || ('خروجی کتابچه · ' + fmtDate(Date.now()));
  lines.push('# ' + title);
  lines.push('');
  if (subtitle) {
    lines.push('> ' + subtitle);
    lines.push('');
  }
  if (docSpec.bookMeta) {
    var bm = docSpec.bookMeta;
    var metaParts = [];
    if (bm.sectionName) metaParts.push('**بخش:** ' + bm.sectionName);
    if (bm.scopeLabel) metaParts.push('**محدوده:** ' + bm.scopeLabel);
    if (bm.totalPages) metaParts.push('**تعداد کل صفحات کتاب:** ' + fa(bm.totalPages));
    metaParts.push('**تاریخ خروجی:** ' + fmtDate(Date.now()));
    lines.push(metaParts.join(' | '));
    lines.push('');
  }
  lines.push('---');
  lines.push('');

  if (docSpec.kind === 'pages') {
    var pages = docSpec.pages || [];
    pages.forEach(function (pg, idx) {
      if (pg.heading) {
        lines.push('## ' + pg.heading);
        lines.push('');
      }
      if (pg.meta) {
        lines.push('*' + pg.meta + '*');
        lines.push('');
      }
      var raw = norm(pg.text || '');
      var rawLines = raw.split('\n'), pos = 0;
      rawLines.forEach(function (ln) {
        lines.push(formatLineWithMarkdownHighlights(ln, pg.hl || [], pos));
        pos += ln.length + 1;
      });
      if (pg.hl && pg.hl.length) {
        lines.push('');
        lines.push('#### هایلایت‌های این صفحه:');
        pg.hl.forEach(function (hItem) {
          var snip = raw.slice(hItem.s, hItem.e).replace(/\s*\n\s*/g, ' ').trim();
          if (snip) {
            var cname = COLOR_NAMES[hItem.c] || 'هایلایت';
            lines.push('- **[' + cname + ']**: ' + snip);
          }
        });
      }
      lines.push('');
      if (idx < pages.length - 1) {
        lines.push('---');
        lines.push('');
      }
    });
  } else if (docSpec.kind === 'table') {
    var rows = docSpec.rows || [];
    var c1 = (docSpec.col1 || 'واژه (Word)').replace(/\|/g, ' ');
    var c2 = (docSpec.col2 || 'معنی و توضیحات (Meaning)').replace(/\|/g, ' ');
    lines.push('| ردیف | ' + c1 + ' | بخش / منبع | ' + c2 + ' |');
    lines.push('| :---: | --- | --- | --- |');
    rows.forEach(function (r, idx) {
      var w = String(r.w || '').replace(/\|/g, '\|').replace(/\r?\n/g, ' ');
      var sub = String(r.sub || '—').replace(/\|/g, '\|').replace(/\r?\n/g, ' ');
      var m = String(r.m || '—').replace(/\|/g, '\|').replace(/\r?\n/g, ' ');
      lines.push('| ' + fa(idx + 1) + ' | **' + w + '** | ' + sub + ' | ' + m + ' |');
    });
    lines.push('');
  }

  return lines.join('\n');
}

/* --- موتور ساخت فایل و ماژول استاندارد JavaScript (.js) برای هر صفحه یا هر کتاب --- */
function createJsContent(docSpec) {
  var mdContent = createMarkdownContent(docSpec);
  var payload = {
    app: 'ketabche',
    version: '2.3',
    format: 'ketabche-js-export-v1',
    exportedAt: new Date().toISOString(),
    exportedDateFa: fmtDate(Date.now()),
    kind: docSpec.kind || 'pages',
    title: docSpec.title || 'کتابچه',
    subtitle: docSpec.subtitle || '',
    bookMeta: docSpec.bookMeta || null
  };

  if (docSpec.kind === 'pages') {
    payload.pages = (docSpec.pages || []).map(function (pg, idx) {
      var raw = norm(pg.text || '');
      return {
        index: typeof pg.pageIdx === 'number' ? pg.pageIdx : idx,
        pageNumber: typeof pg.pageNumber === 'number' ? pg.pageNumber : (idx + 1),
        id: pg.id || ('page_' + (idx + 1)),
        heading: pg.heading || ('صفحه ' + fa(idx + 1)),
        meta: pg.meta || '',
        text: raw,
        lines: raw.split('\n'),
        highlights: (pg.hl || []).map(function (hItem) {
          return {
            id: hItem.id || '',
            start: hItem.s,
            end: hItem.e,
            color: hItem.c || 'y',
            colorName: COLOR_NAMES[hItem.c] || 'زرد',
            colorHex: '#' + (HL_HEX[hItem.c] || 'FDE047'),
            text: raw.slice(hItem.s, hItem.e)
          };
        })
      };
    });
    payload.totalExportedPages = payload.pages.length;
    payload.plainText = payload.pages.map(function (p) {
      return '--- ' + p.heading + ' ---\n' + p.text;
    }).join('\n\n');
  } else if (docSpec.kind === 'table') {
    payload.rows = (docSpec.rows || []).map(function (r, idx) {
      return {
        index: idx + 1,
        word: r.w || '',
        meaning: r.m || '',
        info: r.sub || ''
      };
    });
    payload.totalRows = payload.rows.length;
  }

  payload.markdown = mdContent;

  var jsonStr = JSON.stringify(payload, null, 2);
  var jsLines = [
    '/**',
    ' * Ketabche JavaScript Export (خروجی جاوااسکریپت کتابچه)',
    ' * عنوان: ' + (docSpec.title || 'کتابچه'),
    ' * توضیحات: ' + (docSpec.subtitle || ''),
    ' * تاریخ خروجی: ' + payload.exportedDateFa + ' (' + payload.exportedAt + ')',
    ' * قابل استفاده در مرورگر (<script src="...">)، Node.js (require) و بازیابی در کتابچه',
    ' */',
    '(function (root, factory) {',
    '  var data = factory();',
    '  if (typeof module === "object" && module.exports) {',
    '    module.exports = data;',
    '  }',
    '  if (root) {',
    '    root.KETABCHE_EXPORT = data;',
    '    root.KETABCHE_EXPORTS = root.KETABCHE_EXPORTS || [];',
    '    root.KETABCHE_EXPORTS.push(data);',
    '  }',
    '})(typeof globalThis !== "undefined" ? globalThis : (typeof window !== "undefined" ? window : this), function () {',
    '  var ketabcheData = ' + jsonStr + ';',
    '',
    '  ketabcheData.getFullText = function () {',
    '    if (ketabcheData.plainText) return ketabcheData.plainText;',
    '    if (Array.isArray(ketabcheData.pages)) {',
    '      return ketabcheData.pages.map(function (p) { return p.text; }).join("\n\n---\n\n");',
    '    }',
    '    return "";',
    '  };',
    '',
    '  ketabcheData.getPage = function (pageNumber) {',
    '    if (!Array.isArray(ketabcheData.pages)) return null;',
    '    for (var i = 0; i < ketabcheData.pages.length; i++) {',
    '      if (ketabcheData.pages[i].pageNumber === pageNumber || (i + 1) === pageNumber) return ketabcheData.pages[i];',
    '    }',
    '    return null;',
    '  };',
    '',
    '  ketabcheData.toMarkdown = function () {',
    '    return ketabcheData.markdown || "";',
    '  };',
    '',
    '  return ketabcheData;',
    '});',
    ''
  ];
  return jsLines.join('\n');
}

function deliverExportFile(bytes, filename, mime, label, textContent, forceShare) {
  var savedAndroid = false;
  try {
    if (bridge('saveFile')) {
      var b64 = bytesToBase64(bytes);
      var res = A.saveFile(filename, b64);
      if (res === 'ok') savedAndroid = true;
    }
  } catch (e) {}

  var canShareFile = false;
  var fileObj = null;
  try {
    if (typeof File !== 'undefined' && navigator.canShare) {
      fileObj = new File([bytes], filename, { type: mime });
      if (navigator.canShare({ files: [fileObj] })) canShareFile = true;
    }
  } catch (e) {}

  function triggerShareAction() {
    if (canShareFile && fileObj) {
      try { navigator.share({ files: [fileObj], title: filename }); return true; } catch (e) {}
    }
    if (typeof textContent === 'string' && textContent.length > 0) {
      shareText(textContent, filename);
      return true;
    }
    return false;
  }

  if (forceShare) {
    if (triggerShareAction()) return;
  }

  if (!savedAndroid) {
    try {
      var blob = new Blob([bytes], { type: mime + (typeof textContent === 'string' ? ';charset=utf-8' : '') });
      var url = URL.createObjectURL(blob);
      var a = h('a', { href: url, download: filename });
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(function () { try { URL.revokeObjectURL(url); } catch (e) {} }, 6000);
    } catch (e) {}
  }

  var hasShareOption = canShareFile || (typeof textContent === 'string' && textContent.length > 0);
  toast((label || 'فایل') + (savedAndroid ? ' در پوشه‌ی Downloads ذخیره شد' : ' آماده و ذخیره شد'), hasShareOption ? {
    label: 'ارسال و اشتراک‌گذاری',
    fn: function () { triggerShareAction(); }
  } : null);
}

function runExportDocSpec(docSpec, fmt, opts) {
  opts = opts || {};
  try {
    var meta = getExportFmtMeta(fmt);
    if (meta.id === 'word') {
      var docxBytes = createDocxBytes(docSpec);
      var docxName = safeFileName(docSpec.fileBase || docSpec.title || 'ketabche', 'docx');
      deliverExportFile(docxBytes, docxName, meta.mime, meta.label, null, !!opts.shareOnly);
    } else if (meta.id === 'md') {
      var mdText = createMarkdownContent(docSpec);
      var mdName = safeFileName(docSpec.fileBase || docSpec.title || 'ketabche', 'md');
      if (opts.copyOnly) {
        copyText(mdText);
        toast('کد Markdown در حافظه کپی شد');
        return mdText;
      }
      if (opts.shareTextOnly) {
        shareText(mdText, mdName);
        return mdText;
      }
      deliverExportFile(utf8ToBytes(mdText), mdName, meta.mime, meta.label, mdText, !!opts.shareOnly);
      return mdText;
    } else if (meta.id === 'js') {
      var jsText = createJsContent(docSpec);
      var jsName = safeFileName(docSpec.fileBase || docSpec.title || 'ketabche', 'js');
      if (opts.copyOnly) {
        copyText(jsText);
        toast('کد JavaScript (.js) در حافظه کپی شد');
        return jsText;
      }
      if (opts.shareTextOnly) {
        shareText(jsText, jsName);
        return jsText;
      }
      deliverExportFile(utf8ToBytes(jsText), jsName, meta.mime, meta.label, jsText, !!opts.shareOnly);
      return jsText;
    } else {
      var canvases = renderDocSpecToCanvases(docSpec);
      var pdfBytes = createPdfBytesFromCanvases(canvases);
      var pdfName = safeFileName(docSpec.fileBase || docSpec.title || 'ketabche', 'pdf');
      deliverExportFile(pdfBytes, pdfName, meta.mime, meta.label, null, !!opts.shareOnly);
    }
  } catch (e) {
    toast('خطا در ساخت فایل خروجی');
  }
}

/* --- ساخت مشخصات سند (DocSpec) برای کتاب یا صفحات انتخابی --- */
function buildBookDocSpec(bk, onlyPageIdx) {
  if (!bk || !bk.pages || !bk.pages.length) return null;
  var pages = [];
  var bkLg = getBookEffLang(bk);
  var bkSecMeta = getBookSectionMeta(bkLg);
  var scopeLabel = '';
  var fileSuffix = '';

  if (typeof onlyPageIdx === 'number' && bk.pages[onlyPageIdx]) {
    var p0 = bk.pages[onlyPageIdx];
    scopeLabel = 'صفحه ' + fa(onlyPageIdx + 1) + ' از ' + fa(bk.pages.length);
    fileSuffix = '-page-' + (onlyPageIdx + 1);
    pages.push({
      id: p0.id,
      pageIdx: onlyPageIdx,
      pageNumber: onlyPageIdx + 1,
      heading: bk.title + ' — صفحه ' + fa(onlyPageIdx + 1),
      meta: 'بخش: ' + bkSecMeta.name + ' · بروزرسانی: ' + fmtDate(p0.updated || bk.updated),
      text: p0.text || '',
      hl: p0.hl || [],
      badgeColor: COVERS[bk.color % COVERS.length]
    });
  } else if (Array.isArray(onlyPageIdx) && onlyPageIdx.length) {
    var sortedIdxs = onlyPageIdx.slice().filter(function (i) { return i >= 0 && i < bk.pages.length; }).sort(function (a, b) { return a - b; });
    if (!sortedIdxs.length) return null;
    scopeLabel = fa(sortedIdxs.length) + ' صفحه‌ی انتخابی از ' + fa(bk.pages.length) + ' صفحه';
    fileSuffix = sortedIdxs.length === 1 ? ('-page-' + (sortedIdxs[0] + 1)) : ('-pages-' + sortedIdxs.map(function (i) { return i + 1; }).slice(0, 5).join('-'));
    sortedIdxs.forEach(function (idx) {
      var p = bk.pages[idx];
      pages.push({
        id: p.id,
        pageIdx: idx,
        pageNumber: idx + 1,
        heading: bk.title + ' — صفحه ' + fa(idx + 1) + ' از ' + fa(bk.pages.length),
        meta: 'بروزرسانی: ' + fmtDate(p.updated || bk.updated),
        text: p.text || '',
        hl: p.hl || [],
        badgeColor: COVERS[bk.color % COVERS.length]
      });
    });
  } else {
    scopeLabel = 'کل کتاب (' + fa(bk.pages.length) + ' صفحه)';
    bk.pages.forEach(function (p, idx) {
      pages.push({
        id: p.id,
        pageIdx: idx,
        pageNumber: idx + 1,
        heading: 'صفحه ' + fa(idx + 1) + ' از ' + fa(bk.pages.length),
        meta: '',
        text: p.text || '',
        hl: p.hl || [],
        badgeColor: COVERS[bk.color % COVERS.length]
      });
    });
  }

  return {
    kind: 'pages',
    title: bk.title,
    subtitle: scopeLabel + ' · بخش ' + bkSecMeta.name,
    fileBase: bk.title + fileSuffix,
    accent: COVERS[bk.color % COVERS.length],
    pageBreak: true,
    bookMeta: {
      bookId: bk.id,
      bookTitle: bk.title,
      section: bkLg,
      sectionName: bkSecMeta.name,
      totalPages: bk.pages.length,
      scopeLabel: scopeLabel
    },
    pages: pages
  };
}

function buildAllBooksDocSpec() {
  var pages = [];
  S.data.books.forEach(function (bk) {
    var bkSec = getBookSectionMeta(getBookEffLang(bk));
    bk.pages.forEach(function (p, i) {
      pages.push({
        id: p.id,
        pageIdx: i,
        pageNumber: i + 1,
        heading: bk.title + ' — صفحه ' + fa(i + 1) + ' از ' + fa(bk.pages.length),
        meta: 'بخش: ' + bkSec.name + ' · ' + fmtDate(bk.updated),
        text: p.text || '',
        hl: p.hl || [],
        badgeColor: COVERS[bk.color % COVERS.length]
      });
    });
  });
  if (!pages.length) return null;
  return {
    kind: 'pages',
    title: 'مجموعه کتاب‌های کتابچه',
    subtitle: fa(S.data.books.length) + ' کتاب · ' + fa(pages.length) + ' صفحه',
    fileBase: 'ketabche-books',
    accent: '#007aff',
    pageBreak: true,
    bookMeta: {
      bookId: 'all',
      bookTitle: 'مجموعه کتاب‌های کتابچه',
      section: 'all',
      sectionName: 'همه بخش‌ها',
      totalPages: pages.length,
      scopeLabel: fa(S.data.books.length) + ' کتاب (' + fa(pages.length) + ' صفحه)'
    },
    pages: pages
  };
}

/* --- توابع خروجی PDF، Word، Markdown و JS برای چهار بخش اصلی --- */
function exportBook(bk, fmt, onlyPageIdx, opts) {
  if (!bk || !bk.pages || !bk.pages.length) { toast('این کتاب هنوز صفحه‌ای ندارد'); return; }
  var spec = buildBookDocSpec(bk, onlyPageIdx);
  if (!spec) { toast('صفحه‌ای برای خروجی انتخاب نشده است'); return; }
  return runExportDocSpec(spec, fmt, opts);
}

function exportAllBooksFlow(fmt) {
  if (!S.data.books.length) { toast('هنوز کتابی ثبت نشده است'); return; }
  var meta = getExportFmtMeta(fmt);
  if (S.data.books.length === 1) {
    openBookPageShareSheet(S.data.books[0], null, meta.id);
    return;
  }
  sheet('انتخاب کتاب یا صفحه برای ارسال ' + meta.short, function (body, L) {
    var hubBtn = h('button', { class: 'btn block', style: 'margin-bottom:8px', html: ic('share', 18) + '<span>باز کردن بخش پیشرفته اشتراک‌گذاری کتاب‌ها و صفحات (PDF / Word / MD / JS)</span>' });
    hubBtn.addEventListener('click', function () {
      L.close(true);
      openBookPageShareSheet(null, null, meta.id);
    });
    body.appendChild(hubBtn);

    var allBtn = h('button', { class: 'btn pri block', style: 'margin-bottom:12px', html: ic(meta.icon, 20) + '<span>ارسال یکجای همه‌ی کتاب‌ها (' + fa(S.data.books.length) + ' کتاب) به صورت ' + meta.short + '</span>' });
    allBtn.addEventListener('click', function () {
      L.close(true);
      var spec = buildAllBooksDocSpec();
      if (!spec) { toast('صفحه‌ای برای خروجی وجود ندارد'); return; }
      runExportDocSpec(spec, meta.id);
    });
    body.appendChild(allBtn);

    S.data.books.forEach(function (bk) {
      var pickPageBtn = h('button', { class: 'btn-exp share-hub', type: 'button', title: 'انتخاب صفحه از این کتاب', html: ic('list', 14) + '<span>انتخاب صفحه</span>' });
      var expBkBtn = h('span', { class: 'btn-exp ' + meta.cls, html: ic(meta.icon, 16) + '<span>' + meta.short + ' کل کتاب</span>' });
      var r = h('div', { class: 'row', role: 'button', tabindex: 0 }, [
        h('div', { class: 'grow' }, [
          h('div', { class: 't', text: bk.title }),
          h('div', { class: 'd', text: fa(bk.pages.length) + ' صفحه · ' + fmtDate(bk.updated) })
        ]),
        h('div', { style: 'display:flex;gap:6px;align-items:center' }, [pickPageBtn, expBkBtn])
      ]);
      pickPageBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        L.close(true);
        openBookPageShareSheet(bk, 0, meta.id);
      });
      r.addEventListener('click', function (e) {
        if (e.target.closest('.share-hub')) return;
        L.close(true);
        exportBook(bk, meta.id);
      });
      body.appendChild(r);
    });
  });
}

/* --- بخش جامع اشتراک‌گذاری و خروجی کتاب‌ها و صفحات (PDF / Word / Markdown / JS) --- */
function openBookPageShareSheet(initialBook, initialPageIdx, preferredFmt) {
  if (!S.data.books.length) {
    toast('هنوز کتابی برای اشتراک‌گذاری ثبت نشده است');
    return;
  }
  var selBook = initialBook || curBook() || S.data.books[0];
  var hasInitPage = typeof initialPageIdx === 'number' && selBook && selBook.pages && selBook.pages[initialPageIdx];
  var scope = hasInitPage ? 'page' : (initialBook ? 'book' : (S.view === 'reader' && curBook() ? 'page' : 'book'));
  var selPageIdx = hasInitPage ? initialPageIdx : (S.view === 'reader' && curBook() === selBook ? clamp(S.index, 0, Math.max(0, (selBook.pages.length || 1) - 1)) : 0);
  var multiPages = {};
  if (selBook && selBook.pages && selBook.pages.length) {
    multiPages[selPageIdx] = true;
  }
  var previewFmt = (preferredFmt === 'js' || preferredFmt === 'javascript') ? 'js' : 'md';

  sheet('اشتراک‌گذاری و خروجی کتاب‌ها و صفحات', function (body) {
    var wrap = h('div', { class: 'share-hub-wrap' });
    body.appendChild(wrap);

    function getActiveDocSpec() {
      if (scope === 'all_books') {
        return buildAllBooksDocSpec();
      }
      if (!selBook || !selBook.pages || !selBook.pages.length) return null;
      if (scope === 'page') {
        var idx = clamp(selPageIdx, 0, selBook.pages.length - 1);
        return buildBookDocSpec(selBook, idx);
      }
      if (scope === 'multi') {
        var chosen = [];
        for (var k in multiPages) {
          if (multiPages[k]) chosen.push(+k);
        }
        if (!chosen.length) return null;
        return buildBookDocSpec(selBook, chosen);
      }
      return buildBookDocSpec(selBook, null);
    }

    function renderHub() {
      wrap.textContent = '';

      // ۱. انتخاب کتاب
      var bookSec = h('div', { class: 'share-hub-sec' });
      bookSec.appendChild(h('div', { class: 'share-hub-sec-title' }, [
        h('span', { text: '۱. انتخاب کتاب:' }),
        h('span', { text: selBook ? (fa(selBook.pages.length) + ' صفحه') : '' })
      ]));
      var bookChips = h('div', { class: 'chips compact-chips', style: 'max-height:110px;overflow-y:auto' });
      S.data.books.forEach(function (bk) {
        var isOn = scope !== 'all_books' && selBook && selBook.id === bk.id;
        var c = h('button', {
          class: 'chip sm' + (isOn ? ' on' : ''),
          type: 'button',
          text: bk.title + ' (' + fa(bk.pages.length) + ' ص)'
        });
        c.addEventListener('click', function () {
          selBook = bk;
          if (scope === 'all_books') scope = 'book';
          selPageIdx = clamp(selPageIdx, 0, Math.max(0, bk.pages.length - 1));
          multiPages = {};
          if (bk.pages.length) multiPages[selPageIdx] = true;
          renderHub();
        });
        bookChips.appendChild(c);
      });
      if (S.data.books.length > 1) {
        var allBkChip = h('button', {
          class: 'chip sm' + (scope === 'all_books' ? ' on' : ''),
          type: 'button',
          text: 'همه‌ی کتاب‌ها (' + fa(S.data.books.length) + ' کتاب)'
        });
        allBkChip.addEventListener('click', function () {
          scope = 'all_books';
          renderHub();
        });
        bookChips.appendChild(allBkChip);
      }
      bookSec.appendChild(bookChips);
      wrap.appendChild(bookSec);

      // ۲. انتخاب محدوده (تک‌صفحه، چند صفحه، کل کتاب، همه کتاب‌ها)
      var scopeSec = h('div', { class: 'share-hub-sec' });
      scopeSec.appendChild(h('div', { class: 'share-hub-sec-title' }, [
        h('span', { text: '۲. انتخاب محدوده (هر صفحه یا کل کتاب):' })
      ]));
      var scopeGrid = h('div', { class: 'share-scope-grid' });
      var scopesList = [
        ['page', 'تک‌صفحه (صفحه ' + fa((selPageIdx || 0) + 1) + ')', 'note'],
        ['multi', 'انتخاب چند صفحه', 'list'],
        ['book', 'کل این کتاب', 'book'],
        ['all_books', 'همه‌ی کتاب‌ها', 'layers']
      ];
      scopesList.forEach(function (sc) {
        if (sc[0] === 'all_books' && S.data.books.length < 2) return;
        var b = h('button', {
          class: 'share-scope-btn' + (scope === sc[0] ? ' on' : ''),
          type: 'button',
          html: ic(sc[2], 15) + '<span>' + sc[1] + '</span>'
        });
        b.addEventListener('click', function () {
          scope = sc[0];
          renderHub();
        });
        scopeGrid.appendChild(b);
      });
      scopeSec.appendChild(scopeGrid);

      // انتخابگر شماره صفحه در حالت تک‌صفحه یا چندصفحه
      if (scope === 'page' && selBook && selBook.pages.length > 0) {
        var pgTitle = h('div', { class: 'share-hub-sec-title', style: 'margin-top:10px;margin-bottom:6px' }, [
          h('span', { text: 'صفحه‌ی مورد نظر برای اشتراک‌گذاری را انتخاب کنید:' }),
          h('span', { text: 'صفحه ' + fa(selPageIdx + 1) + ' از ' + fa(selBook.pages.length) })
        ]);
        scopeSec.appendChild(pgTitle);
        var pgStrip = h('div', { class: 'share-pages-strip' });
        selBook.pages.forEach(function (pg, idx) {
          var pill = h('button', {
            class: 'share-pg-pill' + (idx === selPageIdx ? ' on' : ''),
            type: 'button',
            text: 'صفحه ' + fa(idx + 1)
          });
          pill.addEventListener('click', function () {
            selPageIdx = idx;
            renderHub();
          });
          pgStrip.appendChild(pill);
        });
        scopeSec.appendChild(pgStrip);
        var curPgObj = selBook.pages[selPageIdx];
        if (curPgObj) {
          scopeSec.appendChild(h('div', {
            class: 'share-pg-snippet',
            dir: 'auto',
            text: snippet(curPgObj.text || 'صفحه خالی', 180)
          }));
        }
      } else if (scope === 'multi' && selBook && selBook.pages.length > 0) {
        var selCnt = Object.keys(multiPages).filter(function (k) { return multiPages[k]; }).length;
        var actRow = h('div', { style: 'display:flex;gap:6px;align-items:center;margin-top:10px;margin-bottom:6px;flex-wrap:wrap' });
        actRow.appendChild(h('span', { style: 'font-size:12px;font-weight:700;color:var(--muted);flex:1', text: 'صفحات دلخواه را لمس کنید (' + fa(selCnt) + ' صفحه انتخاب‌شده):' }));
        var selAllB = h('button', { class: 'chip sm', type: 'button', text: 'انتخاب همه' });
        var clrAllB = h('button', { class: 'chip sm', type: 'button', text: 'پاک کردن' });
        selAllB.addEventListener('click', function () {
          selBook.pages.forEach(function (_, idx) { multiPages[idx] = true; });
          renderHub();
        });
        clrAllB.addEventListener('click', function () {
          multiPages = {};
          renderHub();
        });
        actRow.appendChild(selAllB);
        actRow.appendChild(clrAllB);
        scopeSec.appendChild(actRow);

        var mStrip = h('div', { class: 'share-pages-strip' });
        selBook.pages.forEach(function (pg, idx) {
          var isOn = !!multiPages[idx];
          var pill = h('button', {
            class: 'share-pg-pill' + (isOn ? ' on' : ''),
            type: 'button',
            html: (isOn ? ic('check', 13) : '') + '<span>صفحه ' + fa(idx + 1) + '</span>'
          });
          pill.addEventListener('click', function () {
            multiPages[idx] = !multiPages[idx];
            renderHub();
          });
          mStrip.appendChild(pill);
        });
        scopeSec.appendChild(mStrip);
      }
      wrap.appendChild(scopeSec);

      var spec = getActiveDocSpec();
      if (!spec) {
        wrap.appendChild(h('div', { class: 'empty-note', text: 'لطفاً یک کتاب دارای صفحه یا حداقل یک صفحه را انتخاب کنید.' }));
        return;
      }

      // ۳. انتخاب فرمت خروجی و اشتراک‌گذاری (PDF / Word / Markdown / JS)
      var fmtSec = h('div', { class: 'share-hub-sec' });
      fmtSec.appendChild(h('div', { class: 'share-hub-sec-title' }, [
        h('span', { text: '۳. فرمت خروجی و اشتراک‌گذاری (' + spec.subtitle + '):' })
      ]));
      var fmtGrid = h('div', { class: 'share-fmt-grid' });

      var formatsInfo = [
        { id: 'md', title: 'Markdown (.md)', sub: 'فایل و متن استاندارد مارک‌داون', icon: 'md', cls: 'md', isText: true },
        { id: 'js', title: 'JavaScript (.js)', sub: 'ماژول و کد ساختاریافته JS', icon: 'js', cls: 'js', isText: true },
        { id: 'pdf', title: 'پی‌دی‌اف (PDF)', sub: 'با خطوط دفترچه و هایلایت‌ها', icon: 'pdf', cls: 'pdf', isText: false },
        { id: 'word', title: 'فایل ورد (Word)', sub: 'سند قابل ویرایش (.docx)', icon: 'word', cls: 'word', isText: false }
      ];

      formatsInfo.forEach(function (f) {
        var dlBtn = h('button', {
          class: 'btn-exp ' + f.cls,
          type: 'button',
          title: 'ذخیره فایل ' + f.title,
          html: ic('download', 14) + '<span>ذخیره فایل</span>'
        });
        var shBtn = h('button', {
          class: 'btn-exp ' + f.cls,
          type: 'button',
          title: 'اشتراک‌گذاری ' + f.title,
          html: ic('share', 14) + '<span>اشتراک‌گذاری</span>'
        });
        dlBtn.addEventListener('click', function () {
          runExportDocSpec(spec, f.id, { shareOnly: false });
        });
        shBtn.addEventListener('click', function () {
          runExportDocSpec(spec, f.id, { shareOnly: true });
        });
        var acts = [dlBtn, shBtn];
        if (f.isText) {
          var cpBtn = h('button', {
            class: 'btn-exp',
            type: 'button',
            title: 'کپی کد ' + f.title,
            html: ic('copy', 14) + '<span>کپی</span>'
          });
          cpBtn.addEventListener('click', function () {
            runExportDocSpec(spec, f.id, { copyOnly: true });
          });
          acts.push(cpBtn);
        }

        var card = h('div', { class: 'share-fmt-card' }, [
          h('div', { class: 'share-fmt-head' }, [
            h('div', { class: 'share-fmt-badge ' + f.cls, html: ic(f.icon, 20) }),
            h('div', { class: 'share-fmt-info' }, [
              h('b', { text: f.title }),
              h('small', { text: f.sub })
            ])
          ]),
          h('div', { class: 'share-fmt-acts' }, acts)
        ]);
        fmtGrid.appendChild(card);
      });
      fmtSec.appendChild(fmtGrid);

      // دکمه اشتراک‌گذاری متن ساده
      var plainRow = h('div', { style: 'display:flex;gap:6px;margin-top:8px;flex-wrap:wrap' });
      var plainShareB = h('button', { class: 'btn-exp', style: 'flex:1;justify-content:center', type: 'button', html: ic('share', 15) + '<span>اشتراک‌گذاری متن ساده</span>' });
      var plainCopyB = h('button', { class: 'btn-exp', style: 'flex:1;justify-content:center', type: 'button', html: ic('copy', 15) + '<span>کپی متن ساده</span>' });
      function getSpecPlainText() {
        return (spec.pages || []).map(function (p) {
          return (spec.pages.length > 1 ? ('— ' + p.heading + ' —\n') : '') + (p.text || '');
        }).join('\n\n');
      }
      plainShareB.addEventListener('click', function () { shareText(getSpecPlainText(), spec.title); });
      plainCopyB.addEventListener('click', function () { copyText(getSpecPlainText()); });
      plainRow.appendChild(plainShareB);
      plainRow.appendChild(plainCopyB);
      fmtSec.appendChild(plainRow);
      wrap.appendChild(fmtSec);

      // ۴. پیش‌نمایش زنده خروجی Markdown (.md) و JavaScript (.js)
      var prevSec = h('div', { class: 'share-hub-sec' });
      var prevHeader = h('div', { class: 'share-hub-sec-title' }, [
        h('span', { text: '۴. پیش‌نمایش زنده کد خروجی (Markdown / JS):' })
      ]);
      var prevTabs = h('div', { style: 'display:flex;gap:6px;margin-bottom:6px;flex-wrap:wrap' });
      var tabMd = h('button', { class: 'btn-exp md' + (previewFmt === 'md' ? ' on-accent' : ''), type: 'button', html: ic('md', 14) + '<span>پیش‌نمایش Markdown (.md)</span>' });
      var tabJs = h('button', { class: 'btn-exp js' + (previewFmt === 'js' ? ' on-accent' : ''), type: 'button', html: ic('js', 14) + '<span>پیش‌نمایش JavaScript (.js)</span>' });
      tabMd.addEventListener('click', function () { previewFmt = 'md'; renderHub(); });
      tabJs.addEventListener('click', function () { previewFmt = 'js'; renderHub(); });
      prevTabs.appendChild(tabMd);
      prevTabs.appendChild(tabJs);

      var previewContent = previewFmt === 'js' ? createJsContent(spec) : createMarkdownContent(spec);
      var preEl = h('pre', { class: 'share-preview-pre', dir: 'ltr', text: previewContent });

      var prevActs = h('div', { style: 'display:flex;gap:6px;margin-top:8px;flex-wrap:wrap' });
      var copyPrevB = h('button', { class: 'btn-exp ' + previewFmt, style: 'flex:1;justify-content:center', type: 'button', html: ic('copy', 15) + '<span>کپی کد ' + (previewFmt === 'js' ? 'JS' : 'Markdown') + '</span>' });
      var sharePrevB = h('button', { class: 'btn-exp ' + previewFmt, style: 'flex:1;justify-content:center', type: 'button', html: ic('share', 15) + '<span>اشتراک‌گذاری ' + (previewFmt === 'js' ? 'JS' : 'Markdown') + '</span>' });
      var savePrevB = h('button', { class: 'btn-exp ' + previewFmt, style: 'flex:1;justify-content:center', type: 'button', html: ic('download', 15) + '<span>دانلود .' + previewFmt + '</span>' });
      copyPrevB.addEventListener('click', function () { runExportDocSpec(spec, previewFmt, { copyOnly: true }); });
      sharePrevB.addEventListener('click', function () { runExportDocSpec(spec, previewFmt, { shareTextOnly: true }); });
      savePrevB.addEventListener('click', function () { runExportDocSpec(spec, previewFmt, { shareOnly: false }); });
      prevActs.appendChild(savePrevB);
      prevActs.appendChild(sharePrevB);
      prevActs.appendChild(copyPrevB);

      prevSec.appendChild(prevHeader);
      prevSec.appendChild(prevTabs);
      prevSec.appendChild(preEl);
      prevSec.appendChild(prevActs);
      wrap.appendChild(prevSec);
    }

    renderHub();
  });
}

function getFilteredWordsList(forceLang) {
  var now = Date.now(), q = wQuery.trim().toLowerCase();
  var targetLg = forceLang !== undefined ? forceLang : wLangFilter;
  return S.data.words.filter(function (x) {
    if (targetLg && targetLg !== 'all' && getWordEffLang(x) !== targetLg) return false;
    if (wFilter === 'due' && x.due > now) return false;
    if (wFilter === 'known' && x.box < 4) return false;
    if (q && (x.w + ' ' + x.m).toLowerCase().indexOf(q) < 0) return false;
    return true;
  }).sort(function (a, b) { return b.created - a.created; });
}

function exportWordsList(wordsArr, fmt, customTitle) {
  var list = (wordsArr && wordsArr.length) ? wordsArr : S.data.words;
  if (!list || !list.length) { toast('هنوز واژه‌ای برای ارسال ثبت نشده است'); return; }
  var rows = list.map(function (x) {
    var lg = wordLang(x.w, '', x.lg);
    var subParts = [];
    if (lg && lg !== 'fa' && LANG_NAME[lg]) subParts.push(LANG_NAME[lg]);
    if (x.bk) subParts.push(x.bk + (x.pg ? ' ص ' + fa(x.pg) : ''));
    return {
      w: x.w,
      m: x.m || '—',
      sub: subParts.join(' · ')
    };
  });
  runExportDocSpec({
    kind: 'table',
    title: customTitle || 'فهرست لغات و معنی — کتابچه',
    subtitle: fa(rows.length) + ' واژه به همراه معنی · ' + fmtDate(Date.now()),
    fileBase: customTitle || 'ketabche-words',
    col1: 'واژه (Word)',
    col2: 'معنی و توضیحات (Meaning)',
    accent: '#007aff',
    rows: rows
  }, fmt);
}

function exportQuickTable(wordsArr, fmt) {
  var list = (wordsArr && wordsArr.length) ? wordsArr : S.data.words;
  if (!list || !list.length) { toast('هنوز لغتی در جدول مرور سریع نیست'); return; }
  exportWordsList(list, fmt, 'جدول مرور سریع لغات و معنی');
}

function exportSingleNote(x, fmt) {
  if (!x) return;
  ensureNoteUnlocked(x, function (plainText) {
    runExportDocSpec({
      kind: 'pages',
      title: x.title || 'یادداشت',
      subtitle: 'دسته: ' + (x.cat || 'عمومی') + (x.bk ? ' · منبع: ' + x.bk + (x.pg ? ' (ص ' + fa(x.pg) + ')' : '') : '') + ' · ' + fmtDate(x.updated),
      fileBase: x.title || 'ketabche-note',
      accent: '#' + (HL_HEX[x.color] || '007AFF'),
      pageBreak: false,
      pages: [{
        heading: x.title || 'یادداشت',
        meta: 'دسته‌بندی: ' + (x.cat || 'عمومی') + ' · تاریخ: ' + fmtDate(x.updated),
        text: plainText || '',
        hl: [],
        badgeColor: '#007aff',
        badgeHex: HL_HEX[x.color] || 'E0F2FE'
      }]
    }, fmt);
  });
}

function exportNotesList(notesArr, fmt) {
  var list = (notesArr && notesArr.length) ? notesArr : getFilteredNotes();
  if (!list || !list.length) { toast('یادداشتی برای ارسال وجود ندارد'); return; }
  if (list.length === 1) {
    exportSingleNote(list[0], fmt);
    return;
  }
  var unlockedList = list.filter(function (x) { return !isNoteLocked(x); });
  if (!unlockedList.length) {
    toast('یادداشت‌های انتخابی قفل هستند؛ ابتدا قفل یادداشت مورد نظر را باز کنید');
    openNoteUnlockDialog(list[0], function () { exportNotesList(list, fmt); });
    return;
  }
  var pages = unlockedList.map(function (x) {
    return {
      heading: (x.title || 'بدون عنوان') + ' [' + (x.cat || 'عمومی') + ']',
      meta: fmtDate(x.updated) + (x.bk ? ' · ' + x.bk + (x.pg ? ' ص ' + fa(x.pg) : '') : ''),
      text: getNoteText(x),
      hl: [],
      badgeColor: '#007aff',
      badgeHex: HL_HEX[x.color] || 'E0F2FE'
    };
  });
  runExportDocSpec({
    kind: 'pages',
    title: 'یادداشت‌های کتابچه',
    subtitle: fa(pages.length) + ' یادداشت · با حفظ طرح دفترچه و کیفیت اصلی',
    fileBase: 'ketabche-notes',
    accent: '#007aff',
    pageBreak: false,
    pages: pages
  }, fmt);
}

function doBackup() {
  flushSave();
  var books = S.data.books.map(function (b) {
    var o = JSON.parse(JSON.stringify(b)), src = coverSrc(b);
    delete o.cover; delete o.coverData;
    if (src) o.coverData = src;
    return o;
  });
  var payload = JSON.stringify({ app: 'ketabche', version: 5, exported: Date.now(), books: books, words: S.data.words, notes: S.data.notes, noteCats: S.data.noteCats }, null, 1);
  var name = backupName();
  deliverExportFile(utf8ToBytes(payload), name, 'application/json', 'فایل پشتیبان');
}
function doRestore() {
  try { if (bridge('pickFile')) { A.pickFile(); return; } } catch (e) {}
  var inp = h('input', { type: 'file', accept: '.json,.js,.md,application/json,text/javascript,text/markdown' });
  inp.addEventListener('change', function () {
    var f = inp.files && inp.files[0]; if (!f) return;
    var rd = new FileReader(); rd.onload = function () { handleRestore(String(rd.result), f.name); }; rd.readAsText(f);
  });
  inp.click();
}
function tryParseKetabcheJsOrMdImport(txt, fileName) {
  var s = String(txt || '').trim();
  if (!s) return null;
  var marker = 'var ketabcheData = ';
  var mIdx = s.indexOf(marker);
  if (mIdx >= 0) {
    var after = s.slice(mIdx + marker.length);
    var endMarker = ';\n\n  ketabcheData.getFullText';
    var eIdx = after.indexOf(endMarker);
    if (eIdx < 0) eIdx = after.indexOf(';\r\n\r\n  ketabcheData.getFullText');
    if (eIdx > 0) {
      try {
        var parsed = JSON.parse(after.slice(0, eIdx));
        if (parsed && parsed.app === 'ketabche' && Array.isArray(parsed.pages)) {
          var now = Date.now();
          return {
            app: 'ketabche',
            books: [{
              id: uid(),
              title: parsed.title || 'کتاب واردشده از JS',
              lg: (parsed.bookMeta && parsed.bookMeta.section && parsed.bookMeta.section !== 'all') ? parsed.bookMeta.section : 'fa',
              color: S.data.nextCover % COVERS.length,
              created: now,
              updated: now,
              last: 0,
              pages: parsed.pages.map(function (p) {
                return {
                  id: uid(),
                  text: norm(p.text || ''),
                  created: now,
                  updated: now,
                  hl: Array.isArray(p.highlights) ? p.highlights.map(function (hItem) {
                    return { id: uid(), s: hItem.start | 0, e: hItem.end | 0, c: hItem.color || 'y' };
                  }) : []
                };
              })
            }],
            words: [],
            notes: [],
            noteCats: []
          };
        }
      } catch (e) {}
    }
  }
  if ((fileName && /\.(md|markdown)$/i.test(fileName)) || /^#\s+.+/m.test(s)) {
    var lines = s.replace(/\r\n?/g, '\n').split('\n');
    var title = (fileName ? fileName.replace(/\.(md|markdown)$/i, '') : 'کتاب مارک‌داون');
    if (lines[0] && /^#\s+/.test(lines[0])) {
      title = lines[0].replace(/^#\s+/, '').trim() || title;
    }
    var rawSections = s.split(/\n---\n/);
    var pages = [];
    rawSections.forEach(function (sec, idx) {
      var clean = sec.trim();
      if (!clean) return;
      if (idx === 0 && /^#\s+/.test(clean) && clean.indexOf('## ') < 0) return;
      clean = clean.replace(/^##\s+.*\n+/, '').replace(/^\*.*\*\n+/, '').replace(/\n+#### هایلایت‌های این صفحه:[\s\S]*$/, '').replace(/==([^=]+)==/g, '$1').trim();
      if (clean) {
        pages.push({ id: uid(), text: clean, created: Date.now(), updated: Date.now(), hl: [] });
      }
    });
    if (!pages.length && s.trim()) {
      pages.push({ id: uid(), text: s.trim(), created: Date.now(), updated: Date.now(), hl: [] });
    }
    if (pages.length) {
      return {
        app: 'ketabche',
        books: [{ id: uid(), title: title, lg: 'fa', color: S.data.nextCover % COVERS.length, created: Date.now(), updated: Date.now(), last: 0, pages: pages }],
        words: [],
        notes: [],
        noteCats: []
      };
    }
  }
  return null;
}
function handleRestore(txt, fileName) {
  var j;
  try { j = JSON.parse(txt); } catch (e) { j = null; }
  if (!j || j.app !== 'ketabche') {
    j = tryParseKetabcheJsOrMdImport(txt, fileName);
  }
  if (!j || j.app !== 'ketabche' || (!Array.isArray(j.books) && !Array.isArray(j.words) && !Array.isArray(j.notes))) { toast('این فایل، پشتیبان یا خروجی کتابچه نیست'); return; }
  var tmp = sanitize({ books: Array.isArray(j.books) ? j.books : [], words: j.words, notes: j.notes, noteCats: j.noteCats });
  if (!tmp.books.length && !tmp.words.length && !tmp.notes.length) { toast('فایل پشتیبان خالی است'); return; }
  var wparts = [];
  if (tmp.books.length) wparts.push(fa(tmp.books.length) + ' کتاب');
  if (tmp.words.length) wparts.push(fa(tmp.words.length) + ' واژه');
  if (tmp.notes.length) wparts.push(fa(tmp.notes.length) + ' یادداشت');
  var what = wparts.join(' و ');
  dialog({ title: 'بازیابی از پشتیبان', message: what + ' در فایل هست. به موارد فعلی اضافه شود؟ (چیزی حذف نمی‌شود.)', ok: 'بازیابی' }).then(function (r) {
    if (!r) return;
    var added = 0;
    tmp.books.forEach(function (b) {
      var ex = bookById(b.id);
      if (ex) {
        if (JSON.stringify(ex.pages) === JSON.stringify(b.pages) && ex.title === b.title) return;
        b.id = uid(); b.title = b.title + ' (بازیابی‌شده)';
      }
      if (b.coverData && bridge('putCover')) {          // عکس را در حافظه‌ی برنامه بازسازی کن
        var tok = uid(), okc = false;
        try { okc = A.putCover(tok, b.coverData) === 'ok'; } catch (e) {}
        if (okc) { b.cover = tok; S.covers[tok] = b.coverData; }
        delete b.coverData;
      }
      S.data.books.push(b); added++;
    });
    var addedW = 0;
    tmp.words.forEach(function (w) {
      var ex = wordByKey(wkey(w.w));
      if (ex) { if (!ex.m && w.m) { ex.m = w.m; ex.updated = Date.now(); addedW++; } return; }
      if (wordById(w.id)) w.id = uid();
      S.data.words.push(w); addedW++;
    });
    var addedN = 0;
    tmp.noteCats.forEach(function (c) {
      if (S.data.noteCats.indexOf(c) < 0) S.data.noteCats.push(c);
    });
    tmp.notes.forEach(function (n) {
      var dup = S.data.notes.some(function (ex) { return ex.title === n.title && ex.text === n.text; });
      if (dup) return;
      if (noteById(n.id)) n.id = uid();
      S.data.notes.push(n); addedN++;
    });
    scheduleSave(); flushSave(); renderLibrary();
    if (S.libTab === 'words') renderWords();
    if (S.libTab === 'quick') renderQuickReview();
    if (S.libTab === 'notes') renderNotes();
    var parts = [];
    if (added) parts.push(fa(added) + ' کتاب');
    if (addedW) parts.push(fa(addedW) + ' واژه');
    if (addedN) parts.push(fa(addedN) + ' یادداشت');
    toast(parts.length ? parts.join(' و ') + ' بازیابی شد' : 'همه‌ی موارد از قبل وجود داشتند');
  });
}
window.onFilePicked = function (b64) {
  if (!S.data) return;
  try {
    var bin = atob(b64), bytes = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    handleRestore(new TextDecoder('utf-8').decode(bytes));
  } catch (e) { toast('خواندن فایل انجام نشد'); }
};

/* =====================================================================
   کتابخانه
   ===================================================================== */
function renderLibrary() {
  var list = $('#libList');
  list.textContent = '';
  var st = S.data.settings;
  var sortMode = st.libSort || 'recent';
  var viewMode = st.libView || 'grid';
  var allBooks = S.data.books.slice().sort(function (a, b) { return b.updated - a.updated; });
  var books = allBooks.filter(function (bk) {
    if (bLangFilter !== 'all' && getBookEffLang(bk) !== bLangFilter) return false;
    return true;
  });
  if (sortMode === 'title') {
    books.sort(function (a, b) { return String(a.title || '').localeCompare(String(b.title || ''), 'fa'); });
  } else if (sortMode === 'progress') {
    books.sort(function (a, b) {
      var pa = a.pages.length ? (a.last + 1) / a.pages.length : 0;
      var pb = b.pages.length ? (b.last + 1) / b.pages.length : 0;
      return pb - pa || (b.updated - a.updated);
    });
  }
  var tp = 0; books.forEach(function (bk) { tp += bk.pages.length; });
  var nw = S.data.words.length, nn = S.data.notes.length;
  var subParts = [];
  if (allBooks.length) subParts.push(fa(allBooks.length) + ' کتاب');
  if (nw) subParts.push(fa(nw) + ' واژه');
  if (nn) subParts.push(fa(nn) + ' یادداشت');
  $('#libSub').textContent = subParts.length ? subParts.join(' · ') : 'متن‌های شما، صفحه به صفحه';
  updateWordCount();
  updateNoteCount();
  updateTopTabLabels();

  var topStrip = buildUnifiedSectionStrip('books', bLangFilter, function (newLg) {
    bLangFilter = newLg;
    bPageIdx = 0;
    renderLibrary();
    updateTopTabLabels();
  });

  var continueCard = null;
  var recentBook = allBooks.length ? allBooks[0] : null;
  if (recentBook && recentBook.pages.length && bPageIdx === 0 && bLangFilter === 'all') {
    var rPct = Math.round(clamp((recentBook.last + 1) / recentBook.pages.length, 0, 1) * 100);
    var rMins = estReadMins(recentBook, recentBook.last);
    var rSrc = coverSrc(recentBook);
    var rThumb = h('div', { class: 'cr-thumb' + (rSrc ? ' has-img' : ''), style: '--cv:' + COVERS[recentBook.color % COVERS.length] });
    if (rSrc) rThumb.style.backgroundImage = 'url("' + rSrc + '")';
    else rThumb.innerHTML = ic('book', 20);
    var rBtn = h('button', { class: 'cr-go', type: 'button', html: ic('play', 14) + '<span>ادامه</span>' });
    continueCard = h('div', { class: 'continue-card', role: 'button', tabindex: 0 }, [
      rThumb,
      h('div', { class: 'cr-body' }, [
        h('div', { class: 'cr-kicker', text: 'ادامه مطالعه' }),
        h('div', { class: 'cr-title', dir: 'auto', text: recentBook.title }),
        h('div', { class: 'cr-meta', text: 'صفحه ' + fa(Math.min(recentBook.last + 1, recentBook.pages.length)) + ' از ' + fa(recentBook.pages.length) + ' · ' + fa(rPct) + '٪ · ' + rMins }),
        h('div', { class: 'cr-bar' }, [h('i', { style: 'width:' + rPct + '%' })])
      ]),
      rBtn
    ]);
    continueCard.addEventListener('click', function () { hapticTap(); openBook(recentBook.id); });
  }

  var activeSecMeta = bLangFilter !== 'all' ? getBookSectionMeta(bLangFilter) : null;
  var bsumTitle = activeSecMeta
    ? ('کتاب‌های ' + activeSecMeta.name + ' (' + fa(books.length) + ')')
    : ('کتاب‌ها (' + fa(books.length) + ' · ' + fa(tp) + ' ص)');

  var sortLabels = { recent: 'اخیر', title: 'الفبا', progress: 'پیشرفت' };
  var bSortBtn = h('button', {
    class: 'btn-exp',
    type: 'button',
    title: 'تغییر ترتیب نمایش کتاب‌ها',
    html: ic('sort', 14) + '<span>' + sortLabels[sortMode] + '</span>'
  });
  var bViewBtn = h('button', {
    class: 'btn-exp',
    type: 'button',
    title: viewMode === 'list' ? 'نمایش شبکه‌ای (جلد کتاب)' : 'نمایش فهرستی (سریع و فشرده)',
    html: ic(viewMode === 'list' ? 'grid' : 'listView', 14) + '<span>' + (viewMode === 'list' ? 'شبکه' : 'فهرست') + '</span>'
  });
  var bManageSecBtn = h('button', {
    class: 'btn-exp',
    type: 'button',
    title: 'ذخیره دستی هر کتاب در بخش‌های مختلف',
    html: ic('folder', 14) + '<span>بخش‌ها</span>'
  });
  var bImportDocBtn = h('button', { class: 'btn-exp import-doc', type: 'button', title: 'بارگذاری فایل Word (.docx)، PDF (.pdf) یا EPUB (.epub) به عنوان کتاب جدید', html: ic('upload', 14) + '<span>Word/PDF/EPUB</span>' });
  var bShareHubBtn = h('button', { class: 'btn-exp share-hub', type: 'button', title: 'اشتراک‌گذاری کتاب‌ها و صفحات (PDF / Word / Markdown / JS)', html: ic('share', 14) + '<span>خروجی</span>' });

  bSortBtn.addEventListener('click', function () {
    var order = ['recent', 'title', 'progress'];
    st.libSort = order[(order.indexOf(sortMode) + 1) % order.length];
    scheduleSave();
    hapticTap();
    renderLibrary();
  });
  bViewBtn.addEventListener('click', function () {
    st.libView = viewMode === 'list' ? 'grid' : 'list';
    scheduleSave();
    hapticTap();
    renderLibrary();
  });
  bImportDocBtn.addEventListener('click', function () { hapticTap(); openImportDocFlow(null); });
  bManageSecBtn.addEventListener('click', function () { openBulkBookSectionManager(); });
  bShareHubBtn.addEventListener('click', function () { openBookPageShareSheet(null, null); });

  var headBar = h('div', { class: 'uni-toolbar uni-toolbar-clean' }, [
    h('div', { class: 'uni-tb-title' }, [
      h('b', { text: bsumTitle })
    ]),
    h('div', { class: 'uni-tb-acts' }, [bImportDocBtn, bSortBtn, bViewBtn, bManageSecBtn, bShareHubBtn])
  ]);

  var stageArea = h('div', { class: 'no-scroll-stage books-stage' });

  if (!books.length) {
    var lgTitle = activeSecMeta ? (' در بخش «کتاب‌های ' + activeSecMeta.name + '»') : '';
    var emptyDiv = h('div', { class: 'lib-empty compact-empty', html: ic('book', 48) + '<h3>هنوز کتابی' + lgTitle + ' ندارید</h3><p>یک کتاب جدید در این بخش بسازید یا کتاب‌های موجود را به صورت دستی در این بخش ذخیره کنید.</p>' });
    var actsWrap = h('div', { style: 'display:flex;gap:8px;flex-wrap:wrap;justify-content:center;margin-top:6px' });
    var b = h('button', { class: 'btn pri', html: ic('plus', 18) + '<span>ساخت کتاب جدید' + (activeSecMeta ? ' (' + activeSecMeta.name + ')' : '') + '</span>' });
    b.addEventListener('click', function () { bookFormFlow(null, bLangFilter !== 'all' ? bLangFilter : 'fa'); });
    actsWrap.appendChild(b);
    if (allBooks.length && bLangFilter !== 'all') {
      var moveExistingB = h('button', { class: 'btn', html: ic('folder', 18) + '<span>انتقال کتاب موجود به این بخش</span>' });
      moveExistingB.addEventListener('click', function () { openBulkBookSectionManager(); });
      actsWrap.appendChild(moveExistingB);
    }
    emptyDiv.appendChild(actsWrap);
    stageArea.appendChild(emptyDiv);
  } else {
    var totalBookPages = Math.max(1, Math.ceil(books.length / BOOKS_PER_PAGE));
    bPageIdx = clamp(bPageIdx, 0, totalBookPages - 1);
    var pagedBooks = books.slice(bPageIdx * BOOKS_PER_PAGE, (bPageIdx + 1) * BOOKS_PER_PAGE);
    var grid = h('div', { class: viewMode === 'list' ? 'books-list-page' : 'books-grid-page' });

    pagedBooks.forEach(function (bk) {
      var bkLg = getBookEffLang(bk);
      var bkMeta = getBookSectionMeta(bkLg);
      var more = h('button', { class: 'more ibtn', 'aria-label': 'گزینه‌ها', html: ic('dots', 20) });
      var src = coverSrc(bk), img = null;
      if (src) { img = h('div', { class: 'cv-img' }); img.style.backgroundImage = 'url("' + src + '")'; }
      var pct = bk.pages.length ? Math.round(clamp((bk.last + 1) / bk.pages.length, 0, 1) * 100) : 0;
      var prog = bk.pages.length ? h('div', { class: 'bk-prog', title: fa(pct) + '٪ خوانده‌شده' }, [h('i', { style: 'width:' + pct + '%' })]) : null;
      var secBadgeBtn = h('button', {
        class: 'bk-lang-badge clickable',
        type: 'button',
        title: 'تغییر دستی بخش ذخیره کتاب (انگلیسی، فارسی و...)',
        text: bkMeta.badge + ' · ' + bkMeta.short + ' ▾'
      });
      secBadgeBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        openBookSectionPicker(bk);
      });
      var card;
      if (viewMode === 'list') {
        var lThumb = h('div', { class: 'bl-thumb' + (src ? ' has-img' : ''), style: '--cv:' + COVERS[bk.color % COVERS.length] });
        if (src) lThumb.style.backgroundImage = 'url("' + src + '")';
        else lThumb.innerHTML = ic('book', 18);
        card = h('div', { class: 'book-row', 'data-lang': bkLg, role: 'button', tabindex: 0 }, [
          lThumb,
          h('div', { class: 'bl-info' }, [
            h('div', { class: 'bl-top' }, [h('h3', { dir: 'auto', text: bk.title }), secBadgeBtn]),
            h('div', { class: 'bl-meta', text: fa(bk.pages.length) + ' صفحه · ' + fa(pct) + '٪ · ' + estReadMins(bk, bk.last) + ' · ' + fmtDate(bk.updated) }),
            prog
          ]),
          more
        ]);
      } else {
        card = h('div', { class: 'book' + (src ? ' has-img' : ''), 'data-lang': bkLg, role: 'button', tabindex: 0, style: '--cv:' + COVERS[bk.color % COVERS.length] }, [
          img,
          h('div', { class: 'bk-in' }, [
            secBadgeBtn,
            h('h3', { dir: 'auto', text: bk.title }), h('div', { class: 'rule' }),
            h('div', { class: 'meta' }, [fa(bk.pages.length) + ' صفحه · ' + fa(pct) + '٪', h('br'), fmtDate(bk.updated), prog])
          ]), more
        ]);
      }
      card.addEventListener('click', function (e) { if (e.target.closest('.more') || e.target.closest('.bk-lang-badge')) return; openBook(bk.id); });
      more.addEventListener('click', function (e) {
        e.stopPropagation();
        menu(more, [
          { icon: 'translate', label: 'افزونه ترجمه کتاب (ترجمه کامل / دوزبانه خط‌به‌خط)…', fn: function () { openBookWithTranslator(bk.id); } },
          { icon: 'share', label: 'بخش اشتراک‌گذاری کتاب و صفحات (PDF / Word / MD / JS)…', fn: function () { openBookPageShareSheet(bk, null); } },
          '-',
          { icon: 'pdf', label: 'ارسال کتاب به صورت پی‌دی‌اف (PDF)', fn: function () { exportBook(bk, 'pdf'); } },
          { icon: 'word', label: 'ارسال کتاب به صورت فایل ورد (Word)', fn: function () { exportBook(bk, 'word'); } },
          { icon: 'md', label: 'ارسال کتاب به صورت مارک‌داون (Markdown - .md)', fn: function () { exportBook(bk, 'md'); } },
          { icon: 'js', label: 'ارسال کتاب به صورت جاوااسکریپت (JS - .js)', fn: function () { exportBook(bk, 'js'); } },
          { icon: 'share', label: 'اشتراک‌گذاری متن ساده', fn: function () { shareText(bookText(bk), bk.title); } },
          '-',
          { icon: 'folder', label: 'ذخیره دستی در بخش (انگلیسی، فارسی و...) — فعلی: ' + bkMeta.name, fn: function () { openBookSectionPicker(bk); } },
          { icon: 'image', label: 'ویرایش نام، بخش و عکس کتاب (' + bkMeta.name + ')', fn: function () { bookFormFlow(bk); } },
          '-',
          { icon: 'trash', label: 'حذف کتاب', danger: true, fn: function () { deleteBookFlow(bk); } }
        ]);
      });
      grid.appendChild(card);
    });
    stageArea.appendChild(grid);
  }

  var addLbl = 'کتاب جدید' + (activeSecMeta ? ' (' + activeSecMeta.short + ')' : '');
  var bottomDock = buildBottomPagerDock(bPageIdx, books.length, BOOKS_PER_PAGE, function (np) {
    bPageIdx = np;
    renderLibrary();
  }, 'کتاب', addLbl, function () { newBookFlow(); });

  list.appendChild(topStrip);
  if (continueCard) list.appendChild(continueCard);
  list.appendChild(headBar);
  list.appendChild(stageArea);
  list.appendChild(bottomDock);
}
/* =====================================================================
   عکس کتاب
   در اندروید: فایل کوچک‌شده در حافظه‌ی برنامه (cover = شناسه‌ی فایل).
   در مرورگر (برای آزمون): خود عکس به شکل data URI (coverData).
   ===================================================================== */
function coverSrc(ref) {
  if (!ref) return '';
  if (ref.coverData) return ref.coverData;
  if (!ref.cover) return '';
  if (S.covers[ref.cover] !== undefined) return S.covers[ref.cover];
  var src = '';
  try { if (bridge('getCover')) src = A.getCover(ref.cover) || ''; } catch (e) {}
  if (src) S.covers[ref.cover] = src;
  return src;
}
function dropCoverFile(token) {
  if (!token) return;
  delete S.covers[token];
  try { if (bridge('deleteCover')) A.deleteCover(token); } catch (e) {}
}
function cleanCoverFiles() {
  try {
    if (!bridge('cleanCovers')) return;
    var keep = [];
    S.data.books.forEach(function (b) { if (b.cover) keep.push(b.cover); });
    if (S.data.settings && S.data.settings.pageBgCover) keep.push(S.data.settings.pageBgCover);
    if (!keep.length) return;
    A.cleanCovers(JSON.stringify(keep));
  } catch (e) {}
}

window.onCoverPicked = function (id, token) {
  var w = S.coverWait; S.coverWait = null;
  if (!w || w.id !== id) { dropCoverFile(token); return; }
  w.fn({ cover: token });
};
window.onCoverFailed = function () { S.coverWait = null; toast('این عکس باز نشد'); };

function pickCoverImage(id, cb) {
  if (bridge('pickCover')) {
    var safeId = String(id || uid()).replace(/[^A-Za-z0-9_-]/g, '') || uid();
    S.coverWait = { id: safeId, fn: cb };
    try {
      A.pickCover(safeId);
      return;
    } catch (e) {
      S.coverWait = null;
    }
  }
  var inp = h('input', {
    type: 'file',
    accept: 'image/*',
    style: 'position:fixed;top:-9999px;left:-9999px;width:1px;height:1px;opacity:0;pointer-events:none'
  });
  document.body.appendChild(inp);
  function cleanup() {
    setTimeout(function () {
      if (inp && inp.parentNode) inp.parentNode.removeChild(inp);
    }, 600);
  }
  inp.addEventListener('change', function () {
    var f = inp.files && inp.files[0];
    cleanup();
    if (!f) return;
    var fr = new FileReader();
    fr.onload = function () {
      var img = new Image();
      img.onload = function () {
        var m = Math.max(img.width, img.height), sc = m > 900 ? 900 / m : 1;
        var cv = document.createElement('canvas');
        cv.width = Math.max(1, Math.round(img.width * sc)); cv.height = Math.max(1, Math.round(img.height * sc));
        var cx = cv.getContext('2d'); cx.fillStyle = '#fff'; cx.fillRect(0, 0, cv.width, cv.height);
        cx.drawImage(img, 0, 0, cv.width, cv.height);
        cb({ coverData: cv.toDataURL('image/jpeg', 0.84) });
      };
      img.onerror = function () { toast('این عکس باز نشد'); };
      img.src = String(fr.result);
    };
    fr.readAsDataURL(f);
  });
  try {
    inp.click();
  } catch (e) {
    cleanup();
    toast('باز کردن گالری ممکن نشد');
  }
}

/* فرم «کتاب جدید» و «ویرایش کتاب» (نام + عکس) */
function bookFormFlow(bk, defaultLang) {
  var isNew = !bk;
  var id = isNew ? uid() : bk.id;
  var cur = { cover: bk && bk.cover ? bk.cover : '', coverData: bk && bk.coverData ? bk.coverData : '' };
  var lgSel = bk ? getBookEffLang(bk) : (defaultLang ? defaultLang : (bLangFilter !== 'all' ? bLangFilter : 'fa'));
  var fresh = [];
  var finished = false;
  var dim = h('div', { class: 'dim' });
  var box = h('div', { class: 'dialog bookform' });
  box.appendChild(h('h3', { text: isNew ? 'کتاب جدید' : 'ویرایش کتاب' }));

  var thumb = h('button', { class: 'cv-pick', 'aria-label': 'انتخاب عکس کتاب' });
  var pickBtn = h('button', { class: 'btn', html: ic('image', 20) + '<span></span>' });
  var rmBtn = h('button', { class: 'btn', html: ic('trash', 20) + '<span>حذف عکس</span>' });
  var side = h('div', { class: 'cv-side' }, [
    h('div', { class: 'd', text: 'عکس کتاب (اختیاری) در کتابخانه روی جلد نمایش داده می‌شود.' }), pickBtn, rmBtn
  ]);
  box.appendChild(h('div', { class: 'cv-row' }, [thumb, side]));
  var input = h('input', { class: 'field', type: 'text', value: isNew ? '' : bk.title, dir: 'auto', maxlength: 120,
    placeholder: isNew ? 'نام کتاب؛ مثلاً: یادداشت‌های مطالعه' : 'نام کتاب' });
  box.appendChild(input);
  box.appendChild(h('label', { class: 'wf-l', style: 'margin-top:12px', text: 'بخش ذخیره کتاب (انتخاب دستی بخش کتاب‌های انگلیسی، فارسی و...):' }));
  var bkLgRow = h('div', { class: 'wf-lg', style: 'margin-top:6px' });
  function drawBkLg() {
    bkLgRow.textContent = '';
    getAllBookSections().forEach(function (m) {
      var ch = h('button', { class: 'chip sm' + (lgSel === m.id ? ' on' : ''), type: 'button', text: m.badge + ' · کتاب‌های ' + m.name });
      ch.addEventListener('click', function () { lgSel = m.id; drawBkLg(); });
      bkLgRow.appendChild(ch);
    });
    var addCh = h('button', { class: 'chip sm', type: 'button', html: ic('plus', 13) + '<span>بخش جدید...</span>' });
    addCh.addEventListener('click', function () {
      promptAddCustomBookSection(function (newId) {
        lgSel = newId;
        drawBkLg();
      });
    });
    bkLgRow.appendChild(addCh);
  }
  drawBkLg();
  box.appendChild(bkLgRow);
  var ok = h('button', { class: 'btn pri', text: isNew ? 'ساخت' : 'ذخیره' });
  var cancel = h('button', { class: 'btn', text: 'انصراف' });
  box.appendChild(h('div', { class: 'acts' }, [cancel, ok]));

  function drawThumb() {
    var src = coverSrc(cur);
    thumb.textContent = '';
    thumb.style.backgroundImage = src ? 'url("' + src + '")' : '';
    thumb.classList.toggle('has', !!src);
    if (!src) thumb.innerHTML = ic('image', 30);
    $('span', pickBtn).textContent = src ? 'تغییر عکس' : 'انتخاب عکس از گالری';
    rmBtn.style.display = src ? '' : 'none';
  }
  function setCover(res) {
    if (cur.cover && fresh.indexOf(cur.cover) >= 0) { dropCoverFile(cur.cover); fresh.splice(fresh.indexOf(cur.cover), 1); }
    cur.cover = res.cover || '';
    cur.coverData = res.coverData || '';
    if (res.cover) fresh.push(res.cover);
    drawThumb();
  }
  function pick() { pickCoverImage(id, setCover); }
  thumb.addEventListener('click', pick);
  pickBtn.addEventListener('click', pick);
  rmBtn.addEventListener('click', function () { setCover({}); });
  drawThumb();

  var L;
  function close() { if (finished) return; finished = true; L.close(true); }
  function abort() {
    if (finished) return;
    fresh.forEach(function (t) { dropCoverFile(t); });
    S.coverWait = null;
    close();
  }
  L = openLayer(h('div', { class: 'layer' }, [dim, box]), { onBack: abort });
  dim.addEventListener('click', abort);
  cancel.addEventListener('click', abort);
  function save() {
    if (finished) return;
    var title = input.value.trim() || (isNew ? 'کتاب بدون نام' : bk.title);
    var oldTok = '';
    if (isNew) {
      var now = Date.now();
      bk = { id: id, title: title, lg: lgSel, color: S.data.nextCover % COVERS.length, created: now, updated: now, last: 0, pages: [] };
      S.data.nextCover++;
      S.data.books.push(bk);
    } else {
      oldTok = bk.cover || '';
      bk.title = title;
      bk.lg = lgSel;
    }
    if (cur.cover) bk.cover = cur.cover; else delete bk.cover;
    if (cur.coverData) bk.coverData = cur.coverData; else delete bk.coverData;
    if (oldTok && oldTok !== cur.cover) dropCoverFile(oldTok);
    S.coverWait = null;
    close();
    if (isNew) {
      scheduleSave();
      openBook(bk.id);
      setTimeout(function () { addPageFlow(); }, 260);
    } else {
      touch(bk, null);
      renderLibrary();
      if (S.view === 'reader') updateBars();
    }
  }
  ok.addEventListener('click', save);
  input.addEventListener('keydown', function (e) { if (e.key === 'Enter') save(); });
  if (isNew) setTimeout(function () { input.focus(); }, 80);
}

function newBookFlow() { bookFormFlow(null, bLangFilter !== 'all' ? bLangFilter : 'fa'); }
function renameBookFlow(bk) { bookFormFlow(bk); }
function deleteBookFlow(bk) {
  dialog({ title: 'حذف کتاب', message: 'کتاب «' + bk.title + '» با ' + fa(bk.pages.length) + ' صفحه حذف شود؟ این کار با دکمه‌ی «بازگردانی» که چند ثانیه نشان داده می‌شود قابل برگشت است.',
    ok: 'حذف', danger: true }).then(function (r) {
    if (!r) return;
    ttsStop();
    var idx = S.data.books.indexOf(bk);
    S.data.books.splice(idx, 1);
    if (S.bookId === bk.id) { S.bookId = null; S.data.lastBook = null; showLibrary(); }
    scheduleSave(); flushSave(); renderLibrary();
    toast('کتاب حذف شد', { label: 'بازگردانی', fn: function () {
      S.data.books.splice(Math.min(idx, S.data.books.length), 0, bk);
      scheduleSave(); flushSave(); renderLibrary();
    } });
  });
}
function showLibrary() {
  S.view = 'library';
  hideBar();
  $('#rd').classList.add('hidden');
  $('#lib').classList.remove('hidden');
  setLibTab(S.libTab);
}
function openBook(id) {
  var b = bookById(id); if (!b) return;
  stopAutoScroll();
  stopHoldScroll();
  trCancelJob();
  S.trBarOpen = false;
  renderTrBar();
  S.bookId = id;
  S.data.lastBook = id;
  S.view = 'reader';
  updateScrollDockVisibility();
  $('#lib').classList.add('hidden');
  $('#rd').classList.remove('hidden');
  scheduleSave();
  var last = clamp(b.last | 0, 0, b.pages.length);
  showPageNow(last);
}
function closeBook() {
  trCancelJob();
  S.trBarOpen = false;
  renderTrBar();
  setImmersive(false);
  ttsStop();
  flushSave();
  S.data.lastBook = null;
  S.bookId = null;
  scheduleSave();
  showLibrary();
}

function libMenu() {
  var tabItems = S.libTab === 'words' ? [
    { icon: 'layers', label: 'مرور واژه‌ها (فلش‌کارت)', fn: function () { reviewStart(dueWords().length ? 'due' : 'all'); } },
    { icon: 'pdf', label: 'ارسال لغات و معنی به صورت PDF', fn: function () { exportWordsList(getFilteredWordsList(), 'pdf'); } },
    { icon: 'word', label: 'ارسال لغات و معنی به صورت Word', fn: function () { exportWordsList(getFilteredWordsList(), 'word'); } },
    { icon: 'md', label: 'ارسال لغات و معنی به صورت Markdown (.md)', fn: function () { exportWordsList(getFilteredWordsList(), 'md'); } },
    { icon: 'js', label: 'ارسال لغات و معنی به صورت JavaScript (.js)', fn: function () { exportWordsList(getFilteredWordsList(), 'js'); } },
    { icon: 'share', label: 'اشتراک‌گذاری متنی لغات', fn: shareWords },
    '-'
  ] : S.libTab === 'quick' ? [
    { icon: 'speaker', label: 'خوانش خودکار همه‌ی لغات ستون', fn: function () { speakWordsColumn(getQuickWords(), null); } },
    { icon: 'pdf', label: 'ارسال جدول مرور سریع به صورت PDF', fn: function () { exportQuickTable(getQuickWords(), 'pdf'); } },
    { icon: 'word', label: 'ارسال جدول مرور سریع به صورت Word', fn: function () { exportQuickTable(getQuickWords(), 'word'); } },
    { icon: 'md', label: 'ارسال جدول مرور سریع به صورت Markdown (.md)', fn: function () { exportQuickTable(getQuickWords(), 'md'); } },
    { icon: 'js', label: 'ارسال جدول مرور سریع به صورت JavaScript (.js)', fn: function () { exportQuickTable(getQuickWords(), 'js'); } },
    { icon: 'layers', label: 'مرور فلش‌کارت لغات', fn: function () { reviewStart(dueWords().length ? 'due' : 'all'); } },
    '-'
  ] : S.libTab === 'notes' ? [
    { icon: 'notebook', label: 'تصویر زمینه مطالعه (دفترچه خط‌دار)', fn: function () { openPageBgPicker(); } },
    { icon: 'pdf', label: 'ارسال یادداشت‌ها به صورت PDF', fn: function () { exportNotesList(getFilteredNotes(), 'pdf'); } },
    { icon: 'word', label: 'ارسال یادداشت‌ها به صورت Word', fn: function () { exportNotesList(getFilteredNotes(), 'word'); } },
    { icon: 'md', label: 'ارسال یادداشت‌ها به صورت Markdown (.md)', fn: function () { exportNotesList(getFilteredNotes(), 'md'); } },
    { icon: 'js', label: 'ارسال یادداشت‌ها به صورت JavaScript (.js)', fn: function () { exportNotesList(getFilteredNotes(), 'js'); } },
    { icon: 'speaker', label: 'خوانش صوتی همه‌ی یادداشت‌ها', fn: function () { var items = getFilteredNotes(); if (items.length) speakNotesList(items, items[0].id); else toast('یادداشتی نیست'); } },
    { icon: 'folder', label: 'مدیریت دسته‌بندی‌های یادداشت', fn: manageNoteCats },
    { icon: 'share', label: 'اشتراک‌گذاری متنی یادداشت‌ها', fn: shareNotes },
    '-'
  ] : [
    { icon: 'upload', label: 'بارگذاری فایل Word / PDF / EPUB به عنوان کتاب…', fn: function () { openImportDocFlow(null); } },
    { icon: 'clock', label: 'آمار مطالعه‌ی روزانه و تایمر پومودورو', fn: openStudyStatsAndTimer },
    { icon: 'share', label: 'بخش اشتراک‌گذاری کتاب‌ها و صفحات (PDF / Word / MD / JS)…', fn: function () { openBookPageShareSheet(null, null); } },
    { icon: 'folder', label: 'ذخیره دستی کتاب‌ها در بخش‌ها (انگلیسی، فارسی و...)', fn: openBulkBookSectionManager },
    { icon: 'notebook', label: 'تصویر زمینه مطالعه (دفترچه خط‌دار)', fn: function () { openPageBgPicker(); } },
    { icon: 'pdf', label: 'ارسال کتاب‌ها به صورت PDF', fn: function () { exportAllBooksFlow('pdf'); } },
    { icon: 'word', label: 'ارسال کتاب‌ها به صورت Word', fn: function () { exportAllBooksFlow('word'); } },
    { icon: 'md', label: 'ارسال کتاب‌ها به صورت Markdown (.md)', fn: function () { exportAllBooksFlow('md'); } },
    { icon: 'js', label: 'ارسال کتاب‌ها به صورت JavaScript (.js)', fn: function () { exportAllBooksFlow('js'); } },
    '-'
  ];
  menu($('#libMore'), tabItems.concat([
    { icon: 'layout', label: 'تنظیمات، اندازه فونت (۸ تا ۳۵) و ظاهر', fn: function () { openSettings('font'); } },
    { icon: 'book', label: 'راهنمای برنامه (در تنظیمات)', fn: function () { openSettings('guide'); } },
    { icon: 'speaker', label: 'تنظیمات خوانش صوتی', fn: openTtsSettings },
    { icon: 'globe', label: 'پیشنهاد معنی از اینترنت: ' + (S.data.settings.net ? 'روشن' : 'خاموش'), fn: netToggle },
    { icon: 'download', label: 'پشتیبان‌گیری (ذخیره فایل)', fn: doBackup },
    { icon: 'upload', label: 'بازیابی / وارد کردن فایل (.json / .md / .js)', fn: doRestore },
    '-',
    { icon: 'info', label: 'درباره‌ی برنامه', fn: openAbout }
  ]));
}
function readerMenu() {
  var b = curBook(); if (!b) return;
  var hasPage = S.index < b.pages.length;
  var bMeta = getBookSectionMeta(getBookEffLang(b));
  var items = [];
  items.push({ icon: 'translate', label: 'افزونه ترجمه کتاب (ترجمه کامل / دوزبانه خط‌به‌خط)', fn: function () { openTrBar(true); } });
  if (hasPage && b.trMode && b.trMode !== 'off') items.push({ icon: 'copy', label: 'کپی ترجمه / دوزبانه این صفحه', fn: copyCurrentTranslation });
  items.push({ icon: 'pdf', label: 'خروجی PDF / Word / MD از نسخه‌ی ترجمه‌شده یا دوزبانه…', fn: function () { openTranslatedExportSheet(b); } });
  items.push({ icon: 'clock', label: 'آمار مطالعه و تایمر تمرکز (پومودورو)', fn: openStudyStatsAndTimer });
  items.push({ icon: 'upload', label: 'بارگذاری فایل Word / PDF / EPUB به این کتاب…', fn: function () { openImportDocFlow(b); } });
  items.push({ icon: 'search', label: 'جستجو در متن این کتاب…', fn: openSearch });
  items.push({ icon: 'mark', label: 'فهرست هایلایت‌ها و یادداشت‌های کتاب', fn: openHighlights });
  items.push({ icon: 'maximize', label: S.immersive ? 'خروج از حالت مطالعه تمام‌صفحه' : 'حالت مطالعه تمام‌صفحه (تمرکز)', fn: toggleImmersive });
  items.push({ icon: 'share', label: 'بخش اشتراک‌گذاری کتاب و صفحات (PDF / Word / MD / JS)…', fn: function () { openBookPageShareSheet(b, hasPage ? S.index : null); } });
  items.push('-');
  items.push({ icon: 'folder', label: 'ذخیره دستی در بخش (فعلی: کتاب‌های ' + bMeta.name + ')', fn: function () { openBookSectionPicker(b); } });
  items.push({ icon: 'notebook', label: 'تصویر زمینه دفترچه (' + findPageBg(S.data.settings.pageBg).name + ')', fn: function () { openPageBgPicker(); } });
  if (b.pages.length) items.push({ icon: 'speaker', label: hasPage ? 'خواندن از این صفحه' : 'خواندن کتاب از ابتدا', fn: function () { ttsBegin(hasPage ? S.index : 0, null); } });
  if (hasPage && S.index > 0) items.push({ icon: 'speaker', label: 'خواندن کتاب از ابتدا', fn: function () { ttsBegin(0, null); } });
  if (hasPage) items.push({ icon: 'edit', label: 'ویرایش این صفحه', fn: editPageFlow });
  items.push({ icon: 'plus', label: 'افزودن صفحه پس از این', fn: function () { addPageFlow(hasPage ? S.index : null); } });
  if (hasPage) items.push({ icon: 'hash', label: 'رفتن به شماره‌ی صفحه…', fn: gotoDialog });
  items.push('-');
  if (hasPage) items.push({ icon: 'pdf', label: 'ارسال این صفحه به صورت PDF (.pdf)', fn: function () { exportBook(b, 'pdf', S.index); } });
  if (hasPage) items.push({ icon: 'word', label: 'ارسال این صفحه به صورت Word (.docx)', fn: function () { exportBook(b, 'word', S.index); } });
  if (hasPage) items.push({ icon: 'md', label: 'ارسال این صفحه به صورت Markdown (.md)', fn: function () { exportBook(b, 'md', S.index); } });
  if (hasPage) items.push({ icon: 'js', label: 'ارسال این صفحه به صورت JavaScript (.js)', fn: function () { exportBook(b, 'js', S.index); } });
  items.push('-');
  items.push({ icon: 'pdf', label: 'ارسال کل کتاب به صورت PDF (.pdf)', fn: function () { exportBook(b, 'pdf'); } });
  items.push({ icon: 'word', label: 'ارسال کل کتاب به صورت Word (.docx)', fn: function () { exportBook(b, 'word'); } });
  items.push({ icon: 'md', label: 'ارسال کل کتاب به صورت Markdown (.md)', fn: function () { exportBook(b, 'md'); } });
  items.push({ icon: 'js', label: 'ارسال کل کتاب به صورت JavaScript (.js)', fn: function () { exportBook(b, 'js'); } });
  if (hasPage) items.push({ icon: 'share', label: 'اشتراک‌گذاری متنی این صفحه', fn: function () { shareText(b.pages[S.index].text, b.title + ' - صفحه ' + fa(S.index + 1)); } });
  items.push({ icon: 'layout', label: 'تنظیمات، اندازه فونت (۸ تا ۳۵) و ظاهر', fn: function () { openSettings('font'); } });
  items.push({ icon: 'book', label: 'راهنمای برنامه (در تنظیمات)', fn: function () { openSettings('guide'); } });
  items.push({ icon: 'speaker', label: 'تنظیمات خوانش صوتی', fn: openTtsSettings });
  items.push({ icon: 'image', label: 'ویرایش نام، بخش و عکس کتاب', fn: function () { bookFormFlow(b); } });
  items.push('-');
  if (hasPage) items.push({ icon: 'trash', label: 'حذف این صفحه', danger: true, fn: function () { deletePageFlow(S.index); } });
  items.push({ icon: 'trash', label: 'حذف کتاب', danger: true, fn: function () { deleteBookFlow(b); } });
  menu($('#rdMore'), items);
}
function showWhatsNew() {
  dialog({ title: 'تازه‌های نسخه‌ی ۲٫۷ کتابچه',
    message: '• انتخاب سبک ترجمه (تخصصی و رسمی / عامیانه و روان / استاندارد) در افزونه‌ی ترجمه کتاب.\n• خروجی PDF، Word و Markdown از نسخه‌ی ترجمه‌شده یا دوزبانه خط‌به‌خط (تک‌صفحه یا کل کتاب).\n• ویرایش دستی ترجمه‌ی هر خط با یک لمس روی آیکون مداد کنار همان خط.\n• معنی فوری با دو بار لمس روی هر کلمه در متن کتاب همراه با تلفظ صوتی و افزودن سریع به لغات.\n• پشتیبانی از بارگذاری کتاب‌های الکترونیکی EPUB (.epub) و تب جدید «فصل‌ها» در فهرست صفحه‌ها.\n• داشبورد آمار مطالعه‌ی روزانه و تایمر تمرکز (پومودورو) روی صفحه‌ی کتاب.',
    ok: 'عالیه!', noCancel: true });
}
function faDigits(s) { return String(s).replace(/\d/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'.charAt(+d); }); }   // بدون جداکننده‌ی هزارگان
var CREATOR_GMAIL = 'law.dehghani.tehran@gmail.com';
function openAbout() {
  sheet('درباره‌ی برنامه', function (body) {
    body.appendChild(h('div', { class: 'row maker about-maker-card' }, [h('div', { class: 'grow' }, [
      h('div', { class: 't', text: 'سازنده امیر دهقانی' }),
      h('div', { class: 'd maker-role', text: 'وکیل پایه یک دادگستری عضو کانون وکلای دادگستری مرکز' }),
      h('div', { class: 'd', style: 'white-space:pre-line;margin-top:6px', text: 'شماره پروانه: ' + faDigits('29230') + '\nشماره تماس: ' + faDigits('09120602738') + '\nجیمیل: ' + CREATOR_GMAIL }),
      h('div', { class: 'about-collab-box' }, [
        h('p', { text: 'همراهان گرامی می‌توانند با ارسال نظرات خود به جیمیل معرفی شده با سازنده در جهت بروزرسانی اپلیکیشن همکاری نمایند.' }),
        h('div', { class: 'about-gmail-badge', dir: 'ltr', text: CREATOR_GMAIL })
      ])
    ])]));

    var mailActs = h('div', { class: 'about-acts-grid' });
    var sendMailB = h('button', { class: 'btn pri', id: 'abSendMail', type: 'button', html: ic('share', 18) + '<span>ارسال نظر به جیمیل سازنده</span>' });
    sendMailB.addEventListener('click', function () {
      openExternal('mailto:' + CREATOR_GMAIL + '?subject=' + encodeURIComponent('نظرات و پیشنهادهای بروزرسانی اپلیکیشن کتابچه'));
    });
    var copyMailB = h('button', { class: 'btn', id: 'abCopyMail', type: 'button', html: ic('copy', 18) + '<span>کپی آدرس جیمیل</span>' });
    copyMailB.addEventListener('click', function () { copyText(CREATOR_GMAIL); });
    var callB = h('button', { class: 'btn', id: 'abCopyTel', type: 'button', html: ic('copy', 18) + '<span>کپی شماره تماس</span>' });
    callB.addEventListener('click', function () { copyText('09120602738'); });
    mailActs.appendChild(sendMailB);
    mailActs.appendChild(copyMailB);
    mailActs.appendChild(callB);
    body.appendChild(mailActs);

    body.appendChild(h('div', { class: 'row' }, [h('div', { class: 'grow' }, [
      h('div', { class: 't', text: 'کتابچه — نسخه‌ی ۲٫۳' }),
      h('div', { class: 'd', text: 'متن‌های دلخواه را صفحه به صفحه نگه دارید، هر کتاب را به صورت دستی در بخش کتاب‌های انگلیسی، فارسی و... ذخیره کنید، با ۱۲ رنگ هایلایت نمایید، متون چندزبانه را با صدا بشنوید، یادداشت‌هایتان را با رمز اختصاصی محافظت کنید و واژه‌ها را در بخش مرور سریع با اسکرول هوشمند مرور نمایید.' })])]));
    body.appendChild(h('div', { class: 'row' }, [h('div', { class: 'grow' }, [
      h('div', { class: 't', text: 'حریم خصوصی' }),
      h('div', { class: 'd', text: 'همه‌ی نوشته‌ها فقط روی همین گوشی ذخیره می‌شوند؛ برای اطمینان گاهی «پشتیبان‌گیری» بزنید. تنها کاری که برنامه با اینترنت می‌کند «پیشنهاد معنی» در بخش واژه‌هاست و فقط اگر اجازه بدهید: خودِ واژه به Free Dictionary، MyMemory و ویکی‌واژه فرستاده می‌شود و هیچ چیز دیگری نه. از منوی صفحه‌ی اصلی می‌توانید خاموشش کنید.' })])]));
    body.appendChild(h('div', { class: 'row' }, [h('div', { class: 'grow' }, [
      h('div', { class: 't', text: 'قلم' }),
      h('div', { class: 'd', text: 'وزیرمتن (فارسی)، Inter، Instrument Sans، Poppins، Carlito، Lora، Crimson Pro، IBM Plex Serif، Libre Baskerville، Caladea، TeX Gyre Pagella، JetBrains Mono، Nothing You Could Do، و برای فارسی FreeSerif و DejaVu Sans — همه با مجوز آزاد (بیشترشان SIL OFL). فقط بخش لازم هر قلم در برنامه گذاشته شده است.' })])]));
  });
}

/* =====================================================================
   راهنمای اولیه (فقط بار اول)
   ===================================================================== */
function seedGuide() {
  var now = Date.now();
  var pages = [
    'به «کتابچه» خوش آمدید.\n\nاینجا می‌توانید هر متنی را که دوست دارید صفحه به صفحه نگه دارید و مثل یک کتاب ورق بزنید.\n\nبرای رفتن به صفحه‌ی بعد، انگشتتان را روی صفحه از چپ به راست بکشید (مثل ورق‌زدن کتاب فارسی). برای برگشتن، برعکس. لبه‌های چپ و راست صفحه و دکمه‌های پایین هم همین کار را می‌کنند.',
    'هایلایت کردن\n\nچند لحظه انگشتتان را روی یک کلمه نگه دارید تا انتخاب شود، با دستگیره‌ها محدوده‌ی دلخواه را مشخص کنید و بعد یکی از ۱۲ رنگ را بزنید.\n\nاین جمله یک نمونه‌ی هایلایت‌شده است. روی آن بزنید تا رنگش را عوض کنید یا پاکش کنید.\n\nهمه‌ی هایلایت‌ها از دکمه‌ی ماژیک بالای صفحه قابل مرور هستند.',
    'نوشتن و ویرایش\n\nبا دکمه‌ی + پایین صفحه، یک صفحه‌ی جدید بنویسید یا متنی را بچسبانید. اگر متن از یک صفحه بلندتر باشد، برنامه پیشنهاد می‌دهد خودکار به چند صفحه‌ی هم‌اندازه تقسیم شود. اگر در متن خطی فقط شامل --- بگذارید، از همان نقطه صفحه عوض می‌شود.\n\nبا دکمه‌ی مداد، متن همین صفحه را ویرایش کنید؛ هایلایت‌ها تا جای ممکن سر جایشان می‌مانند.\n\nاز بالای صفحه می‌توانید فهرست صفحه‌ها (و جابه‌جا کردن آن‌ها) و جستجو را باز کنید.',
    'خواندن با صدا و عکس کتاب\n\nبا دکمه‌ی بلندگو در نوار پایین، کتاب از همین صفحه خوانده می‌شود؛ متن‌های عربی، انگلیسی و فرانسوی خوانده می‌شوند (بخش‌های فارسی رد می‌شوند) و جمله‌ی در حال خواندن علامت می‌خورد. اگر متنی را انتخاب کرده باشید، دکمه‌ی بلندگوی نوار رنگ‌ها از همان‌جا شروع می‌کند.\n\nاز منوی سه‌نقطه‌ی هر کتاب در صفحه‌ی اصلی، «ویرایش نام و عکس کتاب» را بزنید تا یک عکس برای جلد کتاب بگذارید.',
    'ذخیره‌ی واژه‌های سخت\n\nکلمه‌ی ناآشنا را انتخاب کنید و دکمه‌ی «ذخیره‌ی واژه» (آیکن کتاب با حرف A) را در نوار رنگ‌ها بزنید تا فقط خودِ واژه و معنی آن ذخیره شود.\n\nبرای معنی، دکمه‌ی «پیشنهاد معنی» ترجمه و تعریف را از اینترنت می‌آورد (فقط خودِ واژه فرستاده می‌شود)؛ روی هر پیشنهاد بزنید تا اضافه شود و بعد ویرایشش کنید. یا با «جستجوی معنی در مرورگر گوشی» خودتان در مرورگر ببینید و معنی را بنویسید یا بچسبانید.\n\nهمه‌ی واژه‌ها در صفحه‌ی اصلی، تب «واژه‌ها» جمع هستند. آنجا با «شروع مرور» کارت‌ها را سر فرصت مرور کنید؛ واژه‌هایی که بلدید دیرتر دوباره می‌آیند.',
    'نگهداری از نوشته‌ها\n\nهمه‌چیز فقط روی همین گوشی ذخیره می‌شود؛ اینترنت فقط برای «پیشنهاد معنی» واژه‌ها به کار می‌رود.\n\nبرای اینکه نوشته‌هایتان هرگز از بین نرود، از صفحه‌ی اصلی (منوی سه‌نقطه) «پشتیبان‌گیری» را بزنید؛ یک فایل در پوشه‌ی Downloads ذخیره می‌شود و بعداً با «بازیابی» برمی‌گردد (واژه‌ها هم در آن هستند).\n\nظاهر کتاب: از منوی سه‌نقطه «ظاهر و قلم» را بزنید تا پوسته، قلم فارسی و انگلیسی، اندازه و فاصله‌ی خطوط را عوض کنید.\n\nاین کتاب راهنما را هر وقت خواستید حذف کنید.'
  ].map(function (t) { return { id: uid(), text: t, created: now, updated: now, hl: [] }; });
  // هایلایت نمونه در صفحه‌ی دوم
  var t2 = pages[1].text, key = 'این جمله یک نمونه‌ی هایلایت‌شده است.', at = t2.indexOf(key);
  if (at >= 0) pages[1].hl.push({ id: uid(), s: at, e: at + key.length, c: 'y' });
  var k2 = 'یکی از ۱۲ رنگ', a2 = t2.indexOf(k2);
  if (a2 >= 0) pages[1].hl.push({ id: uid(), s: a2, e: a2 + k2.length, c: 'g' });
  pages[1].hl.sort(function (a, b) { return a.s - b.s; });
  S.data.books.push({ id: uid(), title: 'راهنمای کتابچه', lg: 'fa', color: 1, created: now, updated: now, last: 0, pages: pages });
  [
    { title: 'English Reading & Stories', lg: 'en', color: 2, text: 'Welcome to the English section of Ketabche.\n\nSelect any unfamiliar word to save it directly into your English vocabulary section or listen with text-to-speech.\n\nResilience and curiosity open new doors every day.' },
    { title: 'Lectures en Français', lg: 'fr', color: 5, text: 'Bienvenue dans la section française de Ketabche.\n\nIci vous pouvez lire vos textes en français, surligner les phrases importantes et enregistrer chaque mot dans la section française.\n\nChaque papillon apporte la lumière et l’espoir.' },
    { title: 'Deutsche Texte & Lesen', lg: 'de', color: 3, text: 'Willkommen im deutschen Bereich von Ketabche.\n\nLesen Sie deutsche Bücher Seite für Seite, hören Sie die Aussprache und speichern Sie neue Wörter getrennt nach Sprache.' },
    { title: 'نصوص ومطالعات عربية', lg: 'ar', color: 4, text: 'مرحباً بكم في قسم الكتب العربية في برنامج كتابچه.\n\nيمكنكم قراءة النصوص العربية صفحة بصفحة، والاستماع إلى النطق الصوتي، وحفظ المفردات في القسم الخاص باللغة العربية.' },
    { title: 'Türkçe Okuma Kitabı', lg: 'tr', color: 0, text: 'Ketabche Türkçe kitap bölümüne hoş geldiniz.\n\nTürkçe metinlerinizi sayfa sayfa okuyabilir, sesli dinleyebilir ve kelimeleri Türkçe bölümünde ayrı olarak kaydedip tekrar edebilirsiniz.' }
  ].forEach(function (sb, sIdx) {
    var t = now - (sIdx + 1) * 2000;
    S.data.books.push({
      id: uid(),
      title: sb.title,
      lg: sb.lg,
      color: sb.color,
      created: t,
      updated: t,
      last: 0,
      pages: [{ id: uid(), text: sb.text, created: t, updated: t, hl: [] }]
    });
  });
  if (!S.data.words.length) {
    [
      { w: 'Resilience', m: 'تاب‌آوری، استقامت و انعطاف‌پذیری', lg: 'en' },
      { w: 'Eloquent', m: 'شیوا، بلیغ و خوش‌بیان', lg: 'en' },
      { w: 'Serendipity', m: 'یافتنِ اتفاقیِ چیزهای خوب و ارزشمند', lg: 'en' },
      { w: 'Papillon', m: 'پروانه (واژه‌ی فرانسوی)', lg: 'fr' },
      { w: 'Lumière', m: 'نور، روشنایی (واژه‌ی فرانسوی)', lg: 'fr' },
      { w: 'Espoir', m: 'امید، آرزو (واژه‌ی فرانسوی)', lg: 'fr' },
      { w: 'Kelebek', m: 'پروانه (واژه‌ی ترکی استانبولی)', lg: 'tr' },
      { w: 'Umut', m: 'امید (واژه‌ی ترکی استانبولی)', lg: 'tr' },
      { w: 'Özgürlük', m: 'آزادی، رهایی (واژه‌ی ترکی استانبولی)', lg: 'tr' },
      { w: 'Fernweh', m: 'دل‌تنگی برای سفر به جاهای دوردست (آلمانی)', lg: 'de' },
      { w: 'Zeitgeist', m: 'روحِ زمانه (آلمانی)', lg: 'de' },
      { w: 'البصيرة', m: 'بینش عمیق، دانایی و روشن‌بینی (عربی)', lg: 'ar' },
      { w: 'السكينة', m: 'آرامش و قرارِ دل (عربی)', lg: 'ar' },
      { w: 'فرهیختگی', m: 'ادب، دانش، والایی و تربیت‌یافتگی (فارسی)', lg: 'fa' }
    ].forEach(function (item, idx) {
      var wObj = newWord({ w: item.w, m: item.m, lg: item.lg, bk: 'راهنمای کتابچه', pg: 5 });
      wObj.created = now - idx * 1000;
      wObj.updated = wObj.created;
      S.data.words.push(wObj);
    });
  }
  if (!S.data.notes.length) {
    S.data.notes.push({
      id: uid(),
      title: 'راهنمای امکانات ویژه کتابچه',
      text: '• اسکرول دستی و خودکار منحصراً در بخش «مرور سریع» فعال است و سایر بخش‌ها (کتاب‌ها، لغات و یادداشت‌ها) بدون اسکرول و به صورت صفحه‌ای هستند.\n• در بخش کتاب‌ها می‌توانید هر کتاب را دستی در بخش کتاب‌های انگلیسی، فارسی، فرانسوی، آلمانی، عربی یا ترکی ذخیره کنید.\n• در بخش تنظیمات می‌توانید اندازه فونت کلمات را از ۸ تا ۳۵ تنظیم کرده و راهنمای کامل برنامه را مطالعه نمایید.',
      cat: 'مطالعه',
      color: 'b',
      pinned: true,
      archived: false,
      locked: false,
      pwdHash: '',
      pwdSalt: '',
      cipher: '',
      bid: '',
      bk: 'راهنمای کتابچه',
      pg: 1,
      created: now,
      updated: now
    });
  }
  S.data.nextCover = 2;
  S.data.seeded = true;
  S.data.seenVer = 11;
}

/* =====================================================================
   واژه‌ها: ذخیره‌ی کلمه‌های سخت با معنی، جمله‌ی نمونه و مرور
   ===================================================================== */
var DAY_MS = 86400000;
var BOX_DAYS = [0, 1, 3, 7, 14, 30];
var bLangFilter = 'all', nLangFilter = 'all';
var wFilter = 'all', wQuery = '', wLangFilter = 'all';
var qLangFilter = 'all', qActiveWid = null, qWalkTimer = null;
var bPageIdx = 0, wPageIdx = 0, nPageIdx = 0;
var BOOKS_PER_PAGE = 20, WORDS_PER_PAGE = 100, NOTES_PER_PAGE = 20;

/* ---------- زبان‌های مجزای برنامه برای تفکیک کامل کتاب‌ها، لغات، مرور سریع و یادداشت‌ها ---------- */
var APP_LANGS = ['en', 'fa', 'fr', 'de', 'ar', 'tr'];
var LANG_META = {
  en: { id: 'en', name: 'انگلیسی', short: 'انگلیسی', badge: 'EN', color: '#2563eb' },
  fa: { id: 'fa', name: 'فارسی', short: 'فارسی', badge: 'FA', color: '#0d9488' },
  fr: { id: 'fr', name: 'فرانسوی', short: 'فرانسوی', badge: 'FR', color: '#7c3aed' },
  de: { id: 'de', name: 'آلمانی', short: 'آلمانی', badge: 'DE', color: '#d97706' },
  ar: { id: 'ar', name: 'عربی', short: 'عربی', badge: 'AR', color: '#059669' },
  tr: { id: 'tr', name: 'ترکی استانبولی', short: 'ترکی', badge: 'TR', color: '#dc2626' }
};

function getAllBookSections() {
  var list = [
    { id: 'en', name: 'انگلیسی', short: 'انگلیسی', badge: 'EN', color: '#2563eb' },
    { id: 'fa', name: 'فارسی', short: 'فارسی', badge: 'FA', color: '#0d9488' },
    { id: 'fr', name: 'فرانسوی', short: 'فرانسوی', badge: 'FR', color: '#7c3aed' },
    { id: 'de', name: 'آلمانی', short: 'آلمانی', badge: 'DE', color: '#d97706' },
    { id: 'ar', name: 'عربی', short: 'عربی', badge: 'AR', color: '#059669' },
    { id: 'tr', name: 'ترکی استانبولی', short: 'ترکی', badge: 'TR', color: '#dc2626' }
  ];
  var custom = (S.data && Array.isArray(S.data.bookCats)) ? S.data.bookCats : [];
  custom.forEach(function (c) {
    if (c && c.id && !list.some(function (x) { return x.id === c.id; })) {
      list.push({
        id: c.id,
        name: c.name,
        short: c.name,
        badge: c.badge || 'BK',
        color: c.color || '#6366f1',
        custom: true
      });
    }
  });
  return list;
}

function getBookSectionMeta(secId) {
  if (LANG_META[secId]) return LANG_META[secId];
  var all = getAllBookSections();
  for (var i = 0; i < all.length; i++) {
    if (all[i].id === secId) return all[i];
  }
  return LANG_META.fa;
}

function promptAddCustomBookSection(cb) {
  dialog({
    title: 'افزودن بخش جدید کتاب‌ها',
    message: 'نام بخش جدید (مثلاً: اسپانیایی، حقوقی، ادبیات، علمی و...) را بنویسید تا بتوانید کتاب‌ها را دستی در آن ذخیره کنید:',
    input: true,
    ok: 'ساخت بخش',
    max: 35
  }).then(function (val) {
    if (!val) return;
    var name = String(val).replace(/\s+/g, ' ').trim();
    if (!name) return;
    if (!S.data.bookCats) S.data.bookCats = [];
    var existing = getAllBookSections().filter(function (s) { return s.name === name; })[0];
    if (existing) {
      if (cb) cb(existing.id);
      return;
    }
    var newId = 'sec_' + uid().slice(0, 6);
    var palette = ['#6366f1', '#ec4899', '#0891b2', '#84cc16', '#f97316', '#8b5cf6'];
    var col = palette[S.data.bookCats.length % palette.length];
    var badge = name.slice(0, 2).toUpperCase();
    S.data.bookCats.push({ id: newId, name: name, badge: badge, color: col });
    scheduleSave();
    toast('بخش «کتاب‌های ' + name + '» اضافه شد');
    if (cb) cb(newId);
  });
}

function assignBookToSection(bk, secId, silent) {
  if (!bk || !secId) return;
  bk.lg = secId;
  bk.updated = Date.now();
  scheduleSave();
  flushSave();
  var meta = getBookSectionMeta(secId);
  if (!silent) {
    toast('کتاب «' + bk.title + '» در بخش «کتاب‌های ' + meta.name + '» ذخیره شد');
  }
  if (S.view === 'library' && S.libTab === 'books') renderLibrary();
  if (S.view === 'reader') updateBars();
  updateTopTabLabels();
}

function openBookSectionPicker(bk, onDone) {
  if (!bk) return;
  var curSec = getBookEffLang(bk);
  sheet('ذخیره‌ی دستی کتاب در بخش مورد نظر', function (body) {
    body.appendChild(h('div', { class: 'bk-sec-sheet-intro' }, [
      h('b', { text: 'کتاب: «' + bk.title + '»' }),
      h('span', { text: 'بخش مورد نظر را انتخاب کنید تا این کتاب به صورت دستی در همان بخش ذخیره شود:' })
    ]));
    var grid = h('div', { class: 'bk-sec-picker-grid' });
    function renderChoices() {
      grid.textContent = '';
      getAllBookSections().forEach(function (sec) {
        var isOn = curSec === sec.id;
        var count = booksByLang(sec.id).length;
        var btn = h('button', {
          class: 'bk-sec-choice' + (isOn ? ' on' : ''),
          type: 'button',
          style: '--lang-clr:' + sec.color
        }, [
          h('span', { class: 'lang-pill-badge', style: '--lang-clr:' + sec.color, text: sec.badge }),
          h('div', { class: 'bk-sec-choice-txt' }, [
            h('b', { text: 'بخش کتاب‌های ' + sec.name }),
            h('small', { text: fa(count) + ' کتاب در این بخش' + (isOn ? ' · بخش فعلی این کتاب' : '') })
          ]),
          h('span', { class: 'bk-sec-chk', html: isOn ? ic('check', 16) : '' })
        ]);
        btn.addEventListener('click', function () {
          curSec = sec.id;
          assignBookToSection(bk, sec.id);
          var topLayer = layers[layers.length - 1];
          if (topLayer) topLayer.close(true);
          if (onDone) onDone(sec.id);
        });
        grid.appendChild(btn);
      });
      var addSecBtn = h('button', { class: 'bk-sec-choice add-new', type: 'button' }, [
        h('span', { class: 'lang-pill-badge', style: '--lang-clr:var(--accent)', html: ic('plus', 16) }),
        h('div', { class: 'bk-sec-choice-txt' }, [
          h('b', { text: 'افزودن بخش جدید (سایر زبان‌ها یا موضوعات...)' }),
          h('small', { text: 'ساخت بخش دلخواه و ذخیره‌ی کتاب در آن' })
        ])
      ]);
      addSecBtn.addEventListener('click', function () {
        promptAddCustomBookSection(function (newId) {
          curSec = newId;
          assignBookToSection(bk, newId);
          var topLayer = layers[layers.length - 1];
          if (topLayer) topLayer.close(true);
          if (onDone) onDone(newId);
        });
      });
      grid.appendChild(addSecBtn);
    }
    renderChoices();
    body.appendChild(grid);
  });
}

function openBulkBookSectionManager() {
  sheet('ذخیره‌ی دستی کتاب‌ها در بخش‌ها (انگلیسی، فارسی و...)', function (body) {
    body.appendChild(h('div', { class: 'bk-sec-sheet-intro' }, [
      h('b', { text: 'مدیریت و تعیین دستی بخش هر کتاب' }),
      h('span', { text: 'در مقابل هر کتاب، بخش مورد نظر (انگلیسی، فارسی، فرانسوی، آلمانی، عربی، ترکی و...) را لمس کنید تا کتاب در آن بخش ذخیره شود:' })
    ]));
    var addSecRow = h('div', { style: 'display:flex;justify-content:flex-end;margin-bottom:10px' });
    var newSecB = h('button', { class: 'btn sm', type: 'button', html: ic('plus', 15) + '<span>افزودن بخش جدید...</span>' });
    addSecRow.appendChild(newSecB);
    body.appendChild(addSecRow);

    var listWrap = h('div', { class: 'bk-bulk-list' });
    body.appendChild(listWrap);

    function drawList() {
      listWrap.textContent = '';
      var allB = S.data.books.slice().sort(function (a, b) { return b.updated - a.updated; });
      if (!allB.length) {
        listWrap.appendChild(h('div', { class: 'empty-note', text: 'هنوز کتابی ساخته نشده است.' }));
        return;
      }
      var secs = getAllBookSections();
      allB.forEach(function (bk) {
        var curLg = getBookEffLang(bk);
        var chipsRow = h('div', { class: 'bk-bulk-chips' });
        secs.forEach(function (sec) {
          var on = curLg === sec.id;
          var ch = h('button', {
            class: 'chip sm' + (on ? ' on' : ''),
            type: 'button',
            text: sec.badge + ' · ' + sec.name
          });
          ch.addEventListener('click', function () {
            assignBookToSection(bk, sec.id);
            drawList();
          });
          chipsRow.appendChild(ch);
        });
        var item = h('div', { class: 'bk-bulk-item' }, [
          h('div', { class: 'bk-bulk-hdr' }, [
            h('b', { dir: 'auto', text: bk.title }),
            h('span', { class: 'bk-bulk-cur', text: 'بخش فعلی: کتاب‌های ' + getBookSectionMeta(curLg).name })
          ]),
          chipsRow
        ]);
        listWrap.appendChild(item);
      });
    }
    newSecB.addEventListener('click', function () {
      promptAddCustomBookSection(function () { drawList(); });
    });
    drawList();
  }, { tall: true });
}

/* نوار افقی یکپارچه انتخاب بخش/زبان در بالای هر چهار تب (بدون پراکندگی) */
function buildUnifiedSectionStrip(kind, activeLg, onSelectLg) {
  var items = kind === 'books' ? getAllBookSections() : APP_LANGS.map(function (k) { return LANG_META[k]; });
  var sourceArr = kind === 'books' ? S.data.books : (kind === 'notes' ? S.data.notes.filter(function (n) { return !n.archived; }) : S.data.words);
  var counts = { all: sourceArr.length };
  items.forEach(function (it) { counts[it.id] = 0; });
  sourceArr.forEach(function (x) {
    var l = kind === 'books' ? getBookEffLang(x) : (kind === 'notes' ? getNoteEffLang(x) : getWordEffLang(x));
    counts[l] = (counts[l] || 0) + 1;
  });

  var strip = h('div', { class: 'uni-sec-strip', role: 'tablist' });
  var allLabel = kind === 'books' ? 'همه کتاب‌ها' : (kind === 'notes' ? 'همه یادداشت‌ها' : 'همه زبان‌ها');
  var allBtn = h('button', {
    class: 'uni-sec-pill' + (activeLg === 'all' ? ' on' : ''),
    type: 'button'
  }, [
    h('span', { class: 'usp-code', text: 'ALL' }),
    h('span', { text: allLabel }),
    h('em', { class: 'usp-cnt', text: fa(counts.all) })
  ]);
  allBtn.addEventListener('click', function () { onSelectLg('all'); });
  strip.appendChild(allBtn);

  items.forEach(function (meta) {
    var cnt = counts[meta.id] || 0;
    var prefix = kind === 'books' ? 'کتاب‌های ' : '';
    var btn = h('button', {
      class: 'uni-sec-pill' + (activeLg === meta.id ? ' on' : ''),
      type: 'button',
      style: '--lang-clr:' + meta.color
    }, [
      h('span', { class: 'usp-code', style: 'background:' + meta.color + ';color:#fff', text: meta.badge }),
      h('span', { text: prefix + meta.short }),
      h('em', { class: 'usp-cnt', text: fa(cnt) })
    ]);
    btn.addEventListener('click', function () { onSelectLg(meta.id); });
    strip.appendChild(btn);
  });

  if (kind === 'books') {
    var addSec = h('button', { class: 'uni-sec-pill add-sec', type: 'button', title: 'افزودن بخش جدید' }, [
      h('span', { text: '+ بخش جدید' })
    ]);
    addSec.addEventListener('click', function () {
      promptAddCustomBookSection(function (newId) { onSelectLg(newId); });
    });
    strip.appendChild(addSec);
  }
  return strip;
}

/* نوار صفحه‌بندی و دکمه‌ی افزودن در پایین بخش‌های بدون اسکرول (کتاب‌ها، لغات، یادداشت‌ها) */
function buildBottomPagerDock(pageIdx, totalItems, perPage, onPageChange, unitLabel, addBtnLabel, onAddClick) {
  var totalPages = Math.max(1, Math.ceil(totalItems / perPage));
  var cur = clamp(pageIdx, 0, totalPages - 1);

  var prevBtn = h('button', {
    class: 'pager-btn',
    type: 'button',
    disabled: cur <= 0 ? 'disabled' : null,
    html: ic('prev', 15) + '<span>قبلی</span>'
  });
  var nextBtn = h('button', {
    class: 'pager-btn',
    type: 'button',
    disabled: cur >= totalPages - 1 ? 'disabled' : null,
    html: '<span>بعدی</span>' + ic('next', 15)
  });
  prevBtn.addEventListener('click', function () { if (cur > 0) onPageChange(cur - 1); });
  nextBtn.addEventListener('click', function () { if (cur < totalPages - 1) onPageChange(cur + 1); });

  var pageStatus = h('div', { class: 'pager-info' },
    totalPages > 1
      ? [
          h('b', { text: 'صفحه ' + fa(cur + 1) + ' از ' + fa(totalPages) }),
          h('small', { text: fa(totalItems) + ' ' + unitLabel })
        ]
      : [
          h('b', { text: fa(totalItems) + ' ' + unitLabel })
        ]
  );

  var pagerGroup = h('div', { class: 'pager-nav-group' },
    totalPages > 1 ? [prevBtn, pageStatus, nextBtn] : [pageStatus]
  );

  var addBtn = addBtnLabel ? h('button', {
    class: 'btn pri pager-add-btn',
    type: 'button',
    html: ic('plus', 18) + '<span>' + addBtnLabel + '</span>'
  }) : null;
  if (addBtn && onAddClick) addBtn.addEventListener('click', onAddClick);

  return h('div', { class: 'bottom-pager-dock' }, [pagerGroup, addBtn]);
}

function getWordEffLang(x) {
  if (!x) return 'en';
  if (x.lg && LANG_META[x.lg]) return x.lg;
  var detected = wordLang(String(x.w || ''), x.ex || '', '');
  if (detected && LANG_META[detected]) return detected;
  return 'en';
}

function getBookEffLang(bk) {
  if (!bk) return 'fa';
  if (bk.lg) {
    if (LANG_META[bk.lg]) return bk.lg;
    if (S.data && Array.isArray(S.data.bookCats) && S.data.bookCats.some(function (c) { return c.id === bk.lg; })) return bk.lg;
  }
  var sample = String(bk.title || '') + ' ' + (bk.pages && bk.pages[0] ? String(bk.pages[0].text || '').slice(0, 240) : '');
  var det = wordLang(sample, '', '');
  if (det && LANG_META[det]) return det;
  return 'fa';
}

function getNoteEffLang(nt) {
  if (!nt) return 'fa';
  if (nt.lg && LANG_META[nt.lg]) return nt.lg;
  var body = isNoteLocked(nt) ? '' : getNoteText(nt);
  var sample = String(nt.title || '') + ' ' + String(body || '').slice(0, 240);
  var det = wordLang(sample, '', '');
  if (det && LANG_META[det]) return det;
  return 'fa';
}

function booksByLang(langCode) {
  return S.data.books.filter(function (bk) {
    if (!langCode || langCode === 'all') return true;
    return getBookEffLang(bk) === langCode;
  });
}

function notesByLang(langCode) {
  return S.data.notes.filter(function (nt) {
    if (nt.archived && nFilter !== 'archived') return false;
    if (!langCode || langCode === 'all') return true;
    return getNoteEffLang(nt) === langCode;
  });
}

function updateTopTabLabels() {
  var bBtn = $('#tabBooks'), wBtn = $('#tabWords'), qBtn = $('#tabQuick'), nBtn = $('#tabNotes');
  if (bBtn) {
    var bMeta = bLangFilter !== 'all' ? getBookSectionMeta(bLangFilter) : null;
    var bBadge = (bLangFilter !== 'all' && bMeta) ? '<i class="tab-lg-chip">' + esc(bMeta.badge) + '</i>' : '';
    bBtn.innerHTML = '<span id="tabBooksIc">' + ic('book', 18) + '</span><span>کتاب‌ها</span>' + bBadge;
  }
  if (wBtn) {
    var wCnt = wordsByLang(wLangFilter).length;
    var wBadge = (wLangFilter !== 'all' && LANG_META[wLangFilter]) ? '<i class="tab-lg-chip">' + LANG_META[wLangFilter].badge + '</i>' : '';
    wBtn.innerHTML = '<span id="tabWordsIc">' + ic('words', 18) + '</span><span>لغات</span>' + wBadge + '<em id="wordCnt" class="cnt">' + (wCnt ? fa(wCnt) : '') + '</em>';
  }
  if (qBtn) {
    var qBadge = (qLangFilter !== 'all' && LANG_META[qLangFilter]) ? '<i class="tab-lg-chip">' + LANG_META[qLangFilter].badge + '</i>' : '';
    qBtn.innerHTML = '<span id="tabQuickIc">' + ic('layers', 18) + '</span><span>مرور سریع</span>' + qBadge;
  }
  if (nBtn) {
    var nCnt = notesByLang(nLangFilter).length;
    var nBadge = (nLangFilter !== 'all' && LANG_META[nLangFilter]) ? '<i class="tab-lg-chip">' + LANG_META[nLangFilter].badge + '</i>' : '';
    nBtn.innerHTML = '<span id="tabNotesIc">' + ic('note', 18) + '</span><span>یادداشت‌ها</span>' + nBadge + '<em id="noteCnt" class="cnt">' + (nCnt ? fa(nCnt) : '') + '</em>';
  }
}

/* باز شدن لیست زبان‌ها (فارسی، انگلیسی، فرانسوی، آلمانی، عربی، ترکی استانبولی) هنگام کلیک روی تب‌های اصلی بالای صفحه */
function openTabLangMenu(tab, anchorEl) {
  var curLg = tab === 'books' ? bLangFilter : tab === 'words' ? wLangFilter : tab === 'quick' ? qLangFilter : nLangFilter;
  var secPrefix = tab === 'books' ? 'کتاب‌های ' : tab === 'words' ? 'لغات ' : tab === 'quick' ? 'مرور سریع ' : 'یادداشت‌های ';
  var allLabel = tab === 'books' ? 'همه‌ی کتاب‌ها (همه زبان‌ها)' : tab === 'words' ? 'همه‌ی لغات (به تفکیک زبان)' : tab === 'quick' ? 'مرور سریع همه‌ی زبان‌ها' : 'همه‌ی یادداشت‌ها (همه زبان‌ها)';
  var hdrText = tab === 'books' ? 'انتخاب زبان کتاب‌ها:' : tab === 'words' ? 'انتخاب زبان فهرست لغات:' : tab === 'quick' ? 'انتخاب زبان مرور سریع:' : 'انتخاب زبان یادداشت‌ها:';

  function countFor(lk) {
    if (tab === 'books') return booksByLang(lk).length;
    if (tab === 'words' || tab === 'quick') return wordsByLang(lk).length;
    return notesByLang(lk).length;
  }

  function applyLang(lk) {
    if (tab === 'books') bLangFilter = lk;
    else if (tab === 'words') wLangFilter = lk;
    else if (tab === 'quick') qLangFilter = lk;
    else if (tab === 'notes') nLangFilter = lk;
    setLibTab(tab);
  }

  var dim = h('div', { class: 'dim', style: 'background:rgba(0,0,0,0.12);animation:none' });
  var m = h('div', { class: 'tab-lang-menu', role: 'menu' });
  m.appendChild(h('div', { class: 'tlm-hdr', text: hdrText }));

  APP_LANGS.forEach(function (lk) {
    var meta = LANG_META[lk];
    var cnt = countFor(lk);
    var isOn = curLg === lk;
    var btn = h('button', { class: 'tlm-item' + (isOn ? ' on' : ''), type: 'button', role: 'menuitem' }, [
      h('div', { class: 'tlm-left' }, [
        h('span', { class: 'lang-pill-badge', style: '--lang-clr:' + meta.color + ';min-width:30px;height:24px;font-size:11px', text: meta.badge }),
        h('span', { text: secPrefix + meta.name })
      ]),
      h('div', { class: 'tlm-right' }, [
        h('span', { class: 'tlm-cnt', text: fa(cnt) }),
        isOn ? h('span', { class: 'tlm-chk', text: '✓' }) : null
      ])
    ]);
    btn.addEventListener('click', function () {
      L.close(true);
      applyLang(lk);
    });
    m.appendChild(btn);
  });

  m.appendChild(h('hr', { style: 'border:0;border-top:1px solid var(--line);margin:4px 6px' }));
  var totalCnt = countFor('all');
  var allOn = curLg === 'all';
  var allBtn = h('button', { class: 'tlm-item' + (allOn ? ' on' : ''), type: 'button', role: 'menuitem' }, [
    h('div', { class: 'tlm-left' }, [
      h('span', { class: 'lang-pill-badge', style: '--lang-clr:var(--accent);min-width:30px;height:24px;font-size:10.5px', text: 'ALL' }),
      h('span', { text: allLabel })
    ]),
    h('div', { class: 'tlm-right' }, [
      h('span', { class: 'tlm-cnt', text: fa(totalCnt) }),
      allOn ? h('span', { class: 'tlm-chk', text: '✓' }) : null
    ])
  ]);
  allBtn.addEventListener('click', function () {
    L.close(true);
    applyLang('all');
  });
  m.appendChild(allBtn);

  var L = openLayer(h('div', { class: 'layer' }, [dim, m]));
  dim.addEventListener('click', function () { L.close(true); });

  if (anchorEl) {
    var r = anchorEl.getBoundingClientRect(), W = window.innerWidth, H = window.innerHeight;
    var mw = m.offsetWidth || 256, mh = m.offsetHeight || 340;
    var left = clamp(r.left + (r.width / 2) - (mw / 2), 10, W - mw - 10);
    var top = r.bottom + 6;
    if (top + mh > H - 10) top = Math.max(10, H - mh - 10);
    m.style.left = left + 'px';
    m.style.top = top + 'px';
  }
  return L;
}

/* =====================================================================
   موتور اسکرول دستی و خودکار (به بالا و پایین) در تمامی بخش‌ها
   (کتاب‌ها، صفحه‌ی خواندن کتاب، لغات، مرور سریع، یادداشت‌ها و مطالعه‌ی یادداشت)
   ===================================================================== */
var AUTO_SPEEDS = [0.5, 1, 1.5, 2, 3, 4];
var AutoScroll = {
  active: false,
  dir: 1,          // 1 = به پایین، -1 = به بالا
  raf: 0,
  lastTs: 0,
  subPx: 0,
  holdRaf: 0,
  holdDir: 0,
  pageTurnWait: 0,
  collapsed: false,
  pos: null,         // موقعیت اعشاری اسکرول خودکار (scrollTop فقط عدد گردشده برمی‌گرداند)
  resumeAt: 0,       // تا این لحظه اسکرول خودکار صبر می‌کند (بعد از لمس/فلینگ کاربر)
  touchDown: false   // انگشت کاربر روی لیست است
};
/* وقتی کاربر خودش لیست را لمس می‌کند یا می‌کشد، اسکرول خودکار با انگشت او درگیر نشود */
(function () {
  function inList(t) { return t && t.closest && t.closest('#quickList'); }
  document.addEventListener('touchstart', function (e) { if (inList(e.target)) AutoScroll.touchDown = true; }, { capture: true, passive: true });
  function up() { if (AutoScroll.touchDown) { AutoScroll.touchDown = false; AutoScroll.resumeAt = performance.now() + 900; } }
  document.addEventListener('touchend', up, { capture: true, passive: true });
  document.addEventListener('touchcancel', up, { capture: true, passive: true });
  document.addEventListener('wheel', function (e) { if (inList(e.target)) AutoScroll.resumeAt = performance.now() + 900; }, { capture: true, passive: true });
})();

function getAutoSpeedVal() {
  var st = S.data && S.data.settings ? +S.data.settings.autoScrollSpeed : 1;
  if (AUTO_SPEEDS.indexOf(st) < 0) st = 1;
  return st;
}

function isQuickReviewScrollAllowed() {
  return S.view === 'library' && S.libTab === 'quick';
}

function updateScrollDockVisibility() {
  var dock = $('#scrollDock');
  var allowed = isQuickReviewScrollAllowed();
  if (!allowed) {
    if (AutoScroll.active) stopAutoScroll();
    stopHoldScroll();
  }
  if (dock) {
    dock.classList.add('hidden');
  }
}

function getActiveScrollTarget() {
  if (!isQuickReviewScrollAllowed()) return null;
  return $('#quickList');
}

function scrollElementTo(sc, topVal, smooth) {
  if (!sc) return;
  var maxTop = Math.max(0, sc.scrollHeight - sc.clientHeight);
  var target = clamp(topVal, 0, maxTop);
  if (smooth) {
    try {
      sc.scrollTo({ top: target, behavior: 'smooth' });
      return;
    } catch (e) {}
  }
  sc.scrollTop = target;
}

function scrollContainerToElement(sc, el, anchorRatio) {
  if (!sc || !el) return;
  var sr = sc.getBoundingClientRect();
  var er = el.getBoundingClientRect();
  var ratio = anchorRatio != null ? anchorRatio : 0.24;
  var delta = (er.top - sr.top) - (sr.height * ratio);
  var target = Math.max(0, sc.scrollTop + delta);
  try {
    sc.scrollTo({ top: target, behavior: 'smooth' });
  } catch (e) {
    sc.scrollTop = target;
  }
}

function manualScrollStep(dir, customTarget) {
  var sc = customTarget || getActiveScrollTarget();
  if (!sc) return;
  var maxTop = Math.max(0, sc.scrollHeight - sc.clientHeight);
  if (S.view === 'reader' && !customTarget && pBase && sc === pageParts(pBase).scroll) {
    var b = curBook();
    if (dir > 0 && sc.scrollTop >= maxTop - 6 && b && S.index < b.pages.length - 1) {
      flipTo(true);
      return;
    }
    if (dir < 0 && sc.scrollTop <= 6 && b && S.index > 0) {
      flipTo(false);
      return;
    }
  }
  var step = Math.max(150, Math.round(sc.clientHeight * 0.36));
  scrollElementTo(sc, sc.scrollTop + (dir * step), true);
  setTimeout(syncAllScrollSliders, 180);
}

function manualScrollEdge(toBottom, customTarget) {
  var sc = customTarget || getActiveScrollTarget();
  if (!sc) return;
  var maxTop = Math.max(0, sc.scrollHeight - sc.clientHeight);
  scrollElementTo(sc, toBottom ? maxTop : 0, true);
  setTimeout(syncAllScrollSliders, 220);
}

function startHoldScroll(dir, customTarget) {
  stopHoldScroll();
  AutoScroll.holdDir = dir;
  var last = performance.now(), pos = null;
  function stepHold(now) {
    if (!AutoScroll.holdDir) return;
    var dt = Math.min(60, Math.max(8, now - last));
    last = now;
    var sc = customTarget || getActiveScrollTarget();
    if (sc) {
      var maxTop = Math.max(0, sc.scrollHeight - sc.clientHeight);
      if (pos === null || Math.abs(sc.scrollTop - pos) > 1.6) pos = sc.scrollTop;
      pos = clamp(pos + AutoScroll.holdDir * (dt * 0.42), 0, maxTop);
      sc.scrollTop = pos;
      syncAllScrollSliders();
    }
    AutoScroll.holdRaf = requestAnimationFrame(stepHold);
  }
  AutoScroll.holdRaf = requestAnimationFrame(stepHold);
}

function stopHoldScroll() {
  AutoScroll.holdDir = 0;
  if (AutoScroll.holdRaf) {
    cancelAnimationFrame(AutoScroll.holdRaf);
    AutoScroll.holdRaf = 0;
  }
}

function wireManualScrollBtn(btn, dir, customTarget) {
  var holdTimer = null, held = false;
  btn.addEventListener('pointerdown', function (e) {
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    held = false;
    clearTimeout(holdTimer);
    holdTimer = setTimeout(function () {
      held = true;
      startHoldScroll(dir, customTarget);
    }, 240);
  });
  function clearHold() {
    clearTimeout(holdTimer);
    if (held) stopHoldScroll();
  }
  btn.addEventListener('pointerup', clearHold);
  btn.addEventListener('pointercancel', clearHold);
  btn.addEventListener('pointerleave', clearHold);
  btn.addEventListener('click', function (e) {
    e.stopPropagation();
    if (held) { held = false; return; }
    manualScrollStep(dir, customTarget);
  });
}

function highlightRowAtReadingLine(sc) {
  if (!sc || S.view !== 'library' || S.libTab !== 'quick') return;
  if (S.tts && S.tts.vocabSeq) return;
  var rows = $$('.nvocab-row', sc);
  if (!rows.length) return;
  var sr = sc.getBoundingClientRect();
  var lineY = sr.top + sr.height * 0.28;
  var bestRow = null, bestDist = 999999;
  for (var i = 0; i < rows.length; i++) {
    var r = rows[i].getBoundingClientRect();
    var center = (r.top + r.bottom) * 0.5;
    var d = Math.abs(center - lineY);
    if (d < bestDist) {
      bestDist = d;
      bestRow = rows[i];
    }
  }
  if (bestRow) {
    var wid = bestRow.getAttribute('data-wid');
    if (wid && wid !== qActiveWid) {
      qActiveWid = wid;
      rows.forEach(function (rw) {
        rw.classList.toggle('active-step', rw === bestRow);
      });
    }
  }
}

function autoScrollTick(now) {
  if (!AutoScroll.active) return;
  var dt = AutoScroll.lastTs ? Math.min(64, Math.max(4, now - AutoScroll.lastTs)) : 16;
  AutoScroll.lastTs = now;
  var sc = getActiveScrollTarget();
  if (sc) {
    var maxTop = Math.max(0, sc.scrollHeight - sc.clientHeight);
    var cur = sc.scrollTop;
    // کاربر انگشتش روی لیست است، یا لیست هنوز با فلینگ خودش حرکت می‌کند: دخالت نکن
    if (AutoScroll.touchDown || now < AutoScroll.resumeAt) {
      AutoScroll.pos = cur;
      highlightRowAtReadingLine(sc);
      AutoScroll.raf = requestAnimationFrame(autoScrollTick);
      return;
    }
    if (AutoScroll.pos === null || Math.abs(cur - AutoScroll.pos) > 1.6) {
      var wasExternal = AutoScroll.pos !== null;
      AutoScroll.pos = cur;
      if (wasExternal) AutoScroll.resumeAt = now + 350;
      AutoScroll.raf = requestAnimationFrame(autoScrollTick);
      return;
    }
    var pxPerSec = 52 * getAutoSpeedVal();
    var next = clamp(AutoScroll.pos + (pxPerSec * dt / 1000) * AutoScroll.dir, 0, maxTop);
    AutoScroll.pos = next;
    sc.scrollTop = next;
    syncAllScrollSliders();
    highlightRowAtReadingLine(sc);

    var atEdge = (AutoScroll.dir > 0 && next >= maxTop - 0.5) || (AutoScroll.dir < 0 && next <= 0.5);
    if (atEdge && maxTop > 4) {
      stopAutoScroll();
      toast(AutoScroll.dir > 0 ? 'اسکرول خودکار به انتهای بخش رسید' : 'اسکرول خودکار به ابتدای بخش رسید');
      return;
    }
  }
  AutoScroll.raf = requestAnimationFrame(autoScrollTick);
}

function startAutoScroll(dir) {
  AutoScroll.dir = dir < 0 ? -1 : 1;
  AutoScroll.active = true;
  AutoScroll.lastTs = performance.now();
  AutoScroll.subPx = 0;
  AutoScroll.pageTurnWait = 0;
  AutoScroll.pos = null;
  AutoScroll.resumeAt = 0;
  cancelAnimationFrame(AutoScroll.raf);
  AutoScroll.raf = requestAnimationFrame(autoScrollTick);
  updateScrollUiState();
}

function stopAutoScroll() {
  AutoScroll.active = false;
  AutoScroll.pageTurnWait = 0;
  if (AutoScroll.raf) {
    cancelAnimationFrame(AutoScroll.raf);
    AutoScroll.raf = 0;
  }
  updateScrollUiState();
}

function toggleAutoScroll(dir) {
  dir = dir < 0 ? -1 : 1;
  if (AutoScroll.active && AutoScroll.dir === dir) {
    stopAutoScroll();
  } else {
    startAutoScroll(dir);
  }
}

function cycleAutoScrollSpeed() {
  var cur = getAutoSpeedVal();
  var idx = AUTO_SPEEDS.indexOf(cur);
  var next = AUTO_SPEEDS[(idx + 1) % AUTO_SPEEDS.length];
  if (S.data && S.data.settings) {
    S.data.settings.autoScrollSpeed = next;
    scheduleSave();
  }
  updateScrollUiState();
  toast('سرعت اسکرول خودکار: ' + fa(next) + '×');
}

function updateScrollUiState() {
  var upOn = AutoScroll.active && AutoScroll.dir < 0;
  var dnOn = AutoScroll.active && AutoScroll.dir > 0;
  var spdTxt = fa(getAutoSpeedVal()) + '×';
  $$('.js-auto-up').forEach(function (b) { b.classList.toggle('on', upOn); });
  $$('.js-auto-dn').forEach(function (b) { b.classList.toggle('on', dnOn); });
  $$('.js-auto-spd').forEach(function (b) { b.textContent = spdTxt; });
}

function syncAllScrollSliders() {
  var sc = getActiveScrollTarget();
  if (!sc) return;
  var maxTop = Math.max(0, sc.scrollHeight - sc.clientHeight);
  var pct = maxTop > 2 ? Math.round(clamp(sc.scrollTop / maxTop, 0, 1) * 100) : 0;
  $$('.js-scroll-range').forEach(function (inp) {
    if (document.activeElement !== inp) {
      inp.value = String(pct);
      inp.style.setProperty('--p', pct + '%');
    }
  });
  $$('.js-scroll-pct').forEach(function (sp) {
    sp.textContent = fa(pct) + '٪';
  });
}

function createInlineScrollBar(targetSelector, labelText, isCompact) {
  return h('span', { class: 'hidden' });
}
function _unusedCreateInlineScrollBar(targetSelector, labelText, isCompact) {
  function resolveTarget() {
    if (typeof targetSelector === 'function') return targetSelector();
    if (typeof targetSelector === 'string') return $(targetSelector) || getActiveScrollTarget();
    return targetSelector || getActiveScrollTarget();
  }
  var topBtn = h('button', { class: 'ssb-btn', type: 'button', title: 'رفتن به ابتدای صفحه', html: ic('top', 14) + '<span>اول</span>' });
  var upBtn = h('button', { class: 'ssb-btn', type: 'button', title: 'اسکرول دستی به بالا (نگه دارید یا بزنید)', html: ic('up', 14) + '<span>بالا</span>' });
  var dnBtn = h('button', { class: 'ssb-btn', type: 'button', title: 'اسکرول دستی به پایین (نگه دارید یا بزنید)', html: ic('down', 14) + '<span>پایین</span>' });
  var botBtn = h('button', { class: 'ssb-btn', type: 'button', title: 'رفتن به انتهای صفحه', html: ic('bottom', 14) + '<span>آخر</span>' });

  var aUpBtn = h('button', {
    class: 'ssb-btn js-auto-up' + (AutoScroll.active && AutoScroll.dir < 0 ? ' on' : ''),
    type: 'button',
    title: 'اسکرول خودکار به بالا',
    html: ic('autoUp', 14) + '<span>خودکار ▲</span>'
  });
  var aDnBtn = h('button', {
    class: 'ssb-btn js-auto-dn' + (AutoScroll.active && AutoScroll.dir > 0 ? ' on' : ''),
    type: 'button',
    title: 'اسکرول خودکار به پایین',
    html: ic('autoDown', 14) + '<span>خودکار ▼</span>'
  });
  var spdBtn = h('button', {
    class: 'ssb-btn spd js-auto-spd',
    type: 'button',
    title: 'تغییر سرعت اسکرول خودکار',
    text: fa(getAutoSpeedVal()) + '×'
  });

  var rangeInp = h('input', {
    class: 'js-scroll-range',
    type: 'range',
    min: '0',
    max: '100',
    value: '0',
    'aria-label': 'موقعیت اسکرول دستی',
    style: '--p:0%'
  });
  var pctLbl = h('span', { class: 'ssb-pct js-scroll-pct', text: '۰٪' });

  topBtn.addEventListener('click', function () { manualScrollEdge(false, resolveTarget()); });
  botBtn.addEventListener('click', function () { manualScrollEdge(true, resolveTarget()); });
  wireManualScrollBtn(upBtn, -1, null);
  wireManualScrollBtn(dnBtn, 1, null);
  aUpBtn.addEventListener('click', function () { toggleAutoScroll(-1); });
  aDnBtn.addEventListener('click', function () { toggleAutoScroll(1); });
  spdBtn.addEventListener('click', cycleAutoScrollSpeed);

  rangeInp.addEventListener('input', function () {
    var sc = resolveTarget();
    if (!sc) return;
    var v = clamp(+rangeInp.value || 0, 0, 100);
    rangeInp.style.setProperty('--p', v + '%');
    pctLbl.textContent = fa(v) + '٪';
    var maxTop = Math.max(0, sc.scrollHeight - sc.clientHeight);
    sc.scrollTop = Math.round((v / 100) * maxTop);
  });

  return h('div', { class: 'sec-scroll-bar' + (isCompact ? ' compact' : '') }, [
    h('div', { class: 'ssb-group' }, [
      h('span', { class: 'ssb-lbl', text: labelText || 'اسکرول دستی و خودکار:' }),
      topBtn, upBtn, dnBtn, botBtn
    ]),
    h('div', { class: 'ssb-slider-wrap' }, [rangeInp, pctLbl]),
    h('div', { class: 'ssb-group' }, [aUpBtn, aDnBtn, spdBtn])
  ]);
}

function buildScrollDock() {
  if ($('#scrollDock')) return;
  var dock = h('aside', { id: 'scrollDock', class: 'scroll-dock', 'aria-label': 'کنترل اسکرول دستی و خودکار' });
  var toggleBtn = h('button', { class: 'sd-btn toggle', type: 'button', title: 'جمع یا باز کردن نوار اسکرول', text: 'اسکرول' });
  var topB = h('button', { class: 'sd-btn', type: 'button', title: 'ابتدای صفحه', html: ic('top', 15) + '<span>اول</span>' });
  var upB = h('button', { class: 'sd-btn', type: 'button', title: 'اسکرول دستی به بالا', html: ic('up', 16) + '<span>بالا</span>' });
  var aUpB = h('button', { class: 'sd-btn js-auto-up', type: 'button', title: 'اسکرول خودکار به بالا', html: ic('autoUp', 15) + '<span>خودکار▲</span>' });
  var spdB = h('button', { class: 'sd-btn spd js-auto-spd', type: 'button', title: 'سرعت اسکرول خودکار', text: fa(getAutoSpeedVal()) + '×' });
  var aDnB = h('button', { class: 'sd-btn js-auto-dn', type: 'button', title: 'اسکرول خودکار به پایین', html: ic('autoDown', 15) + '<span>خودکار▼</span>' });
  var dnB = h('button', { class: 'sd-btn', type: 'button', title: 'اسکرول دستی به پایین', html: ic('down', 16) + '<span>پایین</span>' });
  var botB = h('button', { class: 'sd-btn', type: 'button', title: 'انتهای صفحه', html: ic('bottom', 15) + '<span>آخر</span>' });

  var body = h('div', { class: 'sd-body' }, [
    topB, upB,
    h('div', { class: 'sd-sep' }),
    aUpB, spdB, aDnB,
    h('div', { class: 'sd-sep' }),
    dnB, botB
  ]);
  dock.appendChild(toggleBtn);
  dock.appendChild(body);
  document.body.appendChild(dock);

  toggleBtn.addEventListener('click', function () {
    AutoScroll.collapsed = !AutoScroll.collapsed;
    dock.classList.toggle('collapsed', AutoScroll.collapsed);
    toggleBtn.textContent = AutoScroll.collapsed ? '▲▼' : 'اسکرول';
  });
  topB.addEventListener('click', function () { manualScrollEdge(false); });
  botB.addEventListener('click', function () { manualScrollEdge(true); });
  wireManualScrollBtn(upB, -1, null);
  wireManualScrollBtn(dnB, 1, null);
  aUpB.addEventListener('click', function () { toggleAutoScroll(-1); });
  aDnB.addEventListener('click', function () { toggleAutoScroll(1); });
  spdB.addEventListener('click', cycleAutoScrollSpeed);

  ['#libList', '#wordList', '#quickList', '#noteList'].forEach(function (sel) {
    var el = $(sel);
    if (el) el.addEventListener('scroll', syncAllScrollSliders, { passive: true });
  });
}

var LATIN_OR_ARABIC_PUNCT = /^[\s"'“”«»()\[\]{}.,;:!?؟،؛…\-–—]+|[\s"'“”«»()\[\]{}.,;:!?؟،؛…\-–—]+$/g;
function wkey(w) {
  return String(w == null ? '' : w).toLowerCase().replace(/[يى]/g, 'ی').replace(/ك/g, 'ک')
    .replace(/[\u064B-\u065F\u0670\u200C-\u200F]/g, '').replace(LATIN_OR_ARABIC_PUNCT, '').replace(/\s+/g, ' ');
}
function wordById(id) {
  for (var i = 0; i < S.data.words.length; i++) if (S.data.words[i].id === id) return S.data.words[i];
  return null;
}
function wordByKey(k, lg) {
  if (!k) return null;
  var targetLg = lg && LANG_META[lg] ? lg : null;
  for (var i = 0; i < S.data.words.length; i++) {
    var item = S.data.words[i];
    if (wkey(item.w) === k) {
      if (!targetLg || getWordEffLang(item) === targetLg) return item;
    }
  }
  return null;
}
function newWord(o) {
  var now = Date.now();
  var resolvedLg = (o.lg && LANG_META[o.lg]) ? o.lg : wordLang(String(o.w || ''), '', '');
  if (!LANG_META[resolvedLg]) resolvedLg = 'en';
  return { id: uid(), w: o.w, m: o.m || '', ex: '', bid: o.bid || '', bk: o.bk || '', pg: o.pg | 0,
    created: now, updated: now, box: 0, due: 0, seen: 0, lg: resolvedLg };
}
function dueWords(langCode) {
  var now = Date.now();
  return S.data.words.filter(function (x) {
    if (langCode && langCode !== 'all' && getWordEffLang(x) !== langCode) return false;
    return x.due <= now;
  });
}
function wordsByLang(langCode) {
  return S.data.words.filter(function (x) {
    if (!langCode || langCode === 'all') return true;
    return getWordEffLang(x) === langCode;
  });
}
function updateWordCount() {
  var n = S.data.words.length, el = $('#wordCnt');
  if (el) el.textContent = n ? fa(n) : '';
}
function boxDots(box) {
  var d = h('span', { class: 'wbox', role: 'img', 'aria-label': 'سطح یادگیری ' + fa(box) + ' از ' + fa(5) });
  for (var i = 1; i <= 5; i++) d.appendChild(h('i', { class: i <= box ? 'on' : '' }));
  return d;
}

/* ---------- نوار انتخاب زبان (تفکیک مجزای هر زبان در لغات و مرور سریع) ---------- */
function buildLangTabsBar(activeLg, onSelectLg, modeLabel, kind) {
  kind = kind || 'words';
  var sourceArr = kind === 'books' ? S.data.books : (kind === 'notes' ? S.data.notes.filter(function (n) { return !n.archived; }) : S.data.words);
  var counts = { all: sourceArr.length };
  APP_LANGS.forEach(function (k) { counts[k] = 0; });
  sourceArr.forEach(function (x) {
    var l = kind === 'books' ? getBookEffLang(x) : (kind === 'notes' ? getNoteEffLang(x) : getWordEffLang(x));
    counts[l] = (counts[l] || 0) + 1;
  });

  var tabsRow = h('div', { class: 'lang-tabs', role: 'tablist', 'aria-label': 'بخش‌های زبان' });
  var allBtn = h('button', {
    class: 'lang-tab' + (activeLg === 'all' ? ' on' : ''),
    type: 'button',
    role: 'tab',
    'aria-selected': activeLg === 'all' ? 'true' : 'false'
  }, [
    h('span', { class: 'lt-code', text: 'ALL' }),
    h('span', { text: 'همه زبان‌ها (بخش‌های مجزا)' }),
    h('span', { class: 'lt-cnt', text: '(' + fa(counts.all) + ')' })
  ]);
  allBtn.addEventListener('click', function () { onSelectLg('all'); });
  tabsRow.appendChild(allBtn);

  APP_LANGS.forEach(function (k) {
    var meta = LANG_META[k];
    var cnt = counts[k] || 0;
    var btn = h('button', {
      class: 'lang-tab' + (activeLg === k ? ' on' : ''),
      type: 'button',
      role: 'tab',
      'data-lang': k,
      'aria-selected': activeLg === k ? 'true' : 'false'
    }, [
      h('span', { class: 'lt-code', text: meta.badge }),
      h('span', { text: meta.name }),
      h('span', { class: 'lt-cnt', text: '(' + fa(cnt) + ')' })
    ]);
    btn.addEventListener('click', function () { onSelectLg(k); });
    tabsRow.appendChild(btn);
  });

  var addInLangBtn = null;
  if (activeLg !== 'all' && LANG_META[activeLg]) {
    var itemLbl = kind === 'books' ? 'کتاب جدید ' : (kind === 'notes' ? 'یادداشت جدید ' : 'افزودن لغت ');
    addInLangBtn = h('button', {
      class: 'ssb-btn on',
      type: 'button',
      html: ic('plus', 14) + '<span>' + itemLbl + LANG_META[activeLg].name + '</span>'
    });
    addInLangBtn.addEventListener('click', function () {
      if (kind === 'books') bookFormFlow(null, activeLg);
      else if (kind === 'notes') noteForm({ lg: activeLg });
      else wordForm({ lg: activeLg });
    });
  }

  return h('div', { class: 'lang-tabs-wrap' }, [
    h('div', { class: 'lang-tabs-hdr' }, [
      h('span', { text: modeLabel || 'تفکیک بر اساس زبان (هر زبان در بخش و ردیف اختصاصی خودش):' }),
      addInLangBtn
    ]),
    tabsRow
  ]);
}

/* ---------- تلفظ، جستجوی معنی ---------- */
function speakWord(w, ex, lg) {
  var l = wordLang(String(w), '', lg);
  if (!ttsAvailable()) { toast('تلفظ در این دستگاه پشتیبانی نمی‌شود'); return; }
  var segs = [{ pid: null, p: 0, s: 0, e: 0, l: l, t: String(w).slice(0, 200) }];
  var st = S.data.settings;
  S.tts = { book: null, segs: segs, idx: 0, cur: null, state: 'loading', lastPid: null, sample: true };
  try {
    if (bridge('ttsStart')) A.ttsStart(JSON.stringify(segs), 0, st.ttsRate, st.ttsPitch);
    else if (!webTtsStart(segs, 0, st.ttsRate, st.ttsPitch)) throw new Error('no tts');
  } catch (e) { S.tts = null; toast('شروع خوانش انجام نشد'); }
}
function lookupUrl(kind, w) {
  var q = encodeURIComponent(w);
  if (kind === 'gt') return 'https://translate.google.com/?sl=auto&tl=fa&text=' + q + '&op=translate';
  if (kind === 'wik') return 'https://en.wiktionary.org/wiki/' + q;
  if (kind === 'vaj') return 'https://www.vajehyab.com/?q=' + q;
  return 'https://www.google.com/search?q=' + q + '+' + encodeURIComponent('معنی');
}
function openExternal(url) {
  try { if (bridge('openUrl')) { A.openUrl(url); return; } } catch (e) {}
  try { window.open(url, '_blank'); } catch (e) {}
}
function lookupMenu(anchor, w, lg) {
  w = String(w || '').replace(/\s+/g, ' ').trim();
  if (!w) { toast('اول واژه را بنویسید'); return; }
  var L = wordLang(w, '', lg);
  function it(label, kind) { return { icon: 'search', label: label, fn: function () { openExternal(lookupUrl(kind, w)); } }; }
  menu(anchor, L === 'fa' ? [it('واژه‌یاب (فرهنگ فارسی)', 'vaj'), it('جستجوی گوگل', 'g')]
    : L === 'ar' ? [it('واژه‌یاب (فرهنگ فارسی)', 'vaj'), it('گوگل ترجمه (به فارسی)', 'gt'), it('ویکی‌واژه', 'wik'), it('جستجوی گوگل', 'g')]
    : L === 'fr' ? [it('گوگل ترجمه (به فارسی)', 'gt'), it('واژه‌یاب (فرهنگ فارسی)', 'vaj'), it('ویکی‌واژه', 'wik'), it('جستجوی گوگل', 'g')]
    : [it('گوگل ترجمه (به فارسی)', 'gt'), it('ویکی‌واژه‌ی انگلیسی', 'wik'), it('جستجوی گوگل', 'g')]);
}

/* ---------- تب‌ها و فهرست ---------- */
function setLibTab(tab) {
  stopAutoScroll();
  stopQuickAutoWalk();
  S.libTab = (tab === 'words' || tab === 'quick' || tab === 'notes') ? tab : 'books';
  var b = S.libTab === 'books', w = S.libTab === 'words', q = S.libTab === 'quick', n = S.libTab === 'notes';
  $('#tabBooks').classList.toggle('on', b);
  $('#tabWords').classList.toggle('on', w);
  if ($('#tabQuick')) $('#tabQuick').classList.toggle('on', q);
  if ($('#tabNotes')) $('#tabNotes').classList.toggle('on', n);
  $('#tabBooks').setAttribute('aria-selected', b ? 'true' : 'false');
  $('#tabWords').setAttribute('aria-selected', w ? 'true' : 'false');
  if ($('#tabQuick')) $('#tabQuick').setAttribute('aria-selected', q ? 'true' : 'false');
  if ($('#tabNotes')) $('#tabNotes').setAttribute('aria-selected', n ? 'true' : 'false');
  $('#libList').classList.toggle('hidden', !b);
  $('#wordList').classList.toggle('hidden', !w);
  if ($('#quickList')) $('#quickList').classList.toggle('hidden', !q);
  if ($('#noteList')) $('#noteList').classList.toggle('hidden', !n);
  var activeLg = b ? bLangFilter : (w ? wLangFilter : (q ? qLangFilter : nLangFilter));
  var lgSuffix = (activeLg && activeLg !== 'all' && LANG_META[activeLg]) ? ' (' + LANG_META[activeLg].short + ')' : '';
  var fabLbl = (w || q) ? ('لغت جدید' + lgSuffix) : (n ? ('یادداشت جدید' + lgSuffix) : ('کتاب جدید' + lgSuffix));
  $('#fabNewBook').innerHTML = ic('plus', 22) + '<span>' + fabLbl + '</span>';
  $('#fabNewBook').setAttribute('aria-label', fabLbl);
  updateWordCount();
  updateNoteCount();
  updateTopTabLabels();
  if (q) {
    if (S._prevTabForFs !== 'quick') {
      S._savedNormalFs = S.data.settings.fontSize || 21;
      S.data.settings.fontSize = 10;
      applyTheme();
    }
    document.documentElement.style.setProperty('--qfs', (S.data.settings.fontSize || 10) + 'px');
  } else if (S._prevTabForFs === 'quick') {
    if (S._savedNormalFs && S.data.settings.fontSize === 10) {
      S.data.settings.fontSize = S._savedNormalFs;
      applyTheme();
    }
  }
  S._prevTabForFs = S.libTab;
  updateScrollDockVisibility();
  if ($('#fabNewBook')) $('#fabNewBook').classList.add('hidden');
  if (w) renderWords();
  else if (q) renderQuickReview();
  else if (n) renderNotes();
  else renderLibrary();
}
function fabClick() {
  if (S.libTab === 'words') {
    wordForm(wLangFilter !== 'all' ? { lg: wLangFilter } : {});
  } else if (S.libTab === 'quick') {
    wordForm(qLangFilter !== 'all' ? { lg: qLangFilter } : {});
  } else if (S.libTab === 'notes') {
    noteForm(nLangFilter !== 'all' ? { lg: nLangFilter } : {});
  } else {
    newBookFlow();
  }
}

var debouncedRenderWordCards = debounce(renderWordCards, 90);
function renderWords() {
  var list = $('#wordList');
  list.textContent = '';
  updateWordCount();
  var activeLg = wLangFilter;
  var allInScope = wordsByLang(activeLg);
  var dueInScope = dueWords(activeLg);
  var knownCnt = 0;
  for (var i = 0; i < allInScope.length; i++) if (allInScope[i].box >= 4) knownCnt++;

  var topStrip = buildUnifiedSectionStrip('words', wLangFilter, function (newLg) {
    wLangFilter = newLg;
    wPageIdx = 0;
    renderWords();
    updateTopTabLabels();
  });

  var scopeTitle = activeLg === 'all' ? 'همه زبان‌ها (' + fa(allInScope.length) + ' واژه)' : ('لغات ' + LANG_META[activeLg].name + ' (' + fa(allInScope.length) + ')');
  var rv = h('button', { class: 'btn-exp on-accent', id: 'wReview', type: 'button', html: ic('layers', 15) + '<span>' + (dueInScope.length ? 'مرور فلش‌کارت' : 'مرور همه') + '</span>' });
  rv.addEventListener('click', function () { reviewStart(dueInScope.length ? 'due' : 'all', activeLg); });
  var wReadBtn = h('button', { class: 'btn-exp', type: 'button', title: 'خوانش صوتی لغات', html: ic('speaker', 15) + '<span>خوانش</span>' });
  wReadBtn.addEventListener('click', function () { speakWordsColumn(getFilteredWordsList(), null); });
  var wPdfBtn = h('button', { class: 'btn-exp pdf', type: 'button', html: ic('pdf', 15) + '<span>PDF</span>' });
  var wWordBtn = h('button', { class: 'btn-exp word', type: 'button', html: ic('word', 15) + '<span>Word</span>' });
  var wMdBtn = h('button', { class: 'btn-exp md', type: 'button', html: ic('md', 15) + '<span>MD</span>' });
  var wJsBtn = h('button', { class: 'btn-exp js', type: 'button', html: ic('js', 15) + '<span>JS</span>' });
  wPdfBtn.addEventListener('click', function () { exportWordsList(getFilteredWordsList(), 'pdf', activeLg !== 'all' ? 'لغات ' + LANG_META[activeLg].name : null); });
  wWordBtn.addEventListener('click', function () { exportWordsList(getFilteredWordsList(), 'word', activeLg !== 'all' ? 'لغات ' + LANG_META[activeLg].name : null); });
  wMdBtn.addEventListener('click', function () { exportWordsList(getFilteredWordsList(), 'md', activeLg !== 'all' ? 'لغات ' + LANG_META[activeLg].name : null); });
  wJsBtn.addEventListener('click', function () { exportWordsList(getFilteredWordsList(), 'js', activeLg !== 'all' ? 'لغات ' + LANG_META[activeLg].name : null); });

  var q = h('input', { class: 'field compact-search', id: 'wSearch', type: 'search', dir: 'auto', placeholder: 'جستجوی واژه یا معنی…', 'aria-label': 'جستجو' });
  q.value = wQuery;
  q.addEventListener('input', function () { wQuery = q.value; wPageIdx = 0; debouncedRenderWordCards(); });

  var chips = h('div', { class: 'chips compact-chips' });
  [['all', 'همه (' + fa(allInScope.length) + ')'], ['due', 'مرور (' + fa(dueInScope.length) + ')'], ['known', 'تثبیت‌شده (' + fa(knownCnt) + ')']].forEach(function (o) {
    var c = h('button', { class: 'chip sm' + (wFilter === o[0] ? ' on' : ''), text: o[1], 'data-f': o[0] });
    c.addEventListener('click', function () {
      wFilter = o[0]; wPageIdx = 0; $$('.chip', chips).forEach(function (x) { x.classList.toggle('on', x === c); }); renderWordCards();
    });
    chips.appendChild(c);
  });

  var headBar = h('div', { class: 'uni-toolbar words-toolbar' }, [
    h('div', { class: 'uni-tb-row1' }, [
      h('b', { text: scopeTitle }),
      h('div', { class: 'uni-tb-acts' }, [rv, wReadBtn, wPdfBtn, wWordBtn, wMdBtn, wJsBtn])
    ]),
    h('div', { class: 'uni-tb-row2' }, [q, chips])
  ]);

  var stageArea = h('div', { id: 'wCards', class: 'no-scroll-stage words-stage' });
  var pagerHost = h('div', { id: 'wPagerHost' });

  list.appendChild(topStrip);
  list.appendChild(headBar);
  list.appendChild(stageArea);
  list.appendChild(pagerHost);
  renderWordCards();
}

function renderWordCards() {
  var box = $('#wCards'), pagerHost = $('#wPagerHost');
  if (!box) return;
  box.textContent = '';
  if (pagerHost) pagerHost.textContent = '';

  var langsToShow = wLangFilter === 'all' ? APP_LANGS : [wLangFilter];
  var allMatching = [];
  langsToShow.forEach(function (lk) {
    var items = getFilteredWordsList(lk);
    items.forEach(function (x, i) {
      allMatching.push({ word: x, lg: lk, idxInLang: i + 1 });
    });
  });

  var totalShown = allMatching.length;
  var totalPages = Math.max(1, Math.ceil(totalShown / WORDS_PER_PAGE));
  wPageIdx = clamp(wPageIdx, 0, totalPages - 1);
  var pageSlice = allMatching.slice(wPageIdx * WORDS_PER_PAGE, (wPageIdx + 1) * WORDS_PER_PAGE);

  if (!totalShown) {
    var msg = wLangFilter !== 'all' && LANG_META[wLangFilter]
      ? 'هنوز واژه‌ای در بخش زبان «' + LANG_META[wLangFilter].name + '» ثبت نشده است.'
      : 'واژه‌ای با این مشخصات پیدا نشد.';
    var emptyBox = h('div', { class: 'lib-empty compact-empty' }, [
      h('h3', { text: msg }),
      h('p', { text: 'با زدن دکمه‌ی «+ لغت جدید» در پایین صفحه، واژه‌ی جدید را به همراه معنی فارسی ثبت کنید.' })
    ]);
    box.appendChild(emptyBox);
  } else {
    var cardsWrap = h('div', { class: 'words-page-list' });
    pageSlice.forEach(function (entry) {
      cardsWrap.appendChild(wordCard(entry.word, entry.idxInLang));
    });
    box.appendChild(cardsWrap);
    box.scrollTop = 0;
  }

  if (pagerHost) {
    var activeMeta = wLangFilter !== 'all' ? LANG_META[wLangFilter] : null;
    var addLbl = 'لغت جدید' + (activeMeta ? ' (' + activeMeta.short + ')' : '');
    pagerHost.appendChild(buildBottomPagerDock(wPageIdx, totalShown, WORDS_PER_PAGE, function (np) {
      wPageIdx = np;
      renderWordCards();
    }, 'واژه', addLbl, function () {
      wordForm(wLangFilter !== 'all' ? { lg: wLangFilter } : {});
    }));
  }
}

function gotoWordSource(x) {
  var b = bookById(x.bid);
  if (!b) { toast('این کتاب دیگر وجود ندارد'); return; }
  openBook(b.id);
  if (x.pg) showPageNow(clamp(x.pg - 1, 0, Math.max(0, b.pages.length - 1)));
}

function wordCard(x, rowIdx) {
  var say = h('button', { class: 'ibtn wsay', 'aria-label': 'تلفظ', html: ic('speaker', 20) });
  var more = h('button', { class: 'ibtn wmore', 'aria-label': 'گزینه‌ها', html: ic('dots', 20) });
  var wl = getWordEffLang(x);
  var meta = LANG_META[wl] || LANG_META.en;
  var topItems = [];
  if (rowIdx != null) topItems.push(h('span', { class: 'widx-badge', text: fa(rowIdx) }));
  topItems.push(h('div', { class: 'wword', dir: 'auto', text: x.w }));
  topItems.push(h('span', { class: 'wlg', 'data-l': wl, text: meta.name }));
  if (wl !== 'fa') topItems.push(say);
  topItems.push(more);

  var kids = [h('div', { class: 'wtop' }, topItems)];
  kids.push(x.m ? h('div', { class: 'wmean', dir: 'auto', text: x.m }) : h('div', { class: 'wmean none', text: 'معنی ثبت نشده؛ برای نوشتن بزنید' }));
  var foot = [];
  if (x.bk) {
    var src = h('button', { class: 'wsrc', html: ic('book', 14) + '<span></span>' });
    src.lastChild.textContent = x.bk + (x.pg ? ' · صفحه ' + fa(x.pg) : '');
    src.addEventListener('click', function (e) { e.stopPropagation(); gotoWordSource(x); });
    foot.push(src);
  } else foot.push(h('span'));
  foot.push(boxDots(x.box));
  kids.push(h('div', { class: 'wfoot' }, foot));
  var isSpeaking = !!(S.tts && S.tts.vocabSeq && S.tts.wordId === x.id);
  var card = h('div', { class: 'wcard' + (x.box >= 4 ? ' known' : '') + (isSpeaking ? ' speaking' : ''), 'data-id': x.id, 'data-wid': x.id, role: 'button', tabindex: 0 }, kids);
  card.addEventListener('click', function (e) { if (e.target.closest && e.target.closest('.wsay,.wmore,.wsrc')) return; wordForm({ id: x.id }); });
  say.addEventListener('click', function (e) { e.stopPropagation(); speakWord(x.w, '', wl); });
  more.addEventListener('click', function (e) {
    e.stopPropagation();
    menu(more, [
      { icon: 'edit', label: 'ویرایش واژه، معنی یا زبان (' + meta.name + ')', fn: function () { wordForm({ id: x.id }); } },
      { icon: 'layers', label: 'مرور فلش‌کارت بخش ' + meta.name, fn: function () { reviewStart('all', wl); } },
      { icon: 'pdf', label: 'ارسال واژه و معنی (PDF)', fn: function () { exportWordsList([x], 'pdf', x.w); } },
      { icon: 'word', label: 'ارسال واژه و معنی (Word)', fn: function () { exportWordsList([x], 'word', x.w); } },
      { icon: 'md', label: 'ارسال واژه و معنی (Markdown)', fn: function () { exportWordsList([x], 'md', x.w); } },
      { icon: 'js', label: 'ارسال واژه و معنی (JS)', fn: function () { exportWordsList([x], 'js', x.w); } },
      { icon: 'check', label: x.box >= 4 ? 'نیاز به مرور دارم' : 'این را بلدم', fn: function () { toggleKnown(x); } },
      { icon: 'copy', label: 'کپی واژه و معنی', fn: function () { copyText(x.w + (x.m ? ' — ' + x.m : '')); } },
      '-',
      { icon: 'trash', label: 'حذف واژه', danger: true, fn: function () { deleteWord(x); } }
    ]);
  });
  return card;
}
function toggleKnown(x) {
  var now = Date.now();
  if (x.box >= 4) { x.box = 1; x.due = now; } else { x.box = 5; x.due = now + BOX_DAYS[5] * DAY_MS; }
  x.updated = now;
  scheduleSave(); renderWords();
}
function deleteWord(x) {
  var idx = S.data.words.indexOf(x);
  if (idx < 0) return;
  S.data.words.splice(idx, 1);
  scheduleSave(); flushSave();
  if (S.view === 'library') { if (S.libTab === 'words') renderWords(); else if (S.libTab === 'quick') { updateWordCount(); renderQuickReview(); } else updateWordCount(); } else updateWordCount();
  toast('واژه حذف شد', { label: 'بازگردانی', fn: function () {
    S.data.words.splice(Math.min(idx, S.data.words.length), 0, x);
    scheduleSave(); flushSave(); if (S.view === 'library') { if (S.libTab === 'words') renderWords(); else if (S.libTab === 'quick') { updateWordCount(); renderQuickReview(); } else updateWordCount(); } else updateWordCount();
  } });
}
function shareWords() {
  if (!S.data.words.length) { toast('هنوز واژه‌ای ذخیره نشده'); return; }
  var txt = S.data.words.slice().sort(function (a, b) { return a.created - b.created; }).map(function (x) {
    var l = getWordEffLang(x);
    return '[' + (LANG_META[l] ? LANG_META[l].name : l) + '] ' + x.w + (x.m ? ' — ' + x.m.replace(/\s*\n\s*/g, '؛ ') : '');
  }).join('\n\n');
  shareText(txt, 'واژه‌های کتابچه');
}

/* =====================================================================
   اینترنت: فقط «پیشنهاد معنی واژه». درخواست‌ها از راه پل بومی (Android.httpGet) می‌روند؛
   فقط خودِ واژه فرستاده می‌شود و فقط به چند سرویس مشخص. وب‌ویو خودش هیچ‌چیز از شبکه نمی‌گیرد.
   ===================================================================== */
var NET_WAIT = {}, netSeq = 0;
window.onHttp = function (id, status, b64) {
  var w = NET_WAIT[id]; if (!w) return;
  delete NET_WAIT[id]; clearTimeout(w.t);
  var txt = '';
  try {
    var bin = atob(b64 || ''), bytes = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    txt = new TextDecoder('utf-8').decode(bytes);
  } catch (e) { txt = ''; }
  try { w.cb(status | 0, txt); } catch (e2) {}
};
function netGet(url, cb) {
  if (!bridge('httpGet')) {
    if (typeof fetch === 'function') {
      fetch(url).then(function (r) { return r.text().then(function (t) { cb(r.status | 0, t); }); })
        .catch(function () { cb(0, ''); });
    } else { cb(0, ''); }
    return;
  }
  var id = 'n' + (++netSeq) + '_' + Date.now().toString(36);
  var w = { cb: cb, t: setTimeout(function () { if (NET_WAIT[id]) { delete NET_WAIT[id]; cb(0, ''); } }, 20000) };
  NET_WAIT[id] = w;
  try { A.httpGet(id, url); } catch (e) { delete NET_WAIT[id]; clearTimeout(w.t); cb(0, ''); }
}
function netAsk() {
  return dialog({ title: 'استفاده از اینترنت',
    message: 'برای «پیشنهاد معنی»، فقط خودِ همان واژه (یک کلمه یا عبارت کوتاه) به سرویس‌های آنلاین فرستاده می‌شود: Free Dictionary، MyMemory و ویکی‌واژه.\n\nمتن کتاب‌ها، جمله‌ها و بقیه‌ی واژه‌ها هرگز فرستاده نمی‌شود. هر وقت خواستید از منوی صفحه‌ی اصلی خاموشش کنید.',
    ok: 'اجازه می‌دهم', cancel: 'نه' }).then(function (r) {
    if (r) { S.data.settings.net = true; scheduleSave(); }
    return !!r;
  });
}
function netEnsure(cb) {
  if (!bridge('httpGet')) { toast('اتصال به اینترنت فقط در برنامه‌ی اندروید کار می‌کند'); return; }
  if (S.data.settings.net) { cb(); return; }
  netAsk().then(function (ok) { if (ok) cb(); });
}
function netToggle() {
  if (S.data.settings.net) { S.data.settings.net = false; scheduleSave(); toast('اینترنت خاموش شد؛ چیزی ارسال نمی‌شود'); return; }
  if (!bridge('httpGet')) { toast('اتصال به اینترنت فقط در برنامه‌ی اندروید کار می‌کند'); return; }
  netAsk().then(function (ok) { if (ok) toast('پیشنهاد معنی از اینترنت روشن شد'); });
}

/* ---------- تحلیل پاسخ سرویس‌ها؛ هر کدام فهرستی از متن‌ها برمی‌گرداند یا خطا پرتاب می‌کند ---------- */
function htmlDecode(t) {
  return String(t).replace(/&#(\d+);/g, function (m, n) { return String.fromCharCode(+n); })
    .replace(/&#x([0-9a-f]+);/gi, function (m, n) { return String.fromCharCode(parseInt(n, 16)); })
    .replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
}
function netClip(t, n) { t = String(t).replace(/\s+/g, ' ').trim(); return t.length > n ? t.slice(0, n - 1) + '…' : t; }
function parseDict(status, txt) {
  if (status === 404) return [];
  if (status !== 200) throw new Error('http');
  var j; try { j = JSON.parse(txt); } catch (e) { throw new Error('parse'); }
  if (!Array.isArray(j)) return [];
  var out = [];
  j.slice(0, 2).forEach(function (en) {
    (en && Array.isArray(en.meanings) ? en.meanings : []).forEach(function (mn) {
      var pos = mn && mn.partOfSpeech ? String(mn.partOfSpeech) : '';
      (Array.isArray(mn.definitions) ? mn.definitions : []).slice(0, 2).forEach(function (d) {
        if (d && d.definition && out.length < 6) out.push(netClip((pos ? '(' + pos + ') ' : '') + d.definition, 300));
      });
    });
  });
  return out;
}
function parseMM(word) {
  var key = wkey(word);
  return function (status, txt) {
    var j; try { j = JSON.parse(txt); } catch (e) { j = null; }
    var st = j ? String(j.responseStatus) : String(status);
    var main = j && j.responseData && j.responseData.translatedText ? String(j.responseData.translatedText) : '';
    if (status === 429 || st === '429' || /MYMEMORY WARNING/i.test(main)) throw new Error('quota');
    if (!j || (status !== 200) || (st !== '200' && st !== 'undefined')) throw new Error('http');
    var cand = [];
    if (main) cand.push({ t: main, m: +j.responseData.match || 0.5 });
    (Array.isArray(j.matches) ? j.matches : []).forEach(function (x) {
      if (x && x.translation && wkey(x.segment || word) === key) cand.push({ t: String(x.translation), m: +x.match || 0 });
    });
    cand.sort(function (a, b) { return b.m - a.m; });
    var seen = {}, out = [];
    cand.forEach(function (c) {
      var t = netClip(htmlDecode(c.t), 120), k = wkey(t);
      if (!k || k === key || seen[k] || /MYMEMORY|NO TRANSLATION/i.test(t)) return;
      seen[k] = 1;
      if (out.length < 5) out.push(t);
    });
    return out;
  };
}
function parseFaWik(status, txt) {
  if (status !== 200) throw new Error('http');
  var j; try { j = JSON.parse(txt); } catch (e) { throw new Error('parse'); }
  var pg = j && j.query && Array.isArray(j.query.pages) ? j.query.pages[0] : null;
  if (!pg || pg.missing || !pg.extract) return [];
  var out = [];
  String(pg.extract).split(/\n+/).forEach(function (ln) {
    ln = ln.replace(/^[#*:;\s]+/, '').trim();
    if (!ln || /^=+.*=+$/.test(ln) || ln.length < 3 || (pg.title && wkey(ln) === wkey(pg.title))) return;
    if (out.length < 5) out.push(netClip(ln, 300));
  });
  return out;
}
function suggestSources(w, lg) {
  var one = String(w).replace(/\s+/g, ' ').trim().slice(0, 60), q = encodeURIComponent(one);
  var L = wordLang(one, '', lg), single = /^[A-Za-z][A-Za-z'’\-]*$/.test(one);
  var mm = 'https://api.mymemory.translated.net/get?q=' + q + '&langpair=';
  var fawik = { id: 'fawik', title: 'ویکی‌واژه‌ی فارسی', url: 'https://fa.wiktionary.org/w/api.php?action=query&prop=extracts&exintro=1&explaintext=1&redirects=1&format=json&formatversion=2&titles=' + q, parse: parseFaWik };
  if (L === 'fa') return [fawik, { id: 'mmen', title: 'معادل انگلیسی', url: mm + 'fa%7Cen', parse: parseMM(one) }];
  if (L === 'ar') return [
    { id: 'mmfa', title: 'ترجمه‌ی فارسی', url: mm + 'ar%7Cfa', parse: parseMM(one) }, fawik,
    { id: 'mmen', title: 'معادل انگلیسی', url: mm + 'ar%7Cen', parse: parseMM(one) }];
  if (L === 'fr') return [
    { id: 'mmfa', title: 'ترجمه‌ی فارسی', url: mm + 'fr%7Cfa', parse: parseMM(one) },
    { id: 'mmen', title: 'معادل انگلیسی', url: mm + 'fr%7Cen', parse: parseMM(one) }];
  if (L === 'de') return [
    { id: 'mmfa', title: 'ترجمه‌ی فارسی', url: mm + 'de%7Cfa', parse: parseMM(one) },
    { id: 'mmen', title: 'معادل انگلیسی', url: mm + 'de%7Cen', parse: parseMM(one) }];
  if (L === 'tr') return [
    { id: 'mmfa', title: 'ترجمه‌ی فارسی', url: mm + 'tr%7Cfa', parse: parseMM(one) },
    { id: 'mmen', title: 'معادل انگلیسی', url: mm + 'tr%7Cen', parse: parseMM(one) }];
  var list = [{ id: 'mmfa', title: 'ترجمه‌ی فارسی', url: mm + 'en%7Cfa', parse: parseMM(one) }];
  if (single) list.push({ id: 'dict', title: 'تعریف انگلیسی', url: 'https://api.dictionaryapi.dev/api/v2/entries/en/' + q, parse: parseDict });
  return list;
}

/* ---------- پنل پیشنهادها زیر خانه‌ی معنی ---------- */
function suggestInto(box, word, mIn, ctx) {
  var run = (box._run = (box._run || 0) + 1);
  var list = suggestSources(word, ctx && ctx.lg);
  box.textContent = '';
  box.classList.remove('hidden');
  var head = h('div', { class: 'sug-top' }, [h('b', { text: 'پیشنهادها برای «' + netClip(word, 30) + '»' })]);
  var closeB = h('button', { class: 'ibtn sug-x', type: 'button', 'aria-label': 'بستن پیشنهادها', html: ic('x', 18) });
  closeB.addEventListener('click', function () { box._run++; box.classList.add('hidden'); box.textContent = ''; });
  head.appendChild(closeB);
  box.appendChild(head);
  var pending = list.length, errors = 0, got = 0;
  var note = h('div', { class: 'sug-note hidden' });
  list.forEach(function (s) {
    var st = h('span', { class: 'sug-st', text: 'در حال دریافت…' });
    var items = h('div', { class: 'sug-items' });
    box.appendChild(h('div', { class: 'sug-grp' }, [h('div', { class: 'sug-h' }, [h('span', { text: s.title }), st]), items]));
    netGet(s.url, function (status, txt) {
      if (box._run !== run || !box.isConnected) return;
      var res = null, err = null;
      try { res = s.parse(status, txt); } catch (e) { err = e && e.message || 'x'; }
      pending--;
      if (err) {
        errors++;
        st.textContent = err === 'quota' ? 'سقف رایگانِ امروز این سرویس تمام شده' : (status === 0 ? 'اتصال برقرار نشد' : 'پاسخ قابل استفاده نبود');
        st.classList.add('bad');
      } else if (!res.length) {
        st.textContent = 'چیزی پیدا نشد';
      } else {
        got += res.length; st.textContent = '';
        res.forEach(function (t) {
          var b = h('button', { class: 'sug-it', type: 'button', dir: 'auto', text: t });
          b.addEventListener('click', function () {
            var cur = mIn.value.trim(), lines = cur ? cur.split(/\n/) : [];
            if (lines.indexOf(t) >= 0) { toast('این مورد قبلاً اضافه شده'); return; }
            mIn.value = cur ? cur + '\n' + t : t;
            b.classList.add('used');
          });
          items.appendChild(b);
        });
      }
      if (!pending) {
        if (!got) {
          note.textContent = errors === list.length ? 'اتصال اینترنت گوشی را بررسی کنید و دوباره بزنید.' : 'برای این واژه پیشنهادی پیدا نشد؛ می‌توانید در مرورگر جستجو کنید.';
          note.classList.remove('hidden');
        } else { note.textContent = 'روی هر مورد بزنید تا به معنی اضافه شود؛ بعد می‌توانید ویرایشش کنید.'; note.classList.remove('hidden'); }
      }
    });
  });
  box.appendChild(note);
  box.scrollIntoView && box.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
}

/* ---------- فرم افزودن / ویرایش واژه (با انتخاب بخش مجزای زبان) ---------- */
function wordForm(o) {
  o = o || {};
  var rec = o.id ? wordById(o.id) : null;
  var defaultLg = rec ? getWordEffLang(rec) : (o.lg && LANG_META[o.lg] ? o.lg : '');
  var f0 = { w: rec ? rec.w : (o.w || ''), m: rec ? rec.m : (o.m || ''), lg: defaultLg };
  var src = rec ? { bid: rec.bid, bk: rec.bk, pg: rec.pg } : (o.src || null);
  if (rec && !rec.bk && o.src) src = o.src;
  var wIn = h('input', { class: 'field', id: 'wfWord', type: 'text', dir: 'auto', maxlength: 160, placeholder: 'واژه یا عبارت (مثلاً فرانسوی، ترکی، انگلیسی…)', 'aria-label': 'واژه' });
  wIn.value = f0.w;
  var mIn = h('textarea', { class: 'field', id: 'wfMean', dir: 'auto', rows: 4, maxlength: 3000, placeholder: 'معنی را بنویسید یا بچسبانید…', 'aria-label': 'معنی', spellcheck: 'false' });
  mIn.value = f0.m;
  var lgSel = f0.lg;
  var lgRow = h('div', { class: 'wf-lg', role: 'group', 'aria-label': 'بخش زبان واژه' });
  var sayB = h('button', { class: 'ibtn wf-say', type: 'button', 'aria-label': 'تلفظ', html: ic('speaker', 20) });
  var look = h('button', { class: 'btn block', type: 'button', id: 'wfLook', html: ic('search', 20) + '<span>جستجوی معنی در مرورگر گوشی</span>' });
  var sugB = h('button', { class: 'btn pri block', type: 'button', id: 'wfSuggest', html: ic('globe', 20) + '<span>پیشنهاد معنی (از اینترنت)</span>' });
  var sugBox = h('div', { class: 'wf-sug hidden', id: 'wfSug' });
  var closeBtn = h('button', { class: 'ibtn', 'aria-label': 'بستن', html: ic('x') });
  var saveBtn = h('button', { class: 'btn pri', id: 'wfSave', text: 'ذخیره', style: 'height:40px;padding:0 20px' });
  var body = h('div', { class: 'wf-body' }, [
    h('label', { class: 'wf-l', text: 'واژه', for: 'wfWord' }),
    h('div', { class: 'wf-row' }, [wIn, sayB]),
    h('label', { class: 'wf-l', text: 'ذخیره در بخش و ردیف زبان:' }),
    lgRow,
    h('label', { class: 'wf-l', text: 'معنی', for: 'wfMean' }), mIn,
    sugB, sugBox,
    look,
    h('div', { class: 'wf-hint', text: 'هر واژه در بخش و ردیف زبان اختصاصی خودش (فرانسوی، ترکی، انگلیسی، آلمانی، عربی یا فارسی) ذخیره و مرور می‌شود تا لغات زبان‌های مختلف با یکدیگر قاطی نشوند.' })
  ]);
  if (src && src.bk) {
    var srcRow = h('div', { class: 'wf-src', html: ic('book', 16) + '<span></span>' });
    srcRow.lastChild.textContent = src.bk + (src.pg ? ' · صفحه ' + fa(src.pg) : '');
    body.appendChild(srcRow);
  }
  if (rec) {
    var del = h('button', { class: 'btn block danger', type: 'button', html: ic('trash', 20) + '<span>حذف این واژه</span>' });
    del.addEventListener('click', function () { L.close(true); deleteWord(rec); });
    body.appendChild(h('div', { style: 'height:6px' })); body.appendChild(del);
  }
  var node = h('div', { class: 'layer' }, [h('div', { class: 'editor wform' }, [
    h('div', { class: 'topbar' }, [closeBtn, h('h3', { text: rec ? 'ویرایش واژه' : 'واژه‌ی جدید' }), saveBtn]), body])]);
  var L;
  function drawLg() {
    lgRow.textContent = '';
    var cur = wordLang(wIn.value, '', '');
    var curName = LANG_NAME[cur] || 'انگلیسی';
    var opts = [['', 'تشخیص خودکار (' + curName + ')']];
    APP_LANGS.forEach(function (k) {
      opts.push([k, LANG_META[k].badge + ' · ' + LANG_META[k].name]);
    });
    opts.forEach(function (c) {
      var chip = h('button', { class: 'chip sm' + (lgSel === c[0] ? ' on' : ''), type: 'button', 'data-lg': c[0], text: c[1] });
      chip.addEventListener('click', function () { lgSel = c[0]; drawLg(); });
      lgRow.appendChild(chip);
    });
  }
  drawLg();
  wIn.addEventListener('input', function () { if (!lgSel) drawLg(); });
  function changed() { return wIn.value !== f0.w || mIn.value !== f0.m || lgSel !== f0.lg; }
  function tryClose() {
    if (!changed()) { L.close(true); return; }
    dialog({ title: 'تغییرات ذخیره نشده', message: 'می‌خواهید بدون ذخیره خارج شوید؟', ok: 'خروج', danger: true, cancel: 'ادامه' })
      .then(function (r) { if (r) L.close(true); });
  }
  L = openLayer(node, { onBack: tryClose });
  closeBtn.addEventListener('click', tryClose);
  sayB.addEventListener('click', function () { var w = wIn.value.trim(); if (w) speakWord(w, '', lgSel || wordLang(w, '', '')); else toast('اول واژه را بنویسید'); });
  look.addEventListener('click', function () { lookupMenu(look, wIn.value, lgSel); });
  function runSuggest() {
    var w = wIn.value.replace(/\s+/g, ' ').trim();
    if (!w) { toast('اول واژه را بنویسید'); wIn.focus(); return; }
    netEnsure(function () { suggestInto(sugBox, w, mIn, { lg: lgSel }); });
  }
  sugB.addEventListener('click', runSuggest);
  function finish(target, w, m, lg) {
    var now = Date.now();
    var resolvedLg = (lg && LANG_META[lg]) ? lg : wordLang(w, '', '');
    if (!LANG_META[resolvedLg]) resolvedLg = 'en';
    if (target) {
      target.w = w; target.m = m; target.ex = ''; target.updated = now; target.lg = resolvedLg;
      if (src && src.bk && !target.bk) { target.bid = src.bid || ''; target.bk = src.bk; target.pg = src.pg | 0; }
    } else {
      S.data.words.push(newWord({ w: w, m: m, lg: resolvedLg, bid: src && src.bid, bk: src && src.bk, pg: src && src.pg }));
    }
    scheduleSave(); flushSave();
    L.close(true);
    if (S.view === 'library') { if (S.libTab === 'words') renderWords(); else if (S.libTab === 'quick') { updateWordCount(); renderQuickReview(); } else updateWordCount(); } else updateWordCount();
    var lgTitle = LANG_META[resolvedLg] ? LANG_META[resolvedLg].name : '';
    toast(target ? ('واژه در بخش «' + lgTitle + '» بروزرسانی شد') : ('به بخش لغات «' + lgTitle + '» اضافه شد'));
  }
  saveBtn.addEventListener('click', function () {
    var w = wIn.value.replace(/\s+/g, ' ').trim(), m = mIn.value.trim();
    if (!w) { toast('واژه را بنویسید'); wIn.focus(); return; }
    var resolvedLg = (lgSel && LANG_META[lgSel]) ? lgSel : wordLang(w, '', '');
    if (!LANG_META[resolvedLg]) resolvedLg = 'en';
    var dup = wordByKey(wkey(w), resolvedLg);
    if (dup && (!rec || dup.id !== rec.id)) {
      dialog({ title: 'واژه‌ی تکراری در بخش ' + LANG_META[resolvedLg].name, message: 'این واژه قبلاً در بخش «' + LANG_META[resolvedLg].name + '» ذخیره شده است. معنی جدید به همان واژه اضافه شود؟', ok: 'اضافه شود' }).then(function (r) {
        if (!r) return;
        var m2 = !dup.m ? m : (!m || dup.m === m || dup.m.indexOf(m) >= 0 ? dup.m : dup.m + '\n' + m);
        if (rec) { var i = S.data.words.indexOf(rec); if (i >= 0) S.data.words.splice(i, 1); }
        finish(dup, dup.w, m2, resolvedLg);
      });
      return;
    }
    finish(rec, w, m, resolvedLg);
  });
  var auto = !rec && !!o.src && !!f0.w && !f0.m && S.data.settings.net === true && bridge('httpGet');
  if (auto) setTimeout(runSuggest, 300);
  else setTimeout(function () { (f0.w ? mIn : wIn).focus(); }, 120);
  return L;
}
function wordFromBar(mode, hid) {
  var pg = currentPage(), b = curBook(); if (!pg || !b) return;
  var s = -1, e = -1;
  if (mode === 'hl') {
    var x = pg.hl.filter(function (q) { return q.id === hid; })[0];
    if (x) { s = x.s; e = x.e; }
  } else {
    var t = selectionTarget();
    if (t) { s = t.s; e = t.e; }
  }
  if (s < 0 || e <= s) { hideBar(); return; }
  var raw = pg.text.slice(s, e).replace(/\s+/g, ' ').trim().replace(LATIN_OR_ARABIC_PUNCT, '');
  if (!raw) { hideBar(); return; }
  hideBar(); clearSel();
  var src = { bid: b.id, bk: b.title, pg: S.index + 1 };
  var guessedLg = wordLang(raw, pg.text.slice(Math.max(0, s - 60), Math.min(pg.text.length, e + 60)), '');
  var dup = wordByKey(wkey(raw), guessedLg);
  if (dup) { toast('این واژه از قبل در بخش ' + (LANG_META[guessedLg] ? LANG_META[guessedLg].name : '') + ' ذخیره شده بود'); wordForm({ id: dup.id, src: src }); }
  else wordForm({ w: raw.slice(0, 160), lg: guessedLg, src: src });
}

/* ---------- مرور (کارت‌های دوسویه با فاصله‌گذاری لایتنر + تفکیک زبان) ---------- */
function shuffle(a) {
  for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; }
  return a;
}
function reviewStart(mode, langCode) {
  var now = Date.now();
  var targetLg = langCode || (S.libTab === 'quick' ? qLangFilter : wLangFilter);
  var pool = S.data.words.filter(function (x) {
    if (targetLg && targetLg !== 'all' && getWordEffLang(x) !== targetLg) return false;
    return mode === 'all' || x.due <= now;
  });
  if (!pool.length && mode !== 'all') {
    pool = S.data.words.filter(function (x) {
      return !targetLg || targetLg === 'all' || getWordEffLang(x) === targetLg;
    });
  }
  if (!pool.length) { toast('واژه‌ای در این بخش برای مرور نیست'); return; }
  pool = shuffle(pool.slice());
  if (pool.length > 40) pool = pool.slice(0, 40);
  reviewOpen(pool, targetLg);
}
function reviewOpen(queue, langCode) {
  var plan = queue.length, shown = 0, known = 0, again = 0, retried = {}, cur = null, flipped = false, finished = false;
  var closeBtn = h('button', { class: 'ibtn', 'aria-label': 'بستن مرور', html: ic('x') });
  var counter = h('span', { class: 'rv-count' });
  var fill = h('i');
  var front = h('div', { class: 'rv-face rv-front' });
  var back = h('div', { class: 'rv-face rv-back' });
  var card = h('div', { class: 'rv-card', role: 'button', tabindex: 0, 'aria-label': 'برگرداندن کارت' }, [front, back]);
  var stageEl = h('div', { class: 'rv-stage' }, [card]);
  var showB = h('button', { class: 'btn pri block', id: 'rvShow', text: 'نمایش معنی' });
  var noB = h('button', { class: 'btn', id: 'rvNo', html: ic('rotate', 20) + '<span>هنوز نه</span>' });
  var yesB = h('button', { class: 'btn pri', id: 'rvYes', html: ic('check', 20) + '<span>بلدم</span>' });
  var acts = h('div', { class: 'rv-acts' }, [showB]);
  var headerTitle = (langCode && langCode !== 'all' && LANG_META[langCode]) ? ('مرور واژه‌های ' + LANG_META[langCode].name) : 'مرور واژه‌ها';
  var node = h('div', { class: 'layer' }, [h('div', { class: 'editor review' }, [
    h('div', { class: 'topbar' }, [closeBtn, h('h3', { text: headerTitle }), counter]),
    h('div', { class: 'rv-bar' }, [fill]), stageEl, acts])]);
  var L = openLayer(node, { onBack: close });
  function close() {
    if (finished === 'closed') return;
    finished = 'closed';
    L.close(true);
    if (S.view === 'library' && S.libTab === 'words') renderWords();
    else if (S.view === 'library' && S.libTab === 'quick') renderQuickReview();
    else updateWordCount();
  }
  function setFlip(v) {
    flipped = v;
    card.classList.toggle('flip', v);
    acts.textContent = '';
    if (v) { acts.appendChild(noB); acts.appendChild(yesB); } else acts.appendChild(showB);
  }
  function fillFaces(x) {
    front.textContent = ''; back.textContent = '';
    var wl = getWordEffLang(x);
    var meta = LANG_META[wl] || LANG_META.en;
    var sp = h('button', { class: 'ibtn rv-say', 'aria-label': 'تلفظ', html: ic('speaker', 24) });
    sp.addEventListener('click', function (e) { e.stopPropagation(); speakWord(x.w, '', wl); });
    front.appendChild(h('span', { class: 'lang-pill-badge', style: '--lang-clr:' + meta.color + ';margin-bottom:10px', text: meta.badge + ' · ' + meta.name }));
    front.appendChild(h('div', { class: 'rv-word', dir: 'auto', text: x.w }));
    if (wl !== 'fa') front.appendChild(sp);
    front.appendChild(h('div', { class: 'rv-tip', text: 'معنی‌اش را به یاد بیاورید، بعد کارت را بزنید' }));
    back.appendChild(h('span', { class: 'lang-pill-badge', style: '--lang-clr:' + meta.color + ';margin-bottom:8px', text: meta.badge + ' · ' + meta.name }));
    back.appendChild(h('div', { class: 'rv-word sm', dir: 'auto', text: x.w }));
    back.appendChild(x.m ? h('div', { class: 'rv-mean', dir: 'auto', text: x.m }) : h('div', { class: 'rv-mean none', text: 'معنی ثبت نشده؛ بعداً از فهرست واژه‌ها ویرایشش کنید.' }));
    if (x.bk) { var s = h('div', { class: 'rv-src', html: ic('book', 14) + '<span></span>' }); s.lastChild.textContent = x.bk + (x.pg ? ' · صفحه ' + fa(x.pg) : ''); back.appendChild(s); }
  }
  function updateHead() {
    counter.textContent = fa(Math.min(shown + 1, plan)) + ' از ' + fa(plan);
    fill.style.width = (plan ? Math.min(100, shown / plan * 100) : 0) + '%';
  }
  function next() {
    if (!queue.length) { done(); return; }
    cur = queue.shift();
    card.classList.remove('flip'); flipped = false;
    fillFaces(cur); setFlip(false); updateHead();
  }
  function done() {
    finished = true;
    fill.style.width = '100%'; counter.textContent = '';
    stageEl.textContent = ''; acts.textContent = '';
    stageEl.appendChild(h('div', { class: 'rv-done' }, [
      h('div', { class: 'rv-done-ic', html: ic('check', 44) }),
      h('h3', { text: 'مرور تمام شد' }),
      h('p', { text: fa(known) + ' واژه را بلد بودید' + (again ? '، ' + fa(again) + ' بار «هنوز نه» زدید و برای مرور بعدی می‌مانند.' : '.') })]));
    var ok = h('button', { class: 'btn pri block', id: 'rvClose', text: 'بستن' });
    ok.addEventListener('click', close);
    acts.appendChild(ok);
  }
  function answer(good) {
    var now = Date.now();
    cur.seen++; cur.updated = now; shown++;
    if (good) { cur.box = Math.min(5, cur.box + 1); cur.due = now + BOX_DAYS[cur.box] * DAY_MS; known++; }
    else {
      cur.box = 0; cur.due = 0; again++;
      if (!retried[cur.id]) { retried[cur.id] = 1; queue.push(cur); plan++; }
    }
    scheduleSave();
    next();
  }
  card.addEventListener('click', function () { if (finished) return; setFlip(!flipped); });
  showB.addEventListener('click', function () { setFlip(true); });
  noB.addEventListener('click', function () { answer(false); });
  yesB.addEventListener('click', function () { answer(true); });
  closeBtn.addEventListener('click', close);
  next();
}

/* =====================================================================
   یادداشت‌ها: جستجو، بایگانی، طبقه‌بندی (دسته‌بندی)، سنجاق و رنگ‌بندی
   ===================================================================== */
var nFilter = 'active'; // 'active' | 'archived' | 'pinned'
var nCat = 'all';
var nQuery = '';

function noteById(id) {
  for (var i = 0; i < S.data.notes.length; i++) if (S.data.notes[i].id === id) return S.data.notes[i];
  return null;
}
/* ---------- خوانش صوتی یادداشت‌ها (Notes TTS v2.0) ---------- */
function buildNoteSegments(notesArr) {
  var segs = [], prevLang = null;
  notesArr.forEach(function (nt) {
    if (isNoteLocked(nt)) return;
    var bodyTxt = getNoteText(nt);
    var full = (nt.title && nt.title !== 'بدون عنوان' ? nt.title + '.\n' : '') + (bodyTxt || '');
    if (!full.trim()) return;
    sentenceRanges(full).forEach(function (r) {
      langRuns(full, r[0], r[1], prevLang).forEach(function (run) {
        var parts = [];
        chunkRange(full, run.s, run.e, parts);
        parts.forEach(function (pr) {
          var s = pr[0], e = pr[1];
          while (s < e && /\s/.test(full.charAt(s))) s++;
          while (e > s && /\s/.test(full.charAt(e - 1))) e--;
          if (e <= s) return;
          var t = full.slice(s, e);
          if (!RE_SPEAK.test(t)) return;
          var lg = run.l || 'fa';
          prevLang = lg;
          segs.push({ nid: nt.id, ntitle: nt.title || 'یادداشت', p: 0, s: s, e: e, l: lg, t: t });
        });
      });
    });
  });
  return segs;
}

function speakNotesList(notesArr, startNoteId) {
  if (!ttsAvailable()) { toast('خوانش صوتی در این دستگاه پشتیبانی نمی‌شود'); return; }
  if (!notesArr || !notesArr.length) { toast('یادداشتی برای خوانش وجود ندارد'); return; }
  var segs = buildNoteSegments(notesArr);
  if (!segs.length) { toast('متن قابل‌خوانش در این یادداشت پیدا نشد'); return; }
  var start = 0;
  if (startNoteId) {
    for (var i = 0; i < segs.length; i++) {
      if (segs[i].nid === startNoteId) { start = i; break; }
    }
  }
  var st = S.data.settings;
  S.tts = {
    book: null,
    note: true,
    noteId: segs[start].nid,
    segs: segs,
    idx: start,
    cur: segs[start],
    state: 'loading',
    lastPid: null,
    sample: false
  };
  try {
    if (bridge('ttsStart')) {
      A.ttsStart(JSON.stringify(segs.map(function (g) { return { p: 0, s: g.s, e: g.e, l: g.l, t: g.t }; })), start, st.ttsRate, st.ttsPitch);
    } else if (!webTtsStart(segs, start, st.ttsRate, st.ttsPitch)) {
      throw new Error('no tts');
    }
  } catch (e) {
    S.tts = null;
    toast('شروع خوانش صوتی یادداشت انجام نشد');
  }
  updateTtsBar();
  updateSpeakingNoteCards();
}

function speakNote(x) {
  if (!x) return;
  ensureNoteUnlocked(x, function () {
    if (S.tts && S.tts.note && S.tts.noteId === x.id) {
      if (S.tts.state === 'playing' || S.tts.state === 'paused') {
        ttsToggle();
        return;
      }
    }
    speakNotesList([x], x.id);
  });
}

function speakNoteRaw(title, text) {
  var temp = { id: '__form__', title: title || 'یادداشت', text: text || '' };
  if (S.tts && S.tts.note && S.tts.noteId === '__form__') {
    ttsStop();
    return;
  }
  speakNotesList([temp], '__form__');
}

function updateSpeakingNoteCards() {
  var activeId = S.tts && S.tts.note ? S.tts.noteId : null;
  var playing = S.tts && S.tts.note && S.tts.state === 'playing';
  var noteSc = $('#noteList');
  $$('.ncard').forEach(function (card) {
    var id = card.getAttribute('data-id');
    var isCur = !!(activeId && id === activeId);
    card.classList.toggle('speaking', isCur);
    var btn = $('.nsay', card);
    if (btn) {
      btn.classList.toggle('on', isCur);
      btn.innerHTML = ic(isCur && playing ? 'pause' : 'speaker', 18);
    }
    if (isCur && noteSc && S.view === 'library' && S.libTab === 'notes') {
      scrollContainerToElement(noteSc, card, 0.24);
    }
  });
}

function updateNoteCount() {
  var el = $('#noteCnt');
  if (!el || !S.data || !S.data.notes) return;
  var all = S.data.notes, activeCnt = 0;
  for (var i = 0; i < all.length; i++) if (!all[i].archived) activeCnt++;
  el.textContent = activeCnt ? fa(activeCnt) : '';
}

/* ---------- خوانش و حرکت گام‌به‌گام رو به پایین در مرور سریع و لغات ---------- */
function stopQuickAutoWalk() {
  if (qWalkTimer) {
    clearInterval(qWalkTimer);
    qWalkTimer = null;
  }
  var wBtn = $('#qAutoWalkBtn');
  if (wBtn) {
    wBtn.classList.remove('on');
    wBtn.innerHTML = ic('autoDown', 16) + '<span>حرکت و مرور خودکار</span>';
  }
}

function stepQuickWord(delta, shouldSpeak) {
  var words = getQuickWordsOrdered();
  if (!words.length) { toast('لغتی برای حرکت وجود ندارد'); return; }
  var curIdx = -1;
  var refId = (S.tts && S.tts.vocabSeq && S.tts.wordId) ? S.tts.wordId : qActiveWid;
  if (refId) {
    for (var i = 0; i < words.length; i++) {
      if (words[i].id === refId) { curIdx = i; break; }
    }
  }
  var nextIdx = curIdx < 0 ? 0 : clamp(curIdx + delta, 0, words.length - 1);
  var targetWord = words[nextIdx];
  qActiveWid = targetWord.id;

  var sc = S.libTab === 'words' ? ($('#wCards') || $('#wordList')) : $('#quickList');
  $$('.nvocab-row, .wcard').forEach(function (row) {
    var wid = row.getAttribute('data-wid') || row.getAttribute('data-id');
    var on = wid === qActiveWid;
    row.classList.toggle('active-step', on);
    if (on && sc) {
      scrollContainerToElement(sc, row, 0.24);
    }
  });
  var stepStatus = $('#qStepStatus');
  if (stepStatus) {
    var wl = getWordEffLang(targetWord);
    stepStatus.textContent = 'لغت ' + fa(nextIdx + 1) + ' از ' + fa(words.length) + ' · ' + (LANG_META[wl] ? LANG_META[wl].name : '') + ' · «' + snippet(targetWord.w, 24) + '»';
  }
  if (shouldSpeak && ttsAvailable() && getWordEffLang(targetWord) !== 'fa') {
    speakWord(targetWord.w, '', getWordEffLang(targetWord));
  }
  setTimeout(syncAllScrollSliders, 200);
}

function toggleQuickAutoWalk() {
  if (qWalkTimer) {
    stopQuickAutoWalk();
    return;
  }
  var words = getQuickWordsOrdered();
  if (!words.length) { toast('لغتی در جدول مرور سریع نیست'); return; }
  var spd = getAutoSpeedVal();
  var intervalMs = Math.max(900, Math.round(2400 / spd));
  stepQuickWord(0, true);
  var wBtn = $('#qAutoWalkBtn');
  if (wBtn) {
    wBtn.classList.add('on');
    wBtn.innerHTML = ic('pause', 16) + '<span>توقف حرکت خودکار</span>';
  }
  qWalkTimer = setInterval(function () {
    var list = getQuickWordsOrdered();
    if (!list.length) { stopQuickAutoWalk(); return; }
    var idx = -1;
    for (var i = 0; i < list.length; i++) if (list[i].id === qActiveWid) { idx = i; break; }
    if (idx >= list.length - 1) {
      stopQuickAutoWalk();
      toast('مرور گام‌به‌گام به پایان فهرست رسید');
      return;
    }
    stepQuickWord(1, true);
  }, intervalMs);
}

function speakWordsColumn(wordsArr, startIndex) {
  stopQuickAutoWalk();
  if (S.tts && S.tts.vocabSeq && startIndex == null) {
    if (S.tts.state === 'playing' || S.tts.state === 'paused') {
      ttsStop();
      return;
    }
  }
  var list = (wordsArr && wordsArr.length) ? wordsArr : getQuickWordsOrdered();
  if (!list || !list.length) { toast('لغتی برای خوانش ثبت نشده است'); return; }
  if (!ttsAvailable()) {
    toggleQuickAutoWalk();
    return;
  }
  var segs = [];
  list.forEach(function (x) {
    var w = String(x.w || '').trim();
    if (!w) return;
    var lg = getWordEffLang(x) || 'en';
    segs.push({
      wid: x.id,
      nid: x.id,
      ntitle: w,
      p: 0,
      s: 0,
      e: w.length,
      l: lg,
      t: w
    });
  });
  if (!segs.length) { toast('لغت قابل‌خوانش پیدا نشد'); return; }
  var start = clamp(startIndex | 0, 0, segs.length - 1);
  var st = S.data.settings;
  qActiveWid = segs[start].wid;
  S.tts = {
    book: null,
    note: true,
    vocabSeq: true,
    wordId: segs[start].wid,
    noteId: segs[start].wid,
    segs: segs,
    idx: start,
    cur: segs[start],
    state: 'loading',
    lastPid: null,
    sample: false
  };
  try {
    if (bridge('ttsStart')) {
      A.ttsStart(JSON.stringify(segs.map(function (g) { return { p: 0, s: g.s, e: g.e, l: g.l, t: g.t }; })), start, st.ttsRate, st.ttsPitch);
    } else if (!webTtsStart(segs, start, st.ttsRate, st.ttsPitch)) {
      throw new Error('no tts');
    }
  } catch (e) {
    S.tts = null;
    toggleQuickAutoWalk();
    return;
  }
  updateTtsBar();
  updateSpeakingVocabRows(true);
}

function updateSpeakingVocabRows(shouldScroll) {
  var isSeq = !!(S.tts && S.tts.vocabSeq);
  var activeWid = isSeq ? S.tts.wordId : null;
  if (activeWid) qActiveWid = activeWid;
  var playing = isSeq && S.tts.state === 'playing';
  var sc = S.libTab === 'words' ? $('#wordList') : $('#quickList');
  $$('.nvocab-row, .wcard').forEach(function (row) {
    var wid = row.getAttribute('data-wid') || row.getAttribute('data-id');
    var on = !!(activeWid && wid === activeWid);
    row.classList.toggle('speaking', on);
    if (on) row.classList.add('active-step');
    else if (isSeq) row.classList.remove('active-step');
    if (on && (shouldScroll !== false) && sc) {
      scrollContainerToElement(sc, row, 0.24);
    }
  });
  if (isSeq && S.tts.cur) {
    var stepStatus = $('#qStepStatus');
    if (stepStatus) {
      var wl = S.tts.cur.l;
      stepStatus.textContent = 'در حال خوانش لغت ' + fa(S.tts.idx + 1) + ' از ' + fa(S.tts.segs.length) + (LANG_META[wl] ? ' · ' + LANG_META[wl].name : '') + ' · «' + snippet(S.tts.cur.t, 24) + '»';
    }
  }
  var readBtn = $('#nVocabReadBtn');
  if (readBtn) {
    readBtn.classList.toggle('on', isSeq);
    readBtn.innerHTML = ic(playing ? 'pause' : 'speaker', 18) + '<span>' + (isSeq ? 'توقف خوانش' : 'خوانش و حرکت به پایین') + '</span>';
  }
  setTimeout(syncAllScrollSliders, 180);
}

var qSearch = '';
function getQuickWords(forceLang) {
  var q = qSearch.trim().toLowerCase();
  var targetLg = forceLang !== undefined ? forceLang : qLangFilter;
  return S.data.words.filter(function (x) {
    if (targetLg && targetLg !== 'all' && getWordEffLang(x) !== targetLg) return false;
    if (q && (x.w + ' ' + x.m).toLowerCase().indexOf(q) < 0) return false;
    return true;
  }).sort(function (a, b) { return b.created - a.created; });
}

/* ترتیب دقیق نمایش لغات در جدول‌های زبان‌بندی‌شده‌ی مرور سریع */
function getQuickWordsOrdered() {
  var langs = qLangFilter === 'all' ? APP_LANGS : [qLangFilter];
  var out = [];
  langs.forEach(function (lk) {
    var items = getQuickWords(lk);
    for (var i = 0; i < items.length; i++) out.push(items[i]);
  });
  return out;
}

var debouncedRenderQuickTable = debounce(renderQuickTable, 80);
function renderQuickReview() {
  var list = $('#quickList');
  if (!list) return;
  list.textContent = '';
  updateWordCount();

  var qFs = S.data && S.data.settings ? (+S.data.settings.fontSize || 10) : 10;
  document.documentElement.style.setProperty('--qfs', qFs + 'px');

  var topStrip = buildUnifiedSectionStrip('quick', qLangFilter, function (newLg) {
    qLangFilter = newLg;
    renderQuickReview();
    updateTopTabLabels();
  });
  list.appendChild(topStrip);

  var words = getQuickWordsOrdered();
  var isSeq = !!(S.tts && S.tts.vocabSeq);
  var isPlaying = isSeq && S.tts.state === 'playing';

  var aDnBtn = h('button', {
    class: 'btn-exp js-auto-dn' + (AutoScroll.active && AutoScroll.dir > 0 ? ' on-accent' : ''),
    type: 'button',
    title: 'اسکرول خودکار رو به پایین',
    html: ic('autoDown', 14) + '<span>اسکرول خودکار</span>'
  });
  var spdBtn = h('button', {
    class: 'btn-exp spd js-auto-spd',
    type: 'button',
    title: 'سرعت اسکرول خودکار',
    text: fa(getAutoSpeedVal()) + '×'
  });
  aDnBtn.addEventListener('click', function () { toggleAutoScroll(1); });
  spdBtn.addEventListener('click', cycleAutoScrollSpeed);

  var readAllWordsBtn = h('button', {
    class: 'btn-exp on-accent' + (isSeq ? ' on' : ''),
    id: 'nVocabReadBtn',
    type: 'button',
    html: ic(isPlaying ? 'pause' : 'speaker', 15) + '<span>' + (isSeq ? 'توقف خوانش' : 'خوانش خودکار') + '</span>'
  });
  var addWordBtn = h('button', { class: 'btn-exp', type: 'button', html: ic('plus', 14) + '<span>+ لغت</span>' });
  var qPdfBtn = h('button', { class: 'btn-exp pdf', type: 'button', html: ic('pdf', 14) + '<span>PDF</span>' });
  var qWordBtn = h('button', { class: 'btn-exp word', type: 'button', html: ic('word', 14) + '<span>Word</span>' });
  var qMdBtn = h('button', { class: 'btn-exp md', type: 'button', html: ic('md', 14) + '<span>MD</span>' });
  var qJsBtn = h('button', { class: 'btn-exp js', type: 'button', html: ic('js', 14) + '<span>JS</span>' });

  readAllWordsBtn.addEventListener('click', function () { speakWordsColumn(getQuickWordsOrdered(), null); });
  addWordBtn.addEventListener('click', function () { wordForm(qLangFilter !== 'all' ? { lg: qLangFilter } : {}); });
  qPdfBtn.addEventListener('click', function () { exportQuickTable(getQuickWordsOrdered(), 'pdf'); });
  qWordBtn.addEventListener('click', function () { exportQuickTable(getQuickWordsOrdered(), 'word'); });
  qMdBtn.addEventListener('click', function () { exportQuickTable(getQuickWordsOrdered(), 'md'); });
  qJsBtn.addEventListener('click', function () { exportQuickTable(getQuickWordsOrdered(), 'js'); });

  var qInput = h('input', {
    class: 'field compact-search',
    id: 'qVocabSearch',
    type: 'search',
    dir: 'auto',
    placeholder: 'جستجو در جدول مرور سریع…',
    'aria-label': 'جستجوی لغت در مرور سریع'
  });
  qInput.value = qSearch;
  qInput.addEventListener('input', function () {
    qSearch = qInput.value;
    debouncedRenderQuickTable();
  });

  var headBar = h('div', { class: 'uni-toolbar words-toolbar quick-toolbar-clean' }, [
    h('div', { class: 'uni-tb-row1' }, [
      h('b', { id: 'qStepStatus', text: 'مرور سریع (' + fa(words.length) + ' لغت · فونت ' + fa(qFs) + ')' }),
      h('div', { class: 'uni-tb-acts' }, [readAllWordsBtn, aDnBtn, spdBtn, addWordBtn, qPdfBtn, qWordBtn, qMdBtn, qJsBtn])
    ]),
    S.data.words.length > 0 ? h('div', { class: 'uni-tb-row2' }, [qInput]) : null
  ]);

  var tableHost = h('div', { id: 'qVocabTableHost', class: 'quick-tables-wrap' });
  list.appendChild(headBar);
  list.appendChild(tableHost);
  renderQuickTable();
}

function renderQuickTable() {
  var host = $('#qVocabTableHost');
  if (!host) return;
  host.textContent = '';
  var isSeq = !!(S.tts && S.tts.vocabSeq);

  if (!S.data.words.length) {
    var eGrid = h('div', { class: 'lang-empty-grid' });
    APP_LANGS.forEach(function (lk) {
      var m = LANG_META[lk];
      var c = h('button', { class: 'lang-empty-card', type: 'button' }, [
        h('span', { class: 'lang-pill-badge', style: '--lang-clr:' + m.color, text: m.badge }),
        h('span', { style: 'flex:1', text: 'جدول ' + m.name }),
        h('span', { style: 'color:var(--accent);font-weight:800', text: '+ ثبت لغت' })
      ]);
      c.addEventListener('click', function () { wordForm({ lg: lk }); });
      eGrid.appendChild(c);
    });
    host.appendChild(h('div', { class: 'nvocab-empty' }, [
      h('div', { text: 'هنوز لغتی ثبت نشده است. برای هر زبان (انگلیسی، فرانسوی، ترکی، آلمانی، عربی و فارسی) یک جدول مجزا در مرور سریع ساخته می‌شود:' }),
      eGrid
    ]));
    return;
  }

  var langsToShow = qLangFilter === 'all' ? APP_LANGS : [qLangFilter];
  var frag = document.createDocumentFragment();
  var emptyLangs = [];
  var totalRendered = 0;

  langsToShow.forEach(function (lk) {
    var meta = LANG_META[lk];
    var langWords = getQuickWords(lk);
    if (!langWords.length) {
      emptyLangs.push(lk);
      return;
    }
    totalRendered += langWords.length;

    var addLangBtn = h('button', { class: 'ssb-btn', type: 'button', title: 'افزودن لغت به بخش ' + meta.name, html: ic('plus', 14) + '<span>لغت ' + meta.short + '</span>' });
    var readLangBtn = h('button', { class: 'ssb-btn on', type: 'button', title: 'خوانش و حرکت رو به پایین در لغات ' + meta.name, html: ic('speaker', 14) + '<span>خوانش ' + meta.short + ' ▼</span>' });
    var revLangBtn = h('button', { class: 'ssb-btn', type: 'button', title: 'مرور فلش‌کارت ' + meta.name, html: ic('layers', 14) + '<span>فلش‌کارت</span>' });
    var pdfLangBtn = h('button', { class: 'btn-exp pdf', style: 'height:30px;padding:0 8px', type: 'button', html: ic('pdf', 14) + '<span>PDF</span>' });
    var wordLangBtn = h('button', { class: 'btn-exp word', style: 'height:30px;padding:0 8px', type: 'button', html: ic('word', 14) + '<span>Word</span>' });
    var mdLangBtn = h('button', { class: 'btn-exp md', style: 'height:30px;padding:0 8px', type: 'button', html: ic('md', 14) + '<span>MD</span>' });
    var jsLangBtn = h('button', { class: 'btn-exp js', style: 'height:30px;padding:0 8px', type: 'button', html: ic('js', 14) + '<span>JS</span>' });

    addLangBtn.addEventListener('click', function () { wordForm({ lg: lk }); });
    readLangBtn.addEventListener('click', function () { speakWordsColumn(langWords, 0); });
    revLangBtn.addEventListener('click', function () { reviewStart('all', lk); });
    pdfLangBtn.addEventListener('click', function () { exportWordsList(langWords, 'pdf', 'مرور سریع لغات ' + meta.name); });
    wordLangBtn.addEventListener('click', function () { exportWordsList(langWords, 'word', 'مرور سریع لغات ' + meta.name); });
    mdLangBtn.addEventListener('click', function () { exportWordsList(langWords, 'md', 'مرور سریع لغات ' + meta.name); });
    jsLangBtn.addEventListener('click', function () { exportWordsList(langWords, 'js', 'مرور سریع لغات ' + meta.name); });

    var colHeaders = h('div', { class: 'nvocab-cols-hdr' }, [
      h('div', { class: 'nvocab-col-left', text: 'لغات ' + meta.name + ' (' + meta.badge + ')' }),
      h('div', { class: 'nvocab-col-right', text: 'معنی لغات' })
    ]);
    var rowsBox = h('div', { class: 'nvocab-rows quick-full' });

    langWords.forEach(function (wItem, idx) {
      var rowActive = !!((isSeq && S.tts.wordId === wItem.id) || qActiveWid === wItem.id);
      var wordCell = h('div', { class: 'nvocab-cell-word', dir: 'auto' }, [
        h('span', { class: 'nvocab-idx', text: fa(idx + 1) }),
        h('span', { class: 'nvocab-wtxt', text: wItem.w }),
        h('button', {
          class: 'ibtn nvocab-say',
          type: 'button',
          title: 'خوانش ترتیبی و حرکت به پایین از این لغت',
          'aria-label': 'خوانش از این لغت',
          html: ic('speaker', 16)
        })
      ]);
      var meanCell = h('div', {
        class: 'nvocab-cell-mean' + (wItem.m ? '' : ' none'),
        dir: 'auto',
        text: wItem.m || 'بدون معنی (برای ثبت بزنید)'
      });
      var row = h('div', {
        class: 'nvocab-row' + (rowActive ? ' speaking active-step' : ''),
        'data-wid': wItem.id,
        'data-lang': lk,
        role: 'button',
        tabindex: 0
      }, [wordCell, meanCell]);

      var sayFromHereBtn = $('.nvocab-say', wordCell);
      sayFromHereBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        qActiveWid = wItem.id;
        scrollContainerToElement($('#quickList'), row, 0.24);
        speakWordsColumn(langWords, idx);
      });
      row.addEventListener('click', function () {
        qActiveWid = wItem.id;
        $$('.nvocab-row', host).forEach(function (r) { r.classList.toggle('active-step', r === row); });
        scrollContainerToElement($('#quickList'), row, 0.24);
        wordForm({ id: wItem.id });
      });
      rowsBox.appendChild(row);
    });

    var langBlock = h('div', { class: 'nvocab-lang-sec', 'data-lang-table': lk, style: '--lang-clr:' + meta.color }, [
      h('div', { class: 'nvocab-lang-hdr' }, [
        h('div', { class: 'nvocab-lang-title' }, [
          h('span', { class: 'lang-pill-badge', text: meta.badge }),
          h('div', { class: 'wlang-tbox' }, [
            h('b', { text: 'بخش مرور سریع ' + meta.name }),
            h('span', { text: fa(langWords.length) + ' لغت در ردیف اختصاصی زبان ' + meta.name })
          ])
        ]),
        h('div', { class: 'wlang-acts' }, [addLangBtn, readLangBtn, revLangBtn, pdfLangBtn, wordLangBtn, mdLangBtn, jsLangBtn])
      ]),
      h('div', { class: 'nvocab-table' }, [colHeaders, rowsBox])
    ]);
    frag.appendChild(langBlock);
  });

  if (!totalRendered) {
    var emptyMsg = qLangFilter !== 'all' && LANG_META[qLangFilter]
      ? 'هنوز لغتی در بخش مرور سریع زبان «' + LANG_META[qLangFilter].name + '» ذخیره نشده است.'
      : 'لغتی با این عبارت پیدا نشد.';
    var empNode = h('div', { class: 'nvocab-empty' }, [h('div', { text: emptyMsg })]);
    if (qLangFilter !== 'all' && LANG_META[qLangFilter]) {
      var addB = h('button', { class: 'btn pri', style: 'margin-top:10px', type: 'button', html: ic('plus', 18) + '<span>افزودن اولین لغت ' + LANG_META[qLangFilter].name + '</span>' });
      addB.addEventListener('click', function () { wordForm({ lg: qLangFilter }); });
      empNode.appendChild(addB);
    }
    frag.appendChild(empNode);
  }

  if (qLangFilter === 'all' && emptyLangs.length && !qSearch.trim()) {
    var eg = h('div', { class: 'lang-empty-grid' });
    emptyLangs.forEach(function (lk) {
      var m = LANG_META[lk];
      var card = h('button', { class: 'lang-empty-card', type: 'button' }, [
        h('span', { class: 'lang-pill-badge', style: '--lang-clr:' + m.color, text: m.badge }),
        h('span', { style: 'flex:1', text: 'جدول ' + m.name + ' (خالی)' }),
        h('span', { style: 'color:var(--accent);font-weight:800', text: '+ افزودن' })
      ]);
      card.addEventListener('click', function () { wordForm({ lg: lk }); });
      eg.appendChild(card);
    });
    frag.appendChild(h('div', { class: 'nvocab-lang-sec', style: '--lang-clr:var(--muted);margin-bottom:0' }, [
      h('div', { class: 'wlang-tbox', style: 'margin-bottom:6px' }, [
        h('b', { style: 'font-size:13px', text: 'سایر زبان‌ها در مرور سریع (بدون ادغام با زبان‌های دیگر):' })
      ]),
      eg
    ]));
  }

  host.appendChild(frag);
}

var debouncedRenderNoteCards = debounce(renderNoteCards, 80);
function renderNotes() {
  var list = $('#noteList');
  if (!list) return;
  list.textContent = '';
  updateNoteCount();

  var topStrip = buildUnifiedSectionStrip('notes', nLangFilter, function (newLg) {
    nLangFilter = newLg;
    nPageIdx = 0;
    renderNotes();
    updateTopTabLabels();
  });

  var all = S.data.notes.filter(function (x) {
    return nLangFilter === 'all' || getNoteEffLang(x) === nLangFilter;
  });
  var activeCnt = all.filter(function (x) { return !x.archived; }).length;
  var pinnedCnt = all.filter(function (x) { return x.pinned && !x.archived; }).length;
  var lockedCnt = all.filter(function (x) { return hasNotePassword(x) && !x.archived; }).length;
  var archCnt = all.filter(function (x) { return x.archived; }).length;

  var nPdfBtn = h('button', { class: 'btn-exp pdf', type: 'button', html: ic('pdf', 15) + '<span>PDF</span>' });
  var nWordBtn = h('button', { class: 'btn-exp word', type: 'button', html: ic('word', 15) + '<span>Word</span>' });
  var nMdBtn = h('button', { class: 'btn-exp md', type: 'button', html: ic('md', 15) + '<span>MD</span>' });
  var nJsBtn = h('button', { class: 'btn-exp js', type: 'button', html: ic('js', 15) + '<span>JS</span>' });
  var nReadAllBtn = h('button', { class: 'btn-exp', type: 'button', html: ic('speaker', 15) + '<span>خوانش</span>' });
  nPdfBtn.addEventListener('click', function () { exportNotesList(getFilteredNotes(), 'pdf'); });
  nWordBtn.addEventListener('click', function () { exportNotesList(getFilteredNotes(), 'word'); });
  nMdBtn.addEventListener('click', function () { exportNotesList(getFilteredNotes(), 'md'); });
  nJsBtn.addEventListener('click', function () { exportNotesList(getFilteredNotes(), 'js'); });
  nReadAllBtn.addEventListener('click', function () {
    var items = getFilteredNotes().filter(function (x) { return !isNoteLocked(x); });
    if (items.length) speakNotesList(items, items[0].id);
    else toast('یادداشت باز برای خوانش وجود ندارد');
  });

  var q = h('input', { class: 'field compact-search', id: 'nSearch', type: 'search', dir: 'auto', placeholder: 'جستجو در یادداشت‌ها…', 'aria-label': 'جستجوی یادداشت‌ها' });
  q.value = nQuery;
  q.addEventListener('input', function () { nQuery = q.value; nPageIdx = 0; debouncedRenderNoteCards(); });

  var fChips = h('div', { class: 'chips compact-chips' });
  [
    ['active', 'فعال (' + fa(activeCnt) + ')'],
    ['pinned', 'سنجاق (' + fa(pinnedCnt) + ')'],
    ['locked', 'رمزدار 🔒 (' + fa(lockedCnt) + ')'],
    ['archived', 'بایگانی (' + fa(archCnt) + ')']
  ].forEach(function (o) {
    var c = h('button', { class: 'chip sm' + (nFilter === o[0] ? ' on' : ''), type: 'button', text: o[1] });
    c.addEventListener('click', function () {
      nFilter = o[0]; nPageIdx = 0;
      $$('.chip', fChips).forEach(function (x) { x.classList.toggle('on', x === c); });
      renderNoteCards();
    });
    fChips.appendChild(c);
  });

  var headBar = h('div', { class: 'uni-toolbar notes-toolbar' }, [
    h('div', { class: 'uni-tb-row1' }, [
      h('b', { text: fa(activeCnt) + ' یادداشت فعال' + (lockedCnt ? ' · ' + fa(lockedCnt) + ' رمزدار 🔒' : '') }),
      h('div', { class: 'uni-tb-acts' }, [nReadAllBtn, nPdfBtn, nWordBtn, nMdBtn, nJsBtn])
    ]),
    h('div', { class: 'uni-tb-row2' }, [q, fChips])
  ]);

  var stageArea = h('div', { id: 'nCards', class: 'no-scroll-stage notes-stage' });
  var pagerHost = h('div', { id: 'nPagerHost' });

  list.appendChild(topStrip);
  list.appendChild(headBar);
  list.appendChild(stageArea);
  list.appendChild(pagerHost);
  renderNoteCards();
}

function getFilteredNotes() {
  var q = nQuery.trim().toLowerCase();
  return S.data.notes.filter(function (x) {
    if (nLangFilter !== 'all' && getNoteEffLang(x) !== nLangFilter) return false;
    if (nFilter === 'active' && x.archived) return false;
    if (nFilter === 'archived' && !x.archived) return false;
    if (nFilter === 'pinned' && (!x.pinned || x.archived)) return false;
    if (nFilter === 'locked' && !hasNotePassword(x)) return false;
    if (nCat !== 'all' && x.cat !== nCat) return false;
    if (q) {
      var searchableBody = isNoteLocked(x) ? '' : getNoteText(x);
      if ((x.title + ' ' + searchableBody + ' ' + x.cat + ' ' + (x.bk || '')).toLowerCase().indexOf(q) < 0) return false;
    }
    return true;
  }).sort(function (a, b) {
    if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
    return b.updated - a.updated;
  });
}

function renderNoteCards() {
  var box = $('#nCards'), pagerHost = $('#nPagerHost');
  if (!box) return;
  box.textContent = '';
  if (pagerHost) pagerHost.textContent = '';
  var allItems = getFilteredNotes();

  if (!allItems.length) {
    var msg = !S.data.notes.length
      ? 'هنوز یادداشتی ثبت نکرده‌اید.'
      : (nFilter === 'archived' ? 'یادداشتی در بایگانی نیست.' : 'یادداشتی با این مشخصات پیدا نشد.');
    box.appendChild(h('div', { class: 'lib-empty compact-empty' }, [
      h('h3', { text: msg }),
      h('p', { text: 'با دکمه‌ی «+ یادداشت جدید» در پایین صفحه، یادداشت خود را با امکان رمزگذاری اختصاصی ثبت کنید.' })
    ]));
  } else {
    var totalNotePages = Math.max(1, Math.ceil(allItems.length / NOTES_PER_PAGE));
    nPageIdx = clamp(nPageIdx, 0, totalNotePages - 1);
    var items = allItems.slice(nPageIdx * NOTES_PER_PAGE, (nPageIdx + 1) * NOTES_PER_PAGE);
    var listWrap = h('div', { class: 'notes-page-list' });
    items.forEach(function (x) { listWrap.appendChild(noteCard(x)); });
    box.appendChild(listWrap);
  }

  if (pagerHost) {
    var activeMeta = nLangFilter !== 'all' ? LANG_META[nLangFilter] : null;
    var addLbl = 'یادداشت جدید' + (activeMeta ? ' (' + activeMeta.short + ')' : '');
    pagerHost.appendChild(buildBottomPagerDock(nPageIdx, allItems.length, NOTES_PER_PAGE, function (np) {
      nPageIdx = np;
      renderNoteCards();
    }, 'یادداشت', addLbl, function () {
      noteForm(nLangFilter !== 'all' ? { lg: nLangFilter } : {});
    }));
  }
}

function noteCard(x) {
  var isSpeaking = !!(S.tts && S.tts.note && S.tts.noteId === x.id);
  var isPlaying = isSpeaking && S.tts.state === 'playing';
  var hasLock = hasNotePassword(x);
  var lockedNow = isNoteLocked(x);
  var bodyTxt = getNoteText(x);

  var lockBtn = h('button', {
    class: 'ibtn nlock' + (hasLock ? (lockedNow ? ' locked' : ' unlocked') : ''),
    'aria-label': hasLock ? (lockedNow ? 'باز کردن قفل یادداشت' : 'قفل کردن یادداشت') : 'رمزگذاری روی این یادداشت',
    title: hasLock ? (lockedNow ? 'باز کردن قفل یادداشت' : 'قفل کردن فوری یادداشت') : 'افزودن رمز عبور به این یادداشت',
    html: ic(hasLock ? (lockedNow ? 'lock' : 'unlock') : 'key', 18)
  });
  var sayBtn = h('button', {
    class: 'ibtn nsay' + (isSpeaking ? ' on' : ''),
    'aria-label': 'خوانش صوتی یادداشت',
    title: 'خوانش صوتی یادداشت',
    html: ic(isPlaying ? 'pause' : 'speaker', 18)
  });
  var archBtn = h('button', { class: 'ibtn narch', 'aria-label': x.archived ? 'خروج از بایگانی' : 'بایگانی کردن', title: x.archived ? 'خروج از بایگانی' : 'بایگانی کردن', html: ic(x.archived ? 'unarchive' : 'archive', 18) });
  var moreBtn = h('button', { class: 'ibtn nmore', 'aria-label': 'گزینه‌ها', html: ic('dots', 20) });
  var topKids = [];
  if (x.pinned) topKids.push(h('span', { class: 'npin-ic', title: 'سنجاق‌شده', html: ic('pin', 16) }));
  topKids.push(h('div', { class: 'ntitle', dir: 'auto', text: x.title || 'بدون عنوان' }));
  topKids.push(lockBtn, sayBtn, archBtn, moreBtn);

  var nLg = getNoteEffLang(x);
  var nLgMeta = LANG_META[nLg] || LANG_META.fa;
  var metaKids = [
    h('span', { class: 'lang-pill-badge', style: '--lang-clr:' + nLgMeta.color + ';height:22px;font-size:10.5px;padding:0 6px', text: nLgMeta.badge + ' · ' + nLgMeta.name }),
    h('span', { class: 'ncat-badge', html: ic('folder', 12) + '<span>' + esc(x.cat || 'عمومی') + '</span>' })
  ];
  if (hasLock) {
    metaKids.push(h('span', {
      class: 'nlock-badge' + (lockedNow ? '' : ' unlocked'),
      html: ic(lockedNow ? 'lock' : 'unlock', 11) + '<span>' + (lockedNow ? 'قفل‌شده' : 'باز') + '</span>'
    }));
  }
  if (x.archived) metaKids.push(h('span', { class: 'narch-badge', text: 'بایگانی' }));
  if (x.bk) {
    var src = h('button', { class: 'wsrc', html: ic('book', 13) + '<span></span>' });
    src.lastChild.textContent = x.bk + (x.pg ? ' · ص ' + fa(x.pg) : '');
    src.addEventListener('click', function (e) { e.stopPropagation(); gotoWordSource(x); });
    metaKids.push(src);
  }

  var bodyNode = lockedNow
    ? h('div', { class: 'nlock-banner', html: ic('lock', 18) + '<span>یادداشت محافظت‌شده با رمز عبور • برای باز کردن بزنید</span>' })
    : (bodyTxt ? h('div', { class: 'nbody', dir: 'auto', text: bodyTxt }) : null);

  var card = h('div', {
    class: 'ncard' + (x.archived ? ' archived' : '') + (isSpeaking ? ' speaking' : '') + (lockedNow ? ' is-locked' : ''),
    'data-id': x.id,
    'data-c': x.color || 'y',
    role: 'button',
    tabindex: 0
  }, [
    h('div', { class: 'ntop' }, topKids),
    bodyNode,
    h('div', { class: 'nfoot' }, [
      h('div', { class: 'nmeta' }, metaKids),
      h('span', { class: 'ndate', text: fmtDate(x.updated) })
    ])
  ]);

  card.addEventListener('click', function (e) {
    if (e.target.closest && e.target.closest('.nlock,.nsay,.narch,.nmore,.wsrc')) return;
    ensureNoteUnlocked(x, function () { openNoteReader(x.id); });
  });
  lockBtn.addEventListener('click', function (e) {
    e.stopPropagation();
    if (!hasLock) openNotePasswordManageDialog(x);
    else if (lockedNow) openNoteUnlockDialog(x);
    else lockNoteNow(x);
  });
  sayBtn.addEventListener('click', function (e) {
    e.stopPropagation();
    speakNote(x);
  });
  archBtn.addEventListener('click', function (e) {
    e.stopPropagation();
    toggleArchiveNote(x);
  });
  moreBtn.addEventListener('click', function (e) {
    e.stopPropagation();
    var mItems = [
      { icon: 'book', label: 'مطالعه‌ی یادداشت', fn: function () { ensureNoteUnlocked(x, function () { openNoteReader(x.id); }); } },
      { icon: 'edit', label: 'ویرایش یادداشت', fn: function () { ensureNoteUnlocked(x, function () { noteForm({ id: x.id }); }); } },
      { icon: 'pdf', label: 'ارسال یادداشت به صورت PDF', fn: function () { exportSingleNote(x, 'pdf'); } },
      { icon: 'word', label: 'ارسال یادداشت به صورت Word', fn: function () { exportSingleNote(x, 'word'); } },
      { icon: 'md', label: 'ارسال یادداشت به صورت Markdown (.md)', fn: function () { exportSingleNote(x, 'md'); } },
      { icon: 'js', label: 'ارسال یادداشت به صورت JavaScript (.js)', fn: function () { exportSingleNote(x, 'js'); } },
      '-'
    ];
    if (!hasLock) {
      mItems.push({ icon: 'lock', label: 'رمزگذاری روی این یادداشت', fn: function () { openNotePasswordManageDialog(x); } });
    } else {
      if (lockedNow) {
        mItems.push({ icon: 'unlock', label: 'باز کردن قفل یادداشت', fn: function () { openNoteUnlockDialog(x); } });
      } else {
        mItems.push({ icon: 'lock', label: 'قفل کردن فوری یادداشت', fn: function () { lockNoteNow(x); } });
      }
      mItems.push({ icon: 'key', label: 'تغییر یا حذف رمز یادداشت', fn: function () { openNotePasswordManageDialog(x); } });
    }
    mItems = mItems.concat([
      { icon: 'speaker', label: 'خوانش صوتی یادداشت', fn: function () { speakNote(x); } },
      { icon: 'pin', label: x.pinned ? 'برداشتن سنجاق' : 'سنجاق کردن به بالا', fn: function () { togglePinNote(x); } },
      { icon: x.archived ? 'unarchive' : 'archive', label: x.archived ? 'برگرداندن از بایگانی' : 'انتقال به بایگانی', fn: function () { toggleArchiveNote(x); } },
      { icon: 'copy', label: 'کپی متن یادداشت', fn: function () { ensureNoteUnlocked(x, function (txt) { copyText((x.title ? x.title + '\n\n' : '') + txt); }); } },
      { icon: 'share', label: 'اشتراک‌گذاری متنی', fn: function () { ensureNoteUnlocked(x, function (txt) { shareText((x.title ? x.title + '\n\n' : '') + txt, x.title || 'یادداشت'); }); } },
      '-',
      { icon: 'trash', label: 'حذف یادداشت', danger: true, fn: function () { ensureNoteUnlocked(x, function () { deleteNote(x); }); } }
    ]);
    menu(moreBtn, mItems);
  });
  return card;
}

function toggleArchiveNote(x) {
  x.archived = !x.archived;
  x.updated = Date.now();
  scheduleSave();
  renderNotes();
  toast(x.archived ? 'یادداشت به بایگانی منتقل شد' : 'یادداشت از بایگانی خارج شد', {
    label: 'برگرداندن',
    fn: function () { x.archived = !x.archived; scheduleSave(); renderNotes(); }
  });
}

function togglePinNote(x) {
  x.pinned = !x.pinned;
  x.updated = Date.now();
  scheduleSave();
  renderNotes();
  toast(x.pinned ? 'یادداشت سنجاق شد' : 'سنجاق یادداشت برداشته شد');
}

function deleteNote(x) {
  var idx = S.data.notes.indexOf(x);
  if (idx < 0) return;
  S.data.notes.splice(idx, 1);
  scheduleSave(); flushSave();
  if (S.view === 'library' && S.libTab === 'notes') renderNotes(); else updateNoteCount();
  toast('یادداشت حذف شد', {
    label: 'بازگردانی',
    fn: function () {
      S.data.notes.splice(Math.min(idx, S.data.notes.length), 0, x);
      scheduleSave(); flushSave();
      if (S.view === 'library' && S.libTab === 'notes') renderNotes(); else updateNoteCount();
    }
  });
}

function shareNotes() {
  if (!S.data.notes.length) { toast('هنوز یادداشتی ثبت نشده است'); return; }
  var list = S.data.notes.filter(function (x) { return !x.archived && !isNoteLocked(x); });
  if (!list.length) { toast('یادداشت باز برای اشتراک‌گذاری نیست'); return; }
  var txt = list.map(function (x) {
    return '▪ ' + x.title + ' [' + x.cat + ']\n' + getNoteText(x);
  }).join('\n\n────────────\n\n');
  shareText(txt || 'یادداشتی نیست', 'یادداشت‌های کتابچه');
}

function manageNoteCats() {
  sheet('دسته‌بندی‌های یادداشت', function (body) {
    var addRow = h('div', { class: 'wf-row', style: 'margin-bottom:14px' });
    var inp = h('input', { class: 'field', type: 'text', dir: 'auto', maxlength: 40, placeholder: 'نام دسته‌ی جدید (مثلاً: پژوهش، خلاصه کتاب…)' });
    var addB = h('button', { class: 'btn pri', style: 'height:48px;flex:none', html: ic('plus', 18) + '<span>افزودن</span>' });
    addRow.appendChild(inp); addRow.appendChild(addB);
    body.appendChild(addRow);
    var list = h('div');
    body.appendChild(list);

    function draw() {
      list.textContent = '';
      S.data.noteCats.forEach(function (cat) {
        var cnt = S.data.notes.filter(function (n) { return n.cat === cat; }).length;
        var delB = h('button', { class: 'ibtn', 'aria-label': 'حذف دسته', html: ic('trash', 18) });
        if (cat === 'عمومی') delB.disabled = true;
        var row = h('div', { class: 'row' }, [
          h('div', { class: 'grow' }, [
            h('div', { class: 't', text: cat }),
            h('div', { class: 'd', text: cnt ? fa(cnt) + ' یادداشت در این دسته' : 'بدون یادداشت' })
          ]),
          delB
        ]);
        delB.addEventListener('click', function () {
          if (cat === 'عمومی') return;
          var idx = S.data.noteCats.indexOf(cat);
          if (idx >= 0) S.data.noteCats.splice(idx, 1);
          S.data.notes.forEach(function (n) { if (n.cat === cat) n.cat = 'عمومی'; });
          if (nCat === cat) nCat = 'all';
          scheduleSave();
          draw();
          if (S.view === 'library' && S.libTab === 'notes') renderNotes();
        });
        list.appendChild(row);
      });
    }
    function addCat() {
      var v = inp.value.replace(/\s+/g, ' ').trim().slice(0, 40);
      if (!v) return;
      if (S.data.noteCats.indexOf(v) >= 0) { toast('این دسته از قبل وجود دارد'); return; }
      S.data.noteCats.push(v);
      inp.value = '';
      scheduleSave();
      draw();
      if (S.view === 'library' && S.libTab === 'notes') renderNotes();
    }
    addB.addEventListener('click', addCat);
    inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') addCat(); });
    draw();
  });
}

/* ---------- صفحه‌ی مطالعه‌ی یادداشت با تصویر زمینه‌ی دفترچه‌ای خط‌دار و کنترل اسکرول ---------- */
function openNoteReader(id) {
  var rec = noteById(id);
  if (!rec) return;
  if (isNoteLocked(rec)) {
    openNoteUnlockDialog(rec, function () { openNoteReader(id); });
    return;
  }
  stopAutoScroll();
  var closeBtn = h('button', { class: 'ibtn', 'aria-label': 'بازگشت', html: ic('back') });
  var titleEl = h('h2', { text: rec.title || 'بدون عنوان' });
  var subEl = h('p', { text: (rec.cat || 'عمومی') + ' · ' + fmtDate(rec.updated) });
  var bgBtn = h('button', { class: 'ibtn', 'aria-label': 'تصویر زمینه دفترچه', title: 'انتخاب تصویر زمینه دفترچه', html: ic('notebook', 21) });
  var wordBtn = h('button', { class: 'ibtn', 'aria-label': 'ذخیره‌ی واژه', title: 'ذخیره‌ی واژه‌ی انتخاب‌شده', html: ic('words', 21) });
  var sayBtn = h('button', { class: 'ibtn', 'aria-label': 'خوانش صوتی', title: 'خوانش صوتی یادداشت', html: ic('speaker', 21) });
  var editBtn = h('button', { class: 'ibtn', 'aria-label': 'ویرایش یادداشت', title: 'ویرایش یادداشت', html: ic('edit', 21) });
  var moreBtn = h('button', { class: 'ibtn', 'aria-label': 'بیشتر', html: ic('dots', 21) });

  var noteCurPage = 0, noteChunks = [''];
  var textRoot = h('div', { class: 'page-text nreader-text', dir: 'auto' });
  var metaRow = h('div', { class: 'nreader-meta' });
  var pagerSlot = h('div', { class: 'nreader-pager-slot' });
  var scrollEl = h('div', { class: 'page-scroll nreader-scroll' }, [metaRow, textRoot]);
  var pageEl = h('div', { class: 'page nreader-page', 'data-c': rec.color || 'y' }, [
    h('div', { class: 'frame' }),
    h('div', { class: 'spine' }),
    scrollEl
  ]);
  var wrapEl = h('div', { class: 'nreader-wrap' }, [pageEl]);

  var node = h('div', { class: 'layer' }, [
    h('div', { class: 'screen nreader-screen' }, [
      h('header', { class: 'topbar' }, [
        closeBtn,
        h('div', { class: 'rd-title' }, [titleEl, subEl]),
        bgBtn, wordBtn, sayBtn, editBtn, moreBtn
      ]),
      wrapEl,
      pagerSlot
    ])
  ]);

  var L = openLayer(node, { onBack: function () { stopAutoScroll(); L.close(); } });

  function splitNoteTextToPages(txt) {
    var raw = String(txt || '');
    if (!raw) return [''];
    var lines = raw.split('\n');
    var out = [], cur = [], charCnt = 0;
    for (var i = 0; i < lines.length; i++) {
      var ln = lines[i];
      if ((cur.length >= 10 || charCnt + ln.length > 480) && cur.length > 0) {
        out.push(cur.join('\n'));
        cur = [];
        charCnt = 0;
      }
      cur.push(ln);
      charCnt += ln.length + 1;
    }
    if (cur.length) out.push(cur.join('\n'));
    return out.length ? out : [''];
  }

  function renderContent() {
    rec = noteById(id);
    if (!rec) { stopAutoScroll(); L.close(true); return; }
    titleEl.textContent = rec.title || 'بدون عنوان';
    subEl.textContent = (rec.cat || 'عمومی') + ' · ' + fmtDate(rec.updated);
    pageEl.setAttribute('data-c', rec.color || 'y');
    metaRow.textContent = '';
    metaRow.appendChild(h('span', { class: 'ncat-badge', html: ic('folder', 12) + '<span>' + esc(rec.cat || 'عمومی') + '</span>' }));
    if (rec.pinned) metaRow.appendChild(h('span', { class: 'npin-ic', title: 'سنجاق‌شده', html: ic('pin', 15) }));
    if (rec.archived) metaRow.appendChild(h('span', { class: 'narch-badge', text: 'بایگانی' }));
    if (rec.bk) {
      var src = h('button', { class: 'wsrc', html: ic('book', 13) + '<span></span>' });
      src.lastChild.textContent = rec.bk + (rec.pg ? ' · ص ' + fa(rec.pg) : '');
      src.addEventListener('click', function () { stopAutoScroll(); L.close(true); gotoWordSource(rec); });
      metaRow.appendChild(src);
    }
    if (hasNotePassword(rec)) {
      metaRow.appendChild(h('span', { class: 'nlock-badge unlocked', html: ic('unlock', 11) + '<span>محافظت‌شده با رمز</span>' }));
    }
    noteChunks = splitNoteTextToPages(getNoteText(rec));
    noteCurPage = clamp(noteCurPage, 0, noteChunks.length - 1);
    renderLines(textRoot, noteChunks[noteCurPage], [], null);
    pagerSlot.textContent = '';
    if (noteChunks.length > 1) {
      pagerSlot.appendChild(buildBottomPagerDock(noteCurPage, noteChunks.length, 1, function (np) {
        noteCurPage = np;
        renderContent();
      }, 'صفحه', 'ویرایش', function () { noteForm({ id: rec.id, onSaved: renderContent }); }));
    }
  }
  renderContent();

  closeBtn.addEventListener('click', function () { stopAutoScroll(); L.close(); });
  bgBtn.addEventListener('click', function () { openPageBgPicker(renderContent); });
  sayBtn.addEventListener('click', function () { speakNote(rec); });
  wordBtn.addEventListener('click', function () {
    var sel = window.getSelection ? String(window.getSelection()).replace(/\s+/g, ' ').trim().replace(LATIN_OR_ARABIC_PUNCT, '') : '';
    if (!sel) {
      toast('یک کلمه را در متن یادداشت انتخاب کنید یا واژه‌ی جدید بنویسید');
      wordForm({});
      return;
    }
    try { window.getSelection().removeAllRanges(); } catch (e) {}
    var guessedLg = wordLang(sel, getNoteText(rec), '');
    var dup = wordByKey(wkey(sel), guessedLg);
    if (dup) wordForm({ id: dup.id });
    else wordForm({ w: sel.slice(0, 160), lg: guessedLg });
  });
  editBtn.addEventListener('click', function () {
    noteForm({ id: rec.id, onSaved: renderContent });
  });
  moreBtn.addEventListener('click', function () {
    menu(moreBtn, [
      { icon: 'pdf', label: 'ارسال یادداشت به صورت PDF', fn: function () { exportSingleNote(rec, 'pdf'); } },
      { icon: 'word', label: 'ارسال یادداشت به صورت Word', fn: function () { exportSingleNote(rec, 'word'); } },
      { icon: 'md', label: 'ارسال یادداشت به صورت Markdown (.md)', fn: function () { exportSingleNote(rec, 'md'); } },
      { icon: 'js', label: 'ارسال یادداشت به صورت JavaScript (.js)', fn: function () { exportSingleNote(rec, 'js'); } },
      { icon: 'key', label: hasNotePassword(rec) ? 'تغییر یا حذف رمز یادداشت' : 'رمزگذاری روی این یادداشت', fn: function () { openNotePasswordManageDialog(rec, renderContent); } },
      { icon: 'notebook', label: 'تصویر زمینه دفترچه (' + findPageBg(S.data.settings.pageBg).name + ')', fn: function () { openPageBgPicker(renderContent); } },
      { icon: 'edit', label: 'ویرایش یادداشت', fn: function () { noteForm({ id: rec.id, onSaved: renderContent }); } },
      { icon: 'speaker', label: 'خوانش صوتی یادداشت', fn: function () { speakNote(rec); } },
      { icon: 'pin', label: rec.pinned ? 'برداشتن سنجاق' : 'سنجاق کردن به بالا', fn: function () { togglePinNote(rec); renderContent(); } },
      { icon: rec.archived ? 'unarchive' : 'archive', label: rec.archived ? 'برگرداندن از بایگانی' : 'انتقال به بایگانی', fn: function () { toggleArchiveNote(rec); renderContent(); } },
      { icon: 'copy', label: 'کپی متن یادداشت', fn: function () { copyText((rec.title ? rec.title + '\n\n' : '') + getNoteText(rec)); } },
      { icon: 'share', label: 'اشتراک‌گذاری متنی', fn: function () { shareText((rec.title ? rec.title + '\n\n' : '') + getNoteText(rec), rec.title || 'یادداشت'); } },
      '-',
      { icon: 'trash', label: 'حذف یادداشت', danger: true, fn: function () { stopAutoScroll(); L.close(true); deleteNote(rec); } }
    ]);
  });
}

function noteForm(o) {
  o = o || {};
  var rec = o.id ? noteById(o.id) : null;
  if (rec && isNoteLocked(rec)) {
    openNoteUnlockDialog(rec, function () { noteForm(o); });
    return;
  }
  var f0 = {
    title: rec ? rec.title : (o.title || ''),
    text: rec ? getNoteText(rec) : (o.text || ''),
    lg: rec ? getNoteEffLang(rec) : (o.lg && LANG_META[o.lg] ? o.lg : (nLangFilter !== 'all' ? nLangFilter : 'fa')),
    cat: rec ? rec.cat : (o.cat || (nCat !== 'all' ? nCat : 'عمومی')),
    color: rec ? rec.color : (o.color || S.data.settings.color || 'y'),
    pinned: rec ? !!rec.pinned : !!o.pinned,
    archived: rec ? !!rec.archived : !!o.archived,
    locked: rec ? hasNotePassword(rec) : false
  };
  var src = rec ? { bid: rec.bid, bk: rec.bk, pg: rec.pg } : (o.src || null);

  var tIn = h('input', { class: 'field', id: 'nfTitle', type: 'text', dir: 'auto', maxlength: 160, placeholder: 'عنوان یادداشت…', 'aria-label': 'عنوان یادداشت' });
  tIn.value = f0.title;
  var bIn = h('textarea', { class: 'field lined-paper-input', id: 'nfText', dir: 'auto', rows: 8, maxlength: 20000, placeholder: 'متن یادداشت را بنویسید یا بچسبانید…', 'aria-label': 'متن یادداشت', spellcheck: 'false' });
  bIn.value = f0.text;

  var catSel = f0.cat;
  var catWrap = h('div', { class: 'nf-cats' });
  function drawCats() {
    catWrap.textContent = '';
    if (S.data.noteCats.indexOf(catSel) < 0) S.data.noteCats.push(catSel);
    S.data.noteCats.forEach(function (c) {
      var ch = h('button', { class: 'chip sm' + (catSel === c ? ' on' : ''), type: 'button', text: c });
      ch.addEventListener('click', function () { catSel = c; drawCats(); });
      catWrap.appendChild(ch);
    });
    var addC = h('button', { class: 'chip sm', type: 'button', html: ic('plus', 14) + '<span>دسته‌ی جدید</span>' });
    addC.addEventListener('click', function () {
      dialog({ title: 'دسته‌بندی جدید', message: 'نام دسته‌ی جدید را بنویسید:', input: true, ok: 'افزودن', max: 40 }).then(function (v) {
        if (!v) return;
        var s = String(v).replace(/\s+/g, ' ').trim().slice(0, 40);
        if (!s) return;
        if (S.data.noteCats.indexOf(s) < 0) S.data.noteCats.push(s);
        catSel = s;
        scheduleSave();
        drawCats();
      });
    });
    catWrap.appendChild(addC);
  }
  drawCats();

  var colSel = f0.color;
  var colWrap = h('div', { class: 'nf-colors' });
  function drawCols() {
    colWrap.textContent = '';
    COLORS.forEach(function (c) {
      var d = h('button', { class: 'fdot' + (colSel === c ? ' on' : ''), type: 'button', 'data-c': c, 'aria-label': COLOR_NAMES[c], title: COLOR_NAMES[c] });
      d.addEventListener('click', function () { colSel = c; drawCols(); });
      colWrap.appendChild(d);
    });
  }
  drawCols();

  var pinSel = f0.pinned, archSel = f0.archived, lockSel = f0.locked;
  var pinChip = h('button', { class: 'chip sm' + (pinSel ? ' on' : ''), type: 'button', html: ic('pin', 15) + '<span>سنجاق به بالا</span>' });
  var archChip = h('button', { class: 'chip sm' + (archSel ? ' on' : ''), type: 'button', html: ic('archive', 15) + '<span>در بایگانی</span>' });
  var lockChip = h('button', { class: 'chip sm' + (lockSel ? ' on' : ''), type: 'button', html: ic('lock', 15) + '<span>رمزگذاری یادداشت</span>' });
  var pwdIn = h('input', {
    class: 'field',
    type: 'password',
    dir: 'auto',
    maxlength: 64,
    style: 'margin-top:8px;' + (lockSel ? '' : 'display:none;'),
    placeholder: f0.locked ? 'رمز جدید (خالی بگذارید تا رمز قبلی بماند)…' : 'رمز عبور اختصاصی این یادداشت را بنویسید…'
  });
  pinChip.addEventListener('click', function () { pinSel = !pinSel; pinChip.classList.toggle('on', pinSel); });
  archChip.addEventListener('click', function () { archSel = !archSel; archChip.classList.toggle('on', archSel); });
  lockChip.addEventListener('click', function () {
    lockSel = !lockSel;
    lockChip.classList.toggle('on', lockSel);
    pwdIn.style.display = lockSel ? '' : 'none';
    if (lockSel) setTimeout(function () { pwdIn.focus(); }, 30);
  });

  var closeBtn = h('button', { class: 'ibtn', 'aria-label': 'بستن', html: ic('x') });
  var bgFormBtn = h('button', { class: 'ibtn', type: 'button', 'aria-label': 'تصویر زمینه دفترچه', title: 'انتخاب تصویر زمینه دفترچه', html: ic('notebook', 20) });
  bgFormBtn.addEventListener('click', function () { openPageBgPicker(); });
  var sayFormBtn = h('button', { class: 'ibtn', 'aria-label': 'خوانش صوتی یادداشت', title: 'خوانش صوتی این یادداشت', html: ic('speaker', 20) });
  var saveBtn = h('button', { class: 'btn pri', text: 'ذخیره', style: 'height:40px;padding:0 20px' });
  sayFormBtn.addEventListener('click', function () {
    var t = tIn.value.trim(), b = bIn.value.trim();
    if (!t && !b) { toast('اول متن یادداشت را بنویسید'); return; }
    speakNoteRaw(t, b);
  });

  var nLgSel = f0.lg;
  var nLgWrap = h('div', { class: 'wf-lg', style: 'margin-top:4px' });
  function drawNoteLgs() {
    nLgWrap.textContent = '';
    APP_LANGS.forEach(function (lk) {
      var m = LANG_META[lk];
      var ch = h('button', { class: 'chip sm' + (nLgSel === lk ? ' on' : ''), type: 'button', text: m.badge + ' · ' + m.name });
      ch.addEventListener('click', function () { nLgSel = lk; drawNoteLgs(); });
      nLgWrap.appendChild(ch);
    });
  }
  drawNoteLgs();

  var body = h('div', { class: 'nf-body' }, [
    h('label', { class: 'wf-l', text: 'عنوان یادداشت', for: 'nfTitle' }),
    h('div', { class: 'wf-row' }, [tIn, bgFormBtn, sayFormBtn]),
    h('label', { class: 'wf-l', text: 'زبان یادداشت:' }), nLgWrap,
    h('label', { class: 'wf-l', text: 'دسته‌بندی (طبقه‌بندی)' }), catWrap,
    h('label', { class: 'wf-l', text: 'متن یادداشت', for: 'nfText' }), bIn,
    h('label', { class: 'wf-l', text: 'رنگ نشانگر کارت' }), colWrap,
    h('div', { class: 'nf-opts' }, [pinChip, archChip, lockChip]),
    pwdIn
  ]);

  if (src && src.bk) {
    var srcRow = h('div', { class: 'wf-src', html: ic('book', 16) + '<span></span>' });
    srcRow.lastChild.textContent = src.bk + (src.pg ? ' · صفحه ' + fa(src.pg) : '');
    body.appendChild(srcRow);
  }
  if (rec) {
    var del = h('button', { class: 'btn block danger', type: 'button', style: 'margin-top:16px', html: ic('trash', 20) + '<span>حذف این یادداشت</span>' });
    del.addEventListener('click', function () { L.close(true); deleteNote(rec); });
    body.appendChild(del);
  }

  var node = h('div', { class: 'layer' }, [
    h('div', { class: 'editor wform nform' }, [
      h('div', { class: 'topbar' }, [closeBtn, h('h3', { text: rec ? 'ویرایش یادداشت' : 'یادداشت جدید' }), saveBtn]),
      body
    ])
  ]);

  var L;
  function changed() {
    return tIn.value !== f0.title || bIn.value !== f0.text || catSel !== f0.cat || colSel !== f0.color || pinSel !== f0.pinned || archSel !== f0.archived;
  }
  function tryClose() {
    if (!changed()) { L.close(true); return; }
    dialog({ title: 'تغییرات ذخیره نشده', message: 'می‌خواهید بدون ذخیره خارج شوید؟', ok: 'خروج', danger: true, cancel: 'ادامه' })
      .then(function (r) { if (r) L.close(true); });
  }
  L = openLayer(node, { onBack: tryClose });
  closeBtn.addEventListener('click', tryClose);
  saveBtn.addEventListener('click', function () {
    var title = tIn.value.replace(/\s+/g, ' ').trim();
    var text = norm(bIn.value).trim();
    if (!title && !text) { toast('عنوان یا متن یادداشت را بنویسید'); tIn.focus(); return; }
    if (!title) title = snippet(text, 45);
    var now = Date.now();
    var newPwd = pwdIn.value;
    if (lockSel && !f0.locked && !newPwd) {
      toast('برای رمزگذاری یادداشت، یک رمز عبور وارد کنید');
      pwdIn.focus();
      return;
    }
    if (rec) {
      rec.title = title; rec.lg = nLgSel; rec.cat = catSel; rec.color = colSel;
      rec.pinned = pinSel; rec.archived = archSel; rec.updated = now;
      if (!lockSel) {
        removeNotePasswordRaw(rec, text);
      } else if (newPwd) {
        setNotePasswordRaw(rec, newPwd, text);
        S.unlockedNotes[rec.id] = text;
      } else if (rec.locked && rec.pwdHash) {
        S.unlockedNotes[rec.id] = text;
        if (S.noteKeys[rec.id]) {
          rec.cipher = encryptNoteText(text, S.noteKeys[rec.id], rec.pwdSalt);
          rec.text = '';
        } else {
          rec.text = text;
        }
      } else {
        rec.text = text;
      }
    } else {
      var nObj = {
        id: uid(), title: title, lg: nLgSel, text: text, cat: catSel, color: colSel,
        pinned: pinSel, archived: archSel, locked: false, pwdHash: '', pwdSalt: '', cipher: '',
        bid: src && src.bid || '', bk: src && src.bk || '', pg: src && src.pg | 0,
        created: now, updated: now
      };
      if (lockSel && newPwd) {
        setNotePasswordRaw(nObj, newPwd, text);
      }
      S.data.notes.push(nObj);
    }
    scheduleSave(); flushSave();
    L.close(true);
    if (o.onSaved) o.onSaved();
    if (S.view === 'library') {
      if (S.libTab === 'notes') renderNotes(); else updateNoteCount();
    } else updateNoteCount();
    toast(rec ? 'یادداشت بروزرسانی شد' : 'به یادداشت‌ها اضافه شد');
  });
  setTimeout(function () { (f0.title ? bIn : tIn).focus(); }, 100);
  return L;
}

function noteFromBar(mode, hid) {
  var pg = currentPage(), b = curBook(); if (!pg || !b) return;
  var s = -1, e = -1, col = S.data.settings.color || 'y';
  if (mode === 'hl') {
    var x = pg.hl.filter(function (q) { return q.id === hid; })[0];
    if (x) { s = x.s; e = x.e; col = x.c || col; }
  } else {
    var t = selectionTarget();
    if (t) { s = t.s; e = t.e; }
  }
  if (s < 0 || e <= s) { hideBar(); return; }
  var raw = pg.text.slice(s, e).trim();
  if (!raw) { hideBar(); return; }
  hideBar(); clearSel();
  noteForm({
    title: snippet(raw, 48),
    text: raw,
    cat: 'نقل‌قول',
    color: col,
    src: { bid: b.id, bk: b.title, pg: S.index + 1 }
  });
}


/* =====================================================================
   ارتقای نسخه ۲٫۴: دسترسی سریع، نشانک، پنل سریع Aa، حالت تمرکز و جستجوی سراسری
   ===================================================================== */
function estReadMins(bk, fromIdx) {
  if (!bk || !bk.pages || !bk.pages.length) return 'کتاب خالی';
  var start = clamp(fromIdx | 0, 0, bk.pages.length - 1);
  var words = 0;
  for (var i = start; i < bk.pages.length; i++) {
    var t = String(bk.pages[i].text || '').trim();
    if (t) words += t.split(/\s+/).length;
  }
  var mins = Math.round(words / 200);
  if (mins <= 0) return 'کمتر از ۱ دقیقه';
  if (mins < 60) return '~' + fa(mins) + ' دقیقه';
  var hrs = Math.floor(mins / 60), rem = mins % 60;
  return '~' + fa(hrs) + ' ساعت' + (rem ? ' و ' + fa(rem) + ' د' : '');
}

function quickToggleTheme() {
  var st = S.data.settings;
  var cur = resolveTheme();
  var isDark = !!(THEMES[cur] && THEMES[cur].dark);
  st.theme = isDark ? 'snow' : 'night';
  if (st.pageBg === 'dark' && isDark) st.pageBg = 'classic';
  scheduleSave();
  applyTheme();
  hapticTap();
  toast(isDark ? 'حالت روشن فعال شد' : 'حالت شب فعال شد');
}

function setImmersive(on) {
  S.immersive = !!on;
  var rd = $('#rd');
  if (rd) rd.classList.toggle('immersive', S.immersive);
}

function toggleImmersive() {
  setImmersive(!S.immersive);
  hapticTap();
}

function toggleCurrentBookmark() {
  var b = curBook();
  if (!b || S.index >= b.pages.length) return;
  var pg = b.pages[S.index];
  pg.bm = !pg.bm;
  touch(b, pg);
  scheduleSave();
  if (pBase) pBase.classList.toggle('bookmarked', !!pg.bm);
  updateBars();
  hapticTap();
  toast(pg.bm ? ('صفحه‌ی ' + fa(S.index + 1) + ' نشانک‌گذاری شد') : 'نشانک این صفحه برداشته شد');
}

function openQuickReaderSheet() {
  var st = S.data.settings;
  sheet('تنظیمات سریع مطالعه', function (body, L) {
    // 1. اندازه فونت سریع
    var fsVal = h('b', { class: 'qa-fs-val', text: fa(st.fontSize) });
    var fsMinus = h('button', { class: 'qa-step-btn', type: 'button', text: 'A−', 'aria-label': 'کوچک‌تر کردن قلم' });
    var fsPlus = h('button', { class: 'qa-step-btn', type: 'button', text: 'A+', 'aria-label': 'بزرگ‌تر کردن قلم' });
    function setFsQuick(v) {
      st.fontSize = clamp(v, 8, 35);
      fsVal.textContent = fa(st.fontSize);
      applyTheme();
      scheduleSave();
      hapticTap();
    }
    fsMinus.addEventListener('click', function () { setFsQuick(st.fontSize - 1); });
    fsPlus.addEventListener('click', function () { setFsQuick(st.fontSize + 1); });
    body.appendChild(h('div', { class: 'qa-row' }, [
      h('span', { class: 'qa-lbl', text: 'اندازه متن' }),
      h('div', { class: 'qa-stepper' }, [fsMinus, fsVal, fsPlus])
    ]));

    // 2. تم‌های سریع مطالعه
    var quickThemes = [
      { id: 'snow', name: 'برفی', bg: '#ffffff', ink: '#171b21' },
      { id: 'paper', name: 'کاغذی', bg: '#fcf6e6', ink: '#2a2216' },
      { id: 'sepia', name: 'سپیا', bg: '#f3e5c8', ink: '#3a2a14' },
      { id: 'night', name: 'شب', bg: '#1a1d23', ink: '#e7e3da' },
      { id: 'black', name: 'مشکی', bg: '#050506', ink: '#d9d6cf' }
    ];
    var swWrap = h('div', { class: 'qa-themes' });
    function drawSw() {
      swWrap.textContent = '';
      var curT = resolveTheme();
      quickThemes.forEach(function (qt) {
        var btn = h('button', {
          class: 'qa-th-btn' + (curT === qt.id ? ' on' : ''),
          type: 'button',
          style: 'background:' + qt.bg + ';color:' + qt.ink
        }, [h('span', { text: qt.name })]);
        btn.addEventListener('click', function () {
          st.theme = qt.id;
          applyTheme();
          scheduleSave();
          hapticTap();
          drawSw();
        });
        swWrap.appendChild(btn);
      });
    }
    drawSw();
    body.appendChild(swWrap);

    // 3. فاصله خطوط
    var lhOpts = [
      { v: 1.6, label: 'فشرده' },
      { v: 1.95, label: 'متعادل' },
      { v: 2.3, label: 'باز' }
    ];
    var lhBar = h('div', { class: 'qa-seg' });
    function drawLh() {
      lhBar.textContent = '';
      lhOpts.forEach(function (o) {
        var active = Math.abs((+st.lineHeight || 1.95) - o.v) < 0.16;
        var b = h('button', { class: 'qa-seg-btn' + (active ? ' on' : ''), type: 'button', text: o.label });
        b.addEventListener('click', function () {
          st.lineHeight = o.v;
          applyTheme();
          scheduleSave();
          hapticTap();
          drawLh();
        });
        lhBar.appendChild(b);
      });
    }
    drawLh();
    body.appendChild(h('div', { class: 'qa-row' }, [
      h('span', { class: 'qa-lbl', text: 'فاصله خطوط' }),
      lhBar
    ]));

    // 4. کلیدهای دسترسی سریع
    var acts = h('div', { class: 'qa-quick-acts' });
    var focusBtn = h('button', { class: 'btn' + (S.immersive ? ' pri' : ''), type: 'button', html: ic('maximize', 16) + '<span>' + (S.immersive ? 'خروج از تمام‌صفحه' : 'مطالعه تمام‌صفحه') + '</span>' });
    var bgBtn = h('button', { class: 'btn', type: 'button', html: ic('notebook', 16) + '<span>کاغذ دفترچه</span>' });
    var fullBtn = h('button', { class: 'btn', type: 'button', html: ic('sliders', 16) + '<span>تنظیمات کامل…</span>' });
    focusBtn.addEventListener('click', function () { L.close(); toggleImmersive(); });
    bgBtn.addEventListener('click', function () { L.close(true); openPageBgPicker(); });
    fullBtn.addEventListener('click', function () { L.close(true); openSettings('font'); });
    acts.appendChild(focusBtn);
    acts.appendChild(bgBtn);
    acts.appendChild(fullBtn);
    body.appendChild(acts);
  });
}

function openGlobalSearch() {
  sheet('جستجوی سریع', function (body, L) {
    var inp = h('input', {
      class: 'field gs-input',
      type: 'search',
      placeholder: 'جستجو در کتاب‌ها، متن صفحات، یادداشت‌ها و لغات…',
      dir: 'auto'
    });
    var res = h('div', { class: 'gs-results' });
    body.appendChild(inp);
    body.appendChild(res);

    function render() {
      res.textContent = '';
      var q = inp.value.trim();
      var ql = q.toLowerCase();
      if (!q) {
        var recents = S.data.books.slice().sort(function (a, b) { return b.updated - a.updated; }).slice(0, 5);
        if (recents.length) {
          res.appendChild(h('div', { class: 'gs-sec', text: 'دسترسی سریع به کتاب‌های اخیر' }));
          recents.forEach(function (bk) {
            var pct = bk.pages.length ? Math.round(clamp((bk.last + 1) / bk.pages.length, 0, 1) * 100) : 0;
            var item = h('button', { class: 'gs-item', type: 'button' }, [
              h('span', { class: 'gs-ic', html: ic('book', 17) }),
              h('span', { class: 'gs-txt' }, [
                h('b', { dir: 'auto', text: bk.title }),
                h('small', { text: fa(bk.pages.length) + ' صفحه · ' + fa(pct) + '٪' })
              ])
            ]);
            item.addEventListener('click', function () { L.close(); openBook(bk.id); });
            res.appendChild(item);
          });
        } else {
          res.appendChild(h('div', { class: 'empty-note', text: 'عبارتی برای جستجو بنویسید.' }));
        }
        return;
      }

      var totalHits = 0;
      // 1. کتاب‌ها و صفحات
      var bookHits = [];
      S.data.books.forEach(function (bk) {
        if (String(bk.title || '').toLowerCase().indexOf(ql) >= 0) {
          bookHits.push({ bk: bk, pi: clamp(bk.last | 0, 0, Math.max(0, bk.pages.length - 1)), sn: 'عنوان کتاب · ' + fa(bk.pages.length) + ' صفحه', flash: null });
        }
        for (var i = 0; i < bk.pages.length && bookHits.length < 18; i++) {
          var t = String(bk.pages[i].text || '');
          var pos = t.toLowerCase().indexOf(ql);
          if (pos >= 0) {
            var a = Math.max(0, pos - 28), e = Math.min(t.length, pos + q.length + 52);
            bookHits.push({ bk: bk, pi: i, sn: 'صفحه ' + fa(i + 1) + ': ' + (a > 0 ? '…' : '') + t.slice(a, e).replace(/\s+/g, ' ') + (e < t.length ? '…' : ''), flash: { s: pos, e: pos + q.length } });
          }
        }
      });
      if (bookHits.length) {
        totalHits += bookHits.length;
        res.appendChild(h('div', { class: 'gs-sec', text: 'کتاب‌ها و صفحات (' + fa(bookHits.length) + ')' }));
        bookHits.slice(0, 12).forEach(function (hit) {
          var item = h('button', { class: 'gs-item', type: 'button' }, [
            h('span', { class: 'gs-ic', html: ic('book', 17) }),
            h('span', { class: 'gs-txt' }, [
              h('b', { dir: 'auto', text: hit.bk.title }),
              h('small', { dir: 'auto', text: hit.sn })
            ])
          ]);
          item.addEventListener('click', function () {
            L.close();
            openBook(hit.bk.id);
            showPageNow(hit.pi, hit.flash ? { flash: hit.flash } : undefined);
          });
          res.appendChild(item);
        });
      }

      // 2. یادداشت‌ها
      var noteHits = S.data.notes.filter(function (n) {
        if (String(n.title || '').toLowerCase().indexOf(ql) >= 0) return true;
        if (!isNoteLocked(n) && String(getNoteText(n) || '').toLowerCase().indexOf(ql) >= 0) return true;
        return false;
      }).slice(0, 8);
      if (noteHits.length) {
        totalHits += noteHits.length;
        res.appendChild(h('div', { class: 'gs-sec', text: 'یادداشت‌ها (' + fa(noteHits.length) + ')' }));
        noteHits.forEach(function (n) {
          var item = h('button', { class: 'gs-item', type: 'button' }, [
            h('span', { class: 'gs-ic', html: ic(isNoteLocked(n) ? 'lock' : 'note', 17) }),
            h('span', { class: 'gs-txt' }, [
              h('b', { dir: 'auto', text: n.title }),
              h('small', { dir: 'auto', text: isNoteLocked(n) ? 'یادداشت قفل‌شده' : snippet(getNoteText(n), 80) })
            ])
          ]);
          item.addEventListener('click', function () { L.close(); setLibTab('notes'); openNoteReader(n.id); });
          res.appendChild(item);
        });
      }

      // 3. لغات
      var wordHits = S.data.words.filter(function (w) {
        return String(w.w || '').toLowerCase().indexOf(ql) >= 0 || String(w.m || '').toLowerCase().indexOf(ql) >= 0;
      }).slice(0, 10);
      if (wordHits.length) {
        totalHits += wordHits.length;
        res.appendChild(h('div', { class: 'gs-sec', text: 'لغات (' + fa(wordHits.length) + ')' }));
        wordHits.forEach(function (w) {
          var item = h('button', { class: 'gs-item', type: 'button' }, [
            h('span', { class: 'gs-ic', html: ic('words', 17) }),
            h('span', { class: 'gs-txt' }, [
              h('b', { dir: 'auto', text: w.w }),
              h('small', { dir: 'auto', text: w.m || 'بدون معنی' })
            ])
          ]);
          item.addEventListener('click', function () {
            L.close();
            speakWord(w.w, w.ex, w.lg);
            setLibTab('words');
          });
          res.appendChild(item);
        });
      }

      if (!totalHits) {
        res.appendChild(h('div', { class: 'empty-note', text: 'موردی با عبارت «' + q + '» پیدا نشد.' }));
      }
    }

    inp.addEventListener('input', debounce(render, 110));
    render();
    setTimeout(function () { inp.focus(); }, 100);
  });
}


/* =====================================================================
   افزونه ترجمه هوشمند کتاب (ترجمه کامل فارسی + نمای دوزبانه خط‌به‌خط) — v2.5
   ===================================================================== */
var TR_SRC_LANGS = [
  { id: 'auto', name: 'تشخیص خودکار زبان' },
  { id: 'en',   name: 'انگلیسی → فارسی' },
  { id: 'ar',   name: 'عربی → فارسی' },
  { id: 'fr',   name: 'فرانسوی → فارسی' },
  { id: 'de',   name: 'آلمانی → فارسی' },
  { id: 'tr',   name: 'ترکی → فارسی' },
  { id: 'es',   name: 'اسپانیایی → فارسی' },
  { id: 'ru',   name: 'روسی → فارسی' }
];
var TR_RUNTIME = {
  jobId: 0,
  busyPageKey: null,
  failedPages: {},
  bookJob: null
};

function trHash(str) {
  str = String(str || '');
  var h1 = 2166136261 >>> 0;
  for (var i = 0; i < str.length; i++) {
    h1 ^= str.charCodeAt(i);
    h1 = Math.imul ? Math.imul(h1, 16777619) : ((h1 * 16777619) >>> 0);
  }
  return str.length + '_' + (h1 >>> 0).toString(36);
}

function trEffectiveSrc(b) {
  if (!b) return 'auto';
  if (b.trSrc && b.trSrc !== 'auto') return b.trSrc;
  var lg = getBookEffLang(b);
  if (lg && lg !== 'fa' && /^(en|ar|fr|de|tr)$/.test(lg)) return lg;
  return 'auto';
}

function trCacheValid(pg, srcLang) {
  if (!pg || !pg.tr || !Array.isArray(pg.tr.segs)) return false;
  if (pg.tr.h !== trHash(pg.text)) return false;
  if (pg.tr.tl && pg.tr.tl !== 'fa') return false;
  if (srcLang && srcLang !== 'auto' && pg.tr.sl && pg.tr.sl !== 'auto' && pg.tr.sl !== srcLang) return false;
  return true;
}

/* تقسیم متن صفحه به خطوط/جملات منظم برای ترجمه دقیق خط‌به‌خط */
function splitLineToSentences(line) {
  var clean = String(line || '').trim();
  if (clean.length <= 150) return [clean];
  var out = [], buf = '', i = 0, len = clean.length;
  while (i < len) {
    var ch = clean.charAt(i);
    buf += ch;
    var isEnd = (ch === '.' || ch === '!' || ch === '?' || ch === '؟' || ch === '؛');
    if (isEnd) {
      while (i + 1 < len && /["'”»)\]]/.test(clean.charAt(i + 1))) {
        i++;
        buf += clean.charAt(i);
      }
      var nextCh = i + 1 < len ? clean.charAt(i + 1) : '';
      if ((!nextCh || /\s/.test(nextCh)) && buf.trim().length >= 28) {
        out.push(buf.trim());
        buf = '';
        while (i + 1 < len && /\s/.test(clean.charAt(i + 1))) i++;
      }
    }
    i++;
  }
  if (buf.trim()) {
    if (out.length && buf.trim().length < 20) out[out.length - 1] += ' ' + buf.trim();
    else out.push(buf.trim());
  }
  return out.length ? out : [clean];
}

function splitForTranslation(text) {
  var rawLines = String(text || '').split('\n');
  var segs = [];
  for (var i = 0; i < rawLines.length; i++) {
    var ln = rawLines[i];
    if (!ln || !ln.trim()) {
      segs.push({ o: '', t: '', pe: true, empty: true });
      continue;
    }
    var parts = splitLineToSentences(ln);
    for (var j = 0; j < parts.length; j++) {
      segs.push({ o: parts[j], t: '', pe: j === parts.length - 1, empty: false });
    }
  }
  return segs;
}

function trNeedsTranslation(line) {
  return /[A-Za-z\u00C0-\u024F\u0400-\u04FF\u0600-\u06FF\u4E00-\u9FFF]/.test(line || '');
}

function trNetEnsure(cb) {
  if (!bridge('httpGet')) { cb(true); return; }
  if (S.data.settings.net) { cb(true); return; }
  dialog({
    title: 'اجازه اتصال برای ترجمه کتاب',
    message: 'برای ترجمه متن کتاب به فارسی، متن صفحه‌ی انتخاب‌شده به سرویس ترجمه آنلاین (Google Translate و در صورت نیاز MyMemory) ارسال می‌شود.\n\nترجمه پس از دریافت در حافظه‌ی کتاب ذخیره می‌شود تا دفعات بعد کاملاً آفلاین نمایش داده شود.',
    ok: 'اجازه می‌دهم و ترجمه کن',
    cancel: 'انصراف'
  }).then(function (ok) {
    if (ok) {
      S.data.settings.net = true;
      scheduleSave();
      cb(true);
    } else {
      cb(false);
    }
  });
}

function parseGoogleTranslate(status, txt) {
  if (status !== 200 || !txt) return null;
  var j;
  try { j = JSON.parse(txt); } catch (e) { return null; }
  if (!Array.isArray(j) || !Array.isArray(j[0])) return null;
  var out = '';
  for (var i = 0; i < j[0].length; i++) {
    if (j[0][i] && typeof j[0][i][0] === 'string') out += j[0][i][0];
  }
  return out;
}

function trFetchGoogle(text, sl, cb) {
  var url = 'https://translate.googleapis.com/translate_a/single?client=gtx&sl=' +
    encodeURIComponent(sl || 'auto') + '&tl=fa&dt=t&q=' + encodeURIComponent(text);
  netGet(url, function (status, txt) {
    var parsed = parseGoogleTranslate(status, txt);
    if (parsed !== null && parsed.trim()) cb(null, parsed);
    else cb(new Error('gt_fail'));
  });
}

function trFetchMyMemory(text, sl, cb) {
  var src = sl && sl !== 'auto' ? sl : (wordLang(text, '', '') || 'en');
  if (src === 'fa') src = 'en';
  var url = 'https://api.mymemory.translated.net/get?q=' + encodeURIComponent(String(text).slice(0, 450)) +
    '&langpair=' + encodeURIComponent(src + '|fa');
  netGet(url, function (status, txt) {
    var j;
    try { j = JSON.parse(txt); } catch (e) { j = null; }
    var main = j && j.responseData && j.responseData.translatedText ? String(j.responseData.translatedText) : '';
    if (status === 200 && main && !/MYMEMORY WARNING|NO TRANSLATION/i.test(main)) {
      cb(null, htmlDecode(main));
    } else {
      cb(new Error('mm_fail'));
    }
  });
}

function trTranslateOne(text, sl, cb) {
  if (!trNeedsTranslation(text)) { cb(null, text); return; }
  trFetchGoogle(text, sl, function (err, res) {
    if (!err && res) { cb(null, res.trim()); return; }
    trFetchMyMemory(text, sl, function (err2, res2) {
      if (!err2 && res2) cb(null, res2.trim());
      else cb(err2 || err || new Error('tr_fail'));
    });
  });
}

function trTranslateBatch(lines, sl, cb) {
  if (!lines.length) { cb(null, []); return; }
  if (lines.length === 1) {
    trTranslateOne(lines[0], sl, function (err, res) {
      cb(err, err ? null : [res]);
    });
    return;
  }
  var joined = lines.join('\n');
  trFetchGoogle(joined, sl, function (err, res) {
    if (!err && res) {
      var parts = res.split('\n');
      if (parts.length === lines.length) {
        cb(null, parts.map(function (s) { return s.trim(); }));
        return;
      }
    }
    /* در صورت عدم تطابق تعداد خطوط یا خطای گروهی، ترجمه تک‌به‌تک برای حفظ تراز دقیق خط‌به‌خط */
    var out = new Array(lines.length), idx = 0;
    function nextOne() {
      if (idx >= lines.length) { cb(null, out); return; }
      var cur = idx++;
      trTranslateOne(lines[cur], sl, function (e2, r2) {
        if (e2) { cb(e2, null); return; }
        out[cur] = r2;
        nextOne();
      });
    }
    nextOne();
  });
}

function translatePageData(b, pg, sl, jobId, cb) {
  var segs = splitForTranslation(pg.text);
  var todoIdx = [];
  for (var i = 0; i < segs.length; i++) {
    if (segs[i].empty || !trNeedsTranslation(segs[i].o)) {
      segs[i].t = segs[i].o;
    } else {
      todoIdx.push(i);
    }
  }
  if (!todoIdx.length) {
    pg.tr = {
      h: trHash(pg.text),
      sl: sl,
      tl: 'fa',
      segs: segs.map(function (s) { return { o: s.o, t: s.t, pe: s.pe }; })
    };
    scheduleSave();
    cb(null, pg.tr);
    return;
  }

  /* دسته‌بندی هوشمند (حداکثر ۷۰۰ کاراکتر و ۸ خط در هر درخواست برای سرعت و اطمینان بالا) */
  var batches = [], curBatch = [], curLen = 0;
  for (var k = 0; k < todoIdx.length; k++) {
    var segIdx = todoIdx[k];
    var txt = segs[segIdx].o;
    if (curBatch.length && (curBatch.length >= 8 || curLen + txt.length > 700)) {
      batches.push(curBatch);
      curBatch = [];
      curLen = 0;
    }
    curBatch.push(segIdx);
    curLen += txt.length + 2;
  }
  if (curBatch.length) batches.push(curBatch);

  var bPos = 0;
  function runNextBatch() {
    if (jobId !== TR_RUNTIME.jobId) { cb(new Error('cancelled')); return; }
    if (bPos >= batches.length) {
      pg.tr = {
        h: trHash(pg.text),
        sl: sl,
        tl: 'fa',
        segs: segs.map(function (s) { return { o: s.o, t: s.t, pe: s.pe }; })
      };
      scheduleSave();
      cb(null, pg.tr);
      return;
    }
    var idxs = batches[bPos++];
    var texts = idxs.map(function (ix) { return segs[ix].o; });
    trTranslateBatch(texts, sl, function (err, results) {
      if (jobId !== TR_RUNTIME.jobId) { cb(new Error('cancelled')); return; }
      if (err || !results) { cb(err || new Error('tr_fail')); return; }
      for (var m = 0; m < idxs.length; m++) {
        segs[idxs[m]].t = results[m] != null ? results[m] : segs[idxs[m]].o;
      }
      runNextBatch();
    });
  }
  runNextBatch();
}

function trCancelJob() {
  TR_RUNTIME.jobId++;
  TR_RUNTIME.busyPageKey = null;
  TR_RUNTIME.bookJob = null;
}

function renderTranslatedPage(root, b, pg, idx, mode, isActiveBase) {
  root.textContent = '';
  var sl = trEffectiveSrc(b);
  var pKey = b.id + ':' + pg.id;

  if (trCacheValid(pg, sl)) {
    delete TR_RUNTIME.failedPages[pKey];
    var segs = pg.tr.segs;
    var trStyle = b.trStyle || 'standard';
    var frag = document.createDocumentFragment();
    if (mode === 'full') {
      for (var i = 0; i < segs.length; i++) {
        (function (segIdx) {
          var sg = segs[segIdx];
          if (!sg.o || !sg.o.trim()) {
            frag.appendChild(h('div', { class: 'ln empty' }));
            return;
          }
          var dispTxt = getStyledSegText(sg, trStyle);
          var edBtn = h('button', {
            class: 'tr-edit-ic' + (sg.ed ? ' edited' : ''),
            type: 'button',
            title: 'ویرایش دستی ترجمه‌ی این خط',
            html: ic('edit', 14)
          });
          edBtn.addEventListener('click', function (e) { e.stopPropagation(); openEditTrSegment(b, pg, segIdx); });
          var lnEl = h('div', { class: 'ln tr-full-ln', dir: 'rtl', text: dispTxt });
          if (sg.ed) lnEl.appendChild(h('span', { class: 'tr-edited-badge', text: '• ویرایش‌شده' }));
          frag.appendChild(h('div', { class: 'tr-full-row' }, [lnEl, edBtn]));
        })(i);
      }
    } else {
      /* حالت دوزبانه خط‌به‌خط: یک خط زبان اصلی و زیر آن ترجمه فارسی + دکمه ویرایش دستی هر خط */
      for (var j = 0; j < segs.length; j++) {
        (function (segIdx) {
          var s2 = segs[segIdx];
          if (!s2.o || !s2.o.trim()) {
            frag.appendChild(h('div', { class: 'ln empty' }));
            return;
          }
          var dispTxt = getStyledSegText(s2, trStyle);
          var edBtn = h('button', {
            class: 'tr-edit-ic' + (s2.ed ? ' edited' : ''),
            type: 'button',
            title: 'ویرایش دستی ترجمه‌ی این خط',
            html: ic('edit', 14)
          });
          edBtn.addEventListener('click', function (e) { e.stopPropagation(); openEditTrSegment(b, pg, segIdx); });
          var faEl = h('div', { class: 'tr-fa', dir: 'rtl', text: dispTxt });
          if (s2.ed) faEl.appendChild(h('span', { class: 'tr-edited-badge', text: '• ویرایش‌شده' }));
          var pair = h('div', { class: 'tr-pair' }, [
            h('div', { class: 'tr-orig', dir: 'auto', text: s2.o }),
            h('div', { class: 'tr-fa-row' }, [faEl, edBtn])
          ]);
          frag.appendChild(pair);
        })(j);
      }
    }
    root.appendChild(frag);
    return;
  }

  /* هنوز ترجمه نشده: نمایش نوار وضعیت و شروع خودکار ترجمه صفحه فعال */
  var failed = !!TR_RUNTIME.failedPages[pKey];
  var banner;
  if (failed) {
    var retryBtn = h('button', { class: 'tr-banner-retry', type: 'button', text: 'تلاش مجدد' });
    retryBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      delete TR_RUNTIME.failedPages[pKey];
      startTranslateCurrentPage(true);
    });
    banner = h('div', { class: 'tr-banner err' }, [
      h('span', { text: 'ترجمه این صفحه انجام نشد. اتصال اینترنت را بررسی کنید.' }),
      retryBtn
    ]);
  } else {
    banner = h('div', { class: 'tr-banner' }, [
      h('span', { style: 'display:inline-flex;align-items:center;gap:8px' }, [
        h('span', { class: 'tr-spin', 'aria-hidden': 'true' }),
        h('span', { text: 'در حال ترجمه صفحه ' + fa(idx + 1) + ' به فارسی…' })
      ])
    ]);
  }
  root.appendChild(banner);
  var origWrap = h('div', { class: 'tr-dimmed' });
  renderLines(origWrap, pg.text, [], null);
  root.appendChild(origWrap);

  if (isActiveBase && !failed && !TR_RUNTIME.bookJob && TR_RUNTIME.busyPageKey !== pKey) {
    startTranslateCurrentPage(false);
  }
}

function startTranslateCurrentPage(forceRedo) {
  var b = curBook(), pg = currentPage();
  if (!b || !pg) return;
  var pKey = b.id + ':' + pg.id;
  if (forceRedo) {
    delete pg.tr;
    delete TR_RUNTIME.failedPages[pKey];
  }
  trNetEnsure(function (ok) {
    if (!ok) {
      TR_RUNTIME.failedPages[pKey] = true;
      rerenderCurrent();
      return;
    }
    var bNow = curBook(), pgNow = currentPage();
    if (!bNow || !pgNow || bNow.id !== b.id || pgNow.id !== pg.id) return;
    TR_RUNTIME.jobId++;
    var myJob = TR_RUNTIME.jobId;
    TR_RUNTIME.busyPageKey = pKey;
    var sl = trEffectiveSrc(bNow);
    rerenderCurrent();
    translatePageData(bNow, pgNow, sl, myJob, function (err) {
      if (TR_RUNTIME.busyPageKey === pKey) TR_RUNTIME.busyPageKey = null;
      if (err) {
        if (err.message !== 'cancelled') {
          TR_RUNTIME.failedPages[pKey] = true;
          if (S.view === 'reader' && curBook() && curBook().id === bNow.id) rerenderCurrent();
          toast('خطا در ترجمه صفحه؛ اتصال اینترنت را بررسی کنید');
        }
        return;
      }
      flushSave();
      if (S.view === 'reader' && curBook() && curBook().id === bNow.id) {
        rerenderCurrent();
        renderTrBar();
      }
    });
  });
}

function startTranslateWholeBook() {
  var b = curBook();
  if (!b || !b.pages.length) { toast('این کتاب صفحه‌ای برای ترجمه ندارد'); return; }
  if (TR_RUNTIME.bookJob) {
    trCancelJob();
    renderTrBar();
    toast('ترجمه کل کتاب متوقف شد');
    return;
  }
  trNetEnsure(function (ok) {
    if (!ok) return;
    var bNow = curBook();
    if (!bNow || bNow.id !== b.id) return;
    if (!bNow.trMode || bNow.trMode === 'off') {
      bNow.trMode = 'full';
      scheduleSave();
      updateTrBtn();
    }
    TR_RUNTIME.jobId++;
    var myJob = TR_RUNTIME.jobId;
    var sl = trEffectiveSrc(bNow);
    var total = bNow.pages.length;
    TR_RUNTIME.bookJob = { bookId: bNow.id, done: 0, total: total, failed: 0 };
    renderTrBar();

    var idx = 0;
    function nextPg() {
      if (myJob !== TR_RUNTIME.jobId) return;
      if (idx >= total) {
        var failedCnt = TR_RUNTIME.bookJob ? TR_RUNTIME.bookJob.failed : 0;
        TR_RUNTIME.bookJob = null;
        flushSave();
        renderTrBar();
        if (S.view === 'reader' && curBook() && curBook().id === bNow.id) rerenderCurrent();
        toast(failedCnt ? ('ترجمه کتاب با ' + fa(failedCnt) + ' صفحه ناموفق پایان یافت') : 'ترجمه کل کتاب تکمیل و ذخیره شد');
        return;
      }
      var pg = bNow.pages[idx];
      var curIdx = idx++;
      if (trCacheValid(pg, sl)) {
        if (TR_RUNTIME.bookJob) TR_RUNTIME.bookJob.done = curIdx + 1;
        renderTrBar();
        setTimeout(nextPg, 10);
        return;
      }
      translatePageData(bNow, pg, sl, myJob, function (err) {
        if (myJob !== TR_RUNTIME.jobId) return;
        if (err && err.message !== 'cancelled') {
          if (TR_RUNTIME.bookJob) TR_RUNTIME.bookJob.failed++;
        } else if (!err) {
          delete TR_RUNTIME.failedPages[bNow.id + ':' + pg.id];
          if (S.view === 'reader' && curBook() && curBook().id === bNow.id && S.index === curIdx) {
            rerenderCurrent();
          }
        }
        if (TR_RUNTIME.bookJob) TR_RUNTIME.bookJob.done = curIdx + 1;
        renderTrBar();
        setTimeout(nextPg, 120);
      });
    }
    nextPg();
  });
}

function setBookTrMode(mode) {
  var b = curBook(); if (!b) return;
  mode = (mode === 'full' || mode === 'bilingual') ? mode : 'off';
  if (b.trMode === mode) {
    if (mode !== 'off') {
      var pg = currentPage();
      if (pg && !trCacheValid(pg, trEffectiveSrc(b))) startTranslateCurrentPage(false);
    }
    return;
  }
  b.trMode = mode;
  scheduleSave();
  hideBar();
  updateTrBtn();
  renderTrBar();
  rerenderCurrent();
  if (mode === 'off') toast('نمایش متن اصلی کتاب');
  else if (mode === 'full') toast('حالت ترجمه کامل فارسی فعال شد');
  else toast('حالت دوزبانه خط‌به‌خط فعال شد');
}

function updateTrBtn() {
  var btn = $('#rdTr');
  if (!btn) return;
  var b = curBook();
  var mode = b ? (b.trMode || 'off') : 'off';
  btn.classList.toggle('tr-on', mode !== 'off');
  var badgeHtml = mode === 'full' ? '<span class="tr-badge">ف</span>' : (mode === 'bilingual' ? '<span class="tr-badge">۲</span>' : '');
  btn.innerHTML = ic('translate', 21) + badgeHtml;
  btn.title = mode === 'full' ? 'افزونه ترجمه: ترجمه کامل فعال' : (mode === 'bilingual' ? 'افزونه ترجمه: دوزبانه خط‌به‌خط فعال' : 'افزونه ترجمه کتاب (کامل / دوزبانه خط‌به‌خط)');
}

function toggleTrBar() {
  openTrBar(!S.trBarOpen);
}

function openTrBar(show) {
  S.trBarOpen = !!show;
  renderTrBar();
}

function openBookWithTranslator(bookId) {
  openBook(bookId);
  openTrBar(true);
}

function renderTrBar() {
  var bar = $('#trBar');
  if (!bar) return;
  var b = curBook();
  if (!S.trBarOpen || !b || S.view !== 'reader') {
    bar.classList.add('hidden');
    return;
  }
  bar.classList.remove('hidden');
  bar.textContent = '';

  var mode = b.trMode || 'off';
  var modesWrap = h('div', { class: 'tr-modes', role: 'group', 'aria-label': 'حالت ترجمه' });
  [
    { id: 'off',       label: 'متن اصلی' },
    { id: 'full',      label: 'ترجمه کامل' },
    { id: 'bilingual', label: 'دوزبانه خط‌به‌خط' }
  ].forEach(function (m) {
    var bt = h('button', { class: 'tr-mode-btn' + (mode === m.id ? ' on' : ''), type: 'button', text: m.label });
    bt.addEventListener('click', function () { hapticTap(); setBookTrMode(m.id); });
    modesWrap.appendChild(bt);
  });
  bar.appendChild(modesWrap);

  var tools = h('div', { class: 'tr-tools' });
  var sel = h('select', { class: 'tr-lang-sel', 'aria-label': 'زبان مبدأ کتاب' });
  var curSrc = b.trSrc || 'auto';
  TR_SRC_LANGS.forEach(function (lg) {
    var opt = h('option', { value: lg.id, text: lg.name });
    if (lg.id === curSrc) opt.selected = true;
    sel.appendChild(opt);
  });
  sel.addEventListener('change', function () {
    b.trSrc = sel.value || 'auto';
    scheduleSave();
    if (b.trMode && b.trMode !== 'off') startTranslateCurrentPage(true);
  });
  tools.appendChild(sel);

  var stSel = h('select', { class: 'tr-lang-sel', 'aria-label': 'سبک ترجمه فارسی' });
  var curStyle = b.trStyle || 'standard';
  TR_STYLES.forEach(function (stOpt) {
    var opt = h('option', { value: stOpt.id, text: stOpt.name });
    if (stOpt.id === curStyle) opt.selected = true;
    stSel.appendChild(opt);
  });
  stSel.addEventListener('change', function () {
    b.trStyle = stSel.value || 'standard';
    scheduleSave();
    if (b.trMode && b.trMode !== 'off') rerenderCurrent();
    toast('سبک ترجمه روی «' + (b.trStyle === 'formal' ? 'تخصصی و رسمی' : (b.trStyle === 'colloquial' ? 'عامیانه و روان' : 'استاندارد')) + '» تنظیم شد');
  });
  tools.appendChild(stSel);

  var isBookJob = !!(TR_RUNTIME.bookJob && TR_RUNTIME.bookJob.bookId === b.id);
  var allBtn = h('button', {
    class: 'tr-act-btn ' + (isBookJob ? 'danger' : 'primary'),
    type: 'button',
    text: isBookJob ? 'توقف ترجمه' : 'ترجمه کل کتاب'
  });
  allBtn.addEventListener('click', function () { hapticTap(); startTranslateWholeBook(); });
  tools.appendChild(allBtn);

  var redoBtn = h('button', {
    class: 'tr-act-btn',
    type: 'button',
    title: 'ترجمه مجدد این صفحه',
    html: ic('rotate', 15) + '<span>بازترجمه</span>'
  });
  redoBtn.disabled = !currentPage() || isBookJob;
  redoBtn.addEventListener('click', function () {
    hapticTap();
    if (!b.trMode || b.trMode === 'off') { b.trMode = 'full'; updateTrBtn(); }
    startTranslateCurrentPage(true);
  });
  tools.appendChild(redoBtn);

  var copyTrBtn = h('button', {
    class: 'tr-act-btn',
    type: 'button',
    title: 'کپی متن ترجمه‌شده یا دوزبانه این صفحه',
    html: ic('copy', 15) + '<span>کپی</span>'
  });
  copyTrBtn.disabled = !currentPage() || mode === 'off';
  copyTrBtn.addEventListener('click', function () { hapticTap(); copyCurrentTranslation(); });
  tools.appendChild(copyTrBtn);

  var expTrBtn = h('button', {
    class: 'tr-act-btn',
    type: 'button',
    title: 'خروجی PDF / Word / Markdown از ترجمه یا نمای دوزبانه',
    html: ic('share', 15) + '<span>خروجی</span>'
  });
  expTrBtn.addEventListener('click', function () { hapticTap(); openTranslatedExportSheet(b); });
  tools.appendChild(expTrBtn);

  var closeBtn = h('button', { class: 'tr-act-btn tr-close-btn', type: 'button', 'aria-label': 'بستن نوار ترجمه', html: ic('x', 16) });
  closeBtn.addEventListener('click', function () { openTrBar(false); });
  tools.appendChild(closeBtn);
  bar.appendChild(tools);

  if (isBookJob) {
    var done = TR_RUNTIME.bookJob.done | 0;
    var tot = Math.max(1, TR_RUNTIME.bookJob.total | 0);
    var pct = Math.round((done / tot) * 100);
    bar.appendChild(h('div', { class: 'tr-prog-wrap' }, [
      h('div', { class: 'tr-prog-txt' }, [
        h('span', { text: 'در حال ترجمه کل کتاب: صفحه ' + fa(done) + ' از ' + fa(tot) }),
        h('span', { text: fa(pct) + '٪' })
      ]),
      h('div', { class: 'tr-prog-track' }, [
        h('div', { class: 'tr-prog-fill', style: 'width:' + pct + '%' })
      ])
    ]));
  } else {
    var slNow = trEffectiveSrc(b);
    var cachedCnt = 0;
    for (var pi = 0; pi < b.pages.length; pi++) if (trCacheValid(b.pages[pi], slNow)) cachedCnt++;
    if (cachedCnt > 0 && b.pages.length > 0) {
      var clrBtn = h('button', { class: 'tr-clear-link', type: 'button', text: 'پاکسازی حافظه ترجمه' });
      clrBtn.addEventListener('click', function () { clearBookTranslations(b); });
      bar.appendChild(h('div', { class: 'tr-prog-txt' }, [
        h('span', { text: fa(cachedCnt) + ' از ' + fa(b.pages.length) + ' صفحه ذخیره آفلاین شده' }),
        clrBtn
      ]));
    }
  }
}


/* =====================================================================
   کپی و پاکسازی ترجمه + بارگذاری مستقیم فایل‌های Word (.docx) و PDF (.pdf) — v2.6
   ===================================================================== */
function formatTranslatedPageText(pg, mode, trStyle) {
  if (!pg || !pg.tr || !Array.isArray(pg.tr.segs)) return '';
  var b = curBook();
  var st = trStyle || (b && b.trStyle) || 'standard';
  var segs = pg.tr.segs, out = [];
  if (mode === 'full') {
    var para = [];
    for (var i = 0; i < segs.length; i++) {
      var sg = segs[i];
      if (!sg.o || !sg.o.trim()) {
        if (para.length) { out.push(para.join(' ')); para = []; }
        out.push('');
      } else {
        para.push(getStyledSegText(sg, st).trim());
        if (sg.pe) { out.push(para.join(' ')); para = []; }
      }
    }
    if (para.length) out.push(para.join(' '));
    return out.join('\n');
  }
  for (var j = 0; j < segs.length; j++) {
    var s2 = segs[j];
    if (!s2.o || !s2.o.trim()) { out.push(''); continue; }
    out.push(s2.o + '\n' + getStyledSegText(s2, st));
  }
  return out.join('\n\n');
}

function copyCurrentTranslation() {
  var b = curBook(), pg = currentPage();
  if (!b || !pg) return;
  var mode = b.trMode || 'off';
  if (mode === 'off' || !trCacheValid(pg, trEffectiveSrc(b))) {
    toast('ابتدا این صفحه را ترجمه کنید');
    return;
  }
  var txt = formatTranslatedPageText(pg, mode);
  if (!txt.trim()) { toast('متنی برای کپی وجود ندارد'); return; }
  if (bridge('copy')) { try { A.copy(txt); toast('متن ترجمه‌شده کپی شد'); return; } catch (e) {} }
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(txt).then(function () { toast('متن ترجمه‌شده کپی شد'); }, function () { shareText(txt, b.title); });
  } else {
    shareText(txt, b.title);
  }
}

function clearBookTranslations(b) {
  if (!b) return;
  dialog({
    title: 'پاکسازی حافظه ترجمه',
    message: 'ترجمه‌های ذخیره‌شده‌ی این کتاب پاک شوند؟ (متن اصلی کتاب دست‌نخورده باقی می‌ماند)',
    ok: 'بله، پاک کن',
    cancel: 'انصراف',
    danger: true
  }).then(function (ok) {
    if (!ok) return;
    trCancelJob();
    b.pages.forEach(function (p) { delete p.tr; });
    b.trMode = 'off';
    scheduleSave();
    flushSave();
    updateTrBtn();
    renderTrBar();
    rerenderCurrent();
    toast('حافظه ترجمه‌ی این کتاب پاک شد');
  });
}

var DOC_IMPORT_CTX = null;

function openImportDocFlow(targetBook) {
  var opts = {
    mode: 'auto',
    lang: targetBook ? (targetBook.lg || 'auto') : (bLangFilter !== 'all' ? bLangFilter : 'auto'),
    targetBookId: targetBook ? targetBook.id : null
  };

  var L = sheet(targetBook ? 'افزودن فایل Word / PDF به کتاب' : 'بارگذاری فایل Word / PDF در بخش کتاب‌ها', function (body) {
    body.appendChild(h('div', { class: 'imp-card' }, [
      h('div', { class: 'imp-card-h', html: ic('upload', 18) + '<span>پشتیبانی کامل از فایل‌های متنی و کتاب‌ها</span>' }),
      h('p', { class: 'imp-hint', text: 'فایل‌های Word (.docx) با حفظ کامل متن، جداول، پاورقی‌ها و نیم‌فاصله‌ها و فایل‌های PDF (.pdf) با حفظ ساختار صفحات مستقیم به کتابچه وارد می‌شوند.' }),
      h('div', { class: 'imp-badges' }, [
        h('span', { class: 'imp-badge', text: 'Word (.docx)' }),
        h('span', { class: 'imp-badge', text: 'PDF (.pdf)' }),
        h('span', { class: 'imp-badge', text: 'EPUB (.epub)' }),
        h('span', { class: 'imp-badge', text: 'Markdown (.md)' }),
        h('span', { class: 'imp-badge', text: 'متن ساده (.txt)' })
      ])
    ]));

    body.appendChild(h('div', { class: 'set-h', html: ic('layers', 18) + '<span>نحوه صفحه‌بندی هنگام بارگذاری</span>' }));
    var modeSeg = h('div', { class: 'seg', style: 'margin-bottom:12px' });
    [
      { id: 'auto',       label: 'صفحه‌بندی خودکار (توصیه‌شده)' },
      { id: 'continuous', label: 'یک صفحه پیوسته و اسکرول‌پذیر' }
    ].forEach(function (m) {
      var bt = h('button', { class: opts.mode === m.id ? 'on' : '', type: 'button', text: m.label });
      bt.addEventListener('click', function () {
        opts.mode = m.id;
        $$('button', modeSeg).forEach(function (x) { x.classList.remove('on'); });
        bt.classList.add('on');
      });
      modeSeg.appendChild(bt);
    });
    body.appendChild(modeSeg);

    if (!targetBook) {
      body.appendChild(h('div', { class: 'set-h', html: ic('folder', 18) + '<span>بخش ذخیره کتاب</span>' }));
      var lgSel = h('select', { class: 'field', style: 'margin-bottom:14px' });
      [
        { id: 'auto', name: 'تشخیص خودکار زبان متن' },
        { id: 'fa',   name: 'کتاب‌های فارسی' },
        { id: 'en',   name: 'کتاب‌های انگلیسی' },
        { id: 'ar',   name: 'کتاب‌های عربی' },
        { id: 'fr',   name: 'کتاب‌های فرانسوی' },
        { id: 'de',   name: 'کتاب‌های آلمانی' },
        { id: 'tr',   name: 'کتاب‌های ترکی' }
      ].forEach(function (x) {
        var o = h('option', { value: x.id, text: x.name });
        if (x.id === opts.lang) o.selected = true;
        lgSel.appendChild(o);
      });
      lgSel.addEventListener('change', function () { opts.lang = lgSel.value || 'auto'; });
      body.appendChild(lgSel);
    }

    var pickBtn = h('button', { class: 'btn pri', style: 'width:100%;margin-top:4px', type: 'button', html: ic('upload', 18) + '<span>انتخاب فایل Word یا PDF از گوشی…</span>' });
    pickBtn.addEventListener('click', function () {
      hapticTap();
      DOC_IMPORT_CTX = { mode: opts.mode, lang: opts.lang, targetBookId: opts.targetBookId };
      L.close(true);
      if (bridge('pickBookDoc')) {
        toast('در حال باز کردن انتخاب‌گر فایل…');
        try { A.pickBookDoc(); } catch (e) { toast('باز کردن انتخاب‌گر فایل انجام نشد'); DOC_IMPORT_CTX = null; }
      } else {
        /* پشتیبان مرورگر برای تست سریع فایل‌های متنی */
        var inp = h('input', { type: 'file', accept: '.docx,.pdf,.txt,.md' });
        inp.addEventListener('change', function () {
          var f = inp.files && inp.files[0];
          if (!f) { DOC_IMPORT_CTX = null; return; }
          var nm = String(f.name || '');
          if (/\.(docx|pdf)$/i.test(nm)) {
            toast('پردازش کامل Word و PDF در نسخه‌ی اندروید کتابچه انجام می‌شود');
            DOC_IMPORT_CTX = null;
            return;
          }
          var fr = new FileReader();
          fr.onload = function () {
            finishBookDocImport({ title: nm.replace(/\.[^.]+$/, '') || 'کتاب جدید', ext: 'txt', pages: [String(fr.result || '')] });
          };
          fr.readAsText(f, 'utf-8');
        });
        inp.click();
      }
    });
    body.appendChild(pickBtn);
  });
}

function splitLongDocToPages(text) {
  text = norm(text);
  if (!text) return [];
  if (typeof splitToFit === 'function') {
    var chunks = splitToFit(text, 2200);
    if (chunks && chunks.length) return chunks;
  }
  var lines = text.split('\n'), out = [], cur = '';
  for (var i = 0; i < lines.length; i++) {
    var ln = lines[i];
    if (cur.length + ln.length + 1 > 2200 && cur.trim()) {
      out.push(cur.trim());
      cur = ln;
    } else {
      cur += (cur ? '\n' : '') + ln;
    }
  }
  if (cur.trim()) out.push(cur.trim());
  return out;
}

function finishBookDocImport(payload) {
  var ctx = DOC_IMPORT_CTX || { mode: 'auto', lang: 'auto', targetBookId: null };
  DOC_IMPORT_CTX = null;
  if (!payload || payload.error) {
    var err = payload && payload.error ? payload.error : 'unknown';
    if (err === 'no_text') {
      dialog({ title: 'متنی در فایل یافت نشد', message: 'در این فایل متنی برای استخراج پیدا نشد. اگر فایل PDF شما به صورت عکس اسکن‌شده است، ابتدا باید متن آن استخراج (OCR) شود.', ok: 'متوجه شدم', noCancel: true });
    } else {
      toast('خواندن یا استخراج متن فایل انجام نشد');
    }
    return;
  }

  var rawPages = Array.isArray(payload.pages) ? payload.pages.filter(function (x) { return String(x || '').trim().length > 0; }) : [];
  if (!rawPages.length) { toast('این فایل خالی است'); return; }

  var finalPages = [];
  if (ctx.mode === 'continuous') {
    finalPages = [rawPages.map(function (p) { return norm(p); }).join('\n\n')];
  } else if ((payload.ext === 'pdf' || payload.ext === 'epub') && rawPages.length > 1) {
    finalPages = rawPages.map(function (p) { return norm(p); });
  } else {
    rawPages.forEach(function (p) {
      var parts = splitLongDocToPages(p);
      for (var k = 0; k < parts.length; k++) finalPages.push(parts[k]);
    });
  }
  if (!finalPages.length) { toast('متن قابل نمایشی یافت نشد'); return; }

  var now = Date.now();
  var target = ctx.targetBookId ? bookById(ctx.targetBookId) : null;
  if (target) {
    var startIdx = target.pages.length;
    finalPages.forEach(function (txt, idx) {
      target.pages.push({ id: uid(), text: txt, created: now + idx, updated: now + idx, hl: [], bm: false });
    });
    target.updated = now;
    scheduleSave(); flushSave();
    toast(fa(finalPages.length) + ' صفحه از فایل ' + String(payload.ext || '').toUpperCase() + ' به کتاب افزوده شد');
    if (S.view === 'reader' && curBook() && curBook().id === target.id) {
      showPageNow(startIdx);
    } else {
      openBook(target.id);
      showPageNow(startIdx);
    }
    return;
  }

  var sample = finalPages.slice(0, 3).join(' ').slice(0, 2000);
  var detectedLg = ctx.lang && ctx.lang !== 'auto' ? ctx.lang : (typeof scoreText === 'function' ? scoreText(sample) : 'fa');
  if (!/^(fa|en|fr|de|ar|tr)$/.test(detectedLg)) detectedLg = 'fa';

  var newBook = {
    id: uid(),
    title: String(payload.title || 'کتاب واردشده').slice(0, 120),
    lg: detectedLg,
    trMode: 'off',
    trSrc: 'auto',
    trStyle: 'standard',
    chapters: (ctx.mode !== 'continuous' && Array.isArray(payload.chapters)) ? payload.chapters : [],
    color: (S.data.nextCover++ | 0) % COVERS.length,
    created: now,
    updated: now,
    last: 0,
    pages: finalPages.map(function (txt, idx) {
      return { id: uid(), text: txt, created: now + idx, updated: now + idx, hl: [], bm: false };
    })
  };
  S.data.books.unshift(newBook);
  scheduleSave(); flushSave();
  toast('کتاب «' + newBook.title + '» (' + fa(finalPages.length) + ' صفحه) با موفقیت وارد شد');
  openBook(newBook.id);
}

window.onBookDocImported = function (b64) {
  try {
    var bin = atob(b64 || ''), bytes = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    var jsonStr = new TextDecoder('utf-8').decode(bytes);
    var payload = JSON.parse(jsonStr);
    finishBookDocImport(payload);
  } catch (e) {
    DOC_IMPORT_CTX = null;
    toast('خطا در پردازش فایل انتخاب‌شده');
  }
};
window.onBookDocFailed = function (reason) {
  DOC_IMPORT_CTX = null;
  if (reason === 'too_big') toast('حجم فایل بیشتر از حد مجاز (۴۵ مگابایت) است');
  else if (reason === 'invalid_docx') toast('فایل Word معتبر نیست یا خراب است');
  else toast('خواندن فایل Word/PDF انجام نشد');
};
window.onBookDocCancelled = function () {
  DOC_IMPORT_CTX = null;
};


/* =====================================================================
   ماژول‌های نسخه‌ی ۲٫۷: سبک ترجمه (تخصصی/عامیانه)، ویرایش دستی هر خط،
   خروجی دوزبانه/ترجمه‌شده، معنی فوری با دو بار لمس، فهرست فصل‌ها، آمار و پومودورو
   ===================================================================== */
var TR_STYLES = [
  { id: 'standard',   name: 'سبک: استاندارد' },
  { id: 'formal',     name: 'سبک: تخصصی و رسمی' },
  { id: 'colloquial', name: 'سبک: عامیانه و روان' }
];

var FORMAL_RULES = [
  [/می[\s\u200c]*تونه(?=\s|[.!؟،؛]|$)/g, 'می‌تواند'],
  [/می[\s\u200c]*تونن(?=\s|[.!؟،؛]|$)/g, 'می‌توانند'],
  [/می[\s\u200c]*تونم(?=\s|[.!؟،؛]|$)/g, 'می‌توانم'],
  [/می[\s\u200c]*تونید(?=\s|[.!؟،؛]|$)/g, 'می‌توانید'],
  [/می[\s\u200c]*تونیم(?=\s|[.!؟،؛]|$)/g, 'می‌توانیم'],
  [/نمی[\s\u200c]*تونه(?=\s|[.!؟،؛]|$)/g, 'نمی‌تواند'],
  [/می[\s\u200c]*شه(?=\s|[.!؟،؛]|$)/g, 'می‌شود'],
  [/نمی[\s\u200c]*شه(?=\s|[.!؟،؛]|$)/g, 'نمی‌شود'],
  [/می[\s\u200c]*کنه(?=\s|[.!؟،؛]|$)/g, 'می‌کند'],
  [/نمی[\s\u200c]*کنه(?=\s|[.!؟،؛]|$)/g, 'نمی‌کند'],
  [/می[\s\u200c]*کنن(?=\s|[.!؟،؛]|$)/g, 'می‌کنند'],
  [/می[\s\u200c]*خواد(?=\s|[.!؟،؛]|$)/g, 'می‌خواهد'],
  [/می[\s\u200c]*ده(?=\s|[.!؟،؛]|$)/g, 'می‌دهد'],
  [/می[\s\u200c]*گه(?=\s|[.!؟،؛]|$)/g, 'می‌گوید'],
  [/داره(?=\s|[.!؟،؛]|$)/g, 'دارد'],
  [/نداره(?=\s|[.!؟،؛]|$)/g, 'ندارد'],
  [/واسه(?=\s)/g, 'برای'],
  [/خیلی(?=\s)/g, 'بسیار'],
  [/چطور(?=\s)/g, 'چگونه'],
  [/الان(?=\s|[.!؟،؛]|$)/g, 'اکنون'],
  [/هیچ[\s\u200c]*وقت(?=\s)/g, 'هیچ‌گاه'],
  [/شروع کرد(?=\s|[.!؟،؛]|$)/g, 'آغاز نمود'],
  [/استفاده کنید(?=\s|[.!؟،؛]|$)/g, 'بهره‌گیری نمایید'],
  [/استفاده کرد(?=\s|[.!؟،؛]|$)/g, 'بهره‌برداری نمود'],
  [/\bمی\s+(?=[آابپتثجچحخدذرزژسشصضطظعغفقکگلمنوهی])/g, 'می‌'],
  [/\bنمی\s+(?=[آابپتثجچحخدذرزژسشصضطظعغفقکگلمنوهی])/g, 'نمی‌']
];

var COLLOQUIAL_RULES = [
  [/می[\s\u200c]*توانید(?=\s|[.!؟،؛]|$)/g, 'می‌تونید'],
  [/نمی[\s\u200c]*توانید(?=\s|[.!؟،؛]|$)/g, 'نمی‌تونید'],
  [/می[\s\u200c]*تواند(?=\s|[.!؟،؛]|$)/g, 'می‌تونه'],
  [/نمی[\s\u200c]*تواند(?=\s|[.!؟،؛]|$)/g, 'نمی‌تونه'],
  [/می[\s\u200c]*توانم(?=\s|[.!؟،؛]|$)/g, 'می‌تونم'],
  [/می[\s\u200c]*توانیم(?=\s|[.!؟،؛]|$)/g, 'می‌تونیم'],
  [/می[\s\u200c]*توانند(?=\s|[.!؟،؛]|$)/g, 'می‌تونن'],
  [/می[\s\u200c]*شود(?=\s|[.!؟،؛]|$)/g, 'می‌شه'],
  [/نمی[\s\u200c]*شود(?=\s|[.!؟،؛]|$)/g, 'نمی‌شه'],
  [/می[\s\u200c]*شوند(?=\s|[.!؟،؛]|$)/g, 'می‌شن'],
  [/می[\s\u200c]*کند(?=\s|[.!؟،؛]|$)/g, 'می‌کنه'],
  [/نمی[\s\u200c]*کند(?=\s|[.!؟،؛]|$)/g, 'نمی‌کنه'],
  [/می[\s\u200c]*کنند(?=\s|[.!؟،؛]|$)/g, 'می‌کنن'],
  [/می[\s\u200c]*خواهد(?=\s|[.!؟،؛]|$)/g, 'می‌خواد'],
  [/می[\s\u200c]*خواهید(?=\s|[.!؟،؛]|$)/g, 'می‌خواید'],
  [/می[\s\u200c]*دهد(?=\s|[.!؟،؛]|$)/g, 'می‌ده'],
  [/می[\s\u200c]*دهند(?=\s|[.!؟،؛]|$)/g, 'می‌دن'],
  [/می[\s\u200c]*گوید(?=\s|[.!؟،؛]|$)/g, 'می‌گه'],
  [/می[\s\u200c]*رود(?=\s|[.!؟،؛]|$)/g, 'می‌ره'],
  [/می[\s\u200c]*آید(?=\s|[.!؟،؛]|$)/g, 'می‌یاد'],
  [/می[\s\u200c]*آورد(?=\s|[.!؟،؛]|$)/g, 'می‌آره'],
  [/می[\s\u200c]*گشایند(?=\s|[.!؟،؛]|$)/g, 'باز می‌کنن'],
  [/دارد(?=\s|[.!؟،؛]|$)/g, 'داره'],
  [/ندارد(?=\s|[.!؟،؛]|$)/g, 'نداره'],
  [/دارند(?=\s|[.!؟،؛]|$)/g, 'دارن'],
  [/شده است(?=\s|[.!؟،؛]|$)/g, 'شده'],
  [/بوده است(?=\s|[.!؟،؛]|$)/g, 'بوده'],
  [/بسیار(?=\s)/g, 'خیلی'],
  [/چگونه(?=\s)/g, 'چطور'],
  [/زیرا(?=\s)/g, 'چون'],
  [/بنابراین(?=\s|[،]|$)/g, 'پس'],
  [/همچنین(?=\s)/g, 'همین‌طور'],
  [/اکنون(?=\s|[.!؟،؛]|$)/g, 'الان'],
  [/هیچ[\s\u200c]*گاه(?=\s)/g, 'هیچ‌وقت'],
  [/همواره(?=\s)/g, 'همیشه'],
  [/آنان(?=\s)/g, 'اون‌ها'],
  [/ایشان(?=\s)/g, 'ایشون'],
  [/انتخاب کنید(?=\s|[.!؟،؛]|$)/g, 'انتخاب کنین'],
  [/ذخیره کنید(?=\s|[.!؟،؛]|$)/g, 'ذخیره کنین'],
  [/گوش دهید(?=\s|[.!؟،؛]|$)/g, 'گوش بدین']
];

function applyPersianTranslationStyle(text, style) {
  var s = String(text || '');
  if (!s || !style || style === 'standard') return s;
  var rules = style === 'formal' ? FORMAL_RULES : (style === 'colloquial' ? COLLOQUIAL_RULES : null);
  if (!rules) return s;
  for (var i = 0; i < rules.length; i++) {
    s = s.replace(rules[i][0], rules[i][1]);
  }
  return s;
}

function getStyledSegText(sg, style) {
  if (!sg) return '';
  if (sg.ed) return sg.t || sg.o || '';
  return applyPersianTranslationStyle(sg.t || sg.o || '', style);
}

/* ---------- ویرایش دستی ترجمه‌ی هر خط ---------- */
function openEditTrSegment(b, pg, segIdx) {
  if (!b || !pg || !pg.tr || !pg.tr.segs || !pg.tr.segs[segIdx]) return;
  var sg = pg.tr.segs[segIdx];
  var curDisp = getStyledSegText(sg, b.trStyle || 'standard');
  sheet('ویرایش دستی ترجمه‌ی خط', function (body, L) {
    body.appendChild(h('div', { class: 'imp-card' }, [
      h('div', { class: 'imp-card-h', text: 'متن اصلی:' }),
      h('p', { class: 'imp-hint', dir: 'auto', style: 'color:var(--ink);font-size:14px', text: sg.o })
    ]));
    var ta = h('textarea', { class: 'field', rows: 4, dir: 'rtl', style: 'width:100%;min-height:96px;line-height:1.75;margin-bottom:12px' });
    ta.value = curDisp;
    body.appendChild(ta);

    var acts = h('div', { style: 'display:flex;gap:8px;flex-wrap:wrap' });
    var saveBtn = h('button', { class: 'btn pri', style: 'flex:1', type: 'button', text: 'ذخیره‌ی ترجمه' });
    saveBtn.addEventListener('click', function () {
      var val = ta.value.trim();
      if (!val) { toast('متن ترجمه نمی‌تواند خالی باشد'); return; }
      if (typeof sg.rawT !== 'string') sg.rawT = sg.t || '';
      sg.t = val;
      sg.ed = true;
      scheduleSave(); flushSave();
      L.close(true);
      rerenderCurrent();
      toast('ترجمه‌ی این خط ذخیره شد');
    });
    acts.appendChild(saveBtn);

    if (sg.ed && typeof sg.rawT === 'string') {
      var rstBtn = h('button', { class: 'btn', type: 'button', text: 'بازگردانی ترجمه خودکار' });
      rstBtn.addEventListener('click', function () {
        sg.t = sg.rawT;
        delete sg.ed;
        scheduleSave(); flushSave();
        L.close(true);
        rerenderCurrent();
        toast('ترجمه‌ی خودکار بازگردانی شد');
      });
      acts.appendChild(rstBtn);
    }
    body.appendChild(acts);
    setTimeout(function () { ta.focus(); }, 80);
  });
}

/* ---------- خروجی PDF / Word / Markdown / JS از نسخه‌ی ترجمه‌شده یا دوزبانه ---------- */
function buildTranslatedBookDocSpec(bk, onlyPageIdx, trLayout) {
  if (!bk || !bk.pages || !bk.pages.length) return null;
  var style = bk.trStyle || 'standard';
  var styleLbl = style === 'formal' ? 'تخصصی' : (style === 'colloquial' ? 'عامیانه' : 'استاندارد');
  var layLbl = trLayout === 'full' ? 'ترجمه کامل فارسی' : 'دوزبانه خط‌به‌خط';
  var indices = onlyPageIdx != null ? [onlyPageIdx] : bk.pages.map(function (_, i) { return i; });
  var pagesSpec = [];
  indices.forEach(function (idx) {
    var pg = bk.pages[idx];
    if (!pg) return;
    var hasTr = pg.tr && Array.isArray(pg.tr.segs) && pg.tr.segs.length > 0;
    var txt = hasTr ? formatTranslatedPageText(pg, trLayout, style) : pg.text;
    pagesSpec.push({
      heading: 'صفحه ' + fa(idx + 1) + (hasTr ? '' : ' (بدون ترجمه)'),
      meta: hasTr ? (layLbl + ' · سبک ' + styleLbl) : 'متن اصلی (ترجمه نشده)',
      text: txt,
      hl: []
    });
  });
  return {
    kind: 'pages',
    title: bk.title + ' (' + layLbl + ')',
    subtitle: 'خروجی کتابچه · ' + layLbl + ' · سبک ' + styleLbl + ' · ' + fmtDate(Date.now()),
    filename: bk.title + (trLayout === 'full' ? '-ترجمه' : '-دوزبانه'),
    bookMeta: {
      sectionName: getBookSectionMeta(getBookEffLang(bk)).name,
      scopeLabel: onlyPageIdx != null ? ('صفحه ' + fa(onlyPageIdx + 1)) : ('کل کتاب (' + fa(pagesSpec.length) + ' صفحه)'),
      totalPages: bk.pages.length
    },
    pages: pagesSpec
  };
}

function openTranslatedExportSheet(bk) {
  if (!bk || !bk.pages.length) { toast('این کتاب صفحه‌ای برای خروجی ندارد'); return; }
  var opts = {
    scope: S.view === 'reader' && S.index < bk.pages.length ? 'page' : 'book',
    layout: bk.trMode === 'full' ? 'full' : 'bilingual'
  };
  var trCount = bk.pages.filter(function (p) { return p.tr && Array.isArray(p.tr.segs) && p.tr.segs.length; }).length;

  sheet('خروجی نسخه‌ی ترجمه‌شده و دوزبانه', function (body, L) {
    body.appendChild(h('p', { class: 'imp-hint', style: 'margin-bottom:10px', text: fa(trCount) + ' از ' + fa(bk.pages.length) + ' صفحه از این کتاب ترجمه شده است. (صفحات ترجمه‌نشده با متن اصلی در خروجی می‌آیند)' }));

    body.appendChild(h('div', { class: 'set-h', html: ic('layers', 18) + '<span>محدوده‌ی خروجی</span>' }));
    var scSeg = h('div', { class: 'seg', style: 'margin-bottom:12px' });
    [
      { id: 'page', label: 'همین صفحه (' + fa(Math.min(S.index + 1, bk.pages.length)) + ')' },
      { id: 'book', label: 'کل کتاب (' + fa(bk.pages.length) + ' ص)' }
    ].forEach(function (x) {
      var bt = h('button', { class: opts.scope === x.id ? 'on' : '', type: 'button', text: x.label });
      bt.addEventListener('click', function () {
        opts.scope = x.id;
        $$('button', scSeg).forEach(function (b2) { b2.classList.remove('on'); });
        bt.classList.add('on');
      });
      scSeg.appendChild(bt);
    });
    body.appendChild(scSeg);

    body.appendChild(h('div', { class: 'set-h', html: ic('translate', 18) + '<span>چیدمان متن در خروجی</span>' }));
    var lySeg = h('div', { class: 'seg', style: 'margin-bottom:14px' });
    [
      { id: 'bilingual', label: 'دوزبانه خط‌به‌خط' },
      { id: 'full',      label: 'ترجمه کامل فارسی' }
    ].forEach(function (x) {
      var bt = h('button', { class: opts.layout === x.id ? 'on' : '', type: 'button', text: x.label });
      bt.addEventListener('click', function () {
        opts.layout = x.id;
        $$('button', lySeg).forEach(function (b2) { b2.classList.remove('on'); });
        bt.classList.add('on');
      });
      lySeg.appendChild(bt);
    });
    body.appendChild(lySeg);

    var fmtWrap = h('div', { style: 'display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px' });
    [
      { id: 'pdf',  icon: 'pdf',  label: 'خروجی PDF (.pdf)' },
      { id: 'word', icon: 'word', label: 'خروجی Word (.docx)' },
      { id: 'md',   icon: 'md',   label: 'خروجی Markdown (.md)' },
      { id: 'js',   icon: 'js',   label: 'خروجی JS (.js)' }
    ].forEach(function (f) {
      var btn = h('button', { class: 'btn', type: 'button', html: ic(f.icon, 18) + '<span>' + f.label + '</span>' });
      btn.addEventListener('click', function () {
        var spec = buildTranslatedBookDocSpec(bk, opts.scope === 'page' ? S.index : null, opts.layout);
        L.close(true);
        if (spec) runExportDocSpec(spec, f.id);
      });
      fmtWrap.appendChild(btn);
    });
    body.appendChild(fmtWrap);
  });
}

/* ---------- معنی فوری با دو بار لمس روی کلمه (Instant Double-Tap Lookup) ---------- */
var activeWpop = null;
function closeWpop() {
  if (activeWpop && activeWpop.parentNode) activeWpop.parentNode.removeChild(activeWpop);
  activeWpop = null;
}

function getWordAtPoint(clientX, clientY) {
  var sel = window.getSelection();
  var chosen = sel ? String(sel.toString() || '').trim() : '';
  if (!chosen && document.caretRangeFromPoint) {
    try {
      var r = document.caretRangeFromPoint(clientX, clientY);
      if (r && r.startContainer && r.startContainer.nodeType === 3) {
        var txt = r.startContainer.nodeValue || '', off = r.startOffset;
        var s = off, e = off;
        var wRe = /[A-Za-z\u00C0-\u024F\u0400-\u04FF\u0600-\u06FF\u200C'-]/;
        while (s > 0 && wRe.test(txt.charAt(s - 1))) s--;
        while (e < txt.length && wRe.test(txt.charAt(e))) e++;
        chosen = txt.slice(s, e).trim();
      }
    } catch (err) {}
  }
  chosen = chosen.replace(/^[^A-Za-z\u00C0-\u024F\u0400-\u04FF\u0600-\u06FF]+|[^A-Za-z\u00C0-\u024F\u0400-\u04FF\u0600-\u06FF]+$/g, '');
  if (!chosen || chosen.length < 2 || chosen.length > 48 || /\s/.test(chosen)) return '';
  return chosen;
}

function showInstantWordBubble(word, x, y) {
  closeWpop();
  var b = curBook();
  var lg = wordLang(word, '', b ? b.lg : '') || 'en';
  var lgName = (LANG_META[lg] && LANG_META[lg].name) ? LANG_META[lg].name : lg.toUpperCase();
  var existing = null;
  var wk = wkey(word);
  for (var i = 0; i < S.data.words.length; i++) {
    if (wkey(S.data.words[i].w) === wk) { existing = S.data.words[i]; break; }
  }

  var meanEl = h('div', { class: 'wpop-mean', text: existing && existing.m ? existing.m : 'در حال دریافت معنی…' });
  var saveBtn = h('button', { class: 'btn pri', type: 'button', text: existing ? 'ذخیره‌شده در لغات ✓' : 'افزودن به لغات' });
  saveBtn.disabled = !!existing;
  var sayBtn = h('button', { class: 'btn', type: 'button', html: ic('speaker', 16) + '<span>تلفظ</span>' });
  var xBtn = h('button', { class: 'ibtn', type: 'button', style: 'width:28px;height:28px', 'aria-label': 'بستن', html: ic('x', 15) });
  xBtn.addEventListener('click', closeWpop);

  sayBtn.addEventListener('click', function () {
    hapticTap();
    if (typeof speakWord === 'function') speakWord(word, lg);
    else if (bridge('speakWord')) try { A.speakWord(word, lg); } catch (e) {}
  });

  var latestMean = existing ? existing.m : '';
  saveBtn.addEventListener('click', function () {
    hapticTap();
    var now = Date.now();
    S.data.words.unshift({
      id: uid(),
      w: word,
      m: latestMean || '',
      ex: '',
      bid: b ? b.id : '',
      bk: b ? b.title : '',
      pg: S.index | 0,
      created: now,
      updated: now,
      box: 0,
      due: now,
      seen: 0,
      lg: /^(ar|en|fr|de|tr|fa)$/.test(lg) ? lg : 'en'
    });
    scheduleSave(); flushSave();
    updateWordCount();
    saveBtn.textContent = 'به لغات اضافه شد ✓';
    saveBtn.disabled = true;
    toast('واژه‌ی «' + word + '» در بخش لغات ذخیره شد');
  });

  var pop = h('div', { class: 'wpop' }, [
    h('div', { class: 'wpop-head' }, [
      h('span', { class: 'wpop-word', dir: 'auto', text: word }),
      h('div', { style: 'display:flex;align-items:center;gap:6px' }, [
        h('span', { class: 'wpop-lang', text: lgName }),
        xBtn
      ])
    ]),
    meanEl,
    h('div', { class: 'wpop-acts' }, [saveBtn, sayBtn])
  ]);
  document.body.appendChild(pop);
  activeWpop = pop;

  var W = window.innerWidth, H = window.innerHeight;
  var pw = pop.offsetWidth, ph = pop.offsetHeight;
  var left = clamp(x - pw / 2, 12, W - pw - 12);
  var top = y - ph - 14;
  if (top < 12) top = Math.min(H - ph - 12, y + 18);
  pop.style.left = left + 'px';
  pop.style.top = top + 'px';

  if (!existing) {
    trTranslateOne(word, lg === 'fa' ? 'auto' : lg, function (err, res) {
      if (activeWpop !== pop) return;
      if (!err && res) {
        latestMean = res;
        meanEl.textContent = res;
      } else {
        meanEl.textContent = 'معنی آنلاین در دسترس نیست (می‌توانید واژه را ذخیره و دستی ویرایش کنید).';
      }
    });
  }
}

function setupInstantWordLookup() {
  if (!stage) return;
  stage.addEventListener('dblclick', function (e) {
    if (S.view !== 'reader' || layers.length) return;
    if (!e.target.closest('.ln, .tr-orig')) return;
    var word = getWordAtPoint(e.clientX, e.clientY);
    if (word) {
      hapticTap();
      showInstantWordBubble(word, e.clientX, e.clientY);
    }
  });
  document.addEventListener('pointerdown', function (e) {
    if (activeWpop && !activeWpop.contains(e.target)) closeWpop();
  });
}

/* ---------- استخراج خودکار فصل‌ها برای TOC (EPUB / Word / PDF) ---------- */
function getBookChapters(b) {
  if (!b || !b.pages) return [];
  if (Array.isArray(b.chapters) && b.chapters.length) return b.chapters;
  var found = [];
  var chRe = /^(?:#{1,3}\s+|(?:فصل|بخش|باب|درس|گفتار|مبحث|Chapter|CHAPTER|Part|PART|Section|Unit)\s+[\d۰-۹A-Za-zآ-ی]+)/;
  for (var i = 0; i < b.pages.length; i++) {
    var lines = String(b.pages[i].text || '').split('\n');
    for (var j = 0; j < Math.min(lines.length, 6); j++) {
      var ln = lines[j].trim();
      if (ln.length >= 3 && ln.length <= 90 && chRe.test(ln)) {
        found.push({ t: ln.replace(/^#+\s+/, ''), p: i });
        break;
      }
    }
  }
  return found;
}

/* ---------- آمار مطالعه‌ی روزانه و تایمر تمرکز (پومودورو) ---------- */
var POMO = { totalSec: 25 * 60, leftSec: 25 * 60, running: false, timer: null };

function todayKey() {
  var d = new Date();
  var m = String(d.getMonth() + 1).padStart(2, '0');
  var day = String(d.getDate()).padStart(2, '0');
  return d.getFullYear() + '-' + m + '-' + day;
}

function ensureStatsObj() {
  if (!S.data.stats || typeof S.data.stats !== 'object') S.data.stats = { daily: {}, goalMins: 30 };
  if (!S.data.stats.daily || typeof S.data.stats.daily !== 'object') S.data.stats.daily = {};
  if (!S.data.stats.goalMins) S.data.stats.goalMins = 30;
  return S.data.stats;
}

function recordStudyPage() {
  var st = ensureStatsObj(), k = todayKey();
  if (!st.daily[k]) st.daily[k] = { mins: 0, pages: 0 };
  st.daily[k].pages = (st.daily[k].pages | 0) + 1;
  scheduleSave();
}

function startStudyTrackerLoop() {
  setInterval(function () {
    if (S.view === 'reader' && !document.hidden) {
      var st = ensureStatsObj(), k = todayKey();
      if (!st.daily[k]) st.daily[k] = { mins: 0, pages: 0 };
      st.daily[k].mins = Math.round(((+st.daily[k].mins || 0) + 0.25) * 100) / 100;
      scheduleSave();
    }
  }, 15000);
}

function fmtMmSs(sec) {
  sec = Math.max(0, sec | 0);
  var m = Math.floor(sec / 60), s = sec % 60;
  return fa(String(m).padStart(2, '0')) + ':' + fa(String(s).padStart(2, '0'));
}

function syncPomoPill() {
  var pill = $('#rdPomoPill');
  if (!pill) return;
  if (POMO.running || POMO.leftSec < POMO.totalSec) {
    pill.classList.remove('hidden');
    pill.innerHTML = ic('clock', 13) + '<span>' + fmtMmSs(POMO.leftSec) + '</span>';
  } else {
    pill.classList.add('hidden');
  }
}

function pomoToggle(onTick) {
  if (POMO.running) {
    POMO.running = false;
    clearInterval(POMO.timer);
    POMO.timer = null;
    syncPomoPill();
    if (onTick) onTick();
    return;
  }
  if (POMO.leftSec <= 0) POMO.leftSec = POMO.totalSec;
  POMO.running = true;
  syncPomoPill();
  if (onTick) onTick();
  clearInterval(POMO.timer);
  POMO.timer = setInterval(function () {
    POMO.leftSec--;
    syncPomoPill();
    if (POMO.leftSec <= 0) {
      POMO.running = false;
      clearInterval(POMO.timer);
      POMO.timer = null;
      hapticTap();
      toast('زمان جلسه‌ی تمرکز (پومودورو) به پایان رسید! خسته نباشید 🎉');
    }
    if (onTick) onTick();
  }, 1000);
}

function computeStudySummary() {
  var st = ensureStatsObj(), daily = st.daily, tk = todayKey();
  var todayMins = Math.round((daily[tk] && daily[tk].mins) || 0);
  var todayPages = (daily[tk] && daily[tk].pages) | 0;
  var totalMins = 0;
  Object.keys(daily).forEach(function (k) { totalMins += (+daily[k].mins || 0); });
  var streak = 0;
  var dt = new Date();
  for (var i = 0; i < 60; i++) {
    var k = dt.getFullYear() + '-' + String(dt.getMonth() + 1).padStart(2, '0') + '-' + String(dt.getDate()).padStart(2, '0');
    var has = daily[k] && ((+daily[k].mins || 0) >= 1 || (daily[k].pages | 0) > 0);
    if (has) streak++;
    else if (i > 0) break;
    dt.setDate(dt.getDate() - 1);
  }
  var last7 = [];
  var wdNames = ['یک', 'دو', 'سه', 'چهار', 'پنج', 'جمعه', 'شنبه'];
  for (var dIdx = 6; dIdx >= 0; dIdx--) {
    var d2 = new Date();
    d2.setDate(d2.getDate() - dIdx);
    var k2 = d2.getFullYear() + '-' + String(d2.getMonth() + 1).padStart(2, '0') + '-' + String(d2.getDate()).padStart(2, '0');
    last7.push({ lbl: wdNames[d2.getDay()], mins: Math.round((daily[k2] && daily[k2].mins) || 0) });
  }
  return { todayMins: todayMins, todayPages: todayPages, totalMins: Math.round(totalMins), streak: streak, goalMins: st.goalMins, last7: last7 };
}

function openStudyStatsAndTimer() {
  var sm = computeStudySummary();
  var goalPct = clamp(Math.round((sm.todayMins / Math.max(1, sm.goalMins)) * 100), 0, 100);
  var sheetAlive = true;

  sheet('آمار مطالعه و تایمر تمرکز (پومودورو)', function (body) {
    /* بخش ۱: تایمر پومودورو */
    var timeEl = h('div', { class: 'pomo-time', text: fmtMmSs(POMO.leftSec) });
    var startBtn = h('button', { class: 'btn pri', type: 'button', text: POMO.running ? 'توقف موقت' : 'شروع تمرکز' });
    var resetBtn = h('button', { class: 'btn', type: 'button', text: 'ریست' });
    var presetSeg = h('div', { class: 'seg' });

    function refreshPomoUi() {
      if (!sheetAlive) return;
      timeEl.textContent = fmtMmSs(POMO.leftSec);
      startBtn.textContent = POMO.running ? 'توقف موقت' : 'شروع تمرکز';
    }

    [15, 25, 45].forEach(function (mins) {
      var bt = h('button', { class: POMO.totalSec === mins * 60 ? 'on' : '', type: 'button', text: fa(mins) + ' دقیقه' });
      bt.addEventListener('click', function () {
        if (POMO.running) pomoToggle();
        POMO.totalSec = mins * 60;
        POMO.leftSec = mins * 60;
        $$('button', presetSeg).forEach(function (x) { x.classList.remove('on'); });
        bt.classList.add('on');
        syncPomoPill();
        refreshPomoUi();
      });
      presetSeg.appendChild(bt);
    });

    startBtn.addEventListener('click', function () { hapticTap(); pomoToggle(refreshPomoUi); });
    resetBtn.addEventListener('click', function () {
      hapticTap();
      if (POMO.running) pomoToggle();
      POMO.leftSec = POMO.totalSec;
      syncPomoPill();
      refreshPomoUi();
    });

    body.appendChild(h('div', { class: 'pomo-box' }, [
      h('div', { style: 'font-size:12.5px;font-weight:700;color:var(--muted)', text: 'تایمر مطالعه‌ی پومودورو (روی صفحه‌ی کتاب هم نمایش داده می‌شود)' }),
      timeEl,
      presetSeg,
      h('div', { class: 'pomo-acts' }, [startBtn, resetBtn])
    ]));

    /* بخش ۲: آمار مطالعه */
    body.appendChild(h('div', { class: 'stat-grid' }, [
      h('div', { class: 'stat-card' }, [h('span', { class: 'sv', text: fa(sm.todayMins) + ' دقیقه' }), h('span', { class: 'sl', text: 'مطالعه‌ی امروز (' + fa(goalPct) + '٪ هدف)' })]),
      h('div', { class: 'stat-card' }, [h('span', { class: 'sv', text: fa(sm.todayPages) + ' صفحه' }), h('span', { class: 'sl', text: 'صفحات مرور‌شده امروز' })]),
      h('div', { class: 'stat-card' }, [h('span', { class: 'sv', text: fa(sm.streak) + ' روز' }), h('span', { class: 'sl', text: 'زنجیره‌ی مطالعه‌ی متوالی' })]),
      h('div', { class: 'stat-card' }, [h('span', { class: 'sv', text: fa(sm.totalMins) + ' دقیقه' }), h('span', { class: 'sl', text: 'مجموع زمان مطالعه' })])
    ]));

    body.appendChild(h('div', { class: 'set-h', html: ic('clock', 18) + '<span>عملکرد ۷ روز اخیر (دقیقه)</span>' }));
    var maxM = Math.max(10, sm.goalMins);
    sm.last7.forEach(function (d) { if (d.mins > maxM) maxM = d.mins; });
    var bars = h('div', { class: 'stat-bars' });
    sm.last7.forEach(function (d) {
      var hp = Math.max(6, Math.round((d.mins / maxM) * 62));
      bars.appendChild(h('div', { class: 'stat-bar-col' }, [
        h('span', { class: 'stat-bar-lbl', text: d.mins ? fa(d.mins) : '' }),
        h('div', { class: 'stat-bar-fill', style: 'height:' + hp + 'px;opacity:' + (d.mins ? '1' : '.25') }),
        h('span', { class: 'stat-bar-lbl', text: d.lbl })
      ]));
    });
    body.appendChild(bars);

    /* تنظیم هدف روزانه */
    var goalRow = h('div', { class: 'set-row', style: 'margin-top:4px' }, [
      h('div', { class: 'grow' }, [
        h('div', { class: 't', text: 'هدف مطالعه‌ی روزانه' }),
        h('div', { class: 'd', text: 'فعلی: ' + fa(sm.goalMins) + ' دقیقه در روز' })
      ])
    ]);
    var goalSel = h('select', { class: 'tr-lang-sel', style: 'flex:none;width:110px' });
    [15, 30, 45, 60, 90, 120].forEach(function (g) {
      var o = h('option', { value: String(g), text: fa(g) + ' دقیقه' });
      if (g === sm.goalMins) o.selected = true;
      goalSel.appendChild(o);
    });
    goalSel.addEventListener('change', function () {
      ensureStatsObj().goalMins = +goalSel.value || 30;
      scheduleSave();
      toast('هدف مطالعه‌ی روزانه ذخیره شد');
    });
    goalRow.appendChild(goalSel);
    body.appendChild(goalRow);
  }, { onClose: function () { sheetAlive = false; } });
}

/* =====================================================================
   راه‌اندازی
   ===================================================================== */
function bind() {
  if ($('#libStats')) $('#libStats').addEventListener('click', function () { hapticTap(); openStudyStatsAndTimer(); });
  if ($('#rdPomoPill')) $('#rdPomoPill').addEventListener('click', function () { hapticTap(); openStudyStatsAndTimer(); });
  if ($('#libSearch')) $('#libSearch').addEventListener('click', openGlobalSearch);
  if ($('#libTheme')) $('#libTheme').addEventListener('click', quickToggleTheme);
  $('#libMore').addEventListener('click', libMenu);
  $('#fabNewBook').addEventListener('click', fabClick);
  $('#tabBooks').addEventListener('click', function () { setLibTab('books'); });
  $('#tabWords').addEventListener('click', function () { setLibTab('words'); });
  if ($('#tabQuick')) $('#tabQuick').addEventListener('click', function () { setLibTab('quick'); });
  if ($('#tabNotes')) $('#tabNotes').addEventListener('click', function () { setLibTab('notes'); });
  $('#rdBack').addEventListener('click', closeBook);
  if ($('#rdTr')) $('#rdTr').addEventListener('click', function () { hapticTap(); toggleTrBar(); });
  if ($('#rdBm')) $('#rdBm').addEventListener('click', toggleCurrentBookmark);
  if ($('#rdAa')) $('#rdAa').addEventListener('click', openQuickReaderSheet);
  if ($('#rdBg')) $('#rdBg').addEventListener('click', function () { openPageBgPicker(); });
  $('#rdMore').addEventListener('click', readerMenu);
  $('#rdToc').addEventListener('click', openToc);
  if ($('#rdHl')) $('#rdHl').addEventListener('click', openHighlights);
  if ($('#rdShare')) $('#rdShare').addEventListener('click', function () {
    var b = curBook();
    if (b) openBookPageShareSheet(b, S.index < b.pages.length ? S.index : null);
  });
  if ($('#rdSearch')) $('#rdSearch').addEventListener('click', openSearch);
  $('#bPrev').addEventListener('click', function () { flipTo(false); });
  $('#bNext').addEventListener('click', function () { flipTo(true); });
  $('#bPos').addEventListener('click', gotoDialog);
  $('#bSay').addEventListener('click', ttsToggle);
  $('#bEdit').addEventListener('click', editPageFlow);
  $('#bAdd').addEventListener('click', function () {
    var b = curBook(); addPageFlow(b && S.index < b.pages.length ? S.index : null);
  });
  stage.addEventListener('click', onStageClick);
  document.addEventListener('selectionchange', onSelectionChange);
  document.addEventListener('keydown', function (e) {
    if (e.target && (e.target.tagName === 'TEXTAREA' || e.target.tagName === 'INPUT')) { if (e.key === 'Escape') window.handleBack(); return; }
    if (S.view !== 'reader' || layers.length) { if (e.key === 'Escape') window.handleBack(); return; }
    var rtl = S.data.settings.flip === 'rtl';
    if (e.key === 'ArrowLeft') flipTo(rtl); else if (e.key === 'ArrowRight') flipTo(!rtl);
    else if (e.key === 'Escape') window.handleBack();
  });
  document.addEventListener('contextmenu', function (e) {
    if (!(e.target.closest && e.target.closest('.page-text,textarea,input'))) e.preventDefault();
  });
}

function init() {
  layersEl = $('#layers');
  stage = $('#stage'); pBase = $('#pBase'); pTop = $('#pTop');
  flipSh = $('#flipSh');
  if (!flipSh) {
    flipSh = h('div', { id: 'flipSh', 'aria-hidden': 'true' });
    stage.insertBefore(flipSh, pTop);
  }
  boot();
}
function boot() {
  S.data = Store.load();
  applySavedPositions(S.data);
  var fresh = false;
  if (!S.data.seeded && !S.data.books.length) { seedGuide(); scheduleSave(); fresh = true; }
  if (S.data.books.length === 1 && S.data.books[0].title === 'راهنمای کتابچه') {
    var now0 = Date.now();
    S.data.books[0].lg = 'fa';
    [
      { title: 'English Reading & Stories', lg: 'en', color: 2, text: 'Welcome to the English section of Ketabche.\n\nSelect any unfamiliar word to save it directly into your English vocabulary section or listen with text-to-speech.\n\nResilience and curiosity open new doors every day.' },
      { title: 'Lectures en Français', lg: 'fr', color: 5, text: 'Bienvenue dans la section française de Ketabche.\n\nIci vous pouvez lire vos textes en français, surligner les phrases importantes et enregistrer chaque mot dans la section française.\n\nChaque papillon apporte la lumière et l’espoir.' },
      { title: 'Deutsche Texte & Lesen', lg: 'de', color: 3, text: 'Willkommen im deutschen Bereich von Ketabche.\n\nLesen Sie deutsche Bücher Seite für Seite, hören Sie die Aussprache und speichern Sie neue Wörter getrennt nach Sprache.' },
      { title: 'نصوص ومطالعات عربية', lg: 'ar', color: 4, text: 'مرحباً بكم في قسم الكتب العربية في برنامج كتابچه.\n\nيمكنكم قراءة النصوص العربية صفحة بصفحة، والاستماع إلى النطق الصوتي، وحفظ المفردات في القسم الخاص باللغة العربية.' },
      { title: 'Türkçe Okuma Kitabı', lg: 'tr', color: 0, text: 'Ketabche Türkçe kitap bölümüne hoş geldiniz.\n\nTürkçe metinlerinizi sayfa sayfa okuyabilir, sesli dinleyebilir ve kelimeleri Türkçe bölümünde ayrı olarak kaydedip tekrar edebilirsiniz.' }
    ].forEach(function (sb, sIdx) {
      var t = now0 - (sIdx + 1) * 2000;
      S.data.books.push({
        id: uid(),
        title: sb.title,
        lg: sb.lg,
        color: sb.color,
        created: t,
        updated: t,
        last: 0,
        pages: [{ id: uid(), text: sb.text, created: t, updated: t, hl: [] }]
      });
    });
    scheduleSave();
  }
  S.data.seeded = true;
  cleanCoverFiles();
  buildPage(pBase); buildPage(pTop);
  setIcons();
  buildTtsBar();
  syncVoiceStudio();
  buildScrollDock();
  updateScrollDockVisibility();
  applyTheme();
  bind();
  setupGestures();
  setupInstantWordLookup();
  startStudyTrackerLoop();
  var last = S.data.lastBook && bookById(S.data.lastBook);
  if (last) openBook(last.id); else showLibrary();
  if (!fresh && S.data.seenVer < 17) { S.data.seenVer = 17; scheduleSave(); setTimeout(showWhatsNew, 450); }
}

window.__ketabche = { S: S, init: init, remap: remapHighlights, addHighlight: addHighlight, splitToFit: splitToFit,
  buildSegments: buildSegments, sentenceRanges: sentenceRanges, langRuns: langRuns, wordLang: wordLang, scoreText: scoreText, COLORS: COLORS };   // برای آزمون
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();

})();
