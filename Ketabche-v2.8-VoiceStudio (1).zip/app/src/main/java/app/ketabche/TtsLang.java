package app.ketabche;

import java.util.Locale;

final class TtsLang {
    private TtsLang() {}

    static String[] candidates(String lang, String defaultLang) {
        if ("fa".equals(lang)) {
            return new String[] { "fa-IR", "fa", "ar-SA", "ar" };
        }
        if ("ar".equals(lang)) {
            return new String[] { "ar-SA", "ar" };
        }
        if ("en".equals(lang)) {
            return new String[] { "en-US", "en-GB", "en" };
        }
        if ("fr".equals(lang)) {
            return new String[] { "fr-FR", "fr" };
        }
        if ("de".equals(lang)) {
            return new String[] { "de-DE", "de" };
        }
        if ("tr".equals(lang)) {
            return new String[] { "tr-TR", "tr" };
        }
        return new String[] { lang };
    }

    static String joinSkipped(boolean ar, boolean en, boolean fr) {
        StringBuilder sb = new StringBuilder();
        if (ar) {
            sb.append("ar");
        }
        if (en) {
            sb.append(sb.length() > 0 ? "," : "").append("en");
        }
        if (fr) {
            sb.append(sb.length() > 0 ? "," : "").append("fr");
        }
        return sb.toString();
    }

    static String norm(String s) {
        if (s == null) {
            return "en";
        }
        return s.trim().toLowerCase(Locale.ROOT);
    }
}
