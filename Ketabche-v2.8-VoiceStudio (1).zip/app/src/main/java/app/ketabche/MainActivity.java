package app.ketabche;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.Base64;
import android.util.Size;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int COVER_MAX = 900;
    private static final long MAX_IMPORT_BYTES = 0x05000000L;
    private static final int NET_MAX_BYTES = 0x00032000;
    private static final int REQ_PICK = 4101;
    private static final int REQ_COVER = 4102;
    private static final int REQ_PICK_DOC = 4103;
    private static final String START_URL = "file:///android_asset/www/index.html";

    private WebView web;
    private final Object fileLock = new Object();
    private boolean visible = true;
    private final ExecutorService netPool = Executors.newFixedThreadPool(2);
    private String pendingCoverBook = null;

    private VoiceStudioClient vsClient;
    private final ExecutorService vsPool = Executors.newSingleThreadExecutor();
    private volatile boolean vsEnabled = false;
    private volatile String vsUrl = "";
    private volatile String vsApiKey = "";
    private volatile String vsModel = "omnivoice";
    private volatile String vsVoice = "default";
    private volatile String vsInstruct = "";
    private volatile boolean vsFallback = true;

    private final Object ttsLock = new Object();
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private boolean ttsInitializing = false;
    private Runnable ttsAfterInit = null;
    private ArrayList<Seg> segs = new ArrayList<>();
    private int[] order = new int[0];
    private int ttsGen = 0;
    private int ttsCursor = 0;
    private int ttsDonePos = -1;
    private int ttsPlayPos = -1;
    private int ttsErrStreak = 0;
    private int pausedIdx = 0;
    private int lastSegIdx = -1;
    private String ttsState = "idle";
    private float ttsRate = 1.0f;
    private float ttsPitch = 1.0f;
    private String langApplied = "";
    private final HashMap<String, Locale> locs = new HashMap<>();
    private boolean locResolved = false;
    private PowerManager.WakeLock wakeLock = null;
    private AudioFocusRequest focusReq = null;

    private final AudioManager.OnAudioFocusChangeListener focusListener = new AudioManager.OnAudioFocusChangeListener() {
        @Override
        public void onAudioFocusChange(int focusChange) {
            if (focusChange == AudioManager.AUDIOFOCUS_LOSS || focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                ttsPause();
            }
        }
    };

    private final UtteranceProgressListener ttsListener = new UtteranceProgressListener() {
        @Override
        public void onStart(String utteranceId) {
            handleStart(utteranceId);
        }

        @Override
        public void onDone(String utteranceId) {
            handleDone(utteranceId, false);
        }

        @Override
        public void onError(String utteranceId) {
            handleDone(utteranceId, true);
        }

        @Override
        public void onError(String utteranceId, int errorCode) {
            handleDone(utteranceId, true);
        }

        @Override
        public void onStop(String utteranceId, boolean interrupted) {
        }
    };

    private static class Seg {
        int page;
        int s;
        int e;
        String lang;
        String text;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        vsClient = new VoiceStudioClient(this);
        web = new WebView(this);
        web.setBackgroundColor(isNight() ? 0xFF000000 : 0xFFF2F2F7);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);

        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);
        settings.setGeolocationEnabled(false);
        settings.setSaveFormData(false);
        settings.setBlockNetworkLoads(true);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !request.getUrl().toString().startsWith("file:///android_asset/");
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "Android");

        FrameLayout root = new FrameLayout(this);
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        web.loadUrl(START_URL);
    }

    @Override
    protected void onPause() {
        visible = false;
        if (web != null) {
            web.evaluateJavascript("window.flushSave && window.flushSave()", null);
            web.onPause();
        }
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        visible = true;
        if (web != null) {
            web.onResume();
        }
        synchronized (ttsLock) {
            emit("sync", lastSegIdx, ttsState);
        }
    }

    @Override
    protected void onDestroy() {
        netPool.shutdownNow();
        vsPool.shutdownNow();
        ttsShutdown();
        if (web != null) {
            ViewParent parent = web.getParent();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(web);
            }
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (web != null) {
            web.evaluateJavascript("window.onSystemTheme && window.onSystemTheme()", null);
        }
    }

    @Override
    public void onBackPressed() {
        if (web == null) {
            super.onBackPressed();
            return;
        }
        web.evaluateJavascript("(function(){try{return window.handleBack?window.handleBack():false}catch(e){return false}})()",
                new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String value) {
                        if (!"true".equals(value)) {
                            finish();
                        }
                    }
                });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_COVER) {
            final String bookId = pendingCoverBook;
            pendingCoverBook = null;
            if (resultCode != RESULT_OK || data == null || data.getData() == null || bookId == null) {
                return;
            }
            final Uri uri = data.getData();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        ImageDecoder.Source src = ImageDecoder.createSource(getContentResolver(), uri);
                        Bitmap bmp = decodeSource(src);
                        String token = newToken();
                        if (!saveCoverBitmap(token, bmp)) {
                            throw new IOException("save failed");
                        }
                        callJs("window.onCoverPicked && window.onCoverPicked('" + bookId + "','" + token + "')");
                    } catch (Exception e) {
                        callJs("window.onCoverFailed && window.onCoverFailed()");
                    }
                }
            }).start();
        } else if (requestCode == REQ_PICK) {
            if (resultCode != RESULT_OK || data == null || data.getData() == null) {
                return;
            }
            final Uri uri = data.getData();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    InputStream in = null;
                    try {
                        in = getContentResolver().openInputStream(uri);
                        if (in == null) {
                            throw new Exception("no stream");
                        }
                        ByteArrayOutputStream out = new ByteArrayOutputStream();
                        byte[] buf = new byte[16384];
                        long total = 0;
                        int n;
                        while ((n = in.read(buf)) > 0) {
                            total += n;
                            if (total > MAX_IMPORT_BYTES) {
                                throw new Exception("too big");
                            }
                            out.write(buf, 0, n);
                        }
                        String b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
                        callJs("window.onFilePicked && window.onFilePicked('" + b64 + "')");
                    } catch (Exception e) {
                        toastUi("خواندن فایل انجام نشد");
                    } finally {
                        closeQuietly(in);
                    }
                }
            }).start();
        } else if (requestCode == REQ_PICK_DOC) {
            if (resultCode != RESULT_OK || data == null || data.getData() == null) {
                callJs("window.onBookDocCancelled && window.onBookDocCancelled()");
                return;
            }
            final Uri uri = data.getData();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        JSONObject res = DocImporter.importUri(MainActivity.this, uri);
                        String b64 = Base64.encodeToString(res.toString().getBytes("UTF-8"), Base64.NO_WRAP);
                        callJs("window.onBookDocImported && window.onBookDocImported('" + b64 + "')");
                    } catch (Exception e) {
                        String code = e.getMessage() != null ? e.getMessage() : "read_failed";
                        String safe = code.replace("\\", "").replace("'", "").replace("\n", " ");
                        callJs("window.onBookDocFailed && window.onBookDocFailed('" + safe + "')");
                    }
                }
            }).start();
        }
    }

    private boolean isNight() {
        return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }

    private File dataFile() {
        return new File(getFilesDir(), "data.json");
    }

    private File tmpFile() {
        return new File(getFilesDir(), "data.json.tmp");
    }

    private File bakFile() {
        return new File(getFilesDir(), "data.bak");
    }

    private File coverDir() {
        File d = new File(getFilesDir(), "covers");
        if (!d.exists()) {
            d.mkdirs();
        }
        return d;
    }

    private File coverFile(String token) {
        return new File(coverDir(), token + ".jpg");
    }

    private static boolean validToken(String s) {
        if (s == null || s.length() == 0 || s.length() > 64) {
            return false;
        }
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            boolean ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' || c == '-';
            if (!ok) {
                return false;
            }
        }
        return true;
    }

    private static String newToken() {
        return Long.toString(System.currentTimeMillis(), 36) + Integer.toString(new Random().nextInt(Integer.MAX_VALUE), 36);
    }

    private Bitmap decodeSource(ImageDecoder.Source src) throws IOException {
        return ImageDecoder.decodeBitmap(src, new ImageDecoder.OnHeaderDecodedListener() {
            @Override
            public void onHeaderDecoded(ImageDecoder decoder, ImageDecoder.ImageInfo info, ImageDecoder.Source source) {
                decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
                Size sz = info.getSize();
                int w = sz.getWidth();
                int h = sz.getHeight();
                int max = Math.max(w, h);
                if (max > COVER_MAX) {
                    float scale = 900.0f / (float) max;
                    int nw = Math.max(1, Math.round(w * scale));
                    int nh = Math.max(1, Math.round(h * scale));
                    decoder.setTargetSize(nw, nh);
                }
            }
        });
    }

    private boolean saveCoverBitmap(String token, Bitmap bmp) {
        if (!validToken(token) || bmp == null) {
            return false;
        }
        FileOutputStream out = null;
        try {
            Bitmap flat = Bitmap.createBitmap(bmp.getWidth(), bmp.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(flat);
            canvas.drawColor(0xFFFFFFFF);
            canvas.drawBitmap(bmp, 0f, 0f, null);
            out = new FileOutputStream(coverFile(token));
            boolean ok = flat.compress(Bitmap.CompressFormat.JPEG, 84, out);
            out.flush();
            return ok;
        } catch (Exception e) {
            return false;
        } finally {
            closeQuietly(out);
        }
    }

    private static void closeQuietly(Closeable c) {
        if (c != null) {
            try {
                c.close();
            } catch (Exception ignored) {
            }
        }
    }

    private String readFile(File f) {
        if (!f.exists()) {
            return "";
        }
        FileInputStream in = null;
        try {
            in = new FileInputStream(f);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "";
        } finally {
            closeQuietly(in);
        }
    }

    private boolean isValidJson(String s) {
        if (s == null || s.length() < 2) {
            return false;
        }
        try {
            new JSONObject(s);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private String loadBest() {
        synchronized (fileLock) {
            File[] files = new File[] { dataFile(), tmpFile(), bakFile() };
            for (File f : files) {
                String content = readFile(f);
                if (isValidJson(content)) {
                    return content;
                }
            }
            return "";
        }
    }

    private boolean saveAtomic(String s) {
        if (s == null || s.length() < 2) {
            return false;
        }
        synchronized (fileLock) {
            FileOutputStream out = null;
            try {
                File tmp = tmpFile();
                out = new FileOutputStream(tmp);
                out.write(s.getBytes("UTF-8"));
                out.flush();
                out.getFD().sync();
                out.close();
                out = null;

                File data = dataFile();
                File bak = bakFile();
                if (data.exists() && isValidJson(readFile(data))) {
                    bak.delete();
                    data.renameTo(bak);
                }
                return tmp.renameTo(data);
            } catch (Exception e) {
                return false;
            } finally {
                closeQuietly(out);
            }
        }
    }

    private void callJs(final String js) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (web != null) {
                    web.evaluateJavascript(js, null);
                }
            }
        });
    }

    private void toastUi(final String msg) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void netReply(String id, int code, String b64) {
        callJs("window.onHttp&&window.onHttp('" + id + "'," + code + ",'" + b64 + "')");
    }

    private void netFetch(String id, String urlStr) {
        byte[] body = new byte[0];
        int code = 0;
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(8000);
            conn.setReadTimeout(15000);
            conn.setInstanceFollowRedirects(false);
            conn.setUseCaches(false);
            conn.setRequestProperty("User-Agent", "Ketabche/2.7 (Android; personal reading app)");
            conn.setRequestProperty("Accept", "application/json");
            code = conn.getResponseCode();
            InputStream in = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
            if (in != null) {
                try {
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    int n;
                    boolean tooBig = false;
                    while ((n = in.read(buf)) > 0) {
                        if (out.size() + n > NET_MAX_BYTES) {
                            tooBig = true;
                            break;
                        }
                        out.write(buf, 0, n);
                    }
                    if (tooBig) {
                        code = 0;
                    } else {
                        body = out.toByteArray();
                    }
                } finally {
                    in.close();
                }
            }
        } catch (Exception e) {
            code = 0;
            body = new byte[0];
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
        netReply(id, code, Base64.encodeToString(body, Base64.NO_WRAP));
    }

    private void emit(String type, int idx, String extra) {
        if (!visible && "seg".equals(type)) {
            return;
        }
        callJs("window.onTts&&window.onTts('" + type + "'," + idx + ",'" + extra + "')");
    }

    private void setState(String st) {
        ttsState = st;
        emit("state", lastSegIdx, st);
    }

    private void stopEngineQuiet() {
        try {
            if (vsClient != null) {
                vsClient.stopPlayback();
            }
        } catch (Exception ignored) {
        }
        try {
            if (tts != null) {
                tts.stop();
            }
        } catch (Exception ignored) {
        }
    }

    private void holdResources() {
        try {
            if (wakeLock == null) {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                if (pm != null) {
                    wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ketabche:tts");
                    wakeLock.setReferenceCounted(false);
                }
            }
            if (wakeLock != null && !wakeLock.isHeld()) {
                wakeLock.acquire(10800000L);
            }
        } catch (Exception ignored) {
        }
        try {
            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (am != null) {
                if (focusReq == null) {
                    AudioAttributes attrs = new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build();
                    focusReq = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                            .setAudioAttributes(attrs)
                            .setOnAudioFocusChangeListener(focusListener)
                            .build();
                }
                am.requestAudioFocus(focusReq);
            }
        } catch (Exception ignored) {
        }
    }

    private void releaseResources() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) {
                wakeLock.release();
            }
        } catch (Exception ignored) {
        }
        try {
            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (am != null && focusReq != null) {
                am.abandonAudioFocusRequest(focusReq);
            }
        } catch (Exception ignored) {
        }
    }

    private Locale[] tags(String lang) {
        String defLang = Locale.getDefault().getLanguage();
        String[] cands = TtsLang.candidates(lang, defLang);
        Locale[] out = new Locale[cands.length];
        for (int i = 0; i < cands.length; i++) {
            out[i] = Locale.forLanguageTag(cands[i]);
        }
        return out;
    }

    private Locale firstAvailable(Locale[] list) {
        for (Locale loc : list) {
            try {
                if (tts.isLanguageAvailable(loc) >= TextToSpeech.LANG_AVAILABLE) {
                    return loc;
                }
            } catch (Exception ignored) {
            }
        }
        return null;
    }

    private Locale localeFor(String lang) {
        return firstAvailable(tags(lang));
    }

    private String langIssue(String lang) {
        Locale[] list = tags(lang);
        for (Locale loc : list) {
            try {
                if (tts.isLanguageAvailable(loc) == TextToSpeech.LANG_MISSING_DATA) {
                    return "data";
                }
            } catch (Exception ignored) {
            }
        }
        return "unsupported";
    }

    private void initTts() {
        if (ttsInitializing) {
            return;
        }
        ttsInitializing = true;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    tts = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
                        @Override
                        public void onInit(int status) {
                            onTtsInit(status);
                        }
                    });
                } catch (Exception e) {
                    onTtsInit(-1);
                }
            }
        });
    }

    private void onTtsInit(int status) {
        synchronized (ttsLock) {
            ttsInitializing = false;
            if (status != TextToSpeech.SUCCESS || tts == null) {
                try {
                    if (tts != null) {
                        tts.shutdown();
                    }
                } catch (Exception ignored) {
                }
                tts = null;
                ttsReady = false;
                ttsAfterInit = null;
                ttsGen++;
                setState("idle");
                emit("error", 0, "init");
                return;
            }
            try {
                AudioAttributes attrs = new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build();
                tts.setAudioAttributes(attrs);
            } catch (Exception ignored) {
            }
            tts.setOnUtteranceProgressListener(ttsListener);
            ttsReady = true;
            locResolved = false;
            langApplied = "";
            Runnable r = ttsAfterInit;
            ttsAfterInit = null;
            if (r != null) {
                r.run();
            }
        }
    }

    private void startAt(final int idx) {
        ttsGen++;
        final int gen = ttsGen;
        setState("loading");
        if (vsEnabled && NetPolicy.allowedVoiceStudio(vsUrl) && vsClient != null) {
            stopEngineQuiet();
            startVoiceStudioAt(idx, gen);
            return;
        }
        startAndroidTtsAt(idx, gen);
    }

    private void startAndroidTtsAt(final int idx, final int gen) {
        Runnable action = new Runnable() {
            @Override
            public void run() {
                synchronized (ttsLock) {
                    if (gen != ttsGen) {
                        return;
                    }
                    beginFrom(idx);
                }
            }
        };
        if (ttsReady && tts != null) {
            stopEngineQuiet();
            action.run();
            return;
        }
        ttsAfterInit = action;
        initTts();
    }

    private void startVoiceStudioAt(final int startIdx, final int gen) {
        ArrayList<Integer> playable = new ArrayList<>();
        int sIdx = Math.max(0, startIdx);
        for (int i = sIdx; i < segs.size(); i++) {
            if (segs.get(i).text.trim().length() > 0) {
                playable.add(i);
            }
        }
        if (playable.isEmpty()) {
            finishAll();
            return;
        }
        order = new int[playable.size()];
        for (int i = 0; i < order.length; i++) {
            order[i] = playable.get(i);
        }
        ttsCursor = 0;
        ttsDonePos = -1;
        ttsPlayPos = -1;
        ttsErrStreak = 0;
        lastSegIdx = order[0];
        holdResources();
        vsClient.resetStopFlag();
        playVoiceStudioPos(0, gen);
    }

    private void playVoiceStudioPos(final int pos, final int gen) {
        vsPool.execute(new Runnable() {
            @Override
            public void run() {
                final Seg sg;
                final float rate;
                synchronized (ttsLock) {
                    if (gen != ttsGen || pos < 0 || pos >= order.length) {
                        return;
                    }
                    sg = segs.get(order[pos]);
                    rate = ttsRate;
                }
                try {
                    final File audio = vsClient.synthesizeToFile(
                            vsUrl, vsApiKey, sg.text, vsModel, vsVoice, sg.lang, rate, vsInstruct);
                    synchronized (ttsLock) {
                        if (gen != ttsGen || audio == null) {
                            if (audio != null) {
                                audio.delete();
                            }
                            return;
                        }
                        ttsPlayPos = pos;
                        lastSegIdx = order[pos];
                        setState("playing");
                        emit("seg", lastSegIdx, "");
                    }
                    vsClient.playFile(audio,
                        new Runnable() {
                            @Override
                            public void run() {
                                synchronized (ttsLock) {
                                    if (gen != ttsGen) {
                                        return;
                                    }
                                    ttsDonePos = pos;
                                    if (pos >= order.length - 1) {
                                        finishAll();
                                    } else {
                                        playVoiceStudioPos(pos + 1, gen);
                                    }
                                }
                            }
                        },
                        new Runnable() {
                            @Override
                            public void run() {
                                synchronized (ttsLock) {
                                    if (gen != ttsGen) {
                                        return;
                                    }
                                    failStop("speak", false);
                                }
                            }
                        });
                } catch (Exception e) {
                    synchronized (ttsLock) {
                        if (gen != ttsGen) {
                            return;
                        }
                        if (vsFallback) {
                            emit("warn", 0, "vs_fallback");
                            startAndroidTtsAt(order[pos], gen);
                        } else {
                            failStop("vs_net", false);
                        }
                    }
                }
            }
        });
    }

    private void beginFrom(int startIdx) {
        if (startIdx < 0) {
            startIdx = 0;
        }
        int firstNonEmpty = -1;
        while (startIdx < segs.size()) {
            if (segs.get(startIdx).text.trim().length() > 0) {
                firstNonEmpty = startIdx;
                break;
            }
            startIdx++;
        }
        if (firstNonEmpty < 0) {
            finishAll();
            return;
        }
        String firstLang = segs.get(firstNonEmpty).lang;
        ArrayList<Integer> playable = new ArrayList<>();
        HashSet<String> skipped = new HashSet<>();
        for (int i = firstNonEmpty; i < segs.size(); i++) {
            Seg sg = segs.get(i);
            if (sg.text.trim().length() == 0) {
                continue;
            }
            if (localeFor(sg.lang) == null) {
                skipped.add(sg.lang);
            } else {
                playable.add(i);
            }
        }
        if (playable.isEmpty()) {
            failStop("lang:" + firstLang + ":" + langIssue(firstLang), true);
            return;
        }
        order = new int[playable.size()];
        for (int i = 0; i < order.length; i++) {
            order[i] = playable.get(i);
        }
        if (!skipped.isEmpty()) {
            emit("warn", 0, TtsLang.joinSkipped(skipped.contains("ar"), skipped.contains("en"), skipped.contains("fr")));
        }
        ttsCursor = 0;
        ttsDonePos = -1;
        ttsPlayPos = -1;
        ttsErrStreak = 0;
        langApplied = "";
        lastSegIdx = order[0];
        holdResources();
        setState("playing");
        pump();
    }

    private void pump() {
        if (tts == null) {
            return;
        }
        while (ttsCursor < order.length && (ttsCursor - (ttsDonePos + 1)) < 2) {
            int pos = ttsCursor;
            Seg sg = segs.get(order[pos]);
            Locale loc = localeFor(sg.lang);
            if (loc == null) {
                ttsDonePos = pos;
                ttsCursor++;
                continue;
            }
            try {
                if (!sg.lang.equals(langApplied)) {
                    tts.setLanguage(loc);
                    langApplied = sg.lang;
                }
                tts.setSpeechRate(ttsRate);
                tts.setPitch(ttsPitch);
                int res = tts.speak(sg.text, TextToSpeech.QUEUE_ADD, null, ttsGen + ":" + pos);
                if (res != TextToSpeech.SUCCESS) {
                    failStop("speak", false);
                    return;
                }
                ttsCursor++;
            } catch (Exception e) {
                failStop("speak", false);
                return;
            }
        }
    }

    private int parseGen(String uttId) {
        try {
            return Integer.parseInt(uttId.substring(0, uttId.indexOf(':')));
        } catch (Exception e) {
            return -1;
        }
    }

    private int parsePos(String uttId) {
        try {
            return Integer.parseInt(uttId.substring(uttId.indexOf(':') + 1));
        } catch (Exception e) {
            return -1;
        }
    }

    private void handleStart(String uttId) {
        synchronized (ttsLock) {
            int pos = parsePos(uttId);
            int gen = parseGen(uttId);
            if (gen != ttsGen || pos < 0 || pos >= order.length || !"playing".equals(ttsState)) {
                return;
            }
            ttsPlayPos = pos;
            lastSegIdx = order[pos];
            emit("seg", lastSegIdx, "");
            pump();
        }
    }

    private void handleDone(String uttId, boolean isErr) {
        synchronized (ttsLock) {
            int pos = parsePos(uttId);
            int gen = parseGen(uttId);
            if (gen != ttsGen || pos < 0 || pos >= order.length || pos <= ttsDonePos) {
                return;
            }
            ttsDonePos = pos;
            if (isErr) {
                ttsErrStreak++;
                if (ttsErrStreak >= 3) {
                    failStop("speak", false);
                    return;
                }
            } else {
                ttsErrStreak = 0;
            }
            if (pos >= order.length - 1) {
                finishAll();
            } else {
                pump();
            }
        }
    }

    private void finishAll() {
        ttsGen++;
        releaseResources();
        lastSegIdx = -1;
        ttsState = "idle";
        emit("end", 0, "");
    }

    private void failStop(String reason, boolean resetEngine) {
        ttsGen++;
        stopEngineQuiet();
        releaseResources();
        ttsState = "idle";
        lastSegIdx = -1;
        if (resetEngine) {
            try {
                if (tts != null) {
                    tts.shutdown();
                }
            } catch (Exception ignored) {
            }
            tts = null;
            ttsReady = false;
            locResolved = false;
        }
        emit("state", -1, "idle");
        emit("error", 0, reason);
    }

    private void ttsPause() {
        synchronized (ttsLock) {
            if (!"playing".equals(ttsState)) {
                return;
            }
            int pos = ttsPlayPos > ttsDonePos ? ttsPlayPos : (ttsDonePos + 1);
            if (pos < 0) {
                pos = 0;
            }
            if (pos >= order.length) {
                pos = order.length - 1;
            }
            pausedIdx = order.length > 0 ? order[pos] : 0;
            lastSegIdx = pausedIdx;
            ttsGen++;
            stopEngineQuiet();
            releaseResources();
            setState("paused");
        }
    }

    private void ttsShutdown() {
        synchronized (ttsLock) {
            ttsGen++;
            ttsAfterInit = null;
            try {
                if (vsClient != null) {
                    vsClient.stopPlayback();
                }
            } catch (Exception ignored) {
            }
            try {
                if (tts != null) {
                    tts.stop();
                    tts.shutdown();
                }
            } catch (Exception ignored) {
            }
            tts = null;
            ttsReady = false;
            ttsState = "idle";
            releaseResources();
        }
    }

    public class Bridge {
        @JavascriptInterface
        public String load() {
            return loadBest();
        }

        @JavascriptInterface
        public String loadBackup() {
            synchronized (fileLock) {
                String s = readFile(bakFile());
                return isValidJson(s) ? s : "";
            }
        }

        @JavascriptInterface
        public boolean save(String json) {
            return saveAtomic(json);
        }

        @JavascriptInterface
        public void copy(final String text) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    if (cm != null) {
                        cm.setPrimaryClip(ClipData.newPlainText("text", text));
                    }
                }
            });
        }

        @JavascriptInterface
        public void share(final String title, final String text) {
            if (text != null && text.length() > 350000) {
                toastUi("متن برای اشتراک‌گذاری بزرگ است؛ از «پشتیبان‌گیری» استفاده کنید");
                return;
            }
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent intent = new Intent(Intent.ACTION_SEND);
                        intent.setType("text/plain");
                        if (title != null && title.length() > 0) {
                            intent.putExtra(Intent.EXTRA_SUBJECT, title);
                        }
                        intent.putExtra(Intent.EXTRA_TEXT, text);
                        startActivity(Intent.createChooser(intent, "اشتراک‌گذاری"));
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "اشتراک‌گذاری انجام نشد", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public void toast(String msg) {
            toastUi(msg);
        }

        @JavascriptInterface
        public String saveFile(String filename, String content) {
            OutputStream out = null;
            try {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Downloads.DISPLAY_NAME, filename);
                String lower = filename != null ? filename.toLowerCase(Locale.ROOT) : "";
                if (lower.endsWith(".pdf")) {
                    cv.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
                } else if (lower.endsWith(".docx")) {
                    cv.put(MediaStore.Downloads.MIME_TYPE, "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
                } else if (lower.endsWith(".json")) {
                    cv.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                } else if (lower.endsWith(".md") || lower.endsWith(".markdown")) {
                    cv.put(MediaStore.Downloads.MIME_TYPE, "text/markdown");
                } else if (lower.endsWith(".js")) {
                    cv.put(MediaStore.Downloads.MIME_TYPE, "text/javascript");
                } else if (lower.endsWith(".txt")) {
                    cv.put(MediaStore.Downloads.MIME_TYPE, "text/plain");
                }
                cv.put(MediaStore.Downloads.RELATIVE_PATH, "Download/");
                ContentResolver cr = getContentResolver();
                Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (uri == null) {
                    return "error";
                }
                out = cr.openOutputStream(uri);
                if (out == null) {
                    return "error";
                }
                byte[] bytes;
                try {
                    bytes = Base64.decode(content, Base64.DEFAULT);
                } catch (Exception ex) {
                    bytes = content != null ? content.getBytes("UTF-8") : new byte[0];
                }
                out.write(bytes);
                out.flush();
                out.close();
                out = null;
                return "ok";
            } catch (Exception e) {
                return "error";
            } finally {
                closeQuietly(out);
            }
        }

        @JavascriptInterface
        public void pickBookDoc() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("*/*");
                        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                            "application/pdf",
                            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                            "application/epub+zip",
                            "text/plain",
                            "text/markdown",
                            "application/octet-stream"
                        });
                        startActivityForResult(intent, REQ_PICK_DOC);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "باز کردن انتخاب‌گر فایل Word/PDF ممکن نشد", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public void pickFile() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("*/*");
                        startActivityForResult(intent, REQ_PICK);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "باز کردن انتخاب‌گر فایل ممکن نشد", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public void keepScreenOn(final boolean on) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (web != null) {
                        web.setKeepScreenOn(on);
                    }
                }
            });
        }

        @JavascriptInterface
        public boolean isNight() {
            return MainActivity.this.isNight();
        }

        @JavascriptInterface
        public void setBars(String hexColor, final boolean darkIcons) {
            try {
                final int c = Color.parseColor(hexColor);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Window w = getWindow();
                            w.setStatusBarColor(c);
                            w.setNavigationBarColor(c);
                            if (web != null) {
                                web.setBackgroundColor(c);
                            }
                            View decor = w.getDecorView();
                            int vis = decor.getSystemUiVisibility();
                            if (darkIcons) {
                                vis |= 8208;
                            } else {
                                vis &= ~8208;
                            }
                            decor.setSystemUiVisibility(vis);
                        } catch (Exception ignored) {
                        }
                    }
                });
            } catch (Exception ignored) {
            }
        }

        @JavascriptInterface
        public void pickCover(final String bookId) {
            if (!validToken(bookId)) {
                return;
            }
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        pendingCoverBook = bookId;
                        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("image/*");
                        startActivityForResult(intent, REQ_COVER);
                    } catch (Exception e) {
                        pendingCoverBook = null;
                        Toast.makeText(MainActivity.this, "باز کردن گالری ممکن نشد", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public String getCover(String token) {
            if (!validToken(token)) {
                return "";
            }
            File f = coverFile(token);
            if (!f.exists() || f.length() > 0x00800000L) {
                return "";
            }
            FileInputStream in = null;
            try {
                in = new FileInputStream(f);
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                }
                return "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
            } catch (Exception e) {
                return "";
            } finally {
                closeQuietly(in);
            }
        }

        @JavascriptInterface
        public String putCover(String token, String dataUrl) {
            if (!validToken(token) || dataUrl == null || dataUrl.length() > 0x01800000) {
                return "error";
            }
            try {
                int idx = dataUrl.indexOf("base64,");
                if (!dataUrl.startsWith("data:image/") || idx < 0) {
                    return "error";
                }
                byte[] raw = Base64.decode(dataUrl.substring(idx + 7), Base64.DEFAULT);
                Bitmap bmp = decodeSource(ImageDecoder.createSource(ByteBuffer.wrap(raw)));
                return saveCoverBitmap(token, bmp) ? "ok" : "error";
            } catch (Exception e) {
                return "error";
            }
        }

        @JavascriptInterface
        public void deleteCover(String token) {
            if (validToken(token)) {
                coverFile(token).delete();
            }
        }

        @JavascriptInterface
        public void cleanCovers(String jsonArrayStr) {
            try {
                JSONArray arr = new JSONArray(jsonArrayStr);
                HashSet<String> keep = new HashSet<>();
                for (int i = 0; i < arr.length(); i++) {
                    keep.add(arr.getString(i));
                }
                File[] files = coverDir().listFiles();
                if (files == null) {
                    return;
                }
                for (File f : files) {
                    String name = f.getName();
                    if (name.endsWith(".jpg")) {
                        String tk = name.substring(0, name.length() - 4);
                        if (!keep.contains(tk)) {
                            f.delete();
                        }
                    }
                }
            } catch (Exception ignored) {
            }
        }

        @JavascriptInterface
        public void httpGet(final String id, final String url) {
            if (id == null || !id.matches("[A-Za-z0-9_]{1,40}")) {
                return;
            }
            if (!NetPolicy.allowed(url)) {
                netReply(id, -1, "");
                return;
            }
            try {
                netPool.execute(new Runnable() {
                    @Override
                    public void run() {
                        netFetch(id, url);
                    }
                });
            } catch (Exception e) {
                netReply(id, 0, "");
            }
        }

        @JavascriptInterface
        public void openUrl(String url) {
            if (url == null || url.length() > 1500) {
                return;
            }
            try {
                final Uri u = Uri.parse(url);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Intent intent = new Intent(Intent.ACTION_VIEW, u);
                            intent.addCategory(Intent.CATEGORY_BROWSABLE);
                            startActivity(intent);
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "باز کردن لینک ممکن نشد", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            } catch (Exception ignored) {
            }
        }

        @JavascriptInterface
        public void openTtsSettings() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        startActivity(new Intent("com.android.settings.TTS_SETTINGS"));
                    } catch (Exception e) {
                        try {
                            startActivity(new Intent("android.settings.SETTINGS"));
                        } catch (Exception e2) {
                            Toast.makeText(MainActivity.this, "باز کردن تنظیمات ممکن نشد", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            });
        }

        @JavascriptInterface
        public void installTtsData() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        startActivity(new Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA));
                    } catch (Exception e) {
                        openTtsSettings();
                    }
                }
            });
        }

        @JavascriptInterface
        public void ttsStart(String jsonSegs, int startIdx, float rate, float pitch) {
            ArrayList<Seg> list = new ArrayList<>();
            try {
                JSONArray arr = new JSONArray(jsonSegs);
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    Seg sg = new Seg();
                    sg.page = o.optInt("p");
                    sg.s = o.optInt("s");
                    sg.e = o.optInt("e");
                    sg.lang = TtsLang.norm(o.optString("l", "en"));
                    sg.text = o.optString("t", "");
                    list.add(sg);
                }
            } catch (Exception e) {
                synchronized (ttsLock) {
                    emit("error", 0, "parse");
                }
                return;
            }
            synchronized (ttsLock) {
                segs = list;
                order = new int[0];
                ttsRate = Math.max(0.3f, Math.min(3.0f, rate));
                ttsPitch = Math.max(0.5f, Math.min(2.0f, pitch));
                startAt(startIdx);
            }
        }

        @JavascriptInterface
        public void ttsPause() {
            MainActivity.this.ttsPause();
        }

        @JavascriptInterface
        public void ttsResume() {
            synchronized (ttsLock) {
                if ("paused".equals(ttsState) && segs.size() > 0) {
                    startAt(pausedIdx);
                }
            }
        }

        @JavascriptInterface
        public void ttsStop() {
            synchronized (ttsLock) {
                ttsGen++;
                ttsAfterInit = null;
                stopEngineQuiet();
                releaseResources();
                lastSegIdx = -1;
                setState("idle");
            }
        }

        @JavascriptInterface
        public void ttsSeek(int idx) {
            synchronized (ttsLock) {
                if (segs.size() == 0) {
                    return;
                }
                startAt(Math.max(0, Math.min(segs.size() - 1, idx)));
            }
        }

        @JavascriptInterface
        public void ttsSet(float rate, float pitch) {
            synchronized (ttsLock) {
                ttsRate = Math.max(0.3f, Math.min(3.0f, rate));
                ttsPitch = Math.max(0.5f, Math.min(2.0f, pitch));
                if ("playing".equals(ttsState) && lastSegIdx >= 0) {
                    startAt(lastSegIdx);
                }
            }
        }

        @JavascriptInterface
        public void haptic() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (web != null) {
                        web.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
                    }
                }
            });
        }

        @JavascriptInterface
        public void vsConfigure(String json) {
            try {
                JSONObject o = new JSONObject(json);
                vsEnabled = o.optBoolean("enabled", false);
                vsUrl = o.optString("url", "").trim();
                vsApiKey = o.optString("apiKey", "").trim();
                vsModel = o.optString("model", "omnivoice").trim();
                vsVoice = o.optString("voice", "default").trim();
                vsInstruct = o.optString("instruct", "").trim();
                vsFallback = o.optBoolean("fallback", true);
            } catch (Exception ignored) {
            }
        }

        @JavascriptInterface
        public void vsListVoices(final String id) {
            if (id == null || !id.matches("[A-Za-z0-9_]{1,40}")) {
                return;
            }
            netPool.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        String resp = vsClient.getJson(vsUrl, "/v1/audio/voices", vsApiKey);
                        String b64 = Base64.encodeToString(resp.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
                        callJs("window.onVsVoices&&window.onVsVoices('" + id + "',200,'" + b64 + "')");
                    } catch (Exception e) {
                        callJs("window.onVsVoices&&window.onVsVoices('" + id + "',0,'')");
                    }
                }
            });
        }

        @JavascriptInterface
        public void vsTest(final String id) {
            if (id == null || !id.matches("[A-Za-z0-9_]{1,40}")) {
                return;
            }
            netPool.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        String resp = vsClient.getJson(vsUrl, "/v1/models", vsApiKey);
                        String b64 = Base64.encodeToString(resp.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
                        callJs("window.onVsTest&&window.onVsTest('" + id + "',200,'" + b64 + "')");
                    } catch (Exception e) {
                        callJs("window.onVsTest&&window.onVsTest('" + id + "',0,'')");
                    }
                }
            });
        }

        @JavascriptInterface
        public String ttsState() {
            synchronized (ttsLock) {
                return ttsState + "|" + lastSegIdx;
            }
        }
    }
}
